"""
utils/formatter.py — вспомогательные функции форматирования.

  escape_mdv2(text)           — экранирование для MarkdownV2
  format_datetime(dt, fmt)    — дата/время в читаемый вид
  truncate(text, limit)       — обрезка до лимита Telegram (4096)
  format_list(items, bullet)  — список с маркерами
  format_header(title, char)  — заголовок с декоративной линией
  format_separator(width, char) — горизонтальный разделитель
"""
from __future__ import annotations

import re
from datetime import datetime

# Все спецсимволы MarkdownV2, которые нужно экранировать
_MDV2_ESCAPE_RE = re.compile(r"([_*\[\]()~`>#+=|{}.!\\-])")

TELEGRAM_MSG_LIMIT = 4096


def escape_mdv2(text: str) -> str:
    """
    Экранирует все спецсимволы Telegram MarkdownV2.
    Используйте перед отправкой строк с parse_mode=MarkdownV2.
    """
    return _MDV2_ESCAPE_RE.sub(r"\\\1", text)


def format_datetime(dt: datetime, fmt: str = "%d.%m.%Y %H:%M") -> str:
    """Форматирует datetime в читаемую строку. Дефолт: ДД.ММ.ГГГГ ЧЧ:ММ"""
    return dt.strftime(fmt)


def truncate(text: str, limit: int = TELEGRAM_MSG_LIMIT) -> str:
    """
    Обрезает текст до указанного лимита.
    Добавляет «…» если текст был обрезан.
    """
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def format_list(items: list[str], bullet: str = "•") -> str:
    """Форматирует список строк с маркером. Пустой список → пустая строка."""
    if not items:
        return ""
    return "\n".join(f"{bullet} {item}" for item in items)


def format_header(title: str, char: str = "═") -> str:
    """
    Обрамляет заголовок декоративными линиями.
    Пример:
      ════════════
      Мой заголовок
      ════════════
    """
    line = char * len(title)
    return f"{line}\n{title}\n{line}"


def format_separator(width: int = 28, char: str = "─") -> str:
    """Возвращает горизонтальный разделитель заданной ширины."""
    return char * width