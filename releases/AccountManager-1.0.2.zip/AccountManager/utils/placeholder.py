"""
utils/placeholder.py — глобальные плейсхолдеры.

Доступны всем плагинам. Плагины определяют свои плейсхолдеры
локально, не добавляя их сюда.

Использование:
  from utils.placeholder import resolve
  text = resolve("Привет, {name}!", message.from_user)
"""
from __future__ import annotations

from aiogram.types import User


def resolve(template: str, user: User) -> str:
    """
    Заменяет глобальные плейсхолдеры в шаблоне.

    {user_name} — Имя Фамилия (full_name из Telegram)
    {username}  — @username или пустая строка если не задан
    {name}      — только имя (first_name)
    {user_id}   — числовой Telegram ID
    """
    full_name: str = user.full_name  # aiogram сам собирает "First Last"
    username: str = f"@{user.username}" if user.username else ""
    first_name: str = user.first_name or ""
    user_id: str = str(user.id)

    return (
        template
        .replace("{user_name}", full_name)
        .replace("{username}", username)
        .replace("{name}", first_name)
        .replace("{user_id}", user_id)
    )