#!/usr/bin/env python3
"""
framework_manager.py — Менеджер Фреймворка AccountManager.

Этот файл — тонкая обёртка над core/framework_manager.py.
Всё реальное CLI-поведение живёт там; здесь — только:
  1. Обнаружение PROJECT_ROOT и chdir в него (как делал исходный файл).
  2. Перехват флага --tui ПЕРЕД argparse, чтобы открыть TUI-меню
     вместо передачи в субкоманды.
  3. Вызов core.framework_manager.main() для всего остального.

Использование:
  python framework_manager.py --tui          # TUI-меню (curses, fallback на текст)
  python framework_manager.py status         # обычные CLI-команды
  python framework_manager.py info
  python framework_manager.py hash --generate
  python framework_manager.py test
  python framework_manager.py deps --install
  python framework_manager.py install --yes <source>
  python framework_manager.py --help
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def _find_project_root(start: Path) -> Path:
    """
    Находит корень проекта (где есть main.py И core/__init__.py).
    Дублируется из core/framework_manager.py намеренно: этот файл должен
    уметь найти корень ДО того, как core/ добавлен в sys.path.
    """
    for candidate in (start, *start.parents):
        if (candidate / "main.py").exists() and (candidate / "core" / "__init__.py").exists():
            return candidate
    return start


_PROJECT_ROOT = _find_project_root(Path(__file__).resolve().parent)
os.chdir(_PROJECT_ROOT)
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))


def main() -> int:
    # --tui перехватываем ДО argparse — он не является субкомандой
    # и argparse не знает о нём (флаг не нужно добавлять в build_parser).
    if "--tui" in sys.argv:
        from core.tui import launch_tui
        launch_tui()
        return 0

    from core.framework_manager import main as _core_main
    return _core_main()


if __name__ == "__main__":
    sys.exit(main())
