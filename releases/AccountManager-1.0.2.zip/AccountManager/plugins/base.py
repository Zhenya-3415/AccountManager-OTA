"""
plugins/base.py — базовый класс для всех плагинов.

Каждый плагин:
  1. Наследует BasePlugin.
  2. Реализует абстрактные свойства name и version.
  3. Реализует async setup(ctx) — регистрирует Router в Dispatcher,
     при необходимости подписывается на события ядра (ctx.on_hook),
     патчит ядро (ctx.patch_around/before/after/replace) и публикует
     свои сервисы для других плагинов (ctx.provide_service).
  4. Опционально переопределяет async teardown() для освобождения
     ресурсов — hooks/patches/services плагина откатываются
     автоматически, руками снимать их в teardown() не нужно.

Если в plugin.py несколько подклассов BasePlugin (например, есть
вспомогательные базовые классы для нескольких похожих плагинов) —
укажите явно, какой из них грузить:

    PLUGIN = MyActualPluginClass

Без этой строки загрузчик берёт единственный найденный в модуле
конкретный подкласс BasePlugin; если их несколько — это ошибка
конфигурации, а не «повезёт с алфавитным порядком», как было раньше.

manifest.json → dependencies.pip / dependencies.plugins принимают
условие версии в формате PEP 440 (см. core/dependencies.py):

    "pip": ["aiogram>=3.15,<4.0"]
    "plugins": ["antispam>=1.0.0"]

Строка без условия ("aiogram", "antispam") по-прежнему означает
«любая версия», как раньше. Плагин с неудовлетворённой версией (или
отсутствующей зависимостью) не грузится, а PluginLoader.check_pip_deps()
дополнительно логирует сводку, если разные плагины требуют разные,
несовместимые версии ОДНОЙ и той же pip-библиотеки.
"""
from __future__ import annotations

from abc import ABC, abstractmethod

from core.plugin_context import PluginContext


class BasePlugin(ABC):

    @property
    @abstractmethod
    def name(self) -> str:
        """Имя плагина — должно совпадать с manifest.json → name."""
        ...

    @property
    @abstractmethod
    def version(self) -> str:
        """Версия плагина — должна совпадать с manifest.json → version."""
        ...

    @abstractmethod
    async def setup(self, ctx: PluginContext) -> None:
        """
        Точка входа плагина. Обязателен.

        ctx.dp / ctx.bot / ctx.db / ctx.config — как раньше.
        ctx.on_hook(event, handler) — подписка на события ядра/других
            плагинов (core/hooks.py).
        ctx.patch_around/before/after/replace(target, attr, ...) —
            управляемый патч ядра (core/patches.py).
        ctx.provide_service(name, value) / ctx.require_service(name) —
            публикация/получение API других плагинов (core/services.py).

        Создайте Router, зарегистрируйте хендлеры,
        подключите через ctx.dp.include_router(router).
        """
        ...

    async def teardown(self) -> None:
        """
        Вызывается при остановке бота (или при reload_plugin) в порядке,
        обратном setup(). Опционален — базовая реализация ничего не
        делает. Освобождайте здесь СВОИ ресурсы (фоновые задачи, файловые
        хендлеры, соединения к внешним сервисам) — hooks/patches/services,
        зарегистрированные через ctx, PluginLoader снимает сам.
        """
        pass
