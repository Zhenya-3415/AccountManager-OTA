#!/usr/bin/env python3
"""
scripts/sign_plugin.py — подпись плагина приватным ключом Ed25519.

Что делает:
  1. Вычисляет sha256 всех файлов плагина (*.py + manifest.json)
  2. Записывает хеш в plugins/<name>/manifest.json → sha256_hash
  3. Создаёт подпись: plugins/<name>/manifest.json.sig

Использование:
  python scripts/sign_plugin.py plugins/antispam/
  python scripts/sign_plugin.py plugins/antispam/ --key configs/keys/private.pem
  python scripts/sign_plugin.py plugins/  --all   # подписать все плагины

Требует: cryptography>=42.0, configs/keys/private.pem
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_KEYS_DIR    = Path("configs") / "keys"
_PRIVATE_KEY = _KEYS_DIR / "private.pem"


def _sign_one(plugin_dir: Path, private_key_path: Path) -> None:
    """Подписывает один плагин. Обновляет manifest.json и создаёт .sig."""
    try:
        from cryptography.hazmat.primitives.serialization import load_pem_private_key
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError:
        print("Ошибка: cryptography не установлена.")
        print("  pip install cryptography>=42.0 --break-system-packages")
        sys.exit(1)

    if not private_key_path.exists():
        print(f"Приватный ключ не найден: {private_key_path}")
        print("Создайте пару ключей: python scripts/generate_keys.py")
        sys.exit(1)

    manifest_path = plugin_dir / "manifest.json"
    if not manifest_path.exists():
        print(f"⚠ Нет manifest.json в {plugin_dir} — пропускаю.")
        return

    # Загружаем ключ
    key = load_pem_private_key(private_key_path.read_bytes(), password=None)
    if not isinstance(key, Ed25519PrivateKey):
        print(f"Ключ в {private_key_path} не является Ed25519.")
        sys.exit(1)

    # Импортируем верификатор для хеширования
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from core.plugin_verifier import compute_plugin_hash, iter_plugin_files

    files = iter_plugin_files(plugin_dir)
    plugin_hash = compute_plugin_hash(plugin_dir)

    # Обновляем sha256_hash в manifest.json
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"Ошибка чтения manifest.json: {exc}")
        sys.exit(1)

    manifest["sha256_hash"] = plugin_hash
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    # Создаём подпись над hash-строкой (те же байты что проверяет verify_plugin)
    sig = key.sign(plugin_hash.encode("utf-8"))
    sig_path = plugin_dir / "manifest.json.sig"
    sig_path.write_bytes(sig)

    print(f"✓ {plugin_dir.name}/")
    print(f"  sha256_hash: {plugin_hash}")
    print(f"  Подписано:   {sig_path}  ({len(files)} файлов)")


def main() -> int:
    p = argparse.ArgumentParser(
        description="Ed25519-подпись плагина AccountManager Framework."
    )
    p.add_argument("plugin", help="путь к папке плагина (или plugins/ с --all)")
    p.add_argument("--key", default=str(_PRIVATE_KEY),
                   help=f"приватный ключ (по умолчанию: {_PRIVATE_KEY})")
    p.add_argument("--all", action="store_true",
                   help="подписать все плагины в указанной папке")
    args = p.parse_args()

    key_path    = Path(args.key)
    plugin_path = Path(args.plugin)

    if args.all:
        if not plugin_path.is_dir():
            print(f"Папка не найдена: {plugin_path}")
            return 1
        plugins = [d for d in plugin_path.iterdir()
                   if d.is_dir() and (d / "manifest.json").exists()]
        if not plugins:
            print(f"Плагины не найдены в {plugin_path}/")
            return 0
        for plugin_dir in sorted(plugins):
            _sign_one(plugin_dir, key_path)
        return 0

    if not plugin_path.is_dir():
        print(f"Папка плагина не найдена: {plugin_path}")
        return 1

    _sign_one(plugin_path, key_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
