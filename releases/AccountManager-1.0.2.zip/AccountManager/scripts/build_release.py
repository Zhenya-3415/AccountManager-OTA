#!/usr/bin/env python3
"""
scripts/build_release.py — сборка и подпись OTA-релиза.

Что делает:
  1. Читает версию из manifest_core.json
  2. Генерирует sha256_hash в manifest_core.json (если не задан / --rehash)
  3. Упаковывает core/, plugins/base.py, main.py, framework_manager.py,
     manifest_core.json в framework.zip
  4. Подписывает framework.zip → framework.zip.sig (Ed25519)
  5. Вычисляет sha256 zip-файла (для releases.json)
  6. Создаёт / обновляет releases/<version>/ в dist-директории
  7. Обновляет releases.json

Использование (из корня проекта):
  python scripts/build_release.py \
      --channel stable \
      --description "Исправления и улучшения" \
      --dist /path/to/AccountManager-OTA/

  python scripts/build_release.py --channel nightly --rehash

Требует: cryptography>=42.0
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from datetime import date
from pathlib import Path

KEYS_DIR    = Path("configs") / "keys"
PRIVATE_KEY = KEYS_DIR / "private.pem"

_PACK_DIRS  = ("core", "plugins")
_PACK_FILES = ("main.py", "framework_manager.py", "manifest_core.json")


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while chunk := fh.read(65536):
            h.update(chunk)
    return h.hexdigest()


def build_zip(src_root: Path, dest_zip: Path) -> int:
    """Упаковывает файлы сборки. Возвращает кол-во файлов."""
    count = 0
    with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for d in _PACK_DIRS:
            for p in (src_root / d).rglob("*"):
                if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc":
                    zf.write(p, p.relative_to(src_root))
                    count += 1
        for f in _PACK_FILES:
            p = src_root / f
            if p.is_file():
                zf.write(p, f)
                count += 1
    return count


def sign_zip(zip_path: Path, sig_path: Path) -> None:
    """Ed25519-подписывает zip_path → sig_path."""
    try:
        from cryptography.hazmat.primitives.serialization import load_pem_private_key
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError:
        print("Ошибка: cryptography не установлена. pip install cryptography>=42.0")
        sys.exit(1)

    if not PRIVATE_KEY.exists():
        print(f"Приватный ключ не найден: {PRIVATE_KEY}")
        print("Запустите: python scripts/generate_keys.py")
        sys.exit(1)

    pem  = PRIVATE_KEY.read_bytes()
    key  = load_pem_private_key(pem, password=None)
    if not isinstance(key, Ed25519PrivateKey):
        print(f"Ключ в {PRIVATE_KEY} не является Ed25519.")
        sys.exit(1)

    sig = key.sign(zip_path.read_bytes())
    sig_path.write_bytes(sig)


def update_releases_json(releases_json: Path, entry: dict, channel: str) -> None:
    """Добавляет / обновляет запись релиза в releases.json."""
    data: dict = {"channel": channel, "releases": []}
    if releases_json.exists():
        try:
            data = json.loads(releases_json.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass

    releases = data.get("releases", [])
    # Заменяем если версия уже есть
    releases = [r for r in releases if r.get("version") != entry["version"]]
    releases.append(entry)
    # Сортируем по версии (новые сначала)
    try:
        from packaging.version import Version
        releases.sort(key=lambda r: Version(r.get("version", "0")), reverse=True)
    except (ImportError, Exception):
        pass

    data["channel"]  = channel
    data["latest"]   = releases[0]["version"] if releases else ""
    data["releases"] = releases

    releases_json.write_text(
        json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


def main() -> int:
    p = argparse.ArgumentParser(description="Сборка OTA-релиза AccountManager Framework.")
    p.add_argument("--channel",     required=True, choices=["stable", "beta", "nightly"])
    p.add_argument("--description", default="")
    p.add_argument("--dist",        default="dist",
                   help="путь к OTA-репозиторию (локально)")
    p.add_argument("--rehash",      action="store_true",
                   help="пересчитать sha256_hash в manifest_core.json перед упаковкой")
    p.add_argument("--min-python",  default="",
                   help="минимальная версия Python (по умолчанию из manifest_core.json → min_python)")
    p.add_argument("--skip-sign",   action="store_true",
                   help="пропустить подпись (для тестирования без private.pem)")
    args = p.parse_args()

    src_root = Path(".")
    manifest_path = src_root / "manifest_core.json"

    if not manifest_path.exists():
        print("manifest_core.json не найден в текущей директории.")
        return 1

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    # Пересчёт хеша
    if args.rehash or not manifest.get("sha256_hash"):
        from core.manifest import compute_source_hash
        h = compute_source_hash(src_root)
        manifest["sha256_hash"] = h
        manifest_path.write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        print(f"✓ sha256_hash обновлён: {h}")

    version = str(manifest.get("version", "")).strip()
    if not version:
        print("manifest_core.json → version не задан.")
        return 1

    min_python = args.min_python.strip() or manifest.get("min_python", "3.10")

    dist      = Path(args.dist)
    ver_dir   = dist / args.channel / "releases" / version
    ver_dir.mkdir(parents=True, exist_ok=True)

    # Упаковка
    zip_path = ver_dir / "framework.zip"
    print(f"Упаковываю → {zip_path}")
    n = build_zip(src_root, zip_path)
    print(f"✓ {n} файлов упаковано.")

    # Подпись
    sig_path = ver_dir / "framework.zip.sig"
    if not args.skip_sign:
        print(f"Подписываю → {sig_path}")
        sign_zip(zip_path, sig_path)
        print("✓ Подпись создана.")
    else:
        sig_path.write_bytes(b"UNSIGNED")
        print("⚠ Подпись пропущена (--skip-sign).")

    # Копируем manifest_core.json
    (ver_dir / "manifest_core.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    # sha256 zip
    zip_sha256 = _sha256_file(zip_path)
    print(f"✓ sha256(zip): {zip_sha256}")

    # releases.json
    releases_json = dist / args.channel / "releases.json"
    # GitHub raw URL placeholder — разработчик вписывает свой repo
    ota_repo = str(manifest.get("ota_repository", "")).rstrip("/")
    raw_base = ota_repo.replace("github.com", "raw.githubusercontent.com") if ota_repo else ""

    entry = {
        "version":      version,
        "date":         date.today().isoformat(),
        "description":  args.description or f"Релиз {version}",
        "zip_url":      f"{raw_base}/{args.channel}/releases/{version}/framework.zip",
        "sig_url":      f"{raw_base}/{args.channel}/releases/{version}/framework.zip.sig",
        "manifest_url": f"{raw_base}/{args.channel}/releases/{version}/manifest_core.json",
        "sha256":       zip_sha256,
        "min_python":   min_python,
        "channel":      args.channel,
    }
    update_releases_json(releases_json, entry, args.channel)
    print(f"✓ releases.json обновлён: {releases_json}")
    print()
    print(f"Готово! Релиз {version} [{args.channel}]")
    print(f"  {ver_dir}/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
