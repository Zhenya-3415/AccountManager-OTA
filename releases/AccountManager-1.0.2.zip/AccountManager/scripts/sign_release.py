#!/usr/bin/env python3
"""
scripts/sign_release.py — подпись уже готового framework.zip.

Используется когда zip уже собран (например, CI собрал его отдельно)
и нужно только подписать. Для полного цикла (сборка + подпись + releases.json)
используйте scripts/build_release.py.

Использование:
  python scripts/sign_release.py releases/1.0.1/framework.zip
  python scripts/sign_release.py releases/1.0.1/framework.zip --key configs/keys/private.pem

Требует: cryptography>=42.0
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

KEYS_DIR    = Path("configs") / "keys"
PRIVATE_KEY = KEYS_DIR / "private.pem"


def sign_file(zip_path: Path, private_key_path: Path, sig_path: Path) -> None:
    try:
        from cryptography.hazmat.primitives.serialization import load_pem_private_key
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError:
        print("Ошибка: cryptography не установлена.")
        print("  pip install cryptography>=42.0 --break-system-packages")
        sys.exit(1)

    if not private_key_path.exists():
        print(f"Приватный ключ не найден: {private_key_path}")
        print("Запустите: python scripts/generate_keys.py")
        sys.exit(1)

    if not zip_path.exists():
        print(f"Файл не найден: {zip_path}")
        sys.exit(1)

    pem = private_key_path.read_bytes()
    key = load_pem_private_key(pem, password=None)

    if not isinstance(key, Ed25519PrivateKey):
        print(f"Ключ в {private_key_path} не является Ed25519.")
        sys.exit(1)

    data = zip_path.read_bytes()
    sig  = key.sign(data)
    sig_path.write_bytes(sig)

    import hashlib
    sha = hashlib.sha256(data).hexdigest()
    print(f"✓ Подпись создана: {sig_path}")
    print(f"  sha256(zip):  {sha}")
    print(f"  Добавьте это значение в releases.json → sha256.")


def main() -> int:
    p = argparse.ArgumentParser(
        description="Ed25519-подпись framework.zip для OTA-релиза."
    )
    p.add_argument("zip",  help="путь к framework.zip")
    p.add_argument("--key", default=str(PRIVATE_KEY),
                   help=f"путь к private.pem (по умолчанию: {PRIVATE_KEY})")
    p.add_argument("--out", default="",
                   help="путь к .sig файлу (по умолчанию: <zip>.sig)")
    args = p.parse_args()

    zip_path  = Path(args.zip)
    key_path  = Path(args.key)
    sig_path  = Path(args.out) if args.out else zip_path.with_suffix(".zip.sig")

    sign_file(zip_path, key_path, sig_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
