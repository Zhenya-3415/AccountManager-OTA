#!/usr/bin/env python3
"""
scripts/generate_keys.py — генерация пары Ed25519-ключей для OTA-подписи.

Создаёт:
  configs/keys/public.pem   — публичный ключ (коммитится в репо)
  configs/keys/private.pem  — приватный ключ (GITIGNORED, только локально)

Запускать ОДИН РАЗ от имени разработчика. Если ключи уже есть —
требует явного флага --force.

Требует: cryptography>=42.0
  pip install cryptography --break-system-packages
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

KEYS_DIR   = Path("configs") / "keys"
PUBLIC_KEY = KEYS_DIR / "public.pem"
PRIVATE_KEY = KEYS_DIR / "private.pem"
GITIGNORE  = KEYS_DIR / ".gitignore"


def main() -> int:
    parser = argparse.ArgumentParser(description="Генерация Ed25519-ключей для OTA-подписи.")
    parser.add_argument("--force", action="store_true", help="перезаписать существующие ключи")
    args = parser.parse_args()

    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives.serialization import (
            Encoding, PublicFormat, PrivateFormat, NoEncryption,
        )
    except ImportError:
        print("Ошибка: библиотека cryptography не установлена.")
        print("  pip install cryptography>=42.0 --break-system-packages")
        return 1

    if (PUBLIC_KEY.exists() or PRIVATE_KEY.exists()) and not args.force:
        print(f"Ключи уже существуют в {KEYS_DIR}.")
        print("Используйте --force для перезаписи.")
        return 1

    KEYS_DIR.mkdir(parents=True, exist_ok=True)

    private_key = Ed25519PrivateKey.generate()
    public_key  = private_key.public_key()

    PRIVATE_KEY.write_bytes(
        private_key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption())
    )
    PUBLIC_KEY.write_bytes(
        public_key.public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo)
    )

    # .gitignore чтобы private.pem НИКОГДА не попал в репо
    if not GITIGNORE.exists():
        GITIGNORE.write_text("private.pem\n", encoding="utf-8")

    print(f"✓ Ключи сгенерированы:")
    print(f"  PUBLIC:  {PUBLIC_KEY}  ← коммитить в репо")
    print(f"  PRIVATE: {PRIVATE_KEY}  ← НИКОГДА не коммитить, хранить в безопасном месте")
    print()
    print("Публичный ключ (добавьте в репо):")
    print(PUBLIC_KEY.read_text())
    return 0


if __name__ == "__main__":
    sys.exit(main())
