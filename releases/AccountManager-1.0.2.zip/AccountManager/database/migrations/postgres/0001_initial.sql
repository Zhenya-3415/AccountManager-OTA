-- Postgres-версия database/migrations/0001_initial.sql.
--
-- Единственное реальное отличие от SQLite-варианта: user_id — BIGINT,
-- не INTEGER. SQLite INTEGER PRIMARY KEY хранит целое произвольного
-- размера (до 8 байт) без каких-либо усилий; Postgres INTEGER — ровно
-- 4 байта (максимум 2 147 483 647). Telegram user_id уже превышает эту
-- границу у части аккаунтов — с обычным INTEGER здесь запись такого
-- пользователя падала бы с "integer out of range" при первом же апдейте
-- от него. См. core/db/migrations.py за тем, почему это НЕ переводится
-- автоматически из SQLite-варианта, а поддерживается отдельным файлом.
CREATE TABLE IF NOT EXISTS users (
    user_id BIGINT PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    last_name TEXT,
    language_code TEXT,
    last_seen_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
