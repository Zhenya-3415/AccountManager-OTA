"""
tests/test_framework_manager.py — core/framework_manager.py: CLI-обвязка
управления плагинами (status/restart/install/uninstall/lock/unlock/
verify/update).

ВАЖНО про импорт этого модуля: core/framework_manager.py на уровне
модуля делает
    PROJECT_ROOT = Path(__file__).resolve().parent
    os.chdir(PROJECT_ROOT)
Поскольку __file__ для core/framework_manager.py — это сам core/, а не
корень проекта, PROJECT_ROOT здесь указывает на core/, а не туда,
где реально лежат plugins/, run/control.json и т.п. — это
задокументировано отдельным тестом ниже
(ProjectRootBugTests.test_project_root_incorrectly_resolves_to_core_dir).
Для ВСЕХ остальных тестов PROJECT_ROOT/DEFAULT_CATALOG_PATH/STAGING_DIR
патчатся напрямую на контролируемые tmp-каталоги — это единственный
надёжный способ тестировать ЛОГИКУ команд независимо от того, куда
реально указывают эти константы.

Импорт модуля производит chdir как побочный эффект — CWD процесса
сохраняется до импорта и немедленно восстанавливается после, чтобы не
"заразить" остальные тестовые файлы, запущенные в том же процессе
(discover запускает все файлы в одном процессе).
"""
from __future__ import annotations

import argparse
import asyncio
import io
import json
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import AsyncMock, patch

from tests._support import env

env.ensure_aiosqlite()

_cwd_before_import = os.getcwd()
import core.framework_manager as pm  # noqa: E402
os.chdir(_cwd_before_import)  # нейтрализуем побочный эффект импорта -- см. докстринг выше

from core.plugin_installer import InstallResult, PluginInstallError, UpdateCheckResult  # noqa: E402


def run_cmd(func, **kwargs) -> tuple[int, str]:
    """Строит argparse.Namespace из kwargs, запускает func, ловит stdout."""
    ns = argparse.Namespace(**kwargs)
    buf = io.StringIO()
    with redirect_stdout(buf):
        code = func(ns)
    return code, buf.getvalue()


class ProjectRootTests(unittest.TestCase):
    def test_project_root_now_correctly_resolves_to_the_real_project_root(self) -> None:
        """
        Раньше core/framework_manager.py вычислял PROJECT_ROOT как папку
        САМОГО СЕБЯ (core/), а не корень проекта — все относительные
        пути (plugins/, run/control.json, plugin_list.json,
        downloaded_updates/) указывали бы не туда, запусти это кто-то
        реально с его собственного пути. Теперь PROJECT_ROOT находится
        поиском вверх по дереву до папки, где лежат main.py И
        core/__init__.py одновременно — независимо от того, где
        физически лежит сам этот файл.
        """
        self.assertNotEqual(pm.PROJECT_ROOT.name, "core")
        self.assertTrue((pm.PROJECT_ROOT / "main.py").exists())
        self.assertTrue((pm.PROJECT_ROOT / "core" / "__init__.py").exists())
        real_top_level_script = pm.PROJECT_ROOT / "framework_manager.py"
        self.assertTrue(real_top_level_script.exists())

    def test_top_level_framework_manager_delegates_to_core(self) -> None:
        """
        framework_manager.py (корневой) — тонкая обёртка над
        core/framework_manager.py. Вся реальная логика (build_static_loader,
        scheduler-wiring, субкоманды) живёт ИСКЛЮЧИТЕЛЬНО в core/.
        Тест проверяет, что обёртка правильно делегирует core-реализацию,
        а не дублирует её. Прежняя проверка на «оба файла содержат одни
        и те же строки с scheduler=Scheduler()» утратила смысл: если бы
        обёртка дублировала Scheduler-wiring — это был бы регресс,
        а не признак синхронизации.
        """
        top_level_src = (pm.PROJECT_ROOT / "framework_manager.py").read_text(encoding="utf-8")
        # Обёртка вызывает core.framework_manager.main — не повторяет код
        self.assertIn("from core.framework_manager import main", top_level_src)
        # Планировщик живёт в core, НЕ дублируется в обёртке
        core_src = (pm.PROJECT_ROOT / "core" / "framework_manager.py").read_text(encoding="utf-8")
        self.assertIn("from core.scheduler import Scheduler", core_src)
        self.assertIn("scheduler=Scheduler()", core_src)


class PluginManagerTestCase(unittest.TestCase):
    """Общий setUp: свежий tmp-каталог, PROJECT_ROOT/DEFAULT_CATALOG_PATH/STAGING_DIR патчатся сюда."""

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.plugins_dir = self.root / "plugins"
        self.plugins_dir.mkdir()
        self.catalog_path = self.root / "plugin_list.json"
        self.staging_dir = self.root / "downloaded_updates"

        for attr, value in (
            ("PROJECT_ROOT", self.root),
            ("DEFAULT_CATALOG_PATH", self.catalog_path),
            ("STAGING_DIR", self.staging_dir),
        ):
            p = patch.object(pm, attr, value)
            p.start()
            self.addCleanup(p.stop)

    def write_plugin(self, folder: str, *, name: str | None = None, version: str = "1.0.0", extra: dict | None = None) -> Path:
        d = self.plugins_dir / folder
        d.mkdir(parents=True, exist_ok=True)
        manifest = {"name": name or folder, "version": version, **(extra or {})}
        (d / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        (d / "plugin.py").write_text(
            "from plugins.base import BasePlugin\n"
            "class P(BasePlugin):\n"
            "    @property\n"
            "    def name(self): return 'p'\n"
            "    @property\n"
            "    def version(self): return '1.0.0'\n"
            "    async def setup(self, ctx): pass\n",
            encoding="utf-8",
        )
        return d


class BuildParserTests(unittest.TestCase):
    def test_all_subcommands_registered(self) -> None:
        parser = pm.build_parser()
        sub_actions = [a for a in parser._actions if isinstance(a, argparse._SubParsersAction)]
        self.assertEqual(len(sub_actions), 1)
        self.assertEqual(
            set(sub_actions[0].choices.keys()),
            {"status", "restart", "install", "uninstall", "lock", "unlock", "verify", "update",
             "info", "hash", "test", "deps", "ota"},
        )

    def test_status_parses_name_and_filter(self) -> None:
        args = pm.build_parser().parse_args(["status", "--name", "antispam", "--filter", "running"])
        self.assertEqual(args.name, "antispam")
        self.assertEqual(args.filter, "running")
        self.assertIs(args.func, pm.cmd_status)

    def test_status_filter_rejects_invalid_choice(self) -> None:
        with self.assertRaises(SystemExit):
            pm.build_parser().parse_args(["status", "--filter", "not-a-real-choice"])

    def test_restart_name_and_all_are_mutually_exclusive(self) -> None:
        with self.assertRaises(SystemExit):
            pm.build_parser().parse_args(["restart", "somename", "--all"])

    def test_restart_no_args_is_valid(self) -> None:
        args = pm.build_parser().parse_args(["restart"])
        self.assertIsNone(args.name)
        self.assertFalse(args.all)

    def test_install_flags(self) -> None:
        args = pm.build_parser().parse_args([
            "install", "owner/repo", "--yes", "--ref", "dev", "--subdir", "sub", "--overwrite",
        ])
        self.assertEqual(args.source, "owner/repo")
        self.assertTrue(args.yes)
        self.assertEqual(args.ref, "dev")
        self.assertEqual(args.subdir, "sub")
        self.assertTrue(args.overwrite)

    def test_update_noconfirm_has_short_alias(self) -> None:
        args = pm.build_parser().parse_args(["update", "-y"])
        self.assertTrue(args.noconfirm)

    def test_no_command_is_required(self) -> None:
        with self.assertRaises(SystemExit):
            pm.build_parser().parse_args([])


class LoadCatalogTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "catalog.json"

    def test_missing_file_returns_empty_list(self) -> None:
        result = pm.load_catalog(self.path)
        self.assertEqual(result, [])

    def test_malformed_json_returns_empty_list(self) -> None:
        self.path.write_text("{not valid", encoding="utf-8")
        result = pm.load_catalog(self.path)
        self.assertEqual(result, [])

    def test_valid_catalog_returns_plugins_list(self) -> None:
        self.path.write_text(json.dumps({"plugins": [{"name": "a"}, {"name": "b"}]}), encoding="utf-8")
        result = pm.load_catalog(self.path)
        self.assertEqual(result, [{"name": "a"}, {"name": "b"}])

    def test_missing_plugins_key_returns_empty_list(self) -> None:
        self.path.write_text(json.dumps({"other": []}), encoding="utf-8")
        self.assertEqual(pm.load_catalog(self.path), [])


class PromptMultiSelectTests(unittest.TestCase):
    def test_zero_cancels(self) -> None:
        with patch("builtins.input", return_value="0"):
            self.assertEqual(pm._prompt_multi_select(5), [])

    def test_empty_cancels(self) -> None:
        with patch("builtins.input", return_value=""):
            self.assertEqual(pm._prompt_multi_select(5), [])

    def test_cancel_word_english_and_russian(self) -> None:
        with patch("builtins.input", return_value="cancel"):
            self.assertEqual(pm._prompt_multi_select(5), [])
        with patch("builtins.input", return_value="отмена"):
            self.assertEqual(pm._prompt_multi_select(5), [])

    def test_all_selects_every_index(self) -> None:
        with patch("builtins.input", return_value="all"):
            self.assertEqual(pm._prompt_multi_select(3), [0, 1, 2])

    def test_comma_separated_selection(self) -> None:
        with patch("builtins.input", return_value="1,3"):
            self.assertEqual(pm._prompt_multi_select(5), [0, 2])

    def test_space_separated_selection(self) -> None:
        with patch("builtins.input", return_value="1 3"):
            self.assertEqual(pm._prompt_multi_select(5), [0, 2])

    def test_mixed_comma_and_space(self) -> None:
        with patch("builtins.input", return_value="1, 3  5"):
            self.assertEqual(pm._prompt_multi_select(5), [0, 2, 4])

    def test_out_of_range_number_cancels_entirely(self) -> None:
        with patch("builtins.input", return_value="1,99"):
            self.assertEqual(pm._prompt_multi_select(5), [])

    def test_non_numeric_token_cancels_entirely(self) -> None:
        with patch("builtins.input", return_value="1,abc"):
            self.assertEqual(pm._prompt_multi_select(5), [])

    def test_zero_as_one_of_several_tokens_is_out_of_range_not_global_cancel(self) -> None:
        # "0" в одиночку -- отмена, но как один из НЕСКОЛЬКИХ токенов
        # это просто "0" вне диапазона 1..count (не входит в спец-путь).
        with patch("builtins.input", return_value="0,1"):
            self.assertEqual(pm._prompt_multi_select(5), [])


class GetLiveBotInfoTests(unittest.TestCase):
    def test_no_control_file_returns_none(self) -> None:
        with patch("core.framework_manager.read_control_file", return_value=None):
            self.assertIsNone(pm.get_live_bot_info())

    def test_control_file_present_but_ping_refused_returns_none(self) -> None:
        with patch("core.framework_manager.read_control_file", return_value={"pid": 1, "port": 9999}), \
             patch("core.framework_manager.send_control_command", side_effect=ConnectionRefusedError):
            self.assertIsNone(pm.get_live_bot_info())

    def test_control_file_present_and_ping_ok_returns_info(self) -> None:
        info = {"pid": 1, "port": 9999}
        with patch("core.framework_manager.read_control_file", return_value=info), \
             patch("core.framework_manager.send_control_command", new=AsyncMock(return_value={"ok": True})):
            self.assertEqual(pm.get_live_bot_info(), info)

    def test_ping_response_not_ok_returns_none(self) -> None:
        info = {"pid": 1, "port": 9999}
        with patch("core.framework_manager.read_control_file", return_value=info), \
             patch("core.framework_manager.send_control_command", new=AsyncMock(return_value={"ok": False})):
            self.assertIsNone(pm.get_live_bot_info())

    def test_timeout_returns_none(self) -> None:
        info = {"pid": 1, "port": 9999}
        with patch("core.framework_manager.read_control_file", return_value=info), \
             patch("core.framework_manager.send_control_command", side_effect=asyncio.TimeoutError):
            self.assertIsNone(pm.get_live_bot_info())


class BuildStaticLoaderTests(PluginManagerTestCase):
    def test_wires_up_full_static_pipeline(self) -> None:
        self.write_plugin("p1", name="p1")
        loader = pm.build_static_loader()
        self.assertIn("p1", loader._records)
        self.assertIn("p1", loader._load_order)  # доказывает, что resolve_order() реально отработал


class CmdStatusTests(PluginManagerTestCase):
    def test_unknown_explicit_name_returns_one(self) -> None:
        with patch.object(pm, "get_live_bot_info", return_value=None):
            code, out = run_cmd(pm.cmd_status, name="ghost", filter=None)
        self.assertEqual(code, 1)
        self.assertIn("не найден", out)

    def test_lists_all_plugins_when_no_filter(self) -> None:
        self.write_plugin("p1", name="alpha", version="1.0.0")
        self.write_plugin("p2", name="beta", version="2.0.0", extra={"core_version": ">=999.0.0"})
        with patch.object(pm, "get_live_bot_info", return_value=None):
            code, out = run_cmd(pm.cmd_status, name=None, filter=None)
        self.assertEqual(code, 0)
        self.assertIn("alpha (1.0.0)", out)
        self.assertIn("beta (2.0.0)", out)
        self.assertIn("✗ пропущен", out)
        self.assertIn("✓ загружен", out)

    def test_filter_running_excludes_skipped(self) -> None:
        self.write_plugin("p1", name="alpha")
        self.write_plugin("p2", name="beta", extra={"core_version": ">=999.0.0"})
        with patch.object(pm, "get_live_bot_info", return_value=None):
            code, out = run_cmd(pm.cmd_status, name=None, filter="running")
        self.assertIn("alpha", out)
        self.assertNotIn("beta", out)

    def test_filter_skipped_excludes_running(self) -> None:
        self.write_plugin("p1", name="alpha")
        self.write_plugin("p2", name="beta", extra={"core_version": ">=999.0.0"})
        with patch.object(pm, "get_live_bot_info", return_value=None):
            code, out = run_cmd(pm.cmd_status, name=None, filter="skipped")
        self.assertNotIn("alpha (", out)
        self.assertIn("beta", out)

    def test_live_bot_shown_in_header(self) -> None:
        self.write_plugin("p1", name="alpha")
        with patch.object(pm, "get_live_bot_info", return_value={"pid": 4242, "port": 1}):
            code, out = run_cmd(pm.cmd_status, name=None, filter=None)
        self.assertIn("Бот запущен (pid 4242", out)


class CmdRestartTests(PluginManagerTestCase):
    def test_no_live_bot_returns_one(self) -> None:
        with patch.object(pm, "get_live_bot_info", return_value=None):
            code, out = run_cmd(pm.cmd_restart, name=None, all=False)
        self.assertEqual(code, 1)
        self.assertIn("не запущен", out)

    def test_unknown_explicit_name_returns_one(self) -> None:
        with patch.object(pm, "get_live_bot_info", return_value={"pid": 1, "port": 1}):
            code, out = run_cmd(pm.cmd_restart, name="ghost", all=False)
        self.assertEqual(code, 1)

    def test_single_explicit_name_success(self) -> None:
        self.write_plugin("p1", name="alpha")
        with patch.object(pm, "get_live_bot_info", return_value={"pid": 1, "port": 1}), \
             patch.object(pm, "send_control_command", new=AsyncMock(return_value={"ok": True})) as mock_send:
            code, out = run_cmd(pm.cmd_restart, name="alpha", all=False)
        self.assertEqual(code, 0)
        self.assertIn("✓", out)
        mock_send.assert_awaited_once_with(1, {"cmd": "reload", "plugin": "alpha"})

    def test_single_explicit_name_failure(self) -> None:
        self.write_plugin("p1", name="alpha")
        with patch.object(pm, "get_live_bot_info", return_value={"pid": 1, "port": 1}), \
             patch.object(pm, "send_control_command", new=AsyncMock(return_value={"ok": False, "reason": "bad"})):
            code, out = run_cmd(pm.cmd_restart, name="alpha", all=False)
        self.assertEqual(code, 1)
        self.assertIn("bad", out)

    def test_all_flag_sends_reload_all(self) -> None:
        self.write_plugin("p1", name="alpha")
        self.write_plugin("p2", name="beta")
        with patch.object(pm, "get_live_bot_info", return_value={"pid": 1, "port": 1}), \
             patch.object(
                 pm, "send_control_command",
                 new=AsyncMock(return_value={"ok": True, "results": {"alpha": True, "beta": True}}),
             ) as mock_send:
            code, out = run_cmd(pm.cmd_restart, name=None, all=True)
        self.assertEqual(code, 0)
        mock_send.assert_awaited_once_with(1, {"cmd": "reload_all"})

    def test_no_args_cancel_via_empty_menu_selection(self) -> None:
        self.write_plugin("p1", name="alpha")
        with patch.object(pm, "get_live_bot_info", return_value={"pid": 1, "port": 1}), \
             patch("builtins.input", return_value="0"):
            code, out = run_cmd(pm.cmd_restart, name=None, all=False)
        self.assertEqual(code, 0)
        self.assertIn("Отменено", out)


class CmdInstallTests(PluginManagerTestCase):
    def test_no_yes_flag_returns_one_without_installing(self) -> None:
        with patch("core.plugin_installer.install_from_local") as mock_install:
            code, out = run_cmd(pm.cmd_install, yes=False, source=None, file=None, ref=None, subdir=None, overwrite=False)
        self.assertEqual(code, 1)
        self.assertIn("--yes", out)
        mock_install.assert_not_called()

    def test_locked_blocks_install(self) -> None:
        with patch("core.lockfile.is_locked", return_value=True):
            code, out = run_cmd(
                pm.cmd_install, yes=True, source="antispam", file=None, ref=None, subdir=None, overwrite=False,
            )
        self.assertEqual(code, 1)
        self.assertIn("залочены", out)

    def test_explicit_existing_local_path_installs_locally(self) -> None:
        src = self.root / "local_plugin_src"
        src.mkdir()
        (src / "manifest.json").write_text(json.dumps({"name": "local1", "version": "1.0.0"}), encoding="utf-8")
        (src / "plugin.py").write_text("# x", encoding="utf-8")

        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None):
            code, out = run_cmd(
                pm.cmd_install, yes=True, source=str(src), file=None, ref=None, subdir=None, overwrite=False,
            )
        self.assertEqual(code, 0)
        self.assertTrue((self.plugins_dir / "local1").exists())

    def test_explicit_github_style_source_uses_github_installer(self) -> None:
        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("core.plugin_installer.install_from_github", return_value=InstallResult(
                 ok=True, name="antispam", message="ok", installed_path=self.plugins_dir / "antispam",
             )) as mock_gh:
            code, out = run_cmd(
                pm.cmd_install, yes=True, source="owner/antispam", file=None, ref="dev", subdir="sub", overwrite=True,
            )
        self.assertEqual(code, 0)
        mock_gh.assert_called_once_with(
            "owner/antispam", self.plugins_dir, ref="dev", subdir="sub", name_override=None, overwrite=True,
        )

    def test_source_not_local_not_github_not_in_catalog_returns_one(self) -> None:
        with patch("core.lockfile.is_locked", return_value=False):
            code, out = run_cmd(
                pm.cmd_install, yes=True, source="justaname", file=None, ref=None, subdir=None, overwrite=False,
            )
        self.assertEqual(code, 1)
        self.assertIn("не найден", out)

    def test_source_matched_in_catalog_by_name_uses_repository_url(self) -> None:
        self.catalog_path.write_text(json.dumps({
            "plugins": [{"name": "antispam", "repository_url": "https://github.com/owner/antispam"}],
        }), encoding="utf-8")
        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("core.plugin_installer.install_from_github", return_value=InstallResult(
                 ok=True, name="antispam", message="ok", installed_path=self.plugins_dir / "antispam",
             )) as mock_gh:
            code, out = run_cmd(
                pm.cmd_install, yes=True, source="antispam", file=None, ref=None, subdir=None, overwrite=False,
            )
        self.assertEqual(code, 0)
        mock_gh.assert_called_once_with(
            "https://github.com/owner/antispam", self.plugins_dir,
            ref=None, subdir="", name_override="antispam", overwrite=False,
        )

    def test_catalog_match_without_repository_url_is_treated_as_not_found(self) -> None:
        self.catalog_path.write_text(json.dumps({
            "plugins": [{"name": "antispam"}],  # без repository_url
        }), encoding="utf-8")
        with patch("core.lockfile.is_locked", return_value=False):
            code, out = run_cmd(
                pm.cmd_install, yes=True, source="antispam", file=None, ref=None, subdir=None, overwrite=False,
            )
        self.assertEqual(code, 1)

    def test_no_source_empty_catalog_returns_one(self) -> None:
        with patch("core.lockfile.is_locked", return_value=False):
            code, out = run_cmd(
                pm.cmd_install, yes=True, source=None, file=None, ref=None, subdir=None, overwrite=False,
            )
        self.assertEqual(code, 1)
        self.assertIn("Каталог пуст", out)

    def test_no_source_interactive_menu_installs_selected(self) -> None:
        self.catalog_path.write_text(json.dumps({
            "plugins": [
                {"name": "alpha", "repository_url": "https://github.com/o/alpha"},
                {"name": "beta", "repository_url": "https://github.com/o/beta"},
            ],
        }), encoding="utf-8")
        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("builtins.input", return_value="2"), \
             patch("core.plugin_installer.install_from_github", return_value=InstallResult(
                 ok=True, name="beta", message="ok", installed_path=self.plugins_dir / "beta",
             )) as mock_gh:
            code, out = run_cmd(
                pm.cmd_install, yes=True, source=None, file=None, ref=None, subdir=None, overwrite=False,
            )
        self.assertEqual(code, 0)
        mock_gh.assert_called_once_with(
            "https://github.com/o/beta", self.plugins_dir, ref=None, subdir="", name_override="beta", overwrite=False,
        )

    def test_live_bot_redirects_to_staging_dir(self) -> None:
        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value={"pid": 4242, "port": 1}), \
             patch("core.plugin_installer.install_from_github", return_value=InstallResult(
                 ok=True, name="antispam", message="ok", installed_path=self.staging_dir / "antispam",
             )) as mock_gh:
            code, out = run_cmd(
                pm.cmd_install, yes=True, source="owner/antispam", file=None, ref=None, subdir=None, overwrite=False,
            )
        self.assertIn("Бот запущен (pid 4242)", out)
        mock_gh.assert_called_once_with(
            "owner/antispam", self.staging_dir, ref=None, subdir="", name_override=None, overwrite=False,
        )

    def test_plugin_install_error_on_one_target_does_not_stop_remaining_targets(self) -> None:
        self.catalog_path.write_text(json.dumps({
            "plugins": [
                {"name": "bad", "repository_url": "https://github.com/o/bad"},
                {"name": "good", "repository_url": "https://github.com/o/good"},
            ],
        }), encoding="utf-8")

        def fake_install(source, *a, **kw):
            if "bad" in source:
                raise PluginInstallError("boom")
            return InstallResult(ok=True, name="good", message="ok", installed_path=self.plugins_dir / "good")

        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("builtins.input", return_value="all"), \
             patch("core.plugin_installer.install_from_github", side_effect=fake_install) as mock_gh:
            code, out = run_cmd(
                pm.cmd_install, yes=True, source=None, file=None, ref=None, subdir=None, overwrite=False,
            )
        self.assertEqual(code, 1)  # общий результат -- неудача (хотя бы одна цель упала)
        self.assertEqual(mock_gh.call_count, 2)  # но ОБЕ цели были реально попытаны
        self.assertIn("boom", out)
        self.assertIn("✓", out)  # good всё равно успешно установлен


class CmdUninstallTests(PluginManagerTestCase):
    def test_no_yes_flag_returns_one(self) -> None:
        code, out = run_cmd(pm.cmd_uninstall, yes=False, name=None)
        self.assertEqual(code, 1)
        self.assertIn("--yes", out)

    def test_live_bot_blocks_uninstall_entirely(self) -> None:
        with patch.object(pm, "get_live_bot_info", return_value={"pid": 4242, "port": 1}):
            code, out = run_cmd(pm.cmd_uninstall, yes=True, name="anything")
        self.assertEqual(code, 1)
        self.assertIn("Бот запущен", out)

    def test_no_installed_plugins_returns_zero(self) -> None:
        with patch.object(pm, "get_live_bot_info", return_value=None):
            code, out = run_cmd(pm.cmd_uninstall, yes=True, name=None)
        self.assertEqual(code, 0)
        self.assertIn("Нет установленных", out)

    def test_unknown_explicit_name_returns_one(self) -> None:
        self.write_plugin("p1", name="alpha")
        with patch.object(pm, "get_live_bot_info", return_value=None):
            code, out = run_cmd(pm.cmd_uninstall, yes=True, name="ghost")
        self.assertEqual(code, 1)

    def test_explicit_name_uninstalls(self) -> None:
        self.write_plugin("p1", name="alpha")
        with patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("core.plugin_installer.uninstall", return_value=InstallResult(
                 ok=True, name="alpha", message="удалено",
             )) as mock_uninstall:
            code, out = run_cmd(pm.cmd_uninstall, yes=True, name="alpha")
        self.assertEqual(code, 0)
        mock_uninstall.assert_called_once_with("alpha", self.plugins_dir)


class CmdLockTests(PluginManagerTestCase):
    def test_no_yes_flag_returns_one(self) -> None:
        code, out = run_cmd(pm.cmd_lock, yes=False)
        self.assertEqual(code, 1)

    def test_generate_lock_failure_does_not_write(self) -> None:
        from core.lockfile import LockGenerationResult
        with patch("core.lockfile.generate_lock", return_value=LockGenerationResult(ok=False, data=None, error="skipped plugins exist")), \
             patch("core.lockfile.write_lock") as mock_write:
            code, out = run_cmd(pm.cmd_lock, yes=True)
        self.assertEqual(code, 1)
        self.assertIn("skipped plugins exist", out)
        mock_write.assert_not_called()

    def test_generate_lock_success_writes_and_reports_counts(self) -> None:
        from core.lockfile import LockGenerationResult
        data = {"plugins": {"a": {}, "b": {}}, "pip_versions": {"x": "1.0"}}
        with patch("core.lockfile.generate_lock", return_value=LockGenerationResult(ok=True, data=data, error="")), \
             patch("core.lockfile.write_lock") as mock_write:
            code, out = run_cmd(pm.cmd_lock, yes=True)
        self.assertEqual(code, 0)
        mock_write.assert_called_once_with(data)
        self.assertIn("2 плагин", out)
        self.assertIn("1 pip-пакет", out)


class CmdUnlockTests(PluginManagerTestCase):
    def test_no_yes_flag_returns_one(self) -> None:
        code, out = run_cmd(pm.cmd_unlock, yes=False)
        self.assertEqual(code, 1)

    def test_nothing_to_unlock_returns_one(self) -> None:
        with patch("core.lockfile.set_locked", return_value=False):
            code, out = run_cmd(pm.cmd_unlock, yes=True)
        self.assertEqual(code, 1)
        self.assertIn("Нечего разлочивать", out)

    def test_successful_unlock_returns_zero(self) -> None:
        with patch("core.lockfile.set_locked", return_value=True):
            code, out = run_cmd(pm.cmd_unlock, yes=True)
        self.assertEqual(code, 0)
        self.assertIn("Разлочено", out)


class CmdVerifyTests(PluginManagerTestCase):
    def test_no_lock_file_returns_one(self) -> None:
        with patch("core.lockfile.verify_against_lock", return_value=None):
            code, out = run_cmd(pm.cmd_verify)
        self.assertEqual(code, 1)

    def test_all_match_returns_zero(self) -> None:
        from core.lockfile import VerifyResult, VerifyEntry
        result = VerifyResult(
            core_version_mismatch="",
            entries=[VerifyEntry(name="a", status="match", detail="")],
            pip_mismatches=[],
        )
        with patch("core.lockfile.verify_against_lock", return_value=result):
            code, out = run_cmd(pm.cmd_verify)
        self.assertEqual(code, 0)
        self.assertIn("Всё совпадает", out)

    def test_plugin_mismatch_returns_one(self) -> None:
        from core.lockfile import VerifyResult, VerifyEntry
        result = VerifyResult(
            core_version_mismatch="",
            entries=[VerifyEntry(name="a", status="version_changed", detail="1.0.0 -> 2.0.0")],
            pip_mismatches=[],
        )
        with patch("core.lockfile.verify_against_lock", return_value=result):
            code, out = run_cmd(pm.cmd_verify)
        self.assertEqual(code, 1)
        self.assertIn("1.0.0 -> 2.0.0", out)

    def test_core_version_mismatch_alone_returns_one(self) -> None:
        from core.lockfile import VerifyResult
        result = VerifyResult(core_version_mismatch="2.0.0 -> 3.0.0", entries=[], pip_mismatches=[])
        with patch("core.lockfile.verify_against_lock", return_value=result):
            code, out = run_cmd(pm.cmd_verify)
        self.assertEqual(code, 1)
        self.assertIn("ядро:", out)


class CmdUpdateTests(PluginManagerTestCase):
    def test_no_yes_no_noconfirm_returns_one(self) -> None:
        code, out = run_cmd(pm.cmd_update, yes=False, noconfirm=False, name=None)
        self.assertEqual(code, 1)
        self.assertIn("--yes", out)

    def test_locked_blocks_update(self) -> None:
        with patch("core.lockfile.is_locked", return_value=True):
            code, out = run_cmd(pm.cmd_update, yes=True, noconfirm=False, name=None)
        self.assertEqual(code, 1)
        self.assertIn("залочены", out)

    def test_unknown_explicit_name_returns_one(self) -> None:
        with patch("core.lockfile.is_locked", return_value=False):
            code, out = run_cmd(pm.cmd_update, yes=True, noconfirm=False, name="ghost")
        self.assertEqual(code, 1)

    def test_no_updates_available_returns_zero(self) -> None:
        self.write_plugin("p1", name="alpha", extra={"repository_url": "https://github.com/o/alpha"})
        with patch("core.lockfile.is_locked", return_value=False), \
             patch("core.plugin_installer.check_for_update", return_value=UpdateCheckResult(
                 name="alpha", current_version="1.0.0", has_update=False,
             )):
            code, out = run_cmd(pm.cmd_update, yes=True, noconfirm=True, name=None)
        self.assertEqual(code, 0)
        self.assertIn("Обновлений не найдено", out)

    def test_plugins_without_repository_url_are_skipped_from_checking(self) -> None:
        self.write_plugin("p1", name="alpha")  # без repository_url
        with patch("core.lockfile.is_locked", return_value=False), \
             patch("core.plugin_installer.check_for_update") as mock_check:
            run_cmd(pm.cmd_update, yes=True, noconfirm=True, name=None)
        mock_check.assert_not_called()

    def test_check_error_is_reported_and_plugin_skipped(self) -> None:
        self.write_plugin("p1", name="alpha", extra={"repository_url": "https://github.com/o/alpha"})
        with patch("core.lockfile.is_locked", return_value=False), \
             patch("core.plugin_installer.check_for_update", return_value=UpdateCheckResult(
                 name="alpha", current_version="1.0.0", error="rate limit exceeded",
             )):
            code, out = run_cmd(pm.cmd_update, yes=True, noconfirm=True, name=None)
        self.assertEqual(code, 0)
        self.assertIn("rate limit exceeded", out)
        self.assertIn("Обновлений не найдено", out)

    def test_name_override_uses_existing_folder_name_not_fresh_manifest_name(self) -> None:
        """
        Явно прокомментированная в исходнике критичная деталь:
        install_from_github(..., name_override=rec.path.name, ...) --
        обновление должно лечь В ТУ ЖЕ папку, где плагин уже стоит,
        даже если она называется иначе, чем "name" в свежем
        manifest.json (например, изначально установили через --name).
        """
        # папка называется "custom_folder", а manifest.json объявляет "alpha"
        d = self.write_plugin(
            "custom_folder", name="alpha", version="1.0.0",
            extra={"repository_url": "https://github.com/o/alpha"},
        )
        self.assertEqual(d.name, "custom_folder")

        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("core.plugin_installer.check_for_update", return_value=UpdateCheckResult(
                 name="alpha", current_version="1.0.0", remote_version="2.0.0", has_update=True, ref="main",
             )), \
             patch("core.plugin_installer.get_installation_info", return_value=None), \
             patch("core.plugin_installer.parse_github_source", return_value=("o", "alpha")), \
             patch("core.plugin_installer.fetch_latest_commit_sha", return_value="deadbeef"), \
             patch("core.plugin_installer.install_from_github", return_value=InstallResult(
                 ok=True, name="alpha", message="ok",
             )) as mock_install:
            code, out = run_cmd(pm.cmd_update, yes=True, noconfirm=True, name=None)

        self.assertEqual(code, 0)
        mock_install.assert_called_once_with(
            "https://github.com/o/alpha", self.plugins_dir,
            ref="main", name_override="custom_folder", overwrite=True,
        )

    def test_noconfirm_skips_the_per_plugin_prompt(self) -> None:
        self.write_plugin("p1", name="alpha", extra={"repository_url": "https://github.com/o/alpha"})
        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("core.plugin_installer.check_for_update", return_value=UpdateCheckResult(
                 name="alpha", current_version="1.0.0", remote_version="2.0.0", has_update=True, ref="main",
             )), \
             patch("core.plugin_installer.get_installation_info", return_value=None), \
             patch("core.plugin_installer.parse_github_source", return_value=("o", "alpha")), \
             patch("core.plugin_installer.fetch_latest_commit_sha", return_value="deadbeef"), \
             patch("core.plugin_installer.install_from_github", return_value=InstallResult(ok=True, message="ok")), \
             patch("builtins.input") as mock_input:
            code, out = run_cmd(pm.cmd_update, yes=True, noconfirm=True, name=None)
        mock_input.assert_not_called()
        self.assertEqual(code, 0)

    def test_declining_the_prompt_skips_that_plugin(self) -> None:
        self.write_plugin("p1", name="alpha", extra={"repository_url": "https://github.com/o/alpha"})
        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("core.plugin_installer.check_for_update", return_value=UpdateCheckResult(
                 name="alpha", current_version="1.0.0", remote_version="2.0.0", has_update=True, ref="main",
             )), \
             patch("core.plugin_installer.get_installation_info", return_value=None), \
             patch("core.plugin_installer.parse_github_source", return_value=("o", "alpha")), \
             patch("core.plugin_installer.fetch_latest_commit_sha", return_value="deadbeef"), \
             patch("core.plugin_installer.install_from_github") as mock_install, \
             patch("builtins.input", return_value="n"):
            code, out = run_cmd(pm.cmd_update, yes=True, noconfirm=False, name="alpha")
        mock_install.assert_not_called()
        self.assertIn("Пропущено", out)
        self.assertEqual(code, 0)  # ни одной ПОПЫТКИ обновления не провалилось -- all_ok остаётся True

    def test_explicit_name_bypasses_interactive_menu_but_still_prompts_per_plugin(self) -> None:
        self.write_plugin("p1", name="alpha", extra={"repository_url": "https://github.com/o/alpha"})
        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("core.plugin_installer.check_for_update", return_value=UpdateCheckResult(
                 name="alpha", current_version="1.0.0", remote_version="2.0.0", has_update=True, ref="main",
             )), \
             patch("core.plugin_installer.get_installation_info", return_value=None), \
             patch("core.plugin_installer.parse_github_source", return_value=("o", "alpha")), \
             patch("core.plugin_installer.fetch_latest_commit_sha", return_value="deadbeef"), \
             patch("core.plugin_installer.install_from_github", return_value=InstallResult(ok=True, message="ok")), \
             patch("builtins.input", return_value="y") as mock_input:
            code, out = run_cmd(pm.cmd_update, yes=True, noconfirm=False, name="alpha")
        mock_input.assert_called_once()  # с explicit name меню пропущено, но per-plugin confirm — нет
        self.assertEqual(code, 0)

    def test_diff_fetch_error_does_not_abort_the_update_itself(self) -> None:
        self.write_plugin("p1", name="alpha", extra={"repository_url": "https://github.com/o/alpha"})
        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("core.plugin_installer.check_for_update", return_value=UpdateCheckResult(
                 name="alpha", current_version="1.0.0", remote_version="2.0.0", has_update=True, ref="main",
             )), \
             patch("core.plugin_installer.get_installation_info", return_value={"commit_sha": "old"}), \
             patch("core.plugin_installer.parse_github_source", side_effect=PluginInstallError("bad url")), \
             patch("core.plugin_installer.install_from_github", return_value=InstallResult(ok=True, message="ok")) as mock_install:
            code, out = run_cmd(pm.cmd_update, yes=True, noconfirm=True, name="alpha")
        self.assertIn("не удалось получить diff", out)
        mock_install.assert_called_once()  # установка всё равно попыталась выполниться
        self.assertEqual(code, 0)

    def test_install_error_during_actual_update_is_isolated_per_plugin(self) -> None:
        self.write_plugin("p1", name="alpha", extra={"repository_url": "https://github.com/o/alpha"})
        self.write_plugin("p2", name="beta", extra={"repository_url": "https://github.com/o/beta"})

        def fake_check(name, version, url):
            return UpdateCheckResult(name=name, current_version=version, remote_version="2.0.0", has_update=True, ref="main")

        def fake_install(url, plugins_dir, *, ref, name_override, overwrite):
            if "alpha" in url:
                raise PluginInstallError("network boom")
            return InstallResult(ok=True, message="ok")

        with patch("core.lockfile.is_locked", return_value=False), \
             patch.object(pm, "get_live_bot_info", return_value=None), \
             patch("core.plugin_installer.check_for_update", side_effect=fake_check), \
             patch("core.plugin_installer.get_installation_info", return_value=None), \
             patch("core.plugin_installer.parse_github_source", return_value=("o", "x")), \
             patch("core.plugin_installer.fetch_latest_commit_sha", return_value="deadbeef"), \
             patch("core.plugin_installer.install_from_github", side_effect=fake_install):
            code, out = run_cmd(pm.cmd_update, yes=True, noconfirm=True, name=None)

        self.assertEqual(code, 1)  # alpha упал -> общий результат неуспех
        self.assertIn("network boom", out)
        self.assertIn("✓", out)  # но beta всё равно обновился


if __name__ == "__main__":
    unittest.main()
