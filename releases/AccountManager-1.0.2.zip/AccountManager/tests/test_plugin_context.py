"""
tests/test_plugin_context.py — core/plugin_context.py: PluginContext.

Это тонкая фасадная обёртка — ctx.on_hook/patch_around/provide_service/
schedule_* просто прокидывают вызов в HookBus/PatchManager/
ServiceRegistry/Scheduler, ПОДСТАВЛЯЯ plugin=self.plugin_name. Тестируем
через create_autospec (не обычный MagicMock) — это одновременно и мок,
и строгая проверка сигнатуры вызова по реальному классу: если
plugin_context.py когда-нибудь передаст не тот набор аргументов
(например, забудет plugin=... или перепутает порядок), autospec сам
бросит TypeError вместо того, чтобы молча проглотить вызов.

Особое внимание — двум местам, где легко ошибиться при копипасте:
schedule_interval и schedule_cron имеют РАЗНЫЕ дефолты misfire_policy
("run_once" против "skip").
"""
from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import create_autospec

from tests._support import env  # noqa: F401

from core.hooks import HookBus
from core.patches import PatchManager
from core.plugin_context import PluginContext
from core.scheduler import Scheduler
from core.services import ServiceNotFoundError, ServiceRegistry


def _make_ctx(**overrides) -> PluginContext:
    defaults = dict(
        dp=object(),
        bot=object(),
        db=object(),
        core_db=object(),
        config=object(),
        hooks=create_autospec(HookBus, instance=True),
        patches=create_autospec(PatchManager, instance=True),
        services=create_autospec(ServiceRegistry, instance=True),
        scheduler=create_autospec(Scheduler, instance=True),
        plugin_name="my-plugin",
        plugin_dir=Path("/tmp/plugins/my-plugin"),
        logger=object(),
    )
    defaults.update(overrides)
    return PluginContext(**defaults)


class HookWrapperTests(unittest.IsolatedAsyncioTestCase):
    async def test_on_hook_injects_plugin_name_and_default_priority(self) -> None:
        ctx = _make_ctx()
        ctx.hooks.on.return_value = "handle"
        handler = lambda: None
        result = ctx.on_hook("evt", handler)
        ctx.hooks.on.assert_called_once_with("evt", handler, plugin="my-plugin", priority=100)
        self.assertEqual(result, "handle")

    async def test_on_hook_forwards_explicit_priority(self) -> None:
        ctx = _make_ctx()
        handler = lambda: None
        ctx.on_hook("evt", handler, priority=5)
        ctx.hooks.on.assert_called_once_with("evt", handler, plugin="my-plugin", priority=5)

    async def test_emit_forwards_args_and_returns_result(self) -> None:
        ctx = _make_ctx()
        ctx.hooks.emit.return_value = ["r1"]
        result = await ctx.emit("evt", 1, 2, foo="bar")
        ctx.hooks.emit.assert_called_once_with("evt", 1, 2, foo="bar")
        self.assertEqual(result, ["r1"])

    async def test_emit_filter_forwards_value_and_args(self) -> None:
        ctx = _make_ctx()
        ctx.hooks.emit_filter.return_value = "transformed"
        result = await ctx.emit_filter("evt", "value", "extra", tag="x")
        ctx.hooks.emit_filter.assert_called_once_with("evt", "value", "extra", tag="x")
        self.assertEqual(result, "transformed")


class PatchWrapperTests(unittest.TestCase):
    def test_patch_around_injects_plugin_name(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        wrapper = lambda original: original
        ctx.patch_around("target", "attr", wrapper)
        ctx.patches.around.assert_called_once_with("target", "attr", wrapper, plugin="antispam")

    def test_patch_before_injects_plugin_name(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        hook = lambda: None
        ctx.patch_before("target", "attr", hook)
        ctx.patches.before.assert_called_once_with("target", "attr", hook, plugin="antispam")

    def test_patch_after_injects_plugin_name(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        hook = lambda result: result
        ctx.patch_after("target", "attr", hook)
        ctx.patches.after.assert_called_once_with("target", "attr", hook, plugin="antispam")

    def test_patch_replace_default_create_if_missing_is_false(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        ctx.patch_replace("target", "attr", "value")
        ctx.patches.replace.assert_called_once_with(
            "target", "attr", "value", plugin="antispam", create_if_missing=False
        )

    def test_patch_replace_forwards_explicit_create_if_missing(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        ctx.patch_replace("target", "attr", "value", create_if_missing=True)
        ctx.patches.replace.assert_called_once_with(
            "target", "attr", "value", plugin="antispam", create_if_missing=True
        )

    def test_patch_handle_return_value_passes_through(self) -> None:
        ctx = _make_ctx()
        ctx.patches.around.return_value = "the-handle"
        self.assertEqual(ctx.patch_around("t", "a", lambda o: o), "the-handle")


class ServiceWrapperTests(unittest.TestCase):
    def test_provide_service_injects_plugin_name(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        ctx.provide_service("antispam.check", "some-value")
        ctx.services.provide.assert_called_once_with("antispam.check", "some-value", plugin="antispam")

    def test_get_service_does_not_pass_plugin_name(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        ctx.services.get.return_value = "found"
        result = ctx.get_service("other.svc")
        ctx.services.get.assert_called_once_with("other.svc")
        self.assertEqual(result, "found")

    def test_require_service_returns_value(self) -> None:
        ctx = _make_ctx()
        ctx.services.require.return_value = 42
        self.assertEqual(ctx.require_service("svc"), 42)
        ctx.services.require.assert_called_once_with("svc")

    def test_require_service_propagates_not_found_error(self) -> None:
        ctx = _make_ctx()
        ctx.services.require.side_effect = ServiceNotFoundError("нет такого")
        with self.assertRaises(ServiceNotFoundError):
            ctx.require_service("missing")


class SchedulerWrapperTests(unittest.TestCase):
    def test_schedule_interval_defaults(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        callback = lambda: None
        ctx.schedule_interval("check", 30.0, callback)
        ctx.scheduler.interval.assert_called_once_with(
            "check", 30.0, callback, plugin="antispam",
            jitter=0.0, misfire_policy="run_once", max_concurrent=1, persist=True,
        )

    def test_schedule_interval_forwards_overrides(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        callback = lambda: None
        ctx.schedule_interval(
            "check", 30.0, callback, jitter=5.0, misfire_policy="skip",
            max_concurrent=3, persist=False,
        )
        ctx.scheduler.interval.assert_called_once_with(
            "check", 30.0, callback, plugin="antispam",
            jitter=5.0, misfire_policy="skip", max_concurrent=3, persist=False,
        )

    def test_schedule_cron_defaults(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        callback = lambda: None
        ctx.schedule_cron("daily", "0 3 * * *", callback)
        ctx.scheduler.cron.assert_called_once_with(
            "daily", "0 3 * * *", callback, plugin="antispam",
            misfire_policy="skip", max_concurrent=1, persist=True,
        )

    def test_interval_and_cron_default_misfire_policy_differ(self) -> None:
        """
        Лёгкая ловушка при копипасте: schedule_interval по умолчанию
        "run_once", а schedule_cron — "skip". Явный тест на РАЗНИЦУ,
        а не только на каждое значение по отдельности.
        """
        ctx = _make_ctx()
        callback = lambda: None
        ctx.schedule_interval("job1", 30.0, callback)
        ctx.schedule_cron("job2", "0 3 * * *", callback)
        interval_kwargs = ctx.scheduler.interval.call_args.kwargs
        cron_kwargs = ctx.scheduler.cron.call_args.kwargs
        self.assertEqual(interval_kwargs["misfire_policy"], "run_once")
        self.assertEqual(cron_kwargs["misfire_policy"], "skip")
        self.assertNotEqual(interval_kwargs["misfire_policy"], cron_kwargs["misfire_policy"])

    def test_schedule_once_injects_plugin_name(self) -> None:
        ctx = _make_ctx(plugin_name="antispam")
        callback = lambda: None
        ctx.schedule_once("welcome", 10.0, callback)
        ctx.scheduler.once.assert_called_once_with("welcome", 10.0, callback, plugin="antispam")

    def test_cancel_job_forwards_handle_and_returns_result(self) -> None:
        ctx = _make_ctx()
        ctx.scheduler.cancel.return_value = True
        result = ctx.cancel_job("some-handle")
        ctx.scheduler.cancel.assert_called_once_with("some-handle")
        self.assertTrue(result)


if __name__ == "__main__":
    unittest.main()
