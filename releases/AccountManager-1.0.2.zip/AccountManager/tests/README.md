# Тесты ядра AccountManager (`core/` + `plugins/base.py`)

787 unit-тестов. Работает и через `pytest`, и через голый `unittest`.

## Версия ядра: 1.0.0 Stable

`core/__version__` теперь `"1.0.0"` (раньше было `"2.0.0"` — см.
docstring в `core/__init__.py` для истории и переноса). **Если у вас
уже есть плагины с `"core_version": ">=2.0.0,..."` в manifest.json —
поправьте на `">=1.0.0,<2.0.0"`, иначе `core/plugin_loader.py` посчитает
их несовместимыми с этой версией ядра и не загрузит.** Это единственное
затрагивающее вас последствие смены номера версии.

## Как запустить

```bash
pip install -r requirements.txt -r requirements-test.txt --break-system-packages
pytest -v
# или, без pytest:
python -m unittest discover -s tests -v
```

Полный прогон — **787 тестов примерно за 3 секунды**. Как и раньше,
`pytest` живьём в песочнице, где я это собираю, не прогнать (нет
исходящей сети) — структура готова, должна просто заработать там, где
пакеты уже стоят.

## Все найденные ошибки исправлены

Все 18 наблюдений из двух предыдущих проходов — не просто
задокументированы, а исправлены в исходном коде, и тесты обновлены
под новое (правильное) поведение:

| Файл | Было | Стало |
|---|---|---|
| `core/config.py` | `"disabled_plugins": "antispam"` разбивался на символы | строка оборачивается как одно имя плагина |
| `core/config.py` | `drop_pending_updates: "false"` включал флаг (`bool("false")==True`) | текстовые "false"/"true"/"yes"/"no" и т.п. разбираются осмысленно |
| `core/config.py` | `log_level` не валидировался вообще | сверяется со списком уровней stdlib `logging` |
| `core/config.py` | `"webhook"`/`"database"` неверного типа → `AttributeError` | явная `RuntimeError` с объяснением |
| `core/dependencies.py` | non-ASCII имя пакета давало ошибку про "условие версии" | ошибка теперь упоминает само имя |
| `core/lockfile.py` | `is_locked()`/`set_locked()` падали `AttributeError` на не-dict JSON | корректно считается "не залочено" |
| `core/patches.py` | `around` не ловил sync-цель + async-обёртку | обе комбинации отклоняются симметрично |
| `core/patches.py` | неудачная первая валидация оставляла "призрачную" запись в `_chains` | запись создаётся только ПОСЛЕ успешной валидации |
| `core/patches.py` | `revert()` созданного атрибута оставлял `None` вместо удаления | сентинел `_MISSING` → корректный `delattr` |
| `core/middleware.py` | ошибка в `hooks.emit()` после успешного `upsert_user` логировалась как "upsert_user не выполнен" | раздельные try/except, точное сообщение |
| `core/control_server.py` | `status_snapshot()` с ключом `"ok"` мог бы переписать хардкод `True` | порядок распаковки инвертирован |
| `core/scheduler.py` | `max_concurrent<=0` тихо отключал задачу навсегда | `ValueError` при регистрации |
| `core/db/migrations.py` | незакрытый `/* комментарий` разбирался как обычный SQL | явная `ValueError` |
| `core/plugin_loader.py` | reload мог подхватить закешированный старый байткод при совпавших (mtime, размер) | кэш для файла явно снимается перед каждой загрузкой |
| `core/framework_manager.py` | `PROJECT_ROOT` указывал на `core/`, а не на корень проекта | ищет вверх по дереву до `main.py` + `core/__init__.py` |
| `core/framework_manager.py` / `framework_manager.py` | верхнеуровневый CLI не передавал `scheduler=Scheduler()` в `PluginLoader(...)` (расхождение с `core/`-копией) | синхронизированы |
| `core/bootstrap.py` | ошибка при создании `logs/bootstrap/` вылетала сырым `OSError` | аккуратный `sys.exit(1)` с сообщением в stderr |

Полная история находок (с объяснением, почему это было проблемой) —
в комментариях самих тестов и в докстрингах фиксов; при желании могу
собрать отдельный CHANGELOG.md.

## Что покрыто

Без изменений с прошлого раза по составу — 21 файл, весь `core/` +
`plugins/base.py`, кроме `core/logger.py`, `core/db/postgres_backend.py`,
верхнеуровневого CLI-скрипта (теперь синхронизирован с `core/`-версией,
см. таблицу выше) и `utils/*`.

## Зависимости и фейки aiogram/aiosqlite

Без изменений: `tests/_support/env.py` автоматически подставляет
лёгкие фейки из `tests/_support/fakes/`, если настоящих
`aiogram`/`aiosqlite` нет в окружении — настоящие пакеты, если стоят,
всегда в приоритете. Тесты БД гоняют настоящий SQL через честную
async-обёртку над stdlib `sqlite3`, а не мокают методы.
