"""
tests/test_settings.py — core/settings.py: ManagerSettings load/save.
"""
from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

from tests._support import env  # noqa: F401

from core.settings import (
    ManagerSettings,
    load_settings,
    save_settings,
    SETTINGS_PATH,
    VALID_BUILD_CHANNELS,
    VALID_LANGUAGES,
    VALID_LOGGER_LEVELS,
)


class WithTmpDir(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)
        self._orig = os.getcwd()
        os.chdir(self.root)
        self.addCleanup(os.chdir, self._orig)

    def write_settings(self, data: dict) -> None:
        p = self.root / SETTINGS_PATH
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(data), encoding="utf-8")


class TestDefaults(WithTmpDir):

    def test_returns_defaults_when_no_file(self) -> None:
        s = load_settings()
        self.assertEqual(s.language, "rus")
        self.assertEqual(s.build_channel, "Stable")
        self.assertEqual(s.logger_level, "Info")
        self.assertFalse(s.allow_nightly_beta)
        self.assertTrue(s.confirm_actions)
        self.assertFalse(s.dev_mode)
        self.assertFalse(s.disable_signature_and_hash_check)

    def test_returns_defaults_on_malformed_json(self) -> None:
        (self.root / SETTINGS_PATH).parent.mkdir(parents=True, exist_ok=True)
        (self.root / SETTINGS_PATH).write_text("{invalid", encoding="utf-8")
        s = load_settings()
        self.assertEqual(s.language, "rus")

    def test_returns_defaults_when_root_is_not_dict(self) -> None:
        self.write_settings([1, 2, 3])  # список вместо объекта
        s = load_settings()
        self.assertEqual(s.logger_level, "Info")


class TestLoading(WithTmpDir):

    def test_reads_all_fields(self) -> None:
        self.write_settings({
            "language": "eng",
            "allow_nightly_beta": True,
            "build_channel": "Beta",
            "confirm_actions": False,
            "logger_level": "Debug",
            "dev_mode": True,
            "disable_signature_and_hash_check": True,
        })
        s = load_settings()
        self.assertEqual(s.language, "eng")
        self.assertTrue(s.allow_nightly_beta)
        self.assertEqual(s.build_channel, "Beta")
        self.assertFalse(s.confirm_actions)
        self.assertEqual(s.logger_level, "Debug")
        self.assertTrue(s.dev_mode)
        self.assertTrue(s.disable_signature_and_hash_check)

    def test_invalid_language_falls_back_to_default(self) -> None:
        self.write_settings({"language": "klingon"})
        s = load_settings()
        self.assertEqual(s.language, "rus")

    def test_invalid_build_channel_falls_back_to_default(self) -> None:
        self.write_settings({"build_channel": "Canary"})
        s = load_settings()
        self.assertEqual(s.build_channel, "Stable")

    def test_invalid_logger_level_falls_back_to_default(self) -> None:
        self.write_settings({"logger_level": "Verbose"})
        s = load_settings()
        self.assertEqual(s.logger_level, "Info")

    def test_one_invalid_field_does_not_nuke_other_fields(self) -> None:
        self.write_settings({"language": "klingon", "build_channel": "Nightly"})
        s = load_settings()
        self.assertEqual(s.language, "rus")         # откат этого поля
        self.assertEqual(s.build_channel, "Nightly")  # другое осталось

    def test_boolean_string_true_parsed(self) -> None:
        self.write_settings({"dev_mode": "true"})
        s = load_settings()
        self.assertTrue(s.dev_mode)

    def test_boolean_string_false_parsed(self) -> None:
        self.write_settings({"dev_mode": "false"})
        s = load_settings()
        self.assertFalse(s.dev_mode)

    def test_build_channel_capitalised_on_load(self) -> None:
        # "stable" -> "Stable" (капитализация при загрузке)
        self.write_settings({"build_channel": "stable"})
        s = load_settings()
        self.assertEqual(s.build_channel, "Stable")


class TestSave(WithTmpDir):

    def test_creates_settings_dir_if_missing(self) -> None:
        self.assertFalse((self.root / "settings").exists())
        save_settings(ManagerSettings())
        self.assertTrue((self.root / SETTINGS_PATH).exists())

    def test_round_trip(self) -> None:
        original = ManagerSettings(
            language="eng",
            allow_nightly_beta=True,
            build_channel="Nightly",
            confirm_actions=False,
            logger_level="Debug",
            dev_mode=True,
            disable_signature_and_hash_check=True,
        )
        save_settings(original)
        loaded = load_settings()
        self.assertEqual(loaded.language, "eng")
        self.assertTrue(loaded.allow_nightly_beta)
        self.assertEqual(loaded.build_channel, "Nightly")
        self.assertFalse(loaded.confirm_actions)
        self.assertEqual(loaded.logger_level, "Debug")
        self.assertTrue(loaded.dev_mode)
        self.assertTrue(loaded.disable_signature_and_hash_check)

    def test_writes_valid_json(self) -> None:
        save_settings(ManagerSettings())
        raw = json.loads((self.root / SETTINGS_PATH).read_text(encoding="utf-8"))
        self.assertIsInstance(raw, dict)
        self.assertIn("language", raw)


class TestConstants(unittest.TestCase):

    def test_all_valid_channels_present(self) -> None:
        self.assertIn("Stable", VALID_BUILD_CHANNELS)
        self.assertIn("Beta",   VALID_BUILD_CHANNELS)
        self.assertIn("Nightly", VALID_BUILD_CHANNELS)

    def test_all_logger_levels_present(self) -> None:
        for level in ("Disabled", "Debug", "Info", "Warning", "Error", "Critical"):
            self.assertIn(level, VALID_LOGGER_LEVELS)

    def test_valid_languages(self) -> None:
        self.assertIn("rus", VALID_LANGUAGES)
        self.assertIn("eng", VALID_LANGUAGES)


if __name__ == "__main__":
    unittest.main()
