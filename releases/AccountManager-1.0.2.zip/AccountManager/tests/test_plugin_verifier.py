"""
tests/test_plugin_verifier.py — core/plugin_verifier.py: sha256 + Ed25519.

Тесты с реальной криптографией запускаются только если cryptography установлена.
Без неё — тесты хеширования проходят, crypto-тесты пропускаются через skipIf.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path

from tests._support import env  # noqa: F401

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey, Ed25519PublicKey,
    )
    from cryptography.hazmat.primitives.serialization import (
        Encoding, NoEncryption, PrivateFormat, PublicFormat,
    )
    _HAS_CRYPTO = True
except ImportError:
    _HAS_CRYPTO = False


def _generate_keypair() -> tuple[bytes, bytes]:
    """Возвращает (private_pem, public_pem)."""
    key = Ed25519PrivateKey.generate()
    priv = key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption())
    pub  = key.public_key().public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo)
    return priv, pub


class WithTmpPlugin(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)
        self._orig = os.getcwd()
        os.chdir(self.root)
        self.addCleanup(os.chdir, self._orig)

    def make_plugin(self, name: str = "testplugin",
                    files: dict | None = None) -> Path:
        """Создаёт минимальный плагин в plugins/<name>/."""
        d = self.root / "plugins" / name
        d.mkdir(parents=True)
        manifest = {"name": name, "version": "1.0.0", "sha256_hash": ""}
        (d / "manifest.json").write_text(
            json.dumps(manifest, indent=2), encoding="utf-8"
        )
        (d / "__init__.py").write_text(f"# plugin {name}", encoding="utf-8")
        if files:
            for fname, content in files.items():
                (d / fname).write_text(content, encoding="utf-8")
        return d


class TestIterPluginFiles(WithTmpPlugin):

    def test_includes_py_files(self) -> None:
        from core.plugin_verifier import iter_plugin_files
        d = self.make_plugin(files={"helper.py": "# helper"})
        files = iter_plugin_files(d)
        names = [f.name for f in files]
        self.assertIn("__init__.py", names)
        self.assertIn("helper.py", names)
        self.assertIn("manifest.json", names)

    def test_excludes_sig_file(self) -> None:
        from core.plugin_verifier import iter_plugin_files, SIG_FILENAME
        d = self.make_plugin()
        (d / SIG_FILENAME).write_bytes(b"sig")
        files = iter_plugin_files(d)
        names = [f.name for f in files]
        self.assertNotIn(SIG_FILENAME, names)

    def test_excludes_pycache(self) -> None:
        from core.plugin_verifier import iter_plugin_files
        d = self.make_plugin()
        pycache = d / "__pycache__"
        pycache.mkdir()
        (pycache / "cached.pyc").write_bytes(b"bytecode")
        files = iter_plugin_files(d)
        self.assertFalse(any("__pycache__" in str(f) for f in files))

    def test_sorted_deterministically(self) -> None:
        from core.plugin_verifier import iter_plugin_files
        d = self.make_plugin(files={"z.py": "# z", "a.py": "# a"})
        files = iter_plugin_files(d)
        paths_str = [f.relative_to(d).as_posix() for f in files]
        self.assertEqual(paths_str, sorted(paths_str))


class TestComputePluginHash(WithTmpPlugin):

    def test_returns_64_char_hex(self) -> None:
        from core.plugin_verifier import compute_plugin_hash
        d = self.make_plugin()
        h = compute_plugin_hash(d)
        self.assertRegex(h, r"^[0-9a-f]{64}$")

    def test_same_content_same_hash(self) -> None:
        from core.plugin_verifier import compute_plugin_hash
        d = self.make_plugin()
        self.assertEqual(compute_plugin_hash(d), compute_plugin_hash(d))

    def test_changed_content_changes_hash(self) -> None:
        from core.plugin_verifier import compute_plugin_hash
        d = self.make_plugin()
        h1 = compute_plugin_hash(d)
        (d / "__init__.py").write_text("# changed", encoding="utf-8")
        h2 = compute_plugin_hash(d)
        self.assertNotEqual(h1, h2)

    def test_added_file_changes_hash(self) -> None:
        from core.plugin_verifier import compute_plugin_hash
        d = self.make_plugin()
        h1 = compute_plugin_hash(d)
        (d / "new.py").write_text("# new", encoding="utf-8")
        h2 = compute_plugin_hash(d)
        self.assertNotEqual(h1, h2)


class TestVerifyPluginNoSig(WithTmpPlugin):

    def test_no_sig_file_returns_not_ok(self) -> None:
        from core.plugin_verifier import verify_plugin
        d = self.make_plugin()
        result = verify_plugin(d, pubkey_path=Path("nonexistent.pem"))
        self.assertFalse(result.ok)
        self.assertFalse(result.has_sig)

    def test_no_sig_reason_contains_filename(self) -> None:
        from core.plugin_verifier import verify_plugin, SIG_FILENAME
        d = self.make_plugin()
        result = verify_plugin(d, pubkey_path=Path("nonexistent.pem"))
        self.assertIn(SIG_FILENAME, result.reason)

    def test_missing_manifest_returns_not_ok(self) -> None:
        from core.plugin_verifier import verify_plugin, SIG_FILENAME
        d = self.make_plugin()
        (d / SIG_FILENAME).write_bytes(b"dummy")
        (d / "manifest.json").unlink()
        result = verify_plugin(d, pubkey_path=Path("nonexistent.pem"))
        self.assertFalse(result.ok)
        self.assertIn("manifest.json", result.reason)

    def test_empty_sha256_hash_returns_not_ok(self) -> None:
        from core.plugin_verifier import verify_plugin, SIG_FILENAME
        d = self.make_plugin()
        (d / SIG_FILENAME).write_bytes(b"dummy")
        # manifest.json уже имеет sha256_hash = "" (из make_plugin)
        result = verify_plugin(d, pubkey_path=Path("nonexistent.pem"))
        self.assertFalse(result.ok)
        self.assertIn("sha256_hash", result.reason)

    def test_wrong_hash_in_manifest_returns_not_ok(self) -> None:
        from core.plugin_verifier import verify_plugin, SIG_FILENAME
        d = self.make_plugin()
        (d / SIG_FILENAME).write_bytes(b"dummy")
        manifest = json.loads((d / "manifest.json").read_text())
        manifest["sha256_hash"] = "deadbeef" * 8
        (d / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        result = verify_plugin(d, pubkey_path=Path("nonexistent.pem"))
        self.assertFalse(result.ok)
        self.assertIn("изменились", result.reason)


@unittest.skipUnless(_HAS_CRYPTO, "cryptography not installed")
class TestVerifyPluginWithCrypto(WithTmpPlugin):

    def setUp(self) -> None:
        super().setUp()
        self.priv_pem, self.pub_pem = _generate_keypair()
        keys_dir = self.root / "configs" / "keys"
        keys_dir.mkdir(parents=True)
        self.pubkey_path = keys_dir / "public.pem"
        self.privkey_path = keys_dir / "private.pem"
        self.pubkey_path.write_bytes(self.pub_pem)
        self.privkey_path.write_bytes(self.priv_pem)

    def _sign(self, plugin_dir: Path) -> None:
        """Подписывает плагин тестовым приватным ключом."""
        from cryptography.hazmat.primitives.serialization import load_pem_private_key
        from core.plugin_verifier import compute_plugin_hash

        key = load_pem_private_key(self.priv_pem, password=None)
        plugin_hash = compute_plugin_hash(plugin_dir)

        # Обновляем manifest.json
        manifest = json.loads((plugin_dir / "manifest.json").read_text())
        manifest["sha256_hash"] = plugin_hash
        (plugin_dir / "manifest.json").write_text(
            json.dumps(manifest, indent=2), encoding="utf-8"
        )

        # Создаём .sig
        sig = key.sign(plugin_hash.encode("utf-8"))
        (plugin_dir / "manifest.json.sig").write_bytes(sig)

    def test_valid_signature_returns_ok(self) -> None:
        from core.plugin_verifier import verify_plugin
        d = self.make_plugin()
        self._sign(d)
        result = verify_plugin(d, pubkey_path=self.pubkey_path)
        self.assertTrue(result.ok)
        self.assertTrue(result.has_sig)
        self.assertGreater(result.files_hashed, 0)

    def test_tampered_py_file_detected(self) -> None:
        from core.plugin_verifier import verify_plugin
        d = self.make_plugin()
        self._sign(d)
        # Подменяем py-файл после подписи
        (d / "__init__.py").write_text("# MALICIOUS CODE", encoding="utf-8")
        result = verify_plugin(d, pubkey_path=self.pubkey_path)
        self.assertFalse(result.ok)
        self.assertIn("изменились", result.reason)

    def test_added_file_after_signing_detected(self) -> None:
        from core.plugin_verifier import verify_plugin
        d = self.make_plugin()
        self._sign(d)
        (d / "injected.py").write_text("# injected", encoding="utf-8")
        result = verify_plugin(d, pubkey_path=self.pubkey_path)
        self.assertFalse(result.ok)

    def test_wrong_public_key_fails(self) -> None:
        from core.plugin_verifier import verify_plugin
        d = self.make_plugin()
        self._sign(d)
        # Другая пара ключей
        _, other_pub = _generate_keypair()
        other_key_path = self.root / "configs" / "keys" / "other_pub.pem"
        other_key_path.write_bytes(other_pub)
        result = verify_plugin(d, pubkey_path=other_key_path)
        self.assertFalse(result.ok)
        self.assertIn("НЕДЕЙСТВИТЕЛЬНА", result.reason)

    def test_modified_sig_fails(self) -> None:
        from core.plugin_verifier import verify_plugin
        d = self.make_plugin()
        self._sign(d)
        # Портим подпись
        sig_path = d / "manifest.json.sig"
        sig_path.write_bytes(b"\x00" * 64)
        result = verify_plugin(d, pubkey_path=self.pubkey_path)
        self.assertFalse(result.ok)

    def test_modified_hash_in_manifest_with_valid_sig_fails(self) -> None:
        """Подменяют hash в manifest.json — sig больше не совпадает."""
        from core.plugin_verifier import verify_plugin
        d = self.make_plugin()
        self._sign(d)
        # Подменяем hash в manifest.json без пересчёта подписи
        manifest = json.loads((d / "manifest.json").read_text())
        manifest["sha256_hash"] = "cafebabe" * 8
        (d / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        result = verify_plugin(d, pubkey_path=self.pubkey_path)
        self.assertFalse(result.ok)


@unittest.skipUnless(_HAS_CRYPTO, "cryptography not installed")
class TestSignPluginScript(WithTmpPlugin):

    def setUp(self) -> None:
        super().setUp()
        priv_pem, pub_pem = _generate_keypair()
        keys_dir = self.root / "configs" / "keys"
        keys_dir.mkdir(parents=True)
        (keys_dir / "public.pem").write_bytes(pub_pem)
        (keys_dir / "private.pem").write_bytes(priv_pem)

    def _project_root(self) -> Path:
        return Path(__file__).resolve().parent.parent

    def test_sign_plugin_creates_sig_and_updates_manifest(self) -> None:
        import subprocess, sys
        d = self.make_plugin()
        result = subprocess.run(
            [sys.executable,
             str(self._project_root() / "scripts" / "sign_plugin.py"),
             str(d),
             "--key", str(self.root / "configs" / "keys" / "private.pem")],
            capture_output=True, text=True,
            cwd=str(self.root),
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue((d / "manifest.json.sig").exists())
        manifest = json.loads((d / "manifest.json").read_text())
        self.assertNotEqual(manifest.get("sha256_hash", ""), "")

    def test_signed_plugin_passes_verification(self) -> None:
        import subprocess, sys
        d = self.make_plugin()
        subprocess.run(
            [sys.executable,
             str(self._project_root() / "scripts" / "sign_plugin.py"),
             str(d),
             "--key", str(self.root / "configs" / "keys" / "private.pem")],
            capture_output=True,
            cwd=str(self.root),
        )
        from core.plugin_verifier import verify_plugin
        result = verify_plugin(d, pubkey_path=self.root / "configs" / "keys" / "public.pem")
        self.assertTrue(result.ok, result.reason)


class TestSandboxConfigNewFields(WithTmpPlugin):

    def _write_env(self) -> None:
        (self.root / "configs").mkdir(exist_ok=True)
        (self.root / "configs" / ".env").write_text("BOT_TOKEN=tok\n", encoding="utf-8")

    def test_verify_plugin_signatures_default_false(self) -> None:
        self._write_env()
        from core.config import load_config
        cfg = load_config()
        self.assertFalse(cfg.sandbox.verify_plugin_signatures)

    def test_allow_unsigned_default_false(self) -> None:
        self._write_env()
        from core.config import load_config
        cfg = load_config()
        self.assertFalse(cfg.sandbox.allow_unsigned_plugins)

    def test_both_fields_parsed_from_config(self) -> None:
        self._write_env()
        (self.root / "configs" / "config.json").write_text(
            json.dumps({
                "sandbox": {
                    "verify_plugin_signatures": True,
                    "allow_unsigned_plugins": True,
                }
            }),
            encoding="utf-8",
        )
        from core.config import load_config
        cfg = load_config()
        self.assertTrue(cfg.sandbox.verify_plugin_signatures)
        self.assertTrue(cfg.sandbox.allow_unsigned_plugins)


if __name__ == "__main__":
    unittest.main()
