"""
tests/test_plugin_base.py — plugins/base.py: BasePlugin (контракт для всех плагинов).
"""
from __future__ import annotations

import unittest

from tests._support import env  # noqa: F401

from plugins.base import BasePlugin


class CannotInstantiateBareBasePluginTests(unittest.TestCase):
    def test_bare_base_plugin_cannot_be_instantiated(self) -> None:
        with self.assertRaises(TypeError):
            BasePlugin()  # type: ignore[abstract]

    def test_subclass_missing_setup_cannot_be_instantiated(self) -> None:
        class Incomplete(BasePlugin):
            @property
            def name(self) -> str:
                return "incomplete"

            @property
            def version(self) -> str:
                return "1.0.0"
            # setup() отсутствует

        with self.assertRaises(TypeError):
            Incomplete()  # type: ignore[abstract]

    def test_subclass_missing_name_cannot_be_instantiated(self) -> None:
        class Incomplete(BasePlugin):
            @property
            def version(self) -> str:
                return "1.0.0"

            async def setup(self, ctx) -> None:
                pass

        with self.assertRaises(TypeError):
            Incomplete()  # type: ignore[abstract]

    def test_subclass_missing_version_cannot_be_instantiated(self) -> None:
        class Incomplete(BasePlugin):
            @property
            def name(self) -> str:
                return "incomplete"

            async def setup(self, ctx) -> None:
                pass

        with self.assertRaises(TypeError):
            Incomplete()  # type: ignore[abstract]


class CompleteSubclassTests(unittest.IsolatedAsyncioTestCase):
    def _make_plugin_class(self):
        class MyPlugin(BasePlugin):
            def __init__(self) -> None:
                self.setup_called_with = None

            @property
            def name(self) -> str:
                return "my-plugin"

            @property
            def version(self) -> str:
                return "1.2.3"

            async def setup(self, ctx) -> None:
                self.setup_called_with = ctx

        return MyPlugin

    async def test_complete_subclass_can_be_instantiated(self) -> None:
        MyPlugin = self._make_plugin_class()
        plugin = MyPlugin()  # не должно бросить
        self.assertEqual(plugin.name, "my-plugin")
        self.assertEqual(plugin.version, "1.2.3")

    async def test_setup_is_called_with_context(self) -> None:
        MyPlugin = self._make_plugin_class()
        plugin = MyPlugin()
        sentinel_ctx = object()
        await plugin.setup(sentinel_ctx)
        self.assertIs(plugin.setup_called_with, sentinel_ctx)

    async def test_default_teardown_is_a_no_op_that_can_be_awaited(self) -> None:
        MyPlugin = self._make_plugin_class()
        plugin = MyPlugin()
        result = await plugin.teardown()  # не должно бросить
        self.assertIsNone(result)

    async def test_teardown_can_be_overridden(self) -> None:
        class WithTeardown(self._make_plugin_class()):
            def __init__(self) -> None:
                super().__init__()
                self.torn_down = False

            async def teardown(self) -> None:
                self.torn_down = True

        plugin = WithTeardown()
        await plugin.teardown()
        self.assertTrue(plugin.torn_down)


if __name__ == "__main__":
    unittest.main()
