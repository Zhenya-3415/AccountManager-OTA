"""
tests/test_middleware.py — core/middleware.py: UserUpsertMiddleware.

Использует настоящий aiogram, если он установлен, иначе — облегчённый
фейк из tests/_support/fakes/aiogram (см. tests/_support/env.py):
достаточно, чтобы протестировать ЛОГИКУ этого модуля (извлечение
from_user, изоляция ошибок upsert/hook), не завязываясь на то, стоит
ли в этом окружении реальный aiogram.
"""
from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock

from tests._support import env

env.ensure_aiogram()
env.ensure_aiosqlite()  # core.middleware -> core.database -> core.db.sqlite_backend

from aiogram.types import Update, User  # noqa: E402

from core.middleware import UserUpsertMiddleware, _extract_user  # noqa: E402


def _make_user(**overrides) -> User:
    defaults = dict(id=1, is_bot=False, first_name="Jsis", last_name=None, username="jsis", language_code="ru")
    defaults.update(overrides)
    return User(**defaults)


def _make_update(**fields) -> Update:
    """Создаёт Update и с реальным aiogram, и с тестовым fallback-фейком."""
    if hasattr(Update, "model_construct"):
        return Update.model_construct(update_id=1, **fields)
    return Update(update_id=1, **fields)


async def _dummy_handler(event, data):
    return "handler-result"


class ExtractUserTests(unittest.TestCase):
    def test_extracts_from_message(self) -> None:
        user = _make_user()
        update = _make_update(message=SimpleNamespace(from_user=user))
        self.assertIs(_extract_user(update), user)

    def test_extracts_from_callback_query_when_message_absent(self) -> None:
        user = _make_user()
        update = _make_update(callback_query=SimpleNamespace(from_user=user))
        self.assertIs(_extract_user(update), user)

    def test_message_takes_priority_over_callback_query(self) -> None:
        message_user = _make_user(id=1)
        callback_user = _make_user(id=2)
        update = _make_update(
            message=SimpleNamespace(from_user=message_user),
            callback_query=SimpleNamespace(from_user=callback_user),
        )
        self.assertIs(_extract_user(update), message_user)

    def test_falls_through_when_container_present_but_from_user_none(self) -> None:
        # Реалистичный случай: channel_post реально существует, но
        # from_user у него нет (анонимные посты каналов).
        user = _make_user()
        update = _make_update(
            channel_post=SimpleNamespace(from_user=None),
            my_chat_member=SimpleNamespace(from_user=user),
        )
        self.assertIs(_extract_user(update), user)

    def test_no_user_anywhere_returns_none(self) -> None:
        update = _make_update()
        self.assertIsNone(_extract_user(update))

    def test_empty_update_with_all_fields_none_returns_none(self) -> None:
        update = _make_update(message=None, callback_query=None)
        self.assertIsNone(_extract_user(update))


class MiddlewareCallTests(unittest.IsolatedAsyncioTestCase):
    async def test_non_update_event_skips_upsert_but_calls_handler(self) -> None:
        db = AsyncMock()
        middleware = UserUpsertMiddleware(db)
        not_an_update = SimpleNamespace()  # не Update -> isinstance-проверка не пройдёт
        result = await middleware(_dummy_handler, not_an_update, {})
        db.upsert_user.assert_not_called()
        self.assertEqual(result, "handler-result")

    async def test_update_with_no_user_skips_upsert_but_calls_handler(self) -> None:
        db = AsyncMock()
        middleware = UserUpsertMiddleware(db)
        update = _make_update()
        result = await middleware(_dummy_handler, update, {})
        db.upsert_user.assert_not_called()
        self.assertEqual(result, "handler-result")

    async def test_bot_user_is_skipped(self) -> None:
        db = AsyncMock()
        middleware = UserUpsertMiddleware(db)
        bot_user = _make_user(is_bot=True)
        update = _make_update(message=SimpleNamespace(from_user=bot_user))
        result = await middleware(_dummy_handler, update, {})
        db.upsert_user.assert_not_called()
        self.assertEqual(result, "handler-result")

    async def test_human_user_triggers_upsert_with_correct_fields(self) -> None:
        db = AsyncMock()
        middleware = UserUpsertMiddleware(db)
        user = _make_user(id=42, username="jsis", first_name="Jsis", last_name="Dev", language_code="ru")
        update = _make_update(message=SimpleNamespace(from_user=user))
        await middleware(_dummy_handler, update, {})
        db.upsert_user.assert_called_once_with(
            user_id=42, username="jsis", first_name="Jsis", last_name="Dev", language_code="ru",
        )

    async def test_handler_result_returned_regardless_of_upsert_outcome(self) -> None:
        db = AsyncMock()
        middleware = UserUpsertMiddleware(db)
        user = _make_user()
        update = _make_update(message=SimpleNamespace(from_user=user))
        result = await middleware(_dummy_handler, update, {"some": "data"})
        self.assertEqual(result, "handler-result")

    async def test_hooks_emitted_after_successful_upsert(self) -> None:
        db = AsyncMock()
        hooks = AsyncMock()
        middleware = UserUpsertMiddleware(db, hooks=hooks)
        user = _make_user()
        update = _make_update(message=SimpleNamespace(from_user=user))
        await middleware(_dummy_handler, update, {})
        hooks.emit.assert_called_once_with("core.user.upserted", user=user)

    async def test_no_hooks_configured_does_not_crash(self) -> None:
        db = AsyncMock()
        middleware = UserUpsertMiddleware(db, hooks=None)
        user = _make_user()
        update = _make_update(message=SimpleNamespace(from_user=user))
        result = await middleware(_dummy_handler, update, {})  # не должно бросить
        self.assertEqual(result, "handler-result")

    async def test_upsert_failure_is_caught_and_handler_still_runs(self) -> None:
        db = AsyncMock()
        db.upsert_user.side_effect = RuntimeError("db is down")
        middleware = UserUpsertMiddleware(db)
        user = _make_user()
        update = _make_update(message=SimpleNamespace(from_user=user))
        with self.assertLogs("middleware", level="WARNING") as ctx:
            result = await middleware(_dummy_handler, update, {})  # не должно бросить
        self.assertEqual(result, "handler-result")
        self.assertIn("db is down", "\n".join(ctx.output))

    async def test_upsert_failure_does_not_attempt_hook_emit(self) -> None:
        db = AsyncMock()
        db.upsert_user.side_effect = RuntimeError("db is down")
        hooks = AsyncMock()
        middleware = UserUpsertMiddleware(db, hooks=hooks)
        user = _make_user()
        update = _make_update(message=SimpleNamespace(from_user=user))
        await middleware(_dummy_handler, update, {})
        hooks.emit.assert_not_called()

    async def test_hook_emit_failure_after_successful_upsert_logs_accurate_message(self) -> None:
        """
        Раньше upsert_user и hooks.emit(...) были обёрнуты ОДНИМ
        try/except — если сам upsert проходил успешно, а падал именно
        emit(), лог всё равно говорил "upsert_user ... не выполнен",
        хотя запись в БД реально прошла. Теперь try/except разделены, и
        сообщение об ошибке emit() не винит в этом upsert_user.
        """
        db = AsyncMock()  # upsert_user сам по себе успешен
        hooks = AsyncMock()
        hooks.emit.side_effect = RuntimeError("hook bus exploded")
        middleware = UserUpsertMiddleware(db, hooks=hooks)
        user = _make_user(id=7)
        update = _make_update(message=SimpleNamespace(from_user=user))

        with self.assertLogs("middleware", level="WARNING") as ctx:
            result = await middleware(_dummy_handler, update, {})

        db.upsert_user.assert_called_once()  # апсерт РЕАЛЬНО выполнился
        self.assertEqual(result, "handler-result")
        joined = "\n".join(ctx.output)
        self.assertIn("hook bus exploded", joined)
        self.assertIn("core.user.upserted", joined)
        self.assertIn("выполнен успешно", joined)  # явно говорит, что upsert НЕ пострадал
        self.assertNotIn("upsert_user user_id=7 не выполнен", joined)  # старая вводящая в заблуждение фраза


if __name__ == "__main__":
    unittest.main()
