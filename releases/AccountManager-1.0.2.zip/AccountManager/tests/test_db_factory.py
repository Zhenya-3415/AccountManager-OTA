"""
tests/test_db_factory.py — core/db/factory.py: create_database().

PostgresDatabase не требует asyncpg на этапе КОНСТРУИРОВАНИЯ (asyncpg
импортируется лениво внутри .connect(), см. core/db/postgres_backend.py)
— поэтому ветку backend="postgres" можно тестировать и без реального
asyncpg в окружении. Ветка backend="sqlite" по-прежнему нуждается в
aiosqlite (настоящем или фейковом).
"""
from __future__ import annotations

import unittest
from pathlib import Path

from tests._support import env

env.ensure_aiosqlite()

from core.config import Config, DatabaseConfig, PostgresConfig  # noqa: E402
from core.db.factory import create_database  # noqa: E402
from core.db.postgres_backend import PostgresDatabase  # noqa: E402
from core.db.sqlite_backend import SQLiteDatabase  # noqa: E402


def _make_config(**db_overrides) -> Config:
    db_defaults = dict(backend="sqlite")
    db_defaults.update(db_overrides)
    if "postgres" not in db_defaults or isinstance(db_defaults.get("postgres"), dict):
        pg_kwargs = db_defaults.pop("postgres", {}) or {}
        db_defaults["postgres"] = PostgresConfig(**pg_kwargs)
    return Config(bot_token="x", database=DatabaseConfig(**db_defaults))


class SqliteBackendSelectionTests(unittest.TestCase):
    def test_sqlite_backend_returns_sqlite_database(self) -> None:
        config = _make_config(backend="sqlite")
        db = create_database(
            namespace="core", config=config, sqlite_path=Path("/tmp/x.db"), sqlite_reader_pool_size=7,
        )
        self.assertIsInstance(db, SQLiteDatabase)
        self.assertEqual(db.db_path, Path("/tmp/x.db"))
        self.assertEqual(db._reader_pool_size, 7)

    def test_sqlite_reader_pool_size_default(self) -> None:
        config = _make_config(backend="sqlite")
        db = create_database(namespace="core", config=config, sqlite_path=Path("/tmp/x.db"))
        self.assertEqual(db._reader_pool_size, 4)


class PostgresBackendSelectionTests(unittest.TestCase):
    def test_postgres_backend_returns_postgres_database(self) -> None:
        config = _make_config(backend="postgres", postgres={"dsn": "postgresql://u:p@host/db"})
        db = create_database(namespace="myplugin", config=config, sqlite_path=Path("/tmp/unused.db"))
        self.assertIsInstance(db, PostgresDatabase)
        self.assertEqual(db.dsn, "postgresql://u:p@host/db")

    def test_postgres_pool_sizes_forwarded(self) -> None:
        config = _make_config(backend="postgres", postgres={"dsn": "postgresql://u:p@host/db"})
        db = create_database(
            namespace="myplugin", config=config, sqlite_path=Path("/tmp/unused.db"),
            postgres_pool_min_size=2, postgres_pool_max_size=20,
        )
        self.assertEqual(db._pool_min_size, 2)
        self.assertEqual(db._pool_max_size, 20)

    def test_postgres_without_dsn_raises(self) -> None:
        config = _make_config(backend="postgres", postgres={"dsn": ""})
        with self.assertRaises(RuntimeError):
            create_database(namespace="myplugin", config=config, sqlite_path=Path("/tmp/unused.db"))

    def test_postgres_with_explicit_none_postgres_config_raises(self) -> None:
        # Ветка "pg is None" защищает от config, собранного напрямую (не
        # через load_config()), где database.postgres выставили в None руками.
        config = Config(bot_token="x", database=DatabaseConfig(backend="postgres", postgres=None))
        with self.assertRaises(RuntimeError):
            create_database(namespace="myplugin", config=config, sqlite_path=Path("/tmp/unused.db"))

    def test_sqlite_path_argument_is_ignored_for_postgres_backend(self) -> None:
        config = _make_config(backend="postgres", postgres={"dsn": "postgresql://u:p@host/db"})
        db = create_database(namespace="myplugin", config=config, sqlite_path=Path("/some/sqlite/path.db"))
        self.assertFalse(hasattr(db, "db_path"))


class InvalidBackendTests(unittest.TestCase):
    def test_unknown_backend_raises_value_error_with_helpful_message(self) -> None:
        config = _make_config(backend="sqlite")
        config.database.backend = "mysql"  # обходим валидацию config.py напрямую
        with self.assertRaises(ValueError) as ctx:
            create_database(namespace="core", config=config, sqlite_path=Path("/tmp/x.db"))
        self.assertIn("mysql", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
