"""
tests/test_ota.py — unit tests for core/ota/*.

Тестируем без сети (urllib мокается), без cryptography
(verifier.py используется с skip_signature=True), без реального subprocess.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import MagicMock, patch

from tests._support import env  # noqa: F401


# ═══════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════

class WithTmpDir(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)
        self._orig = os.getcwd()
        os.chdir(self.root)
        self.addCleanup(os.chdir, self._orig)

    def write(self, rel: str, content: str = "# x") -> Path:
        p = self.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return p

    def write_json(self, rel: str, data: dict) -> Path:
        p = self.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(data), encoding="utf-8")
        return p


# ═══════════════════════════════════════════════════════════════
# core/ota/slot_manager.py
# ═══════════════════════════════════════════════════════════════

class TestOTAState(WithTmpDir):

    def test_load_state_returns_default_when_no_file(self) -> None:
        from core.ota.slot_manager import load_state
        state = load_state()
        self.assertEqual(state.active_slot, "a")
        self.assertEqual(state.status, "idle")
        self.assertEqual(state.crash_count, 0)

    def test_save_and_load_roundtrip(self) -> None:
        from core.ota.slot_manager import OTAState, load_state, save_state
        Path("slots").mkdir()
        s = OTAState(active_slot="b", status="testing", crash_count=2)
        save_state(s)
        loaded = load_state()
        self.assertEqual(loaded.active_slot, "b")
        self.assertEqual(loaded.status, "testing")
        self.assertEqual(loaded.crash_count, 2)

    def test_save_is_atomic_uses_tmp_then_rename(self) -> None:
        from core.ota.slot_manager import OTAState, save_state, OTA_STATE_PATH
        Path("slots").mkdir()
        save_state(OTAState())
        self.assertTrue(OTA_STATE_PATH.exists())
        self.assertFalse(OTA_STATE_PATH.with_suffix(".tmp").exists())

    def test_load_state_is_resilient_to_corrupt_json(self) -> None:
        from core.ota.slot_manager import load_state
        Path("slots").mkdir()
        Path("slots/ota_state.json").write_text("{bad", encoding="utf-8")
        state = load_state()
        self.assertEqual(state.status, "idle")  # дефолт

    def test_set_status_persists(self) -> None:
        from core.ota.slot_manager import set_status, load_state
        Path("slots").mkdir()
        set_status("downloading", crash_count=1)
        self.assertEqual(load_state().status, "downloading")
        self.assertEqual(load_state().crash_count, 1)

    def test_apply_pending_if_any_noop_when_not_pending(self) -> None:
        from core.ota.slot_manager import apply_pending_if_any, OTAState, save_state
        Path("slots").mkdir()
        save_state(OTAState(status="idle"))
        result = apply_pending_if_any()
        self.assertFalse(result)

    def test_apply_pending_if_any_promotes_when_pending(self) -> None:
        from core.ota.slot_manager import apply_pending_if_any, OTAState, save_state, SLOT_B_DIR
        Path("slots").mkdir()
        save_state(OTAState(status="pending_promote", pending_version="1.0.1"))
        # Создаём минимальный слот B чтобы копирование не упало
        (self.root / SLOT_B_DIR / "core").mkdir(parents=True, exist_ok=True)
        with patch("core.ota.slot_manager.promote_b_to_a") as mock_promote:
            mock_promote.return_value = "1.0.1"
            result = apply_pending_if_any()
        self.assertTrue(result)
        mock_promote.assert_called_once()

    def test_rollback_sets_correct_status(self) -> None:
        from core.ota.slot_manager import rollback, load_state
        Path("slots").mkdir()
        from core.ota.slot_manager import OTAState, save_state
        save_state(OTAState(status="testing", pending_version="1.0.1"))
        rollback("тест провалился")
        state = load_state()
        self.assertEqual(state.status, "rolled_back")
        self.assertIn("тест провалился", state.last_error)

    def test_init_slots_creates_slot_a_dirs(self) -> None:
        from core.ota.slot_manager import init_slots
        self.write("core/__init__.py", "")
        self.write("main.py", "")
        self.write("framework_manager.py", "")
        self.write("plugins/base.py", "")
        self.write_json("manifest_core.json", {"version": "1.0.0", "sha256_hash": ""})
        init_slots(self.root)
        self.assertTrue((self.root / "slots" / "a" / "configs").is_dir())
        self.assertTrue((self.root / "slots" / "a" / "core").is_dir())

    def _make_unpacked_ota(self, base_content: str = "# new base") -> "Path":
        """Создаёт минимальный распакованный OTA-архив."""
        unpacked = self.root / "unpacked"
        (unpacked / "core").mkdir(parents=True)
        (unpacked / "plugins").mkdir()
        (unpacked / "plugins" / "base.py").write_text(base_content, encoding="utf-8")
        (unpacked / "core" / "__init__.py").write_text("", encoding="utf-8")
        (unpacked / "main.py").write_text("", encoding="utf-8")
        (unpacked / "framework_manager.py").write_text("", encoding="utf-8")
        self.write_json(str(unpacked / "manifest_core.json"),
                        {"version": "1.0.1", "sha256_hash": ""})
        return unpacked

    def test_prepare_slot_b_copies_user_plugins(self) -> None:
        """
        Слот B должен содержать новое ядро (из OTA-архива) И текущие
        пользовательские плагины (из production plugins/).  Только так
        тест воспроизводит реальную конфигурацию после промоута.
        """
        from core.ota.slot_manager import prepare_slot_b, SLOT_B_DIR

        unpacked = self._make_unpacked_ota("# new base")
        Path("slots").mkdir()

        # Устанавливаем «продакшен плагины»
        (self.root / "plugins").mkdir(exist_ok=True)
        (self.root / "plugins" / "base.py").write_text("# old base", encoding="utf-8")
        (self.root / "plugins" / "antispam").mkdir()
        (self.root / "plugins" / "antispam" / "manifest.json").write_text(
            '{"name":"antispam"}', encoding="utf-8")
        (self.root / "plugins" / "welcome").mkdir()
        (self.root / "plugins" / "welcome" / "manifest.json").write_text(
            '{"name":"welcome"}', encoding="utf-8")

        prepare_slot_b(unpacked, "1.0.1", "test_tok", production_root=self.root)

        slot_plugins = self.root / SLOT_B_DIR / "plugins"
        # Пользовательские плагины скопированы
        self.assertTrue((slot_plugins / "antispam").is_dir())
        self.assertTrue((slot_plugins / "welcome").is_dir())
        # base.py — из OTA-архива (новая версия), а не из production
        base = (slot_plugins / "base.py").read_text(encoding="utf-8")
        self.assertEqual(base, "# new base")
        # .env содержит тестовый токен
        env = (self.root / SLOT_B_DIR / "configs" / ".env").read_text(encoding="utf-8")
        self.assertIn("test_tok", env)

    def test_prepare_slot_b_no_user_plugins_is_not_an_error(self) -> None:
        """Если в production нет пользовательских плагинов — только base.py, не ошибка."""
        from core.ota.slot_manager import prepare_slot_b, SLOT_B_DIR

        unpacked = self._make_unpacked_ota("# base")
        Path("slots").mkdir()
        (self.root / "plugins").mkdir(exist_ok=True)
        (self.root / "plugins" / "base.py").write_text("# old", encoding="utf-8")

        prepare_slot_b(unpacked, "1.0.1", "tok", production_root=self.root)

        slot_plugins = self.root / SLOT_B_DIR / "plugins"
        self.assertTrue((slot_plugins / "base.py").exists())
        dirs = [x.name for x in slot_plugins.iterdir() if x.is_dir()]
        self.assertEqual(dirs, [])

    def test_prepare_slot_b_base_py_from_archive_not_production(self) -> None:
        """base.py всегда берётся из OTA-архива, даже если в production другая версия."""
        from core.ota.slot_manager import prepare_slot_b, SLOT_B_DIR

        unpacked = self._make_unpacked_ota("# ARCHIVE VERSION")
        Path("slots").mkdir()
        (self.root / "plugins").mkdir(exist_ok=True)
        (self.root / "plugins" / "base.py").write_text("# PROD VERSION", encoding="utf-8")

        prepare_slot_b(unpacked, "1.0.1", "tok", production_root=self.root)

        base = (self.root / SLOT_B_DIR / "plugins" / "base.py").read_text(encoding="utf-8")
        self.assertEqual(base, "# ARCHIVE VERSION")


# ═══════════════════════════════════════════════════════════════
# core/ota/checker.py
# ═══════════════════════════════════════════════════════════════

class TestOTAChecker(unittest.TestCase):

    def _make_releases_json(self, versions: list[str], channel: str = "stable") -> dict:
        return {
            "channel": channel,
            "releases": [
                {
                    "version": v,
                    "date": "2024-09-01",
                    "description": f"Release {v}",
                    "zip_url": f"https://example.com/{v}/framework.zip",
                    "sig_url": f"https://example.com/{v}/framework.zip.sig",
                    "manifest_url": f"https://example.com/{v}/manifest_core.json",
                    "sha256": "abc123",
                    "min_python": "3.10",
                }
                for v in versions
            ],
        }

    def test_parse_releases_returns_list(self) -> None:
        from core.ota.checker import parse_releases
        data = self._make_releases_json(["1.0.0", "1.0.1"])
        releases = parse_releases(data, "https://example.com", "stable")
        self.assertEqual(len(releases), 2)
        self.assertEqual(releases[0].version, "1.0.0")

    def test_get_latest_release_picks_highest(self) -> None:
        from core.ota.checker import parse_releases, get_latest_release
        data = self._make_releases_json(["1.0.0", "1.0.2", "1.0.1"])
        releases = parse_releases(data, "https://example.com", "stable")
        latest = get_latest_release(releases)
        self.assertEqual(latest.version, "1.0.2")

    def test_get_latest_release_returns_none_for_empty(self) -> None:
        from core.ota.checker import get_latest_release
        self.assertIsNone(get_latest_release([]))

    def test_check_python_compat_passes_current(self) -> None:
        from core.ota.checker import check_python_compat, ReleaseInfo
        r = ReleaseInfo("1.0.1","","","","","","",min_python="3.8")
        self.assertTrue(check_python_compat(r))

    def test_check_python_compat_fails_future(self) -> None:
        from core.ota.checker import check_python_compat, ReleaseInfo
        r = ReleaseInfo("1.0.1","","","","","","",min_python="99.0")
        self.assertFalse(check_python_compat(r))

    def test_check_for_update_no_repo(self) -> None:
        from core.ota.checker import check_for_update
        has, release, msg = check_for_update("1.0.0", "", "stable")
        self.assertFalse(has)
        self.assertIn("не задан", msg)

    def test_check_for_update_network_error(self) -> None:
        from core.ota.checker import check_for_update
        import urllib.error
        with patch("urllib.request.urlopen",
                   side_effect=urllib.error.URLError("connection refused")):
            has, release, msg = check_for_update("1.0.0", "https://example.com", "stable")
        self.assertFalse(has)
        self.assertIn("Сеть", msg)

    def test_check_for_update_already_latest(self) -> None:
        from core.ota.checker import check_for_update
        releases_data = self._make_releases_json(["1.0.0"])
        response_body = json.dumps(releases_data).encode()
        mock_resp = MagicMock()
        mock_resp.read.return_value = response_body
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_resp):
            has, release, msg = check_for_update("1.0.0", "https://example.com", "stable")
        self.assertFalse(has)
        self.assertIn("актуальн", msg)

    def test_check_for_update_finds_newer(self) -> None:
        from core.ota.checker import check_for_update
        releases_data = self._make_releases_json(["1.0.0", "1.0.1"])
        response_body = json.dumps(releases_data).encode()
        mock_resp = MagicMock()
        mock_resp.read.return_value = response_body
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_resp):
            has, release, msg = check_for_update("1.0.0", "https://example.com", "stable")
        self.assertTrue(has)
        self.assertEqual(release.version, "1.0.1")

    def test_github_raw_url_conversion(self) -> None:
        from core.ota.checker import _github_raw_url
        url = _github_raw_url("https://github.com/owner/repo", "stable", "releases.json")
        self.assertIn("raw.githubusercontent.com", url)
        self.assertIn("stable/releases.json", url)


# ═══════════════════════════════════════════════════════════════
# core/ota/downloader.py
# ═══════════════════════════════════════════════════════════════

class TestDownloader(WithTmpDir):

    def _make_release(self, sha256: str = "") -> "ReleaseInfo":
        from core.ota.checker import ReleaseInfo
        return ReleaseInfo(
            version="1.0.1", date="2024-09-01", description="Test",
            zip_url="https://example.com/fw.zip",
            sig_url="https://example.com/fw.zip.sig",
            manifest_url="https://example.com/manifest.json",
            sha256=sha256,
        )

    def _mock_urlopen(self, content: bytes):
        mock_resp = MagicMock()
        mock_resp.read.side_effect = [content, b""]
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        return mock_resp

    def test_download_returns_ok_without_sha256(self) -> None:
        import hashlib
        from core.ota.downloader import download_release
        release = self._make_release(sha256="")
        calls = [self._mock_urlopen(b"fake-zip-content"),
                 self._mock_urlopen(b"fake-sig")]
        with patch("urllib.request.urlopen", side_effect=calls):
            result = download_release(release, self.root / "dest")
        self.assertTrue(result.ok)

    def test_download_fails_on_wrong_sha256(self) -> None:
        from core.ota.downloader import download_release
        release = self._make_release(sha256="deadbeef" * 8)
        calls = [self._mock_urlopen(b"fake-zip-content"),
                 self._mock_urlopen(b"fake-sig")]
        with patch("urllib.request.urlopen", side_effect=calls):
            result = download_release(release, self.root / "dest")
        self.assertFalse(result.ok)
        self.assertIn("sha256", result.reason)

    def test_download_passes_with_correct_sha256(self) -> None:
        import hashlib
        from core.ota.downloader import download_release
        content = b"real-zip-content"
        correct_sha = hashlib.sha256(content).hexdigest()
        release = self._make_release(sha256=correct_sha)
        calls = [self._mock_urlopen(content),
                 self._mock_urlopen(b"sig")]
        with patch("urllib.request.urlopen", side_effect=calls):
            result = download_release(release, self.root / "dest")
        self.assertTrue(result.ok)

    def test_download_returns_error_on_network_failure(self) -> None:
        import urllib.error
        from core.ota.downloader import download_release
        release = self._make_release()
        with patch("urllib.request.urlopen",
                   side_effect=urllib.error.URLError("connection refused")):
            result = download_release(release, self.root / "dest")
        self.assertFalse(result.ok)
        self.assertIn("zip", result.reason)


# ═══════════════════════════════════════════════════════════════
# core/ota/verifier.py
# ═══════════════════════════════════════════════════════════════

class TestVerifier(WithTmpDir):

    def _make_unpacked(self) -> Path:
        """Создаёт минимальный 'распакованный' слот с manifest_core.json."""
        import json
        from core.manifest import compute_source_hash
        d = self.root / "unpacked"
        (d / "core").mkdir(parents=True)
        (d / "plugins").mkdir(parents=True)
        (d / "core" / "__init__.py").write_text("# x", encoding="utf-8")
        (d / "main.py").write_text("# main", encoding="utf-8")
        (d / "framework_manager.py").write_text("# pm", encoding="utf-8")
        (d / "plugins" / "base.py").write_text("# base", encoding="utf-8")
        h = compute_source_hash(d)
        manifest = {"version": "1.0.1", "sha256_hash": h, "name": "Test"}
        (d / "manifest_core.json").write_text(json.dumps(manifest), encoding="utf-8")
        return d

    def test_verify_unpacked_ok_with_correct_hash(self) -> None:
        from core.ota.verifier import verify_unpacked
        d = self._make_unpacked()
        result = verify_unpacked(d, skip_signature=True)
        self.assertTrue(result.ok)
        self.assertGreater(result.files_count, 0)

    def test_verify_unpacked_fails_with_wrong_hash(self) -> None:
        from core.ota.verifier import verify_unpacked, OTAVerifyError
        d = self._make_unpacked()
        import json
        manifest = json.loads((d / "manifest_core.json").read_text())
        manifest["sha256_hash"] = "deadbeef" * 8
        (d / "manifest_core.json").write_text(json.dumps(manifest), encoding="utf-8")
        with self.assertRaises(OTAVerifyError) as ctx:
            verify_unpacked(d, skip_signature=True)
        self.assertIn("провалилась", str(ctx.exception))

    def test_verify_unpacked_fails_without_manifest(self) -> None:
        from core.ota.verifier import verify_unpacked, OTAVerifyError
        d = self.root / "empty"
        d.mkdir()
        with self.assertRaises(OTAVerifyError):
            verify_unpacked(d, skip_signature=True)

    def test_extract_zip_rejects_zip_slip(self) -> None:
        import zipfile
        from core.ota.verifier import extract_zip, OTAVerifyError
        z = self.root / "evil.zip"
        with zipfile.ZipFile(z, "w") as zf:
            zf.writestr("../../../etc/passwd", "root:x:0:0")
        with self.assertRaises(OTAVerifyError) as ctx:
            extract_zip(z, self.root / "dest")
        self.assertIn("путь", str(ctx.exception).lower())

    def test_extract_zip_normal_succeeds(self) -> None:
        import zipfile
        from core.ota.verifier import extract_zip
        z = self.root / "fw.zip"
        with zipfile.ZipFile(z, "w") as zf:
            zf.writestr("core/__init__.py", "# init")
            zf.writestr("main.py", "# main")
        n = extract_zip(z, self.root / "dest")
        self.assertEqual(n, 2)
        self.assertTrue((self.root / "dest" / "main.py").exists())


# ═══════════════════════════════════════════════════════════════
# core/ota/process_manager.py
# ═══════════════════════════════════════════════════════════════

class TestProcessManager(unittest.TestCase):

    def test_detect_manager_plain_on_windows(self) -> None:
        from core.ota.process_manager import detect_manager
        with patch("sys.platform", "win32"):
            self.assertEqual(detect_manager("auto"), "plain")

    def test_detect_manager_plain_on_termux(self) -> None:
        from core.ota.process_manager import detect_manager
        with patch("core.ota.process_manager.is_termux", return_value=True):
            self.assertEqual(detect_manager("auto"), "plain")

    def test_detect_manager_respects_override(self) -> None:
        from core.ota.process_manager import detect_manager
        self.assertEqual(detect_manager("systemctl"), "systemctl")
        self.assertEqual(detect_manager("supervisor"), "supervisor")
        self.assertEqual(detect_manager("plain"), "plain")

    def test_is_termux_false_on_standard_linux(self) -> None:
        from core.ota.process_manager import is_termux
        with patch.dict(os.environ, {"PREFIX": "/usr"}, clear=False):
            # Not a guarantee but at least not crashing
            result = is_termux()
            self.assertIsInstance(result, bool)


# ═══════════════════════════════════════════════════════════════
# core/ota/notifier.py  (без реальной сети)
# ═══════════════════════════════════════════════════════════════

class TestNotifier(unittest.TestCase):

    def test_send_message_handles_network_error(self) -> None:
        import urllib.error
        from core.ota.notifier import _send_message
        with patch("urllib.request.urlopen",
                   side_effect=urllib.error.URLError("timeout")):
            result = _send_message("fake_token", "123", "hello")
        self.assertIsNone(result)

    def test_notify_rollback_does_not_raise_without_tg(self) -> None:
        from core.ota.notifier import notify_rollback
        # Без токена — только лог, не должно упасть
        notify_rollback("1.0.1", "тест", "", "")

    def test_notify_promote_done_does_not_raise_without_tg(self) -> None:
        from core.ota.notifier import notify_promote_done
        notify_promote_done("1.0.1", "", "")

    def test_get_updates_returns_list_on_error(self) -> None:
        import urllib.error
        from core.ota.notifier import _get_updates
        with patch("urllib.request.urlopen",
                   side_effect=urllib.error.URLError("network error")):
            result = _get_updates("fake_token", offset=0)
        self.assertEqual(result, [])


# ═══════════════════════════════════════════════════════════════
# config.py — OTA + Process sections
# ═══════════════════════════════════════════════════════════════

class TestConfigOTASections(WithTmpDir):

    def _write_env(self) -> None:
        Path("configs").mkdir(exist_ok=True)
        Path("configs/.env").write_text(
            "BOT_TOKEN=test123\nBOT_TOKEN_TEST=test456\nADMIN_CHAT_ID=789\n",
            encoding="utf-8",
        )

    def test_ota_defaults_when_no_config_json(self) -> None:
        self._write_env()
        from core.config import load_config
        cfg = load_config()
        self.assertEqual(cfg.ota.max_crashes, 3)
        self.assertEqual(cfg.ota.test_duration_s, 300)
        self.assertTrue(cfg.ota.interrupt_allowed)
        self.assertEqual(cfg.ota.interrupt_timeout_s, 60)
        self.assertFalse(cfg.ota.auto_check_on_startup)
        self.assertEqual(cfg.ota.notify_on_rollback, "log")
        self.assertEqual(cfg.ota.poll_interval_s, 5)
        self.assertEqual(cfg.ota.startup_grace_s, 10)

    def test_process_defaults_when_no_config_json(self) -> None:
        self._write_env()
        from core.config import load_config
        cfg = load_config()
        self.assertEqual(cfg.process.manager, "auto")
        self.assertEqual(cfg.process.unit_name, "accountmanager")
        self.assertEqual(cfg.process.supervisor_name, "accountmanager")

    def test_ota_fields_parsed_from_config_json(self) -> None:
        self._write_env()
        self.write_json("configs/config.json", {
            "ota": {
                "max_crashes": 5,
                "test_duration_s": 600,
                "interrupt_allowed": False,
                "interrupt_timeout_s": 30,
                "auto_check_on_startup": True,
                "notify_on_rollback": "telegram",
                "poll_interval_s": 3,
                "startup_grace_s": 7,
            }
        })
        from core.config import load_config
        cfg = load_config()
        self.assertEqual(cfg.ota.max_crashes, 5)
        self.assertEqual(cfg.ota.test_duration_s, 600)
        self.assertFalse(cfg.ota.interrupt_allowed)
        self.assertEqual(cfg.ota.interrupt_timeout_s, 30)
        self.assertTrue(cfg.ota.auto_check_on_startup)
        self.assertEqual(cfg.ota.notify_on_rollback, "telegram")
        self.assertEqual(cfg.ota.poll_interval_s, 3)
        self.assertEqual(cfg.ota.startup_grace_s, 7)

    def test_bot_token_test_read_from_env(self) -> None:
        self._write_env()
        from core.config import load_config
        cfg = load_config()
        self.assertEqual(cfg.bot_token_test, "test456")

    def test_admin_chat_id_read_from_env(self) -> None:
        self._write_env()
        from core.config import load_config
        cfg = load_config()
        self.assertEqual(cfg.admin_chat_id, "789")

    def test_process_manager_invalid_value_falls_back_to_auto(self) -> None:
        self._write_env()
        self.write_json("configs/config.json", {
            "process": {"manager": "kubernetes"}
        })
        from core.config import load_config
        cfg = load_config()
        self.assertEqual(cfg.process.manager, "auto")


if __name__ == "__main__":
    unittest.main()
