"""
tests/test_patches.py — core/patches.py: PatchManager (around/before/
after/replace, слоями поверх true_original).

Основной фокус — то, что легко перепутать при чтении докстринга, но
критично для корректности при нескольких плагинах, патчащих одно и то
же: порядок вызова слоёв РАЗНЫЙ для around/before (снаружи = последний
установленный, вызывается ПЕРВЫМ) и after (снаружи = последний
установленный, но вызывается ПОСЛЕДНИМ, видит уже изменённый result).
Плюс два обнаруженных при чтении кода пограничных случая:
  - around НЕ проверяет комбинацию "sync-цель + async-обёртка" (в
    отличие от before/after, где обратная несовместимость проверяется
    явно) — такой патч ставится без ошибки, но на вызове возвращает
    неawaited корутину вместо результата.
  - неудачная ПЕРВАЯ попытка пропатчить (target, attr) всё равно
    регистрирует пустую цепочку в PatchManager._chains (регистрация
    происходит до валидации).
"""
from __future__ import annotations

import dataclasses
import inspect
import unittest
from unittest.mock import patch

from tests._support import env  # noqa: F401

from core.patches import PatchError, PatchHandle, PatchManager, _safe_log_error


def _make_target_class():
    """Фабрика — КАЖДЫЙ тест, патчащий на уровне КЛАССА, должен получить
    свой свежий класс, иначе setattr(Class, attr, ...) в одном тесте
    заразит все остальные (классы — общие мутируемые объекты)."""

    class Target:
        def __init__(self) -> None:
            self.calls: list = []

        def sync_method(self, x):
            self.calls.append(("sync_method", x))
            return x * 2

        async def async_method(self, x):
            self.calls.append(("async_method", x))
            return x * 2

        def raises(self):
            raise ValueError("original boom")

    return Target


class _Target:
    """Для тестов патчинга на уровне ЭКЗЕМПЛЯРА — setattr(instance, ...)
    не трогает класс, так что повторное использование безопасно: каждый
    тест создаёт свой `_Target()`."""

    def sync_method(self, x):
        return x * 2

    async def async_method(self, x):
        return x * 2

    def raises(self):
        raise ValueError("original boom")


class AroundBasicTests(unittest.IsolatedAsyncioTestCase):
    async def test_sync_around_wraps_result(self) -> None:
        mgr = PatchManager()
        t = _Target()

        def wrapper(original, x):
            return original(x) + 1

        mgr.around(t, "sync_method", wrapper, plugin="p")
        self.assertEqual(t.sync_method(5), 11)

    async def test_async_around_wraps_result(self) -> None:
        mgr = PatchManager()
        t = _Target()

        async def wrapper(original, x):
            r = await original(x)
            return r + 1

        mgr.around(t, "async_method", wrapper, plugin="p")
        self.assertEqual(await t.async_method(5), 11)

    async def test_wrapper_can_short_circuit_and_never_call_original(self) -> None:
        mgr = PatchManager()
        t = _Target()
        original_calls = []
        real_sync = t.sync_method

        def spy(x):
            original_calls.append(x)
            return real_sync(x)

        t.sync_method = spy

        def wrapper(original, x):
            return "short-circuited"

        mgr.around(t, "sync_method", wrapper, plugin="p")
        self.assertEqual(t.sync_method(5), "short-circuited")
        self.assertEqual(original_calls, [])  # оригинал реально не вызывался

    async def test_class_level_patch_receives_self_explicitly(self) -> None:
        Target = _make_target_class()
        mgr = PatchManager()

        def wrapper(original, self_, x):
            return original(self_, x) + 1000

        mgr.around(Target, "sync_method", wrapper, plugin="p")
        t = Target()
        self.assertEqual(t.sync_method(5), 1010)

    async def test_wrapper_exception_propagates_to_caller(self) -> None:
        mgr = PatchManager()
        t = _Target()

        def wrapper(original, x):
            raise RuntimeError("wrapper boom")

        mgr.around(t, "sync_method", wrapper, plugin="p")
        with self.assertRaises(RuntimeError):
            t.sync_method(5)

    async def test_wrapper_exception_is_logged_with_plugin_name(self) -> None:
        mgr = PatchManager()
        t = _Target()

        def wrapper(original, x):
            raise RuntimeError("boom")

        mgr.around(t, "sync_method", wrapper, plugin="antispam")
        with self.assertLogs("patches", level="ERROR") as ctx:
            with self.assertRaises(RuntimeError):
                t.sync_method(5)
        self.assertIn("antispam", "\n".join(ctx.output))


class LayerOrderingTests(unittest.IsolatedAsyncioTestCase):
    async def test_around_last_installed_is_outermost(self) -> None:
        mgr = PatchManager()
        t = _Target()
        order = []

        def wrapper_a(original, x):
            order.append("A:before")
            r = original(x)
            order.append("A:after")
            return r

        def wrapper_b(original, x):
            order.append("B:before")
            r = original(x)
            order.append("B:after")
            return r

        mgr.around(t, "sync_method", wrapper_a, plugin="pluginA")
        mgr.around(t, "sync_method", wrapper_b, plugin="pluginB")
        t.sync_method(5)
        self.assertEqual(order, ["B:before", "A:before", "A:after", "B:after"])

    async def test_before_last_installed_fires_first(self) -> None:
        mgr = PatchManager()
        t = _Target()
        order = []
        mgr.before(t, "sync_method", lambda x: order.append("hookA"), plugin="pluginA")
        mgr.before(t, "sync_method", lambda x: order.append("hookB"), plugin="pluginB")
        t.sync_method(5)
        self.assertEqual(order, ["hookB", "hookA"])

    async def test_after_first_installed_fires_first_opposite_of_before(self) -> None:
        """
        Асимметрия, которую легко пропустить: для after «снаружи» всё
        равно последний установленный, НО он вызывается ПОСЛЕДНИМ (видит
        result уже после внутренних слоёв), а не первым, как для
        before/around.
        """
        mgr = PatchManager()
        t = _Target()
        order = []

        def hook_a(result, x):
            order.append("hookA")

        def hook_b(result, x):
            order.append("hookB")

        mgr.after(t, "sync_method", hook_a, plugin="pluginA")
        mgr.after(t, "sync_method", hook_b, plugin="pluginB")
        t.sync_method(5)
        self.assertEqual(order, ["hookA", "hookB"])

    async def test_after_hooks_chain_transformed_value_in_installation_order(self) -> None:
        mgr = PatchManager()
        t = _Target()
        mgr.after(t, "sync_method", lambda result, x: result + 100, plugin="pluginA")
        mgr.after(t, "sync_method", lambda result, x: result * 2, plugin="pluginB")
        # original: 5*2=10 -> +100 (pluginA, внутренний) = 110 -> *2 (pluginB, внешний) = 220
        self.assertEqual(t.sync_method(5), 220)

    async def test_async_around_layering_order_matches_sync(self) -> None:
        mgr = PatchManager()
        t = _Target()
        order = []

        async def wrapper_a(original, x):
            order.append("A:before")
            r = await original(x)
            order.append("A:after")
            return r

        async def wrapper_b(original, x):
            order.append("B:before")
            r = await original(x)
            order.append("B:after")
            return r

        mgr.around(t, "async_method", wrapper_a, plugin="pluginA")
        mgr.around(t, "async_method", wrapper_b, plugin="pluginB")
        await t.async_method(5)
        self.assertEqual(order, ["B:before", "A:before", "A:after", "B:after"])


class BeforeHookTests(unittest.IsolatedAsyncioTestCase):
    async def test_hook_runs_before_original_and_cannot_alter_args(self) -> None:
        mgr = PatchManager()
        t = _Target()
        seen = []
        mgr.before(t, "sync_method", lambda x: seen.append(x), plugin="p")
        result = t.sync_method(5)
        self.assertEqual(seen, [5])
        self.assertEqual(result, 10)  # неизменный результат оригинала

    async def test_raising_before_hook_does_not_prevent_original(self) -> None:
        mgr = PatchManager()
        t = _Target()

        def bad_hook(x):
            raise ValueError("hook boom")

        mgr.before(t, "sync_method", bad_hook, plugin="p")
        result = t.sync_method(5)  # не должно бросить
        self.assertEqual(result, 10)

    async def test_raising_before_hook_does_not_block_a_different_outer_layer(self) -> None:
        mgr = PatchManager()
        t = _Target()
        order = []

        def bad_inner_hook(x):
            order.append("inner-ran")
            raise ValueError("boom")

        def outer_hook(x):
            order.append("outer-ran")

        mgr.before(t, "sync_method", bad_inner_hook, plugin="pluginA")
        mgr.before(t, "sync_method", outer_hook, plugin="pluginB")
        t.sync_method(5)
        # outer (pluginB, установлен вторым) вызывается первым и не видит
        # исключение inner — они изолированы РАЗНЫМИ слоями.
        self.assertEqual(order, ["outer-ran", "inner-ran"])

    async def test_async_target_accepts_sync_before_hook(self) -> None:
        mgr = PatchManager()
        t = _Target()
        seen = []
        mgr.before(t, "async_method", lambda x: seen.append(x), plugin="p")
        result = await t.async_method(5)
        self.assertEqual(seen, [5])
        self.assertEqual(result, 10)

    async def test_async_target_accepts_async_before_hook(self) -> None:
        mgr = PatchManager()
        t = _Target()
        seen = []

        async def hook(x):
            seen.append(x)

        mgr.before(t, "async_method", hook, plugin="p")
        result = await t.async_method(5)
        self.assertEqual(seen, [5])
        self.assertEqual(result, 10)


class AfterHookTests(unittest.IsolatedAsyncioTestCase):
    async def test_hook_returning_none_leaves_result_unchanged(self) -> None:
        mgr = PatchManager()
        t = _Target()
        mgr.after(t, "sync_method", lambda result, x: None, plugin="p")
        self.assertEqual(t.sync_method(5), 10)

    async def test_hook_returning_value_replaces_result(self) -> None:
        mgr = PatchManager()
        t = _Target()
        mgr.after(t, "sync_method", lambda result, x: "replaced", plugin="p")
        self.assertEqual(t.sync_method(5), "replaced")

    async def test_raising_after_hook_leaves_result_as_it_was_before_that_hook(self) -> None:
        mgr = PatchManager()
        t = _Target()

        def bad_hook(result, x):
            raise ValueError("boom")

        mgr.after(t, "sync_method", bad_hook, plugin="p")
        self.assertEqual(t.sync_method(5), 10)  # исходный результат original, не тронут

    async def test_async_after_hook_can_be_awaited(self) -> None:
        mgr = PatchManager()
        t = _Target()

        async def hook(result, x):
            return result + 1

        mgr.after(t, "async_method", hook, plugin="p")
        self.assertEqual(await t.async_method(5), 11)


class ReplaceModeTests(unittest.IsolatedAsyncioTestCase):
    async def test_replace_fully_substitutes_attribute(self) -> None:
        mgr = PatchManager()
        t = _Target()
        mgr.replace(t, "sync_method", lambda x: "replaced-entirely", plugin="p")
        self.assertEqual(t.sync_method(5), "replaced-entirely")

    async def test_replace_on_missing_attribute_requires_create_if_missing(self) -> None:
        mgr = PatchManager()
        t = _Target()
        with self.assertRaises(PatchError):
            mgr.replace(t, "brand_new_attr", "value", plugin="p")

    async def test_replace_with_create_if_missing_succeeds(self) -> None:
        mgr = PatchManager()
        t = _Target()
        mgr.replace(t, "brand_new_attr", "value", plugin="p", create_if_missing=True)
        self.assertEqual(t.brand_new_attr, "value")

    async def test_reverting_a_created_attribute_now_deletes_it(self) -> None:
        """
        Раньше revert() восстанавливал chain.true_original — а для
        create_if_missing-атрибута true_original был None (атрибута не
        было), так что после revert атрибут ОСТАВАЛСЯ существовать (со
        значением None), а не исчезал. Теперь используется сентинел
        _MISSING, отличающий "атрибута не было" от "атрибут был None",
        и revert корректно делает delattr.
        """
        mgr = PatchManager()
        t = _Target()
        handle = mgr.replace(t, "brand_new_attr", "value", plugin="p", create_if_missing=True)
        mgr.revert(handle)
        self.assertFalse(hasattr(t, "brand_new_attr"))

    async def test_reverting_a_created_attribute_that_genuinely_had_value_none_still_works(self) -> None:
        # Отличаем "атрибута не было" от "атрибут СУЩЕСТВОВАЛ и был None" —
        # второй случай должен остаться None после revert, а не исчезнуть.
        mgr = PatchManager()
        t = _Target()
        t.existing_none_attr = None
        handle = mgr.replace(t, "existing_none_attr", "value", plugin="p", create_if_missing=True)
        self.assertEqual(t.existing_none_attr, "value")
        mgr.revert(handle)
        self.assertTrue(hasattr(t, "existing_none_attr"))
        self.assertIsNone(t.existing_none_attr)

    async def test_replace_stacked_on_top_of_around_hides_it_but_preserves_the_layer(self) -> None:
        mgr = PatchManager()
        t = _Target()

        def double_plus_one(original, x):
            return original(x) + 1

        around_handle = mgr.around(t, "sync_method", double_plus_one, plugin="pluginA")
        self.assertEqual(t.sync_method(5), 11)

        replace_handle = mgr.replace(t, "sync_method", lambda x: "replaced", plugin="pluginB")
        self.assertEqual(t.sync_method(5), "replaced")  # around-слой временно невидим

        mgr.revert(replace_handle)
        self.assertEqual(t.sync_method(5), 11)  # around-слой снова виден как ни в чём не бывало

        mgr.revert(around_handle)
        self.assertEqual(t.sync_method(5), 10)  # обратно к истинному оригиналу


class ValidationTests(unittest.IsolatedAsyncioTestCase):
    async def test_around_rejects_non_callable_payload(self) -> None:
        mgr = PatchManager()
        t = _Target()
        with self.assertRaises(PatchError):
            mgr.around(t, "sync_method", "not-callable", plugin="p")

    async def test_around_on_async_target_requires_async_wrapper(self) -> None:
        mgr = PatchManager()
        t = _Target()

        def sync_wrapper(original, x):
            return x

        with self.assertRaises(PatchError):
            mgr.around(t, "async_method", sync_wrapper, plugin="p")

    async def test_around_on_sync_target_with_async_wrapper_is_now_rejected(self) -> None:
        """
        Раньше _validate_callable_shape для mode "around" проверял
        ТОЛЬКО одно направление (async-цель требует async-обёртку).
        Обратная комбинация — sync-цель, async-обёртка — не отклонялась,
        хотя рантайм-поведение было сломано: вызов async-функции без
        await просто возвращал объект корутины, а не результат. Теперь
        обе комбинации отклоняются симметрично.
        """
        mgr = PatchManager()
        t = _Target()

        async def async_wrapper(original, x):
            return original(x) + 1

        with self.assertRaises(PatchError):
            mgr.around(t, "sync_method", async_wrapper, plugin="p")
        # атрибут цели не пострадал -- патч не установился вообще
        self.assertEqual(t.sync_method(5), 10)

    async def test_before_on_sync_target_rejects_async_hook(self) -> None:
        mgr = PatchManager()
        t = _Target()

        async def async_hook(x):
            pass

        with self.assertRaises(PatchError):
            mgr.before(t, "sync_method", async_hook, plugin="p")

    async def test_after_on_sync_target_rejects_async_hook(self) -> None:
        mgr = PatchManager()
        t = _Target()

        async def async_hook(result, x):
            pass

        with self.assertRaises(PatchError):
            mgr.after(t, "sync_method", async_hook, plugin="p")

    async def test_missing_attribute_without_create_if_missing_raises(self) -> None:
        mgr = PatchManager()
        t = _Target()
        with self.assertRaises(PatchError):
            mgr.around(t, "does_not_exist", lambda original: None, plugin="p")

    async def test_failed_first_validation_no_longer_registers_a_ghost_chain(self) -> None:
        """
        Раньше неудачная ПЕРВАЯ попытка патча регистрировала chain в
        self._chains ДО валидации — пустая цепочка (layers=[]) оставалась
        там навсегда, ничем не убираемая. Теперь валидация происходит
        ДО регистрации: self._chains остаётся нетронутым при провале.
        """
        mgr = PatchManager()
        t = _Target()
        key = (id(t), "sync_method")
        self.assertNotIn(key, mgr._chains)

        with self.assertRaises(PatchError):
            mgr.around(t, "sync_method", "not-callable", plugin="p")

        self.assertNotIn(key, mgr._chains)  # никакой "призрачной" записи
        self.assertEqual(t.sync_method(5), 10)  # атрибут цели не пострадал

        # Последующий УСПЕШНЫЙ патч на то же (target, attr) создаёт
        # чистую запись с нуля и работает корректно.
        mgr.around(t, "sync_method", lambda original, x: original(x) + 1, plugin="p")
        self.assertEqual(t.sync_method(5), 11)
        self.assertEqual(len(mgr._chains), 1)


class RevertTests(unittest.IsolatedAsyncioTestCase):
    async def test_revert_unknown_handle_returns_false(self) -> None:
        mgr = PatchManager()
        fake_handle = PatchHandle(id=99999, plugin="p", target_key=(1, "nope"))
        self.assertFalse(mgr.revert(fake_handle))

    async def test_revert_restores_true_original_when_last_layer_removed(self) -> None:
        mgr = PatchManager()
        t = _Target()
        handle = mgr.around(t, "sync_method", lambda original, x: original(x) + 1, plugin="p")
        self.assertEqual(t.sync_method(5), 11)
        self.assertTrue(mgr.revert(handle))
        self.assertEqual(t.sync_method(5), 10)

    async def test_revert_removes_chain_entry_when_empty(self) -> None:
        mgr = PatchManager()
        t = _Target()
        key = (id(t), "sync_method")
        handle = mgr.around(t, "sync_method", lambda original, x: original(x), plugin="p")
        mgr.revert(handle)
        self.assertNotIn(key, mgr._chains)

    async def test_revert_one_of_several_layers_keeps_the_rest(self) -> None:
        mgr = PatchManager()
        t = _Target()
        h1 = mgr.around(t, "sync_method", lambda original, x: original(x) + 1, plugin="pluginA")
        mgr.around(t, "sync_method", lambda original, x: original(x) * 10, plugin="pluginB")
        # original=10 -> +1 (A, inner) = 11 -> *10 (B, outer) = 110
        self.assertEqual(t.sync_method(5), 110)
        mgr.revert(h1)
        # только B остаётся: original=10 -> *10 = 100
        self.assertEqual(t.sync_method(5), 100)

    async def test_revert_same_handle_twice_returns_false_second_time(self) -> None:
        mgr = PatchManager()
        t = _Target()
        handle = mgr.around(t, "sync_method", lambda original, x: original(x), plugin="p")
        self.assertTrue(mgr.revert(handle))
        self.assertFalse(mgr.revert(handle))

    async def test_reverting_middle_layer_preserves_relative_order_of_the_rest(self) -> None:
        mgr = PatchManager()
        t = _Target()
        order = []
        mgr.before(t, "sync_method", lambda x: order.append("A"), plugin="pluginA")
        h_mid = mgr.before(t, "sync_method", lambda x: order.append("B"), plugin="pluginB")
        mgr.before(t, "sync_method", lambda x: order.append("C"), plugin="pluginC")
        mgr.revert(h_mid)
        t.sync_method(5)
        # C (последний установленный) всё ещё первым, затем A
        self.assertEqual(order, ["C", "A"])


class RevertPluginTests(unittest.IsolatedAsyncioTestCase):
    async def test_removes_all_patches_for_a_plugin_across_multiple_targets(self) -> None:
        mgr = PatchManager()
        t1, t2 = _Target(), _Target()

        async def noop_async_wrapper(original, x):
            return await original(x)

        mgr.around(t1, "sync_method", lambda original, x: original(x) + 1, plugin="pluginA")
        mgr.around(t2, "sync_method", lambda original, x: original(x) + 2, plugin="pluginA")
        mgr.around(t1, "async_method", noop_async_wrapper, plugin="pluginB")  # другой плагин

        removed = mgr.revert_plugin("pluginA")
        self.assertEqual(removed, 2)
        self.assertEqual(t1.sync_method(5), 10)
        self.assertEqual(t2.sync_method(5), 10)

    async def test_plugin_with_no_patches_returns_zero(self) -> None:
        mgr = PatchManager()
        t = _Target()
        mgr.around(t, "sync_method", lambda original, x: original(x), plugin="someone-else")
        self.assertEqual(mgr.revert_plugin("ghost-plugin"), 0)

    async def test_mixed_chain_keeps_other_plugins_layers_in_order(self) -> None:
        mgr = PatchManager()
        t = _Target()
        order = []
        mgr.before(t, "sync_method", lambda x: order.append("A"), plugin="pluginA")
        mgr.before(t, "sync_method", lambda x: order.append("B"), plugin="pluginB")
        mgr.before(t, "sync_method", lambda x: order.append("C"), plugin="pluginC")
        mgr.revert_plugin("pluginB")
        t.sync_method(5)
        self.assertEqual(order, ["C", "A"])


class ListActiveTests(unittest.IsolatedAsyncioTestCase):
    async def test_empty_manager_lists_nothing(self) -> None:
        mgr = PatchManager()
        self.assertEqual(mgr.list_active(), [])

    async def test_lists_position_and_total_per_chain(self) -> None:
        mgr = PatchManager()
        t = _Target()
        mgr.around(t, "sync_method", lambda original, x: original(x), plugin="pluginA")
        mgr.around(t, "sync_method", lambda original, x: original(x), plugin="pluginB")
        active = mgr.list_active()
        self.assertEqual(len(active), 2)
        self.assertEqual([e["plugin"] for e in active], ["pluginA", "pluginB"])
        self.assertEqual([e["position"] for e in active], [1, 2])
        self.assertEqual([e["of"] for e in active], [2, 2])

    async def test_target_description_differs_between_class_and_instance_patching(self) -> None:
        mgr = PatchManager()
        Target = _make_target_class()
        instance = _Target()

        mgr.around(Target, "sync_method", lambda original, self_, x: original(self_, x), plugin="p1")
        mgr.around(instance, "sync_method", lambda original, x: original(x), plugin="p2")

        active = mgr.list_active()
        by_plugin = {e["plugin"]: e["target"] for e in active}
        # Патч на класс -> использует __qualname__ (содержит путь фабрики)
        self.assertIn("Target", by_plugin["p1"])
        self.assertIn("_make_target_class", by_plugin["p1"])
        # Патч на экземпляр -> falls back на type(instance).__name__ (без "<locals>")
        self.assertNotIn("_make_target_class", by_plugin["p2"])
        self.assertTrue(by_plugin["p2"].startswith("_Target."))


class SafeLogErrorTests(unittest.TestCase):
    def test_recursion_error_is_never_logged(self) -> None:
        with patch("core.patches.logger") as mock_logger:
            _safe_log_error("msg", RecursionError())
        mock_logger.error.assert_not_called()

    def test_other_exceptions_are_logged_with_exc_info(self) -> None:
        with patch("core.patches.logger") as mock_logger:
            _safe_log_error("msg", ValueError("boom"))
        mock_logger.error.assert_called_once_with("msg", exc_info=True)

    def test_logging_failure_itself_is_swallowed(self) -> None:
        with patch("core.patches.logger") as mock_logger:
            mock_logger.error.side_effect = Exception("logging is broken too")
            _safe_log_error("msg", ValueError("boom"))  # не должно бросить


class PatchHandleTests(unittest.TestCase):
    def test_is_frozen(self) -> None:
        handle = PatchHandle(id=1, plugin="p", target_key=(1, "attr"))
        with self.assertRaises(dataclasses.FrozenInstanceError):
            handle.id = 2  # type: ignore[misc]


if __name__ == "__main__":
    unittest.main()
