"""
tests/test_hooks.py — core/hooks.py: HookBus (шина событий).

Фокус — то, что явно объявлено контрактом модуля: изоляция ошибок
обработчиков, порядок по priority (стабильный при равенстве), семантика
wildcard "*", отсутствие утечки пустых bucket'ов в self._subs, и
устойчивость emit() к модификации подписок ИЗ обработчика во время
самого emit().
"""
from __future__ import annotations

import dataclasses
import unittest

from tests._support import env  # noqa: F401

from core.hooks import HookBus, HookHandle


class _Awaitable:
    """Произвольный awaitable, который не является корутиной/coroutine function —
    проверяет, что _call_maybe_async полагается на inspect.isawaitable(),
    а не на inspect.iscoroutinefunction()."""

    def __init__(self, value):
        self._value = value

    def __await__(self):
        async def _inner():
            return self._value
        return _inner().__await__()

    def __call__(self):
        return self


class BasicSubscribeEmitTests(unittest.IsolatedAsyncioTestCase):
    async def test_single_handler_called_with_args_and_kwargs(self) -> None:
        bus = HookBus()
        calls = []

        def handler(*a, **kw):
            calls.append((a, kw))
            return "ok"

        bus.on("evt", handler, plugin="p1")
        results = await bus.emit("evt", 1, 2, foo="bar")
        self.assertEqual(calls, [((1, 2), {"foo": "bar"})])
        self.assertEqual(results, ["ok"])

    async def test_no_subscribers_returns_empty_list(self) -> None:
        bus = HookBus()
        results = await bus.emit("nobody-listens")
        self.assertEqual(results, [])

    async def test_async_handler_is_awaited(self) -> None:
        bus = HookBus()

        async def handler(x):
            return x * 2

        bus.on("evt", handler, plugin="p1")
        results = await bus.emit("evt", 21)
        self.assertEqual(results, [42])

    async def test_arbitrary_awaitable_object_is_awaited_not_just_coroutines(self) -> None:
        bus = HookBus()
        bus.on("evt", _Awaitable("from-awaitable"), plugin="p1")
        results = await bus.emit("evt")
        self.assertEqual(results, ["from-awaitable"])

    async def test_mixed_sync_and_async_handlers_on_same_event(self) -> None:
        bus = HookBus()

        def sync_h():
            return "sync"

        async def async_h():
            return "async"

        bus.on("evt", sync_h, plugin="p1", priority=10)
        bus.on("evt", async_h, plugin="p2", priority=20)
        results = await bus.emit("evt")
        self.assertEqual(results, ["sync", "async"])

    async def test_multiple_independent_bus_instances_do_not_share_subscriptions(self) -> None:
        bus1 = HookBus()
        bus2 = HookBus()
        bus1.on("evt", lambda: "from-bus1", plugin="p1")
        results_bus2 = await bus2.emit("evt")
        self.assertEqual(results_bus2, [])


class PriorityOrderingTests(unittest.IsolatedAsyncioTestCase):
    async def test_lower_priority_number_runs_first(self) -> None:
        bus = HookBus()
        order = []
        bus.on("evt", lambda: order.append("high-number-100"), plugin="p", priority=100)
        bus.on("evt", lambda: order.append("low-number-1"), plugin="p", priority=1)
        bus.on("evt", lambda: order.append("mid-number-50"), plugin="p", priority=50)
        await bus.emit("evt")
        self.assertEqual(order, ["low-number-1", "mid-number-50", "high-number-100"])

    async def test_equal_priority_preserves_registration_order(self) -> None:
        bus = HookBus()
        order = []
        bus.on("evt", lambda: order.append("first"), plugin="p", priority=50)
        bus.on("evt", lambda: order.append("second"), plugin="p", priority=50)
        bus.on("evt", lambda: order.append("third"), plugin="p", priority=50)
        await bus.emit("evt")
        self.assertEqual(order, ["first", "second", "third"])

    async def test_default_priority_is_100(self) -> None:
        bus = HookBus()
        order = []
        bus.on("evt", lambda: order.append("explicit-1"), plugin="p", priority=1)
        bus.on("evt", lambda: order.append("default"), plugin="p")  # priority=100
        bus.on("evt", lambda: order.append("explicit-200"), plugin="p", priority=200)
        await bus.emit("evt")
        self.assertEqual(order, ["explicit-1", "default", "explicit-200"])


class OffTests(unittest.IsolatedAsyncioTestCase):
    async def test_off_removes_handler(self) -> None:
        bus = HookBus()
        calls = []
        handle = bus.on("evt", lambda: calls.append(1), plugin="p")
        self.assertTrue(bus.off(handle))
        await bus.emit("evt")
        self.assertEqual(calls, [])

    async def test_off_returns_false_for_unknown_event(self) -> None:
        bus = HookBus()
        fake_handle = HookHandle(id=999999, event="never-subscribed", plugin="p")
        self.assertFalse(bus.off(fake_handle))

    async def test_off_twice_returns_false_second_time(self) -> None:
        bus = HookBus()
        handle = bus.on("evt", lambda: None, plugin="p")
        self.assertTrue(bus.off(handle))
        self.assertFalse(bus.off(handle))

    async def test_off_one_of_several_leaves_others_intact(self) -> None:
        bus = HookBus()
        calls = []
        h1 = bus.on("evt", lambda: calls.append("a"), plugin="p")
        bus.on("evt", lambda: calls.append("b"), plugin="p")
        bus.off(h1)
        await bus.emit("evt")
        self.assertEqual(calls, ["b"])

    async def test_off_empties_bucket_removes_event_key_entirely(self) -> None:
        # Whitebox: без этой очистки self._subs накапливал бы пустые
        # списки по каждому уникальному имени события навсегда.
        bus = HookBus()
        handle = bus.on("some.unique.event", lambda: None, plugin="p")
        self.assertIn("some.unique.event", bus._subs)
        bus.off(handle)
        self.assertNotIn("some.unique.event", bus._subs)

    async def test_large_scale_subscribe_unsubscribe_cycle_leaves_no_leftover_state(self) -> None:
        """
        Повторяет сценарий из комментария в исходнике (там эмпирически
        проверяли 50 000 циклов) в уменьшенном, но всё ещё нетривиальном
        масштабе — каждый цикл на СВОЁМ уникальном имени события, как в
        реальном сценарии per-user событий.
        """
        bus = HookBus()
        for i in range(5000):
            handle = bus.on(f"evt.user.{i}", lambda: None, plugin="p")
            bus.off(handle)
        self.assertEqual(len(bus._subs), 0)


class RemoveAllForTests(unittest.IsolatedAsyncioTestCase):
    async def test_removes_only_specified_plugin_across_multiple_events(self) -> None:
        bus = HookBus()
        calls = []
        bus.on("evt1", lambda: calls.append("p1-evt1"), plugin="p1")
        bus.on("evt1", lambda: calls.append("p2-evt1"), plugin="p2")
        bus.on("evt2", lambda: calls.append("p1-evt2"), plugin="p1")
        removed = bus.remove_all_for("p1")
        self.assertEqual(removed, 2)
        await bus.emit("evt1")
        await bus.emit("evt2")
        self.assertEqual(calls, ["p2-evt1"])

    async def test_plugin_with_no_subscriptions_returns_zero(self) -> None:
        bus = HookBus()
        bus.on("evt", lambda: None, plugin="someone-else")
        self.assertEqual(bus.remove_all_for("ghost-plugin"), 0)

    async def test_leaves_no_empty_event_keys_behind(self) -> None:
        bus = HookBus()
        bus.on("evt1", lambda: None, plugin="p1")
        bus.on("evt2", lambda: None, plugin="p1")
        bus.remove_all_for("p1")
        self.assertEqual(bus._subs, {})

    async def test_partial_removal_keeps_remaining_subs_relative_order(self) -> None:
        bus = HookBus()
        order = []
        bus.on("evt", lambda: order.append("p1"), plugin="p1", priority=10)
        bus.on("evt", lambda: order.append("p2-a"), plugin="p2", priority=20)
        bus.on("evt", lambda: order.append("p2-b"), plugin="p2", priority=30)
        bus.remove_all_for("p1")
        await bus.emit("evt")
        self.assertEqual(order, ["p2-a", "p2-b"])


class ErrorIsolationTests(unittest.IsolatedAsyncioTestCase):
    async def test_raising_handler_does_not_stop_others_or_propagate(self) -> None:
        bus = HookBus()
        calls = []

        def bad(*a, **kw):
            raise ValueError("boom")

        def good(*a, **kw):
            calls.append("good-ran")
            return "good-result"

        bus.on("evt", bad, plugin="bad-plugin", priority=1)
        bus.on("evt", good, plugin="good-plugin", priority=2)

        results = await bus.emit("evt")  # не должно бросить
        self.assertEqual(calls, ["good-ran"])
        self.assertEqual(results, ["good-result"])  # упавший обработчик не попал в results

    async def test_raising_async_handler_is_also_isolated(self) -> None:
        bus = HookBus()

        async def bad():
            raise RuntimeError("async boom")

        bus.on("evt", bad, plugin="bad-plugin")
        results = await bus.emit("evt")  # не должно бросить
        self.assertEqual(results, [])

    async def test_error_is_logged_with_event_and_plugin_name(self) -> None:
        bus = HookBus()

        def bad():
            raise ValueError("boom")

        bus.on("payment.processed", bad, plugin="antispam")
        with self.assertLogs("hooks", level="ERROR") as log_ctx:
            await bus.emit("payment.processed")
        joined = "\n".join(log_ctx.output)
        self.assertIn("payment.processed", joined)
        self.assertIn("antispam", joined)


class EmitFilterTests(unittest.IsolatedAsyncioTestCase):
    async def test_value_passes_through_unchanged_with_no_subscribers(self) -> None:
        bus = HookBus()
        result = await bus.emit_filter("evt", "original")
        self.assertEqual(result, "original")

    async def test_handler_returning_none_leaves_value_unchanged(self) -> None:
        bus = HookBus()
        bus.on("evt", lambda v: None, plugin="p")
        result = await bus.emit_filter("evt", "original")
        self.assertEqual(result, "original")

    async def test_handler_returning_new_value_replaces_it(self) -> None:
        bus = HookBus()
        bus.on("evt", lambda v: v.upper(), plugin="p")
        result = await bus.emit_filter("evt", "hello")
        self.assertEqual(result, "HELLO")

    async def test_chained_transformations_across_multiple_handlers_in_priority_order(self) -> None:
        bus = HookBus()
        bus.on("evt", lambda v: v + "-a", plugin="p1", priority=1)
        bus.on("evt", lambda v: v + "-b", plugin="p2", priority=2)
        bus.on("evt", lambda v: v + "-c", plugin="p3", priority=3)
        result = await bus.emit_filter("evt", "start")
        self.assertEqual(result, "start-a-b-c")

    async def test_extra_args_and_kwargs_passed_through_alongside_value(self) -> None:
        bus = HookBus()
        seen = []

        def handler(value, extra, flag=None):
            seen.append((value, extra, flag))
            return value

        bus.on("evt", handler, plugin="p")
        await bus.emit_filter("evt", "val", "extra-positional", flag="on")
        self.assertEqual(seen, [("val", "extra-positional", "on")])

    async def test_raising_handler_leaves_value_as_it_was_before_that_handler(self) -> None:
        bus = HookBus()

        def first(v):
            return v + "-first"

        def bad(v):
            raise ValueError("boom")

        def third(v):
            return v + "-third"

        bus.on("evt", first, plugin="p1", priority=1)
        bus.on("evt", bad, plugin="p2", priority=2)
        bus.on("evt", third, plugin="p3", priority=3)

        result = await bus.emit_filter("evt", "start")
        # bad() не откатывает то, что уже сделал first(), и не мешает third()
        self.assertEqual(result, "start-first-third")

    async def test_async_filter_handlers_work_too(self) -> None:
        bus = HookBus()

        async def handler(v):
            return v * 2

        bus.on("evt", handler, plugin="p")
        result = await bus.emit_filter("evt", 21)
        self.assertEqual(result, 42)


class WildcardTests(unittest.IsolatedAsyncioTestCase):
    async def test_wildcard_handler_receives_event_name_and_args(self) -> None:
        bus = HookBus()
        seen = []
        bus.on(HookBus.WILDCARD, lambda ev, *a, **kw: seen.append((ev, a, kw)), plugin="audit")
        bus.on("payment.processed", lambda *a, **kw: "ignored", plugin="p")
        await bus.emit("payment.processed", 42, currency="USD")
        self.assertEqual(seen, [("payment.processed", (42,), {"currency": "USD"})])

    async def test_wildcard_fires_for_every_distinct_event(self) -> None:
        bus = HookBus()
        seen_events = []
        bus.on("*", lambda ev, *a, **kw: seen_events.append(ev), plugin="audit")
        await bus.emit("evt.one")
        await bus.emit("evt.two")
        await bus.emit("evt.three")
        self.assertEqual(seen_events, ["evt.one", "evt.two", "evt.three"])

    async def test_emitting_wildcard_event_directly_does_not_double_invoke(self) -> None:
        bus = HookBus()
        calls = []
        bus.on("*", lambda *a, **kw: calls.append(a), plugin="audit")
        await bus.emit("*", "payload")
        self.assertEqual(len(calls), 1)

    async def test_wildcard_results_are_not_mixed_into_normal_results_list(self) -> None:
        bus = HookBus()
        bus.on("*", lambda ev, *a, **kw: "wildcard-value", plugin="audit")
        bus.on("evt", lambda: "normal-value", plugin="p")
        results = await bus.emit("evt")
        self.assertEqual(results, ["normal-value"])

    async def test_wildcard_handler_error_is_isolated(self) -> None:
        bus = HookBus()

        def bad_wildcard(ev, *a, **kw):
            raise ValueError("wildcard boom")

        calls = []

        def marker():
            calls.append("ran")
            return "marker-result"

        bus.on("*", bad_wildcard, plugin="bad-audit")
        bus.on("evt", marker, plugin="p")
        results = await bus.emit("evt")  # не должно бросить
        self.assertEqual(calls, ["ran"])
        self.assertEqual(results, ["marker-result"])

    async def test_wildcard_sees_emit_filter_as_value_plus_args(self) -> None:
        bus = HookBus()
        seen = []
        bus.on("*", lambda ev, *a, **kw: seen.append((ev, a, kw)), plugin="audit")
        # Обычный обработчик "evt" тоже должен уметь принять доп. args/kwargs,
        # которые emit_filter прокидывает вместе с value.
        bus.on("evt", lambda v, *a, **kw: v + "!", plugin="p")
        await bus.emit_filter("evt", "hi", "extra", tag="x")
        # wildcard видит value уже ПОСЛЕ обработки обычными подписчиками события
        self.assertEqual(seen, [("evt", ("hi!", "extra"), {"tag": "x"})])

    async def test_no_wildcard_subscribers_is_a_silent_noop(self) -> None:
        bus = HookBus()
        bus.on("evt", lambda: "x", plugin="p")
        results = await bus.emit("evt")  # не должно бросить, даже без "*" вообще
        self.assertEqual(results, ["x"])


class ConcurrentModificationDuringEmitTests(unittest.IsolatedAsyncioTestCase):
    async def test_handler_unsubscribing_itself_mid_emit_does_not_crash(self) -> None:
        bus = HookBus()
        calls = []

        def self_removing():
            calls.append("ran")
            bus.off(handle)

        handle = bus.on("evt", self_removing, plugin="p")
        await bus.emit("evt")  # не должно бросить
        self.assertEqual(calls, ["ran"])
        # и вторая эмиссия действительно больше не вызывает обработчик
        await bus.emit("evt")
        self.assertEqual(calls, ["ran"])

    async def test_handler_subscribing_new_handler_mid_emit_does_not_run_it_same_pass(self) -> None:
        bus = HookBus()
        calls = []

        def adds_new_handler():
            calls.append("original-ran")
            bus.on("evt", lambda: calls.append("newly-added-ran"), plugin="p2")

        bus.on("evt", adds_new_handler, plugin="p1")
        await bus.emit("evt")
        # добавленный обработчик не должен сработать в ЭТОМ же emit()
        self.assertEqual(calls, ["original-ran"])
        calls.clear()
        # но сработает при следующем emit()
        await bus.emit("evt")
        self.assertEqual(sorted(calls), ["newly-added-ran", "original-ran"])

    async def test_handler_removing_a_different_handler_mid_emit_is_safe(self) -> None:
        bus = HookBus()
        calls = []

        def remover():
            calls.append("remover-ran")
            bus.off(victim_handle)

        def victim():
            calls.append("victim-ran")

        bus.on("evt", remover, plugin="p1", priority=1)
        victim_handle = bus.on("evt", victim, plugin="p2", priority=2)
        await bus.emit("evt")
        # victim уже был скопирован в список для текущего emit() ДО удаления
        self.assertEqual(calls, ["remover-ran", "victim-ran"])
        calls.clear()
        await bus.emit("evt")
        self.assertEqual(calls, ["remover-ran"])  # а тут victim и правда снят


class ListHooksTests(unittest.IsolatedAsyncioTestCase):
    async def test_list_all_hooks_groups_by_event(self) -> None:
        bus = HookBus()
        bus.on("evt1", lambda: None, plugin="p1")
        bus.on("evt1", lambda: None, plugin="p2")
        bus.on("evt2", lambda: None, plugin="p3")
        result = bus.list_hooks()
        self.assertEqual(set(result.keys()), {"evt1", "evt2"})
        self.assertEqual(sorted(result["evt1"]), ["p1", "p2"])
        self.assertEqual(result["evt2"], ["p3"])

    async def test_list_hooks_for_specific_event_respects_priority_order(self) -> None:
        bus = HookBus()
        bus.on("evt", lambda: None, plugin="low-prio", priority=100)
        bus.on("evt", lambda: None, plugin="high-prio", priority=1)
        result = bus.list_hooks("evt")
        self.assertEqual(result, {"evt": ["high-prio", "low-prio"]})

    async def test_list_hooks_for_event_with_no_subscribers_returns_empty_list_not_error(self) -> None:
        bus = HookBus()
        result = bus.list_hooks("nobody-home")
        self.assertEqual(result, {"nobody-home": []})

    async def test_list_hooks_on_fresh_bus_is_empty_dict(self) -> None:
        bus = HookBus()
        self.assertEqual(bus.list_hooks(), {})


class HookHandleTests(unittest.TestCase):
    def test_is_frozen_dataclass(self) -> None:
        handle = HookHandle(id=1, event="evt", plugin="p")
        with self.assertRaises(dataclasses.FrozenInstanceError):
            handle.id = 2  # type: ignore[misc]

    def test_ids_increase_monotonically_across_subscriptions(self) -> None:
        bus = HookBus()
        h1 = bus.on("evt", lambda: None, plugin="p")
        h2 = bus.on("evt", lambda: None, plugin="p")
        self.assertLess(h1.id, h2.id)

    def test_ids_are_unique_across_different_bus_instances(self) -> None:
        # _id_counter в core.hooks — модульный (общий для ВСЕХ HookBus).
        bus1 = HookBus()
        bus2 = HookBus()
        h1 = bus1.on("evt", lambda: None, plugin="p")
        h2 = bus2.on("evt", lambda: None, plugin="p")
        self.assertNotEqual(h1.id, h2.id)


if __name__ == "__main__":
    unittest.main()
