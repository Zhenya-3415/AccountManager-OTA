"""
tests/test_scheduler.py — core/scheduler.py: Scheduler (interval/cron/
once, misfire/catch-up, max_concurrent) и вспомогательный 5-полевой cron.

Персистентность (_load_last_run/_save_last_run) тестируется через
лёгкий фейковый db-объект в памяти (не настоящий SQLite) — это
намеренно: здесь проверяется логика ПЛАНИРОВЩИКА (что он делает с
last_run_at), а не корректность самого SQL, для которой есть
test_sqlite_backend.py.

Живые асинхронные тесты (_run_job/_fire/_wait_until) используют очень
короткие интервалы (доли секунды), чтобы не раздувать время прогона.
"""
from __future__ import annotations

import asyncio
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from tests._support import env  # noqa: F401

from core.scheduler import CronSyntaxError, JobHandle, Scheduler, _CronExpression, _CronField, _Job


class _FakeSchedulerDB:
    """In-memory замена core_db — только то, что реально трогает scheduler.py."""

    def __init__(self) -> None:
        self.rows: dict[str, str] = {}
        self.ddl_executed = False

    async def execute(self, sql: str, params=()) -> None:
        if "CREATE TABLE" in sql:
            self.ddl_executed = True
            return
        if "INSERT INTO scheduler_state" in sql:
            self.rows[params["job_id"]] = params["when"]
            return
        raise AssertionError(f"неожиданный SQL в фейковой БД: {sql}")

    async def fetchone(self, sql: str, params=()):
        job_id = params[0]
        if job_id not in self.rows:
            return None
        return {"last_run_at": self.rows[job_id]}


class CronFieldTests(unittest.TestCase):
    def test_wildcard_allows_full_range(self) -> None:
        field = _CronField("*", 0, 4)
        self.assertEqual(field.allowed, {0, 1, 2, 3, 4})

    def test_step_within_full_range(self) -> None:
        field = _CronField("*/15", 0, 59)
        self.assertEqual(field.allowed, {0, 15, 30, 45})

    def test_simple_range(self) -> None:
        field = _CronField("5-7", 0, 59)
        self.assertEqual(field.allowed, {5, 6, 7})

    def test_comma_separated_list(self) -> None:
        field = _CronField("1,5,10", 0, 59)
        self.assertEqual(field.allowed, {1, 5, 10})

    def test_combined_list_range_and_step(self) -> None:
        field = _CronField("1,5-7,*/20", 0, 59)
        self.assertEqual(field.allowed, {1, 5, 6, 7, 0, 20, 40})

    def test_whitespace_around_commas_is_tolerated(self) -> None:
        field = _CronField(" 5 , 10 ", 0, 59)
        self.assertEqual(field.allowed, {5, 10})

    def test_step_larger_than_range_yields_single_value(self) -> None:
        field = _CronField("0-5/10", 0, 59)
        self.assertEqual(field.allowed, {0})

    def test_empty_element_raises(self) -> None:
        with self.assertRaises(CronSyntaxError):
            _CronField("1,,3", 0, 59)

    def test_zero_step_raises(self) -> None:
        with self.assertRaises(CronSyntaxError):
            _CronField("*/0", 0, 59)

    def test_negative_step_raises(self) -> None:
        with self.assertRaises(CronSyntaxError):
            _CronField("*/-1", 0, 59)

    def test_non_integer_step_raises(self) -> None:
        with self.assertRaises(CronSyntaxError):
            _CronField("*/abc", 0, 59)

    def test_reversed_range_raises(self) -> None:
        with self.assertRaises(CronSyntaxError):
            _CronField("5-3", 0, 59)

    def test_out_of_bounds_value_raises(self) -> None:
        with self.assertRaises(CronSyntaxError):
            _CronField("60", 0, 59)

    def test_leading_dash_is_treated_as_malformed_range_not_negative_number(self) -> None:
        with self.assertRaises(CronSyntaxError):
            _CronField("-1", 0, 59)


class CronExpressionTests(unittest.TestCase):
    def test_wrong_field_count_raises_with_count_in_message(self) -> None:
        with self.assertRaises(CronSyntaxError) as ctx:
            _CronExpression("* * *")
        self.assertIn("3", str(ctx.exception))

    def test_extra_whitespace_between_fields_tolerated(self) -> None:
        expr = _CronExpression("0   3  *  *  *")  # не должно бросить
        self.assertEqual(expr.hour.allowed, {3})

    def test_matches_sunday_as_zero(self) -> None:
        # 2026-01-04 - воскресенье
        expr = _CronExpression("0 0 * * 0")
        sunday = datetime(2026, 1, 4, 0, 0, tzinfo=timezone.utc)
        self.assertTrue(expr.matches(sunday))

    def test_matches_monday_as_one(self) -> None:
        # 2026-01-05 - понедельник
        expr = _CronExpression("0 0 * * 1")
        monday = datetime(2026, 1, 5, 0, 0, tzinfo=timezone.utc)
        self.assertTrue(expr.matches(monday))
        sunday_expr = _CronExpression("0 0 * * 0")
        self.assertFalse(sunday_expr.matches(monday))

    def test_next_after_simple_every_five_minutes(self) -> None:
        expr = _CronExpression("*/5 * * * *")
        after = datetime(2026, 1, 1, 10, 2, 30, tzinfo=timezone.utc)
        result = expr.next_after(after)
        self.assertEqual(result, datetime(2026, 1, 1, 10, 5, 0, tzinfo=timezone.utc))

    def test_next_after_truncates_seconds_and_microseconds(self) -> None:
        expr = _CronExpression("* * * * *")  # каждую минуту
        after = datetime(2026, 1, 1, 10, 2, 45, 123456, tzinfo=timezone.utc)
        result = expr.next_after(after)
        self.assertEqual(result.second, 0)
        self.assertEqual(result.microsecond, 0)

    def test_next_after_is_always_strictly_later_even_on_exact_match(self) -> None:
        expr = _CronExpression("* * * * *")  # matches любую минуту
        after = datetime(2026, 1, 1, 10, 2, 0, tzinfo=timezone.utc)
        result = expr.next_after(after)
        self.assertGreater(result, after)
        self.assertEqual(result, datetime(2026, 1, 1, 10, 3, 0, tzinfo=timezone.utc))

    def test_impossible_expression_raises_runtime_error_quickly(self) -> None:
        expr = _CronExpression("0 0 31 2 *")  # 31 февраля не существует
        after = datetime(2026, 1, 1, tzinfo=timezone.utc)
        with self.assertRaises(RuntimeError):
            expr.next_after(after, limit_minutes=200)  # маленький лимит -> быстро


class RegistrationValidationTests(unittest.TestCase):
    def test_interval_rejects_non_positive_seconds(self) -> None:
        sched = Scheduler()
        with self.assertRaises(ValueError):
            sched.interval("job", 0, lambda: None, plugin="p")
        with self.assertRaises(ValueError):
            sched.interval("job", -5, lambda: None, plugin="p")

    def test_interval_default_misfire_policy_is_run_once(self) -> None:
        sched = Scheduler()
        sched.interval("job", 30, lambda: None, plugin="p")
        self.assertEqual(sched._jobs["p.job"].misfire_policy, "run_once")

    def test_interval_rejects_invalid_misfire_policy(self) -> None:
        sched = Scheduler()
        with self.assertRaises(ValueError):
            sched.interval("job", 30, lambda: None, plugin="p", misfire_policy="whenever")

    def test_interval_rejects_max_concurrent_zero(self) -> None:
        sched = Scheduler()
        with self.assertRaises(ValueError):
            sched.interval("job", 30, lambda: None, plugin="p", max_concurrent=0)

    def test_interval_rejects_negative_max_concurrent(self) -> None:
        sched = Scheduler()
        with self.assertRaises(ValueError):
            sched.interval("job", 30, lambda: None, plugin="p", max_concurrent=-1)

    def test_interval_accepts_max_concurrent_of_one_or_more(self) -> None:
        sched = Scheduler()
        sched.interval("job", 30, lambda: None, plugin="p", max_concurrent=1)  # не должно бросить
        sched.interval("job2", 30, lambda: None, plugin="p", max_concurrent=5)  # тоже

    def test_cron_default_misfire_policy_is_skip(self) -> None:
        sched = Scheduler()
        sched.cron("job", "0 3 * * *", lambda: None, plugin="p")
        self.assertEqual(sched._jobs["p.job"].misfire_policy, "skip")

    def test_cron_invalid_expression_propagates_cron_syntax_error(self) -> None:
        sched = Scheduler()
        with self.assertRaises(CronSyntaxError):
            sched.cron("job", "not a cron expr", lambda: None, plugin="p")

    def test_cron_rejects_max_concurrent_zero(self) -> None:
        sched = Scheduler()
        with self.assertRaises(ValueError):
            sched.cron("job", "0 3 * * *", lambda: None, plugin="p", max_concurrent=0)

    def test_duplicate_job_id_same_plugin_raises(self) -> None:
        sched = Scheduler()
        sched.interval("job", 30, lambda: None, plugin="p")
        with self.assertRaises(ValueError):
            sched.interval("job", 60, lambda: None, plugin="p")

    def test_same_job_id_different_plugins_do_not_collide(self) -> None:
        sched = Scheduler()
        h1 = sched.interval("check", 30, lambda: None, plugin="pluginA")
        h2 = sched.interval("check", 30, lambda: None, plugin="pluginB")
        self.assertNotEqual(h1.job_id, h2.job_id)
        self.assertEqual(len(sched._jobs), 2)

    def test_once_accepts_float_delay(self) -> None:
        sched = Scheduler()
        before = datetime.now(timezone.utc)
        sched.once("job", 10.0, lambda: None, plugin="p")
        run_at = sched._jobs["p.job"].run_at
        self.assertGreater(run_at, before + timedelta(seconds=9))

    def test_once_accepts_explicit_datetime(self) -> None:
        sched = Scheduler()
        target = datetime(2030, 1, 1, tzinfo=timezone.utc)
        sched.once("job", target, lambda: None, plugin="p")
        self.assertEqual(sched._jobs["p.job"].run_at, target)


class CancelAndQueryTests(unittest.TestCase):
    def test_cancel_unknown_handle_returns_false(self) -> None:
        sched = Scheduler()
        self.assertFalse(sched.cancel(JobHandle(job_id="ghost.job", plugin="ghost")))

    def test_cancel_known_handle_removes_it(self) -> None:
        sched = Scheduler()
        handle = sched.interval("job", 30, lambda: None, plugin="p")
        self.assertTrue(sched.cancel(handle))
        self.assertNotIn("p.job", sched._jobs)

    def test_remove_all_for_filters_by_plugin(self) -> None:
        sched = Scheduler()
        sched.interval("a", 30, lambda: None, plugin="p1")
        sched.interval("b", 30, lambda: None, plugin="p1")
        sched.interval("c", 30, lambda: None, plugin="p2")
        removed = sched.remove_all_for("p1")
        self.assertEqual(removed, 2)
        self.assertEqual(list(sched._jobs.keys()), ["p2.c"])

    def test_remove_all_for_no_matches_returns_zero(self) -> None:
        sched = Scheduler()
        sched.interval("a", 30, lambda: None, plugin="p1")
        self.assertEqual(sched.remove_all_for("ghost"), 0)

    def test_list_jobs_shape(self) -> None:
        sched = Scheduler()
        sched.interval("a", 30, lambda: None, plugin="p1")
        jobs = sched.list_jobs()
        self.assertEqual(jobs, [{"job_id": "p1.a", "plugin": "p1", "kind": "interval", "running": False}])


class ComputeNextTests(unittest.TestCase):
    def _make_interval_job(self, seconds=60.0, jitter=0.0) -> _Job:
        return _Job(
            job_id="p.job", plugin="p", kind="interval", callback=lambda: None,
            persist=True, misfire_policy="run_once", max_concurrent=1,
            jitter=jitter, interval_seconds=seconds,
        )

    def test_interval_without_jitter_is_exact(self) -> None:
        sched = Scheduler()
        job = self._make_interval_job(seconds=60.0, jitter=0.0)
        after = datetime(2026, 1, 1, tzinfo=timezone.utc)
        result = sched._compute_next(job, after=after)
        self.assertEqual(result, after + timedelta(seconds=60))

    def test_interval_with_jitter_adds_random_offset(self) -> None:
        sched = Scheduler()
        job = self._make_interval_job(seconds=60.0, jitter=10.0)
        after = datetime(2026, 1, 1, tzinfo=timezone.utc)
        with patch("core.scheduler.random.uniform", return_value=3.5) as mock_uniform:
            result = sched._compute_next(job, after=after)
        mock_uniform.assert_called_once_with(0, 10.0)
        self.assertEqual(result, after + timedelta(seconds=63.5))

    def test_cron_delegates_to_cron_expression_next_after(self) -> None:
        sched = Scheduler()
        job = _Job(
            job_id="p.job", plugin="p", kind="cron", callback=lambda: None,
            persist=True, misfire_policy="skip", max_concurrent=1, jitter=0.0,
            cron=_CronExpression("*/5 * * * *"),
        )
        after = datetime(2026, 1, 1, 10, 2, tzinfo=timezone.utc)
        result = sched._compute_next(job, after=after)
        self.assertEqual(result, datetime(2026, 1, 1, 10, 5, tzinfo=timezone.utc))

    def test_once_kind_raises_assertion_error_defensive_branch(self) -> None:
        sched = Scheduler()
        job = _Job(
            job_id="p.job", plugin="p", kind="once", callback=lambda: None,
            persist=False, misfire_policy="skip", max_concurrent=1, jitter=0.0,
        )
        with self.assertRaises(AssertionError):
            sched._compute_next(job, after=datetime.now(timezone.utc))


class InitialNextRunTests(unittest.IsolatedAsyncioTestCase):
    def _make_job(self, persist=True, misfire_policy="run_once", seconds=60.0) -> _Job:
        return _Job(
            job_id="p.job", plugin="p", kind="interval", callback=lambda: None,
            persist=persist, misfire_policy=misfire_policy, max_concurrent=1,
            jitter=0.0, interval_seconds=seconds,
        )

    async def test_non_persistent_job_always_computes_from_scratch_without_touching_db(self) -> None:
        db = _FakeSchedulerDB()
        db.rows["p.job"] = datetime.now(timezone.utc).isoformat()  # даже если что-то есть...
        sched = Scheduler(db=db)
        job = self._make_job(persist=False)
        result = await sched._initial_next_run(job)
        # from_scratch -> after=now, без обращения к db.rows вообще
        self.assertGreater(result, datetime.now(timezone.utc))

    async def test_no_db_configured_falls_back_to_from_scratch(self) -> None:
        sched = Scheduler(db=None)
        job = self._make_job(persist=True)
        result = await sched._initial_next_run(job)
        self.assertGreater(result, datetime.now(timezone.utc))

    async def test_no_prior_run_recorded_falls_back_to_from_scratch(self) -> None:
        db = _FakeSchedulerDB()
        sched = Scheduler(db=db)
        job = self._make_job(persist=True)
        result = await sched._initial_next_run(job)
        self.assertGreater(result, datetime.now(timezone.utc))

    async def test_scheduled_next_still_in_future_is_used_as_is(self) -> None:
        db = _FakeSchedulerDB()
        last_run = datetime.now(timezone.utc) - timedelta(seconds=5)
        db.rows["p.job"] = last_run.isoformat()
        sched = Scheduler(db=db)
        job = self._make_job(persist=True, seconds=3600)  # следующий тик далеко в будущем
        result = await sched._initial_next_run(job)
        self.assertAlmostEqual(
            result.timestamp(), (last_run + timedelta(seconds=3600)).timestamp(), delta=1
        )

    async def test_missed_run_with_run_once_policy_fires_almost_immediately(self) -> None:
        db = _FakeSchedulerDB()
        last_run = datetime.now(timezone.utc) - timedelta(seconds=120)
        db.rows["p.job"] = last_run.isoformat()
        sched = Scheduler(db=db)
        job = self._make_job(persist=True, misfire_policy="run_once", seconds=30)
        result = await sched._initial_next_run(job)
        self.assertLessEqual(abs((result - datetime.now(timezone.utc)).total_seconds()), 1)

    async def test_missed_run_with_skip_policy_waits_a_full_interval_from_now(self) -> None:
        db = _FakeSchedulerDB()
        last_run = datetime.now(timezone.utc) - timedelta(seconds=120)
        db.rows["p.job"] = last_run.isoformat()
        sched = Scheduler(db=db)
        job = self._make_job(persist=True, misfire_policy="skip", seconds=30)
        result = await sched._initial_next_run(job)
        expected = datetime.now(timezone.utc) + timedelta(seconds=30)
        self.assertAlmostEqual(result.timestamp(), expected.timestamp(), delta=1)

    async def test_corrupted_stored_timestamp_is_treated_as_no_prior_run(self) -> None:
        db = _FakeSchedulerDB()
        db.rows["p.job"] = "this-is-not-a-valid-iso-timestamp"
        sched = Scheduler(db=db)
        job = self._make_job(persist=True)
        result = await sched._initial_next_run(job)  # не должно бросить
        self.assertGreater(result, datetime.now(timezone.utc))


class FireMaxConcurrentTests(unittest.IsolatedAsyncioTestCase):
    """
    _fire() напрямую (без реального параллелизма — в текущей архитектуре
    _run_job() всегда await'ит _fire() последовательно, так что
    running_count органически никогда не превышает 1 через нормальный
    цикл; здесь running_count проставляется вручную, чтобы всё равно
    покрыть саму проверку max_concurrent).
    """

    def _make_job(self, max_concurrent=1, persist=False, callback=None) -> _Job:
        return _Job(
            job_id="p.job", plugin="p", kind="interval", callback=callback or (lambda: None),
            persist=persist, misfire_policy="run_once", max_concurrent=max_concurrent,
            jitter=0.0, interval_seconds=30,
        )

    async def test_normal_fire_calls_callback_and_resets_running_count(self) -> None:
        sched = Scheduler()
        calls = []
        job = self._make_job(callback=lambda: calls.append(1))
        await sched._fire(job)
        self.assertEqual(calls, [1])
        self.assertEqual(job.running_count, 0)

    async def test_fire_skipped_when_running_count_already_at_max(self) -> None:
        sched = Scheduler()
        calls = []
        job = self._make_job(max_concurrent=1, callback=lambda: calls.append(1))
        job.running_count = 1  # симулируем "предыдущий запуск ещё не завершился"
        with self.assertLogs("scheduler", level="WARNING"):
            await sched._fire(job)
        self.assertEqual(calls, [])  # не вызван
        self.assertEqual(job.running_count, 1)  # не тронут

    async def test_max_concurrent_zero_means_job_never_actually_fires(self) -> None:
        """
        _fire() напрямую (в обход теперь уже добавленной валидации на
        уровне interval()/cron() — см. RegistrationValidationTests) —
        при max_concurrent=0 условие running_count(0) >= max_concurrent(0)
        истинно уже на самом первом срабатывании, job.callback никогда
        не вызывается. С момента фикса это конкретное значение до
        _fire() просто не доходит через публичный API — но сама
        защита внутри _fire() остаётся отдельным, независимым
        рубежом обороны, и здесь тестируется напрямую.
        """
        sched = Scheduler()
        calls = []
        job = self._make_job(max_concurrent=0, callback=lambda: calls.append(1))
        with self.assertLogs("scheduler", level="WARNING"):
            await sched._fire(job)
        self.assertEqual(calls, [])

    async def test_skipped_fire_does_not_persist_last_run(self) -> None:
        db = _FakeSchedulerDB()
        sched = Scheduler(db=db)
        job = self._make_job(max_concurrent=1, persist=True)
        job.running_count = 1
        with self.assertLogs("scheduler", level="WARNING"):
            await sched._fire(job)
        self.assertEqual(db.rows, {})

    async def test_successful_fire_with_persist_saves_last_run(self) -> None:
        db = _FakeSchedulerDB()
        sched = Scheduler(db=db)
        job = self._make_job(persist=True)
        await sched._fire(job)
        self.assertIn("p.job", db.rows)

    async def test_successful_fire_without_persist_never_touches_db(self) -> None:
        db = _FakeSchedulerDB()
        sched = Scheduler(db=db)
        job = self._make_job(persist=False)
        await sched._fire(job)
        self.assertEqual(db.rows, {})

    async def test_exception_in_callback_still_resets_running_count_and_still_persists(self) -> None:
        db = _FakeSchedulerDB()
        sched = Scheduler(db=db)

        def bad_callback():
            raise ValueError("boom")

        job = self._make_job(persist=True, callback=bad_callback)
        with self.assertLogs("scheduler", level="ERROR"):
            await sched._fire(job)  # не должно бросить
        self.assertEqual(job.running_count, 0)
        self.assertIn("p.job", db.rows)  # persist всё равно случился

    async def test_async_callback_is_awaited(self) -> None:
        sched = Scheduler()
        calls = []

        async def async_callback():
            await asyncio.sleep(0)
            calls.append(1)

        job = self._make_job(callback=async_callback)
        await sched._fire(job)
        self.assertEqual(calls, [1])


class LiveLifecycleTests(unittest.IsolatedAsyncioTestCase):
    async def asyncTearDown(self) -> None:
        # подчищаем любые задачи планировщика, если тест не сделал этого сам
        if hasattr(self, "_sched"):
            await self._sched.stop()

    async def test_once_job_fires_exactly_once_then_self_removes(self) -> None:
        self._sched = sched = Scheduler()
        calls = []
        sched.once("job", 0.02, lambda: calls.append(1), plugin="p")
        await sched.start()
        await asyncio.sleep(0.15)
        self.assertEqual(calls, [1])
        self.assertNotIn("p.job", sched._jobs)

    async def test_once_job_with_zero_delay_fires_almost_immediately(self) -> None:
        self._sched = sched = Scheduler()
        calls = []
        sched.once("job", 0.0, lambda: calls.append(1), plugin="p")
        await sched.start()
        await asyncio.sleep(0.1)
        self.assertEqual(calls, [1])

    async def test_cancelling_once_job_before_it_fires_prevents_callback(self) -> None:
        self._sched = sched = Scheduler()
        calls = []
        handle = sched.once("job", 1.0, lambda: calls.append(1), plugin="p")
        await sched.start()
        await asyncio.sleep(0.02)
        sched.cancel(handle)
        await asyncio.sleep(0.05)
        self.assertEqual(calls, [])

    async def test_interval_job_fires_repeatedly(self) -> None:
        self._sched = sched = Scheduler()
        calls = []
        sched.interval("job", 0.03, lambda: calls.append(1), plugin="p", misfire_policy="skip", persist=False)
        await sched.start()
        await asyncio.sleep(0.16)
        self.assertGreaterEqual(len(calls), 2)

    async def test_exception_in_one_firing_does_not_stop_the_loop(self) -> None:
        self._sched = sched = Scheduler()
        calls = []

        def flaky():
            calls.append(1)
            if len(calls) == 1:
                raise ValueError("first call fails")

        sched.interval("job", 0.03, flaky, plugin="p", misfire_policy="skip", persist=False)
        with self.assertLogs("scheduler", level="ERROR"):
            await sched.start()
            await asyncio.sleep(0.16)
        self.assertGreaterEqual(len(calls), 2)  # цикл пережил исключение

    async def test_registering_after_start_spawns_immediately(self) -> None:
        self._sched = sched = Scheduler()
        await sched.start()
        handle = sched.interval("job", 30, lambda: None, plugin="p")
        job = sched._jobs[handle.job_id]
        self.assertIsNotNone(job.task)

    async def test_stop_cancels_all_tasks_without_raising(self) -> None:
        sched = Scheduler()
        sched.interval("a", 30, lambda: None, plugin="p")
        sched.interval("b", 30, lambda: None, plugin="p")
        await sched.start()
        await sched.stop()  # не должно бросить, несмотря на CancelledError внутри задач
        for job in sched._jobs.values():
            self.assertTrue(job.cancelled)

    async def test_stop_on_never_started_scheduler_is_a_safe_no_op(self) -> None:
        sched = Scheduler()
        sched.interval("a", 30, lambda: None, plugin="p")
        await sched.stop()  # задачи никогда не спавнились -> просто no-op


if __name__ == "__main__":
    unittest.main()
