"""
tests/test_bootstrap.py — core/bootstrap.py: run_bootstrap().

Всё завязано на CWD через относительные пути — изоляция через
os.chdir() во временный каталог, как и в test_config.py.

После перехода configs/ (.env и config.json переехали из корня в
settings/), добавления manifest_core.json как обязательного файла и
хеш-проверки целостности сборки (core/manifest.py) тесты обновлены:
  - write_env() пишет в configs/.env
  - make_everything_valid() создаёт manifest_core.json с валидным хешем
  - добавлены тест-классы ManifestTests и BuildIntegrityTests
  - тесты ConfigJsonValidation пишут в configs/config.json
  - тесты PermissionCheck патчат пути configs/.env / configs/config.json
"""
from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tests._support import env  # noqa: F401

from core.bootstrap import run_bootstrap
from core.manifest import compute_source_hash


# ── helpers ──────────────────────────────────────────────────────────

def _write_manifest(path: Path, sha256_hash: str = "") -> None:
    """Пишет минимальный корректный manifest_core.json в path."""
    path.write_text(
        json.dumps({
            "name": "Test Framework",
            "version": "1.0.0",
            "build_channel": "Stable",
            "authors": ["test"],
            "requirements": [],
            "repository_url": "",
            "ota_repository": "",
            "plugin_repository": "",
            "sha256_hash": sha256_hash,
        }),
        encoding="utf-8",
    )


class BootstrapTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self._orig_cwd = os.getcwd()
        os.chdir(self._tmp.name)
        self.addCleanup(os.chdir, self._orig_cwd)

    # ── настройка обязательных файлов ────────────────────────────────

    def write_env(self, content: str = "BOT_TOKEN=abc123\n") -> None:
        Path("configs").mkdir(exist_ok=True)
        Path("configs/.env").write_text(content, encoding="utf-8")

    def write_plugins_base(self) -> None:
        Path("plugins").mkdir(exist_ok=True)
        (Path("plugins") / "base.py").write_text("# base plugin contract", encoding="utf-8")

    def write_manifest(self, sha256_hash: str = "") -> None:
        _write_manifest(Path("manifest_core.json"), sha256_hash)

    def write_valid_manifest(self) -> None:
        """Пишет manifest_core.json с хешем, который реально совпадёт с compute_source_hash()."""
        _write_manifest(Path("manifest_core.json"), compute_source_hash())

    def make_everything_valid(self) -> None:
        self.write_env()
        self.write_plugins_base()
        self.write_valid_manifest()

    def read_bootstrap_log(self) -> str:
        log_dir = Path("logs/bootstrap")
        logs = list(log_dir.glob("bootstrap-*.log"))
        self.assertEqual(len(logs), 1)
        return logs[0].read_text(encoding="utf-8")


# ═══════════════════════════════════════════════════════════════════
class HappyPathTests(BootstrapTestCase):
    def test_success_returns_none_and_creates_all_dirs(self) -> None:
        self.make_everything_valid()
        result = run_bootstrap()
        self.assertIsNone(result)
        for d in ("database", "database/migrations", "logs", "logs/bootstrap", "plugins", "configs"):
            self.assertTrue(Path(d).is_dir(), f"{d} должен быть создан")

    def test_success_logs_final_success_message(self) -> None:
        self.make_everything_valid()
        run_bootstrap()
        self.assertIn("Bootstrap завершён успешно.", self.read_bootstrap_log())

    def test_config_json_absent_is_not_an_error(self) -> None:
        self.make_everything_valid()
        self.assertFalse(Path("configs/config.json").exists())
        run_bootstrap()  # не должно бросить SystemExit

    def test_config_json_valid_but_unusual_shape_still_passes_this_check(self) -> None:
        # bootstrap.py проверяет только «это валидный JSON», а не форму —
        # даже список пройдёт (в отличие от более придирчивого core/config.py).
        self.make_everything_valid()
        Path("configs").mkdir(exist_ok=True)
        Path("configs/config.json").write_text("[1, 2, 3]", encoding="utf-8")
        run_bootstrap()  # не должно бросить

    def test_bot_token_value_whitespace_is_stripped(self) -> None:
        self.write_env("BOT_TOKEN=  abc123  \n")
        self.write_plugins_base()
        self.write_valid_manifest()
        run_bootstrap()  # не должно бросить

    def test_leading_whitespace_on_the_env_line_itself_is_tolerated(self) -> None:
        self.write_env("   BOT_TOKEN=abc123\n")
        self.write_plugins_base()
        self.write_valid_manifest()
        run_bootstrap()  # не должно бросить

    def test_first_bot_token_line_wins_when_duplicated(self) -> None:
        self.write_env("BOT_TOKEN=first\nBOT_TOKEN=second\n")
        self.write_plugins_base()
        self.write_valid_manifest()
        run_bootstrap()  # первая строка непустая -> ок


# ═══════════════════════════════════════════════════════════════════
class MissingFileTests(BootstrapTestCase):
    def test_missing_env_file_exits_with_code_one(self) -> None:
        self.write_plugins_base()
        self.write_manifest()
        with self.assertRaises(SystemExit) as ctx:
            run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_missing_env_file_logs_helpful_message(self) -> None:
        self.write_plugins_base()
        self.write_manifest()
        with self.assertRaises(SystemExit):
            run_bootstrap()
        log = self.read_bootstrap_log()
        self.assertIn(".env", log)
        self.assertIn(".env.example", log)

    def test_missing_plugins_base_py_exits_with_code_one(self) -> None:
        self.write_env()
        self.write_manifest()
        with self.assertRaises(SystemExit) as ctx:
            run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_freshly_autocreated_empty_plugins_dir_does_not_satisfy_base_py_requirement(self) -> None:
        self.write_env()
        self.write_manifest()
        self.assertFalse(Path("plugins").exists())
        with self.assertRaises(SystemExit):
            run_bootstrap()
        self.assertTrue(Path("plugins").is_dir())   # папка создалась
        self.assertFalse((Path("plugins") / "base.py").exists())  # но не файл

    def test_both_missing_reports_both_errors_before_exiting(self) -> None:
        self.write_manifest()
        with self.assertRaises(SystemExit):
            run_bootstrap()
        log = self.read_bootstrap_log()
        self.assertIn(".env", log)
        self.assertIn("plugins/base.py", log)

    def test_missing_manifest_exits_with_code_one(self) -> None:
        self.write_env()
        self.write_plugins_base()
        # manifest_core.json НЕ создаём намеренно
        with self.assertRaises(SystemExit) as ctx:
            run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_missing_manifest_logs_helpful_message(self) -> None:
        self.write_env()
        self.write_plugins_base()
        with self.assertRaises(SystemExit):
            run_bootstrap()
        self.assertIn("manifest_core.json", self.read_bootstrap_log())


# ═══════════════════════════════════════════════════════════════════
class ManifestTests(BootstrapTestCase):
    def test_malformed_manifest_json_exits_with_code_one(self) -> None:
        self.write_env()
        self.write_plugins_base()
        Path("manifest_core.json").write_text("{not valid json!!", encoding="utf-8")
        with self.assertRaises(SystemExit) as ctx:
            run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_malformed_manifest_logs_error(self) -> None:
        self.write_env()
        self.write_plugins_base()
        Path("manifest_core.json").write_text("{not valid json!!", encoding="utf-8")
        with self.assertRaises(SystemExit):
            run_bootstrap()
        self.assertIn("manifest_core.json", self.read_bootstrap_log())


# ═══════════════════════════════════════════════════════════════════
class BuildIntegrityTests(BootstrapTestCase):
    def test_empty_sha256_hash_exits_with_code_one(self) -> None:
        self.write_env()
        self.write_plugins_base()
        self.write_manifest(sha256_hash="")   # пусто — ошибка
        with self.assertRaises(SystemExit) as ctx:
            run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_wrong_hash_exits_with_code_one(self) -> None:
        self.write_env()
        self.write_plugins_base()
        self.write_manifest(sha256_hash="deadbeef" * 8)
        with self.assertRaises(SystemExit) as ctx:
            run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_wrong_hash_logs_mismatch_message(self) -> None:
        self.write_env()
        self.write_plugins_base()
        self.write_manifest(sha256_hash="deadbeef" * 8)
        with self.assertRaises(SystemExit):
            run_bootstrap()
        self.assertIn("хэш", self.read_bootstrap_log())

    def test_correct_hash_succeeds(self) -> None:
        self.write_env()
        self.write_plugins_base()
        self.write_valid_manifest()
        run_bootstrap()   # не должно бросить

    def test_hash_bypass_with_disable_flag_logs_warning_not_error(self) -> None:
        self.write_env()
        self.write_plugins_base()
        self.write_manifest(sha256_hash="deadbeef" * 8)  # неверный хеш
        # включаем обход через settings.json
        Path("configs").mkdir(exist_ok=True)
        Path("configs/settings.json").write_text(
            json.dumps({"disable_signature_and_hash_check": True}), encoding="utf-8"
        )
        run_bootstrap()  # должно УСПЕШНО завершиться
        log = self.read_bootstrap_log()
        self.assertIn("WARN", log)
        self.assertIn("Bootstrap завершён успешно.", log)


# ═══════════════════════════════════════════════════════════════════
class BotTokenValidationTests(BootstrapTestCase):
    def test_no_bot_token_line_at_all_is_an_error(self) -> None:
        self.write_env("SOME_OTHER_VAR=x\n")
        self.write_plugins_base()
        self.write_valid_manifest()
        with self.assertRaises(SystemExit) as ctx:
            run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_empty_bot_token_value_is_an_error(self) -> None:
        self.write_env("BOT_TOKEN=\n")
        self.write_plugins_base()
        self.write_valid_manifest()
        with self.assertRaises(SystemExit):
            run_bootstrap()

    def test_whitespace_only_bot_token_value_is_an_error(self) -> None:
        self.write_env("BOT_TOKEN=   \n")
        self.write_plugins_base()
        self.write_valid_manifest()
        with self.assertRaises(SystemExit):
            run_bootstrap()

    def test_commented_out_bot_token_line_does_not_count(self) -> None:
        self.write_env("# BOT_TOKEN=commented\n")
        self.write_plugins_base()
        self.write_valid_manifest()
        with self.assertRaises(SystemExit):
            run_bootstrap()


# ═══════════════════════════════════════════════════════════════════
class ConfigJsonValidationTests(BootstrapTestCase):
    def test_malformed_config_json_exits_with_code_one(self) -> None:
        self.make_everything_valid()
        Path("configs").mkdir(exist_ok=True)
        Path("configs/config.json").write_text("{not valid json!!", encoding="utf-8")
        with self.assertRaises(SystemExit) as ctx:
            run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_malformed_config_json_logs_the_json_error(self) -> None:
        self.make_everything_valid()
        Path("configs").mkdir(exist_ok=True)
        Path("configs/config.json").write_text("{not valid json!!", encoding="utf-8")
        with self.assertRaises(SystemExit):
            run_bootstrap()
        log = self.read_bootstrap_log()
        self.assertIn("config.json", log)
        self.assertIn("невалидный JSON", log)


# ═══════════════════════════════════════════════════════════════════
class DirectoryCreationFailureTests(BootstrapTestCase):
    def test_one_failing_mkdir_does_not_stop_the_others_from_being_attempted(self) -> None:
        self.make_everything_valid()
        real_mkdir = Path.mkdir
        attempted = []

        def flaky_mkdir(self_path, *a, **kw):
            attempted.append(str(self_path))
            if str(self_path) == "database":
                raise OSError("simulated permission denied")
            return real_mkdir(self_path, *a, **kw)

        with patch.object(Path, "mkdir", flaky_mkdir):
            with self.assertRaises(SystemExit):
                run_bootstrap()

        self.assertIn("database/migrations", attempted)
        self.assertIn("logs", attempted)

    def test_mkdir_failure_is_logged_as_error_with_reason(self) -> None:
        self.make_everything_valid()
        real_mkdir = Path.mkdir

        def flaky_mkdir(self_path, *a, **kw):
            if str(self_path) == "database":
                raise OSError("disk full")
            return real_mkdir(self_path, *a, **kw)

        with patch.object(Path, "mkdir", flaky_mkdir):
            with self.assertRaises(SystemExit):
                run_bootstrap()
        log = self.read_bootstrap_log()
        self.assertIn("database", log)
        self.assertIn("disk full", log)

    def test_bootstrap_log_dir_itself_is_now_error_handled(self) -> None:
        import io
        from contextlib import redirect_stderr
        real_mkdir = Path.mkdir

        def flaky_mkdir(self_path, *a, **kw):
            if str(self_path) == "logs/bootstrap":
                raise OSError("simulated failure creating the log dir itself")
            return real_mkdir(self_path, *a, **kw)

        stderr_buf = io.StringIO()
        with patch.object(Path, "mkdir", flaky_mkdir):
            with redirect_stderr(stderr_buf):
                with self.assertRaises(SystemExit) as ctx:
                    run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)
        self.assertIn("logs/bootstrap", stderr_buf.getvalue())


# ═══════════════════════════════════════════════════════════════════
class PermissionCheckTests(BootstrapTestCase):
    def test_unreadable_rw_dir_is_reported(self) -> None:
        self.make_everything_valid()
        run_bootstrap()  # первый прогон создаёт директории штатно
        with patch("core.bootstrap.os.access",
                   side_effect=lambda p, m: not (str(p) == "logs" and m == os.R_OK)):
            with self.assertRaises(SystemExit) as ctx:
                run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_unwritable_rw_dir_is_reported(self) -> None:
        self.make_everything_valid()
        run_bootstrap()
        with patch("core.bootstrap.os.access",
                   side_effect=lambda p, m: not (str(p) == "plugins" and m == os.W_OK)):
            with self.assertRaises(SystemExit) as ctx:
                run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_unreadable_required_file_is_reported(self) -> None:
        self.make_everything_valid()
        run_bootstrap()
        env_str = str(Path("configs/.env"))
        with patch("core.bootstrap.os.access",
                   side_effect=lambda p, m: not (str(p) == env_str and m == os.R_OK)):
            with self.assertRaises(SystemExit) as ctx:
                run_bootstrap()
        self.assertEqual(ctx.exception.code, 1)

    def test_all_permissions_fine_does_not_report_anything_spurious(self) -> None:
        self.make_everything_valid()
        run_bootstrap()  # не должно бросить


if __name__ == "__main__":
    unittest.main()
