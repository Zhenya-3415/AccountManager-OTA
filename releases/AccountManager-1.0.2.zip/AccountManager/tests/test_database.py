"""
tests/test_database.py — core/database.py: обратно-совместимый шим
(Database == SQLiteDatabase, реэкспорт из core.db.*).
"""
from __future__ import annotations

import unittest

from tests._support import env

env.ensure_aiosqlite()

import core.database as database_module  # noqa: E402
from core.db.base import BaseDatabase  # noqa: E402
from core.db.sqlite_backend import SQLiteDatabase  # noqa: E402


class BackwardCompatShimTests(unittest.TestCase):
    def test_database_is_literally_sqlite_database(self) -> None:
        self.assertIs(database_module.Database, SQLiteDatabase)

    def test_all_exports_are_present_and_correct_identity(self) -> None:
        self.assertIs(database_module.BaseDatabase, BaseDatabase)
        self.assertIs(database_module.SQLiteDatabase, SQLiteDatabase)
        self.assertTrue(callable(database_module.create_database))
        self.assertTrue(callable(database_module.resolve_migration_dir))
        self.assertTrue(callable(database_module.split_sql_statements))

    def test_all_dunder_matches_actual_exports(self) -> None:
        for name in database_module.__all__:
            self.assertTrue(hasattr(database_module, name), f"__all__ заявляет {name}, но его нет в модуле")

    def test_old_style_construction_still_works(self) -> None:
        # Старый код: Database(path) — без импорта SQLiteDatabase напрямую.
        db = database_module.Database("some/path.db")
        self.assertIsInstance(db, SQLiteDatabase)


if __name__ == "__main__":
    unittest.main()
