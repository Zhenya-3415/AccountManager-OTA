"""
tests/test_update_staging.py — core/update_staging.py: применение
отложенных обновлений плагинов при graceful shutdown.

_validate_all_staged() лениво импортирует
core.plugin_installer.validate_plugin_folder — здесь он МОКАЕТСЯ
(валидация plugin_installer.py тестируется отдельно в
test_plugin_installer.py), чтобы этот файл проверял именно оркестрацию
update_staging.py: backup-перед-любым-изменением, всё-или-ничего при
провале валидации, порядок применения, самоисключение бэкапа из
собственного же архива.
"""
from __future__ import annotations

import tempfile
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from tests._support import env  # noqa: F401

import core.update_staging as update_staging
from core.update_staging import apply_staged_updates, has_staged_updates, restart_process


def _ok_result():
    return SimpleNamespace(ok=True, errors=[])


def _fail_result(*errors):
    return SimpleNamespace(ok=False, errors=list(errors))


class UpdateStagingTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.plugins_dir = self.root / "plugins"
        self.staging_dir = self.root / "downloaded_updates"
        self.backup_path = self.plugins_dir / "plugins_old.zip"

    def make_staged_plugin(self, name: str, files: dict[str, str] | None = None) -> Path:
        d = self.staging_dir / name
        d.mkdir(parents=True, exist_ok=True)
        for fname, content in (files or {"manifest.json": "{}", "plugin.py": "# x"}).items():
            (d / fname).write_text(content, encoding="utf-8")
        return d

    def make_existing_plugin(self, name: str, files: dict[str, str] | None = None) -> Path:
        d = self.plugins_dir / name
        d.mkdir(parents=True, exist_ok=True)
        for fname, content in (files or {"manifest.json": "{}", "plugin.py": "# old"}).items():
            (d / fname).write_text(content, encoding="utf-8")
        return d


class HasStagedUpdatesTests(UpdateStagingTestCase):
    def test_nonexistent_dir_is_false(self) -> None:
        self.assertFalse(has_staged_updates(self.staging_dir))

    def test_empty_existing_dir_is_false(self) -> None:
        self.staging_dir.mkdir()
        self.assertFalse(has_staged_updates(self.staging_dir))

    def test_dir_with_only_stray_files_is_false(self) -> None:
        self.staging_dir.mkdir()
        (self.staging_dir / "leftover.tmp").write_text("x", encoding="utf-8")
        self.assertFalse(has_staged_updates(self.staging_dir))

    def test_dir_with_a_plugin_subfolder_is_true(self) -> None:
        self.make_staged_plugin("antispam")
        self.assertTrue(has_staged_updates(self.staging_dir))


class BackupPluginsTests(UpdateStagingTestCase):
    def test_backup_contains_all_current_plugin_files_with_relative_paths(self) -> None:
        self.make_existing_plugin("antispam", {"manifest.json": '{"a":1}', "plugin.py": "x=1"})
        update_staging._backup_plugins(self.plugins_dir, self.backup_path)
        with zipfile.ZipFile(self.backup_path) as zf:
            names = set(zf.namelist())
        self.assertIn(str(Path("antispam") / "manifest.json"), names)
        self.assertIn(str(Path("antispam") / "plugin.py"), names)

    def test_backup_excludes_itself_when_a_stale_backup_already_exists_inside_plugins_dir(self) -> None:
        self.make_existing_plugin("antispam")
        self.plugins_dir.mkdir(exist_ok=True)
        # предыдущий бэкап уже лежит внутри plugins/ (как и в реальности,
        # т.к. BACKUP_PATH по умолчанию — plugins/plugins_old.zip)
        with zipfile.ZipFile(self.backup_path, "w") as zf:
            zf.writestr("stale.txt", "old backup content")

        update_staging._backup_plugins(self.plugins_dir, self.backup_path)

        with zipfile.ZipFile(self.backup_path) as zf:
            names = zf.namelist()
        self.assertNotIn("plugins_old.zip", names)  # новый архив не содержит сам себя

    def test_backup_of_nonexistent_plugins_dir_creates_empty_archive_without_crashing(self) -> None:
        update_staging._backup_plugins(self.plugins_dir, self.backup_path)  # plugins/ не существует
        self.assertTrue(self.backup_path.exists())
        with zipfile.ZipFile(self.backup_path) as zf:
            self.assertEqual(zf.namelist(), [])

    def test_backup_creates_missing_parent_directories(self) -> None:
        nested_backup = self.root / "some" / "nested" / "backup.zip"
        update_staging._backup_plugins(self.plugins_dir, nested_backup)
        self.assertTrue(nested_backup.exists())


class ApplyStagedUpdatesNoOpTests(UpdateStagingTestCase):
    def test_no_staging_dir_returns_not_applied(self) -> None:
        result = apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)
        self.assertFalse(result.applied)

    def test_empty_staging_dir_returns_not_applied_and_leaves_plugins_untouched(self) -> None:
        self.staging_dir.mkdir()
        self.make_existing_plugin("antispam")
        result = apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)
        self.assertFalse(result.applied)
        self.assertFalse(self.backup_path.exists())  # даже бэкап не создавался


class ApplyStagedUpdatesValidationFailureTests(UpdateStagingTestCase):
    def test_one_invalid_staged_plugin_cancels_the_whole_batch(self) -> None:
        self.make_staged_plugin("good_plugin")
        self.make_staged_plugin("bad_plugin")
        self.make_existing_plugin("untouched_existing")

        def fake_validate(path):
            return _fail_result("отсутствует manifest.json") if path.name == "bad_plugin" else _ok_result()

        with patch("core.plugin_installer.validate_plugin_folder", side_effect=fake_validate):
            result = apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)

        self.assertFalse(result.applied)
        self.assertFalse(result.ok)
        self.assertIn("bad_plugin", result.error)
        # ничего не тронуто: ни бэкапа, ни перемещений
        self.assertFalse(self.backup_path.exists())
        self.assertTrue((self.plugins_dir / "untouched_existing").exists())
        self.assertFalse((self.plugins_dir / "good_plugin").exists())
        # staging остался как был — для разбора
        self.assertTrue((self.staging_dir / "bad_plugin").exists())
        self.assertTrue((self.staging_dir / "good_plugin").exists())

    def test_validation_failure_message_lists_all_failing_plugins(self) -> None:
        self.make_staged_plugin("bad_one")
        self.make_staged_plugin("bad_two")

        def fake_validate(path):
            return _fail_result(f"ошибка в {path.name}")

        with patch("core.plugin_installer.validate_plugin_folder", side_effect=fake_validate):
            result = apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)

        self.assertIn("bad_one", result.error)
        self.assertIn("bad_two", result.error)

    def test_stray_files_directly_in_staging_dir_are_ignored_by_validation(self) -> None:
        self.staging_dir.mkdir()
        (self.staging_dir / "readme.txt").write_text("not a plugin", encoding="utf-8")
        self.make_staged_plugin("good_plugin")

        with patch("core.plugin_installer.validate_plugin_folder", return_value=_ok_result()) as mock_validate:
            result = apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)

        self.assertTrue(result.ok)
        mock_validate.assert_called_once()  # только на good_plugin, не на readme.txt


class ApplyStagedUpdatesSuccessTests(UpdateStagingTestCase):
    def test_fresh_plugin_is_moved_into_plugins_dir(self) -> None:
        self.make_staged_plugin("new_plugin", {"manifest.json": '{"v":1}'})
        with patch("core.plugin_installer.validate_plugin_folder", return_value=_ok_result()):
            result = apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)

        self.assertTrue(result.applied)
        self.assertTrue(result.ok)
        self.assertEqual(result.applied_plugins, ["new_plugin"])
        self.assertTrue((self.plugins_dir / "new_plugin" / "manifest.json").exists())
        self.assertFalse(self.staging_dir.exists())  # staging полностью очищен

    def test_existing_plugin_is_fully_replaced_not_merged(self) -> None:
        self.make_existing_plugin("antispam", {"manifest.json": '{"v":"old"}', "old_only_file.txt": "gone soon"})
        self.make_staged_plugin("antispam", {"manifest.json": '{"v":"new"}'})

        with patch("core.plugin_installer.validate_plugin_folder", return_value=_ok_result()):
            result = apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)

        self.assertTrue(result.ok)
        content = (self.plugins_dir / "antispam" / "manifest.json").read_text(encoding="utf-8")
        self.assertEqual(content, '{"v":"new"}')
        self.assertFalse((self.plugins_dir / "antispam" / "old_only_file.txt").exists())

    def test_backup_is_created_before_any_plugin_is_moved(self) -> None:
        self.make_existing_plugin("antispam", {"manifest.json": '{"v":"old"}'})
        self.make_staged_plugin("antispam", {"manifest.json": '{"v":"new"}'})

        with patch("core.plugin_installer.validate_plugin_folder", return_value=_ok_result()):
            apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)

        # бэкап должен содержать СТАРУЮ версию, а не новую
        with zipfile.ZipFile(self.backup_path) as zf:
            old_manifest = zf.read(str(Path("antispam") / "manifest.json")).decode("utf-8")
        self.assertEqual(old_manifest, '{"v":"old"}')

    def test_multiple_plugins_all_applied_in_sorted_order(self) -> None:
        self.make_staged_plugin("zeta")
        self.make_staged_plugin("alpha")
        self.make_staged_plugin("middle")

        with patch("core.plugin_installer.validate_plugin_folder", return_value=_ok_result()):
            result = apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)

        self.assertEqual(result.applied_plugins, ["alpha", "middle", "zeta"])
        for name in ("alpha", "middle", "zeta"):
            self.assertTrue((self.plugins_dir / name).exists())

    def test_stray_file_in_staging_dir_is_not_moved_or_counted(self) -> None:
        self.staging_dir.mkdir()
        (self.staging_dir / "readme.txt").write_text("not a plugin", encoding="utf-8")
        self.make_staged_plugin("good_plugin")

        with patch("core.plugin_installer.validate_plugin_folder", return_value=_ok_result()):
            result = apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)

        self.assertEqual(result.applied_plugins, ["good_plugin"])

    def test_plugins_dir_did_not_exist_beforehand_gets_created_via_backup_step(self) -> None:
        # Реалистичное соотношение путей по умолчанию: backup_path лежит
        # ВНУТРИ plugins_dir, так что создание родителя backup_path
        # попутно создаёт и сам plugins_dir ещё до цикла переноса.
        self.assertFalse(self.plugins_dir.exists())
        self.make_staged_plugin("new_plugin")

        with patch("core.plugin_installer.validate_plugin_folder", return_value=_ok_result()):
            result = apply_staged_updates(self.plugins_dir, self.staging_dir, self.backup_path)

        self.assertTrue(result.ok)
        self.assertTrue((self.plugins_dir / "new_plugin").exists())


class RestartProcessTests(unittest.TestCase):
    def test_execv_called_with_python_executable_and_reconstructed_argv(self) -> None:
        with patch.object(update_staging, "_ENTRY_SCRIPT_ABS", "/abs/path/main.py"), \
             patch.object(update_staging.sys, "argv", ["main.py", "--flag", "value"]), \
             patch.object(update_staging.os, "execv") as mock_execv:
            restart_process()

        mock_execv.assert_called_once_with(
            update_staging.sys.executable,
            [update_staging.sys.executable, "/abs/path/main.py", "--flag", "value"],
        )

    def test_uses_precomputed_entry_script_path_not_a_freshly_recomputed_one(self) -> None:
        """
        Задокументированное в докстрине поведение: _ENTRY_SCRIPT_ABS
        вычисляется ОДИН РАЗ при импорте модуля, а не заново из
        sys.argv[0] в момент вызова restart_process(). Подделываем
        сценарий "cwd успел смениться, argv[0] относительный" и
        проверяем, что используется именно старое, предвычисленное
        значение, а НЕ os.path.abspath(sys.argv[0]) здесь-и-сейчас.
        """
        with patch.object(update_staging, "_ENTRY_SCRIPT_ABS", "/original/cwd/main.py"), \
             patch.object(update_staging.sys, "argv", ["main.py"]), \
             patch.object(update_staging.os, "execv") as mock_execv, \
             patch.object(update_staging.os.path, "abspath", return_value="/some/other/cwd/main.py"):
            restart_process()

        called_args = mock_execv.call_args[0][1]
        self.assertIn("/original/cwd/main.py", called_args)
        self.assertNotIn("/some/other/cwd/main.py", called_args)


if __name__ == "__main__":
    unittest.main()
