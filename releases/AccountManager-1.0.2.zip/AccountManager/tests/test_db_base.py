"""
tests/test_db_base.py — core/db/base.py: BaseDatabase (контракт бэкендов БД).
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from tests._support import env  # noqa: F401

from core.db.base import BaseDatabase


class CannotInstantiateBareContractTests(unittest.TestCase):
    def test_bare_base_database_cannot_be_instantiated(self) -> None:
        with self.assertRaises(TypeError):
            BaseDatabase()  # type: ignore[abstract]

    def test_subclass_missing_one_abstract_method_cannot_be_instantiated(self) -> None:
        class Incomplete(BaseDatabase):
            async def connect(self) -> None: pass
            async def close(self) -> None: pass
            async def execute(self, sql, params=()): pass
            async def execute_returning(self, sql, params=()): pass
            async def fetchone(self, sql, params=()): pass
            async def fetchall(self, sql, params=()): pass
            async def run_migrations(self, namespace, migration_dir): pass
            async def verify_schema_version(self, namespace, expected_versions): pass
            # upsert_user() отсутствует

        with self.assertRaises(TypeError):
            Incomplete()  # type: ignore[abstract]


class CompleteSubclassTests(unittest.IsolatedAsyncioTestCase):
    def _make_complete_subclass(self):
        class Complete(BaseDatabase):
            backend_name = "fake"

            async def connect(self) -> None: pass
            async def close(self) -> None: pass
            async def execute(self, sql, params=()): return "executed"
            async def execute_returning(self, sql, params=()): return None
            async def fetchone(self, sql, params=()): return None
            async def fetchall(self, sql, params=()): return []
            async def run_migrations(self, namespace, migration_dir): return True
            async def verify_schema_version(self, namespace, expected_versions): return True
            async def upsert_user(self, user_id, **fields): pass

        return Complete

    async def test_complete_subclass_can_be_instantiated_and_used(self) -> None:
        Complete = self._make_complete_subclass()
        db = Complete()
        self.assertEqual(db.backend_name, "fake")
        self.assertEqual(await db.execute("SELECT 1"), "executed")

    async def test_default_backend_name_is_base_if_not_overridden(self) -> None:
        class NoOverride(self._make_complete_subclass()):
            pass

        # дочерний класс НЕ переопределяет backend_name сам -> наследует "fake" от родителя
        # (тест на то, что backend_name — обычный атрибут класса, а не что-то специальное)
        self.assertEqual(NoOverride.backend_name, "fake")

    async def test_base_database_class_attribute_default_is_base(self) -> None:
        self.assertEqual(BaseDatabase.backend_name, "base")


class CollectMigrationFilesDelegationTests(unittest.TestCase):
    """
    BaseDatabase.collect_migration_files — статический метод-делегат к
    core.db.migrations.collect_migration_files. Тестируем саму делегацию
    (не повторяем все edge-case'ы парсера — те живут в test_db_migrations.py).
    """

    def test_delegates_to_the_real_migrations_module(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            mig_dir = Path(tmp)
            (mig_dir / "0001_a.sql").write_text("SELECT 1;", encoding="utf-8")
            (mig_dir / "0002_b.sql").write_text("SELECT 2;", encoding="utf-8")

            result = BaseDatabase.collect_migration_files(mig_dir, "ns")
            self.assertEqual([v for v, _ in result], [1, 2])

    def test_delegation_propagates_duplicate_version_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            mig_dir = Path(tmp)
            (mig_dir / "0001_a.sql").write_text("SELECT 1;", encoding="utf-8")
            (mig_dir / "0001_b.sql").write_text("SELECT 2;", encoding="utf-8")

            with self.assertRaises(ValueError):
                BaseDatabase.collect_migration_files(mig_dir, "ns")


if __name__ == "__main__":
    unittest.main()
