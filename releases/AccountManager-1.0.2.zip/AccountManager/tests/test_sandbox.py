"""
tests/test_sandbox.py — core/sandbox.py: мягкая изоляция плагинов.

ВАЖНО про sys.addaudithook:
  Python гарантирует что audit hooks нельзя снять — они необратимы.
  Поэтому тесты блокировки системных вызовов запускаются в отдельных
  subprocess через python -c "..." чтобы не загрязнять process-wide хук
  основного test-runner процесса. Это единственный надёжный способ тестировать
  audit hooks без риска сломать другие тесты.

Timeout middleware тестируется через asyncio.run() с mock-handler.
"""
from __future__ import annotations

import asyncio
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from tests._support import env  # noqa: F401


# ═══════════════════════════════════════════════════════════════
# Import restrictions (importlib meta finder) — можно тестировать
# в текущем процессе через временный state, но осторожно:
# мы НЕ устанавливаем настоящий finder (он постоянный), а тестируем
# его логику напрямую.
# ═══════════════════════════════════════════════════════════════

class TestImportRestrictions(unittest.TestCase):

    def _make_finder(self, extra: frozenset | None = None):
        """Создаёт экземпляр BlockedImportFinder без side-effect установки в sys.meta_path."""
        from core.sandbox import _ALWAYS_BLOCKED_MODULES
        blocked = _ALWAYS_BLOCKED_MODULES | (extra or frozenset())

        class _Finder:
            def find_module(self, fullname, path=None):
                if fullname in blocked or fullname.split(".")[0] in blocked:
                    return self
            def load_module(self, fullname):
                raise ImportError(f"Blocked: {fullname}")

        return _Finder()

    def test_ctypes_is_blocked(self) -> None:
        finder = self._make_finder()
        self.assertIsNotNone(finder.find_module("ctypes"))

    def test_ctypes_util_is_blocked(self) -> None:
        finder = self._make_finder()
        self.assertIsNotNone(finder.find_module("ctypes.util"))

    def test_pty_is_blocked(self) -> None:
        finder = self._make_finder()
        self.assertIsNotNone(finder.find_module("pty"))

    def test_pexpect_is_blocked(self) -> None:
        finder = self._make_finder()
        self.assertIsNotNone(finder.find_module("pexpect"))

    def test_os_is_not_blocked(self) -> None:
        """os должен быть доступен — aiogram и core его используют."""
        finder = self._make_finder()
        self.assertIsNone(finder.find_module("os"))

    def test_socket_is_not_blocked(self) -> None:
        """socket нужен aiogram."""
        finder = self._make_finder()
        self.assertIsNone(finder.find_module("socket"))

    def test_asyncio_is_not_blocked(self) -> None:
        finder = self._make_finder()
        self.assertIsNone(finder.find_module("asyncio"))

    def test_json_is_not_blocked(self) -> None:
        finder = self._make_finder()
        self.assertIsNone(finder.find_module("json"))

    def test_extra_module_is_blocked_when_specified(self) -> None:
        finder = self._make_finder(extra=frozenset({"my_dangerous_lib"}))
        self.assertIsNotNone(finder.find_module("my_dangerous_lib"))

    def test_load_module_raises_import_error(self) -> None:
        finder = self._make_finder()
        with self.assertRaises(ImportError) as ctx:
            finder.load_module("ctypes")
        self.assertIn("ctypes", str(ctx.exception))
        self.assertIn("Blocked", str(ctx.exception))

    def test_blocked_events_frozenset_contains_subprocess(self) -> None:
        from core.sandbox import _BLOCKED_AUDIT_EVENTS
        self.assertIn("subprocess.Popen", _BLOCKED_AUDIT_EVENTS)
        self.assertIn("os.system", _BLOCKED_AUDIT_EVENTS)
        self.assertIn("os.execve", _BLOCKED_AUDIT_EVENTS)

    def test_always_blocked_frozenset_contains_ctypes(self) -> None:
        from core.sandbox import _ALWAYS_BLOCKED_MODULES
        self.assertIn("ctypes", _ALWAYS_BLOCKED_MODULES)
        self.assertIn("pty", _ALWAYS_BLOCKED_MODULES)


# ═══════════════════════════════════════════════════════════════
# Audit hooks — тестируем в subprocess чтобы не загрязнять
# process-wide state основного test runner
# ═══════════════════════════════════════════════════════════════

class TestAuditHooksSubprocess(unittest.TestCase):
    """
    Каждый тест запускает отдельный python subprocess чтобы:
    1. sys.addaudithook необратим — нельзя удалить после теста
    2. Блокировка subprocess.Popen не должна ломать test runner
    """

    def _run_snippet(self, code: str, timeout: int = 10) -> tuple[int, str, str]:
        """Запускает python -c '<code>' и возвращает (returncode, stdout, stderr)."""
        result = subprocess.run(
            [sys.executable, "-c", code],
            capture_output=True, text=True, timeout=timeout,
        )
        return result.returncode, result.stdout, result.stderr

    def test_audit_hook_blocks_os_system(self) -> None:
        code = """
import sys
sys.path.insert(0, '.')
from core.sandbox import install_audit_hooks
install_audit_hooks()
import os
try:
    os.system("echo hi")
    print("NOT_BLOCKED")
except PermissionError as e:
    print(f"BLOCKED:{e}")
"""
        rc, out, err = self._run_snippet(code)
        self.assertIn("BLOCKED", out, f"os.system should be blocked.\nstdout:{out}\nstderr:{err}")
        self.assertNotIn("NOT_BLOCKED", out)

    def test_audit_hook_blocks_subprocess_popen(self) -> None:
        code = """
import sys
sys.path.insert(0, '.')
from core.sandbox import install_audit_hooks
install_audit_hooks()
import subprocess
try:
    subprocess.run(['echo', 'hi'], capture_output=True)
    print("NOT_BLOCKED")
except PermissionError as e:
    print(f"BLOCKED:{e}")
"""
        rc, out, err = self._run_snippet(code)
        self.assertIn("BLOCKED", out, f"subprocess.Popen should be blocked.\nstdout:{out}\nstderr:{err}")
        self.assertNotIn("NOT_BLOCKED", out)

    def test_audit_hook_does_not_block_file_open(self) -> None:
        """Файловый ввод-вывод должен работать нормально."""
        code = """
import sys, tempfile, os
sys.path.insert(0, '.')
from core.sandbox import install_audit_hooks
install_audit_hooks()
with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
    f.write('hello')
    name = f.name
with open(name) as f:
    content = f.read()
os.unlink(name)
print(f"OK:{content}")
"""
        rc, out, err = self._run_snippet(code)
        self.assertIn("OK:hello", out, f"File I/O should work.\nstdout:{out}\nstderr:{err}")

    def test_install_audit_hooks_idempotent(self) -> None:
        """Двойная установка не должна ронять процесс."""
        code = """
import sys
sys.path.insert(0, '.')
from core.sandbox import install_audit_hooks
install_audit_hooks()
install_audit_hooks()
print("OK")
"""
        rc, out, _ = self._run_snippet(code)
        self.assertIn("OK", out)

    def test_sandbox_disabled_does_not_install_hooks(self) -> None:
        """apply_sandbox(config) с enabled=False ничего не устанавливает."""
        code = """
import sys
sys.path.insert(0, '.')
from core.sandbox import _audit_hook_installed, _import_finder_installed
from core.config import SandboxConfig

class _FakeConfig:
    sandbox = SandboxConfig(enabled=False)

from core.sandbox import apply_sandbox
apply_sandbox(_FakeConfig())

from core.sandbox import _audit_hook_installed as a, _import_finder_installed as b
print(f"audit={a} finder={b}")
"""
        rc, out, _ = self._run_snippet(code)
        self.assertIn("audit=False", out)
        self.assertIn("finder=False", out)


# ═══════════════════════════════════════════════════════════════
# Timeout middleware
# ═══════════════════════════════════════════════════════════════

class TestTimeoutMiddleware(unittest.TestCase):

    def _make_middleware(self, timeout_s: float):
        """Создаёт middleware без реального aiogram (fallback в sandbox.py)."""
        from core.sandbox import make_timeout_middleware
        cls = make_timeout_middleware(timeout_s)
        return cls()

    def test_fast_handler_completes_normally(self) -> None:
        mw = self._make_middleware(5.0)

        async def fast_handler(event, data):
            return "result"

        result = asyncio.run(mw(fast_handler, object(), {}))
        self.assertEqual(result, "result")

    def test_slow_handler_returns_none_after_timeout(self) -> None:
        mw = self._make_middleware(0.05)  # 50ms timeout

        async def slow_handler(event, data):
            await asyncio.sleep(10)   # 10 секунд — должен быть отменён
            return "never"

        result = asyncio.run(mw(slow_handler, object(), {}))
        self.assertIsNone(result, "Timeout should return None")

    def test_handler_exception_propagates(self) -> None:
        """Исключения плагина (не TimeoutError) должны propagate нормально."""
        mw = self._make_middleware(5.0)

        async def broken_handler(event, data):
            raise ValueError("plugin bug")

        with self.assertRaises(ValueError):
            asyncio.run(mw(broken_handler, object(), {}))

    def test_zero_timeout_disables_timeout(self) -> None:
        """handler_timeout_s=0 — timeout middleware не регистрируется (проверяем в main.py логике)."""
        # Здесь проверяем только что middleware с большим timeout не мешает
        mw = self._make_middleware(999.0)

        async def instant(event, data):
            return 42

        result = asyncio.run(mw(instant, object(), {}))
        self.assertEqual(result, 42)

    def test_handler_receives_event_and_data(self) -> None:
        mw = self._make_middleware(5.0)
        received = []

        async def capturing_handler(event, data):
            received.append((event, data))
            return "ok"

        event = object()
        data  = {"key": "value"}
        asyncio.run(mw(capturing_handler, event, data))
        self.assertEqual(len(received), 1)
        self.assertIs(received[0][0], event)
        self.assertEqual(received[0][1], data)


# ═══════════════════════════════════════════════════════════════
# SandboxConfig parsing
# ═══════════════════════════════════════════════════════════════

class TestSandboxConfig(unittest.TestCase):

    def setUp(self) -> None:
        import os, tempfile
        self._tmp = tempfile.TemporaryDirectory()
        self._orig = os.getcwd()
        os.chdir(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)
        self.addCleanup(os.chdir, self._orig)

    def _write_env(self) -> None:
        Path("configs").mkdir(exist_ok=True)
        Path("configs/.env").write_text("BOT_TOKEN=tok\n", encoding="utf-8")

    def _write_cfg(self, data: dict) -> None:
        import json
        Path("configs").mkdir(exist_ok=True)
        Path("configs/config.json").write_text(json.dumps(data), encoding="utf-8")

    def test_sandbox_defaults(self) -> None:
        self._write_env()
        from core.config import load_config
        cfg = load_config()
        self.assertTrue(cfg.sandbox.enabled)
        self.assertEqual(cfg.sandbox.handler_timeout_s, 30.0)
        self.assertTrue(cfg.sandbox.block_system_calls)
        self.assertEqual(cfg.sandbox.extra_blocked_modules, [])

    def test_sandbox_fields_parsed(self) -> None:
        self._write_env()
        self._write_cfg({
            "sandbox": {
                "enabled": False,
                "handler_timeout_s": 10.5,
                "block_system_calls": False,
                "extra_blocked_modules": ["dangerous_lib"],
            }
        })
        from core.config import load_config
        cfg = load_config()
        self.assertFalse(cfg.sandbox.enabled)
        self.assertAlmostEqual(cfg.sandbox.handler_timeout_s, 10.5)
        self.assertFalse(cfg.sandbox.block_system_calls)
        self.assertEqual(cfg.sandbox.extra_blocked_modules, ["dangerous_lib"])

    def test_sandbox_empty_section_uses_defaults(self) -> None:
        self._write_env()
        self._write_cfg({"sandbox": {}})
        from core.config import load_config
        cfg = load_config()
        self.assertTrue(cfg.sandbox.enabled)
        self.assertEqual(cfg.sandbox.handler_timeout_s, 30.0)


if __name__ == "__main__":
    unittest.main()
