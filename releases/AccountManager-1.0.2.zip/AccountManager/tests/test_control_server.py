"""
tests/test_control_server.py — core/control_server.py: ControlServer.

Протокол (одна JSON-строка запрос/ответ по TCP-loopback) тестируется
через настоящие сокеты (asyncio.start_server + asyncio.open_connection)
— иначе легко упустить реальные детали кодирования/декодирования,
таймаута, закрытия соединения. Логика отдельных команд (_handle_*)
тестируется напрямую, без сокетов, через мок PluginLoader.
"""
from __future__ import annotations

import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, create_autospec, patch

from tests._support import env  # noqa: F401

import core.control_server as control_server_module
import core as core_pkg
from core.control_server import ControlServer, read_control_file
from core.plugin_loader import PluginLoader


def _make_loader(**overrides) -> AsyncMock:
    loader = create_autospec(PluginLoader, instance=True)
    loader.known_plugin_names.return_value = overrides.get("known_plugin_names", [])
    loader.reload_plugin = AsyncMock(return_value=overrides.get("reload_plugin_result", True))
    loader.reload_all = AsyncMock(return_value=overrides.get("reload_all_result", {}))
    loader.status_snapshot.return_value = overrides.get("status_snapshot", {})
    loader._skip_reasons = overrides.get("skip_reasons", {})
    return loader


class ControlFileTestCase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.control_dir = Path(self._tmp.name) / "run"
        self.control_file = self.control_dir / "control.json"
        self._patch_dir = patch.object(control_server_module, "CONTROL_DIR", self.control_dir)
        self._patch_file = patch.object(control_server_module, "CONTROL_FILE", self.control_file)
        self._patch_dir.start()
        self._patch_file.start()
        self.addCleanup(self._patch_dir.stop)
        self.addCleanup(self._patch_file.stop)


class ReadControlFileTests(ControlFileTestCase):
    async def test_missing_file_returns_none(self) -> None:
        self.assertIsNone(read_control_file())

    async def test_malformed_json_returns_none(self) -> None:
        self.control_dir.mkdir(parents=True)
        self.control_file.write_text("{not valid", encoding="utf-8")
        self.assertIsNone(read_control_file())

    async def test_valid_file_returns_parsed_dict(self) -> None:
        self.control_dir.mkdir(parents=True)
        self.control_file.write_text(json.dumps({"pid": 123, "port": 4567}), encoding="utf-8")
        self.assertEqual(read_control_file(), {"pid": 123, "port": 4567})


class StartStopIntegrationTests(ControlFileTestCase):
    async def _send(self, port: int, payload: dict) -> dict:
        reader, writer = await asyncio.open_connection("127.0.0.1", port)
        writer.write((json.dumps(payload) + "\n").encode("utf-8"))
        await writer.drain()
        line = await asyncio.wait_for(reader.readline(), timeout=2.0)
        writer.close()
        await writer.wait_closed()
        return json.loads(line.decode("utf-8"))

    async def test_start_writes_control_file_with_matching_port_and_pid(self) -> None:
        import os
        loader = _make_loader()
        server = ControlServer(loader, dp=object())
        await server.start()
        self.addAsyncCleanup(server.stop)

        data = read_control_file()
        self.assertEqual(data["pid"], os.getpid())
        self.assertIn("started_at", data)

        response = await self._send(data["port"], {"cmd": "ping"})
        self.assertTrue(response["ok"])
        self.assertEqual(response["pid"], os.getpid())
        self.assertEqual(response["core_version"], core_pkg.__version__)

    async def test_stop_removes_control_file_and_refuses_new_connections(self) -> None:
        loader = _make_loader()
        server = ControlServer(loader, dp=object())
        await server.start()
        data = read_control_file()
        port = data["port"]

        await server.stop()
        self.assertIsNone(read_control_file())

        with self.assertRaises(ConnectionRefusedError):
            await asyncio.open_connection("127.0.0.1", port)

    async def test_stop_is_safe_to_call_when_control_file_already_gone(self) -> None:
        loader = _make_loader()
        server = ControlServer(loader, dp=object())
        await server.start()
        self.control_file.unlink()
        await server.stop()  # не должно бросить FileNotFoundError наружу

    async def test_unknown_command_over_the_wire(self) -> None:
        loader = _make_loader()
        server = ControlServer(loader, dp=object())
        await server.start()
        self.addAsyncCleanup(server.stop)
        data = read_control_file()

        response = await self._send(data["port"], {"cmd": "self_destruct"})
        self.assertFalse(response["ok"])
        self.assertIn("self_destruct", response["error"])

    async def test_malformed_json_over_the_wire_does_not_crash_server(self) -> None:
        loader = _make_loader()
        server = ControlServer(loader, dp=object())
        await server.start()
        self.addAsyncCleanup(server.stop)
        data = read_control_file()

        reader, writer = await asyncio.open_connection("127.0.0.1", data["port"])
        writer.write(b"{not valid json at all\n")
        await writer.drain()
        line = await asyncio.wait_for(reader.readline(), timeout=2.0)
        writer.close()
        await writer.wait_closed()
        response = json.loads(line.decode("utf-8"))
        self.assertFalse(response["ok"])
        self.assertIn("некорректный запрос", response["error"])

        # сервер остаётся рабочим для следующего соединения
        response2 = await self._send(data["port"], {"cmd": "ping"})
        self.assertTrue(response2["ok"])


class HandleConnectionTimeoutTests(unittest.IsolatedAsyncioTestCase):
    """Юнит-тест таймаута напрямую (без реального 10-секундного ожидания)."""

    async def test_timeout_waiting_for_request_returns_error_without_waiting_ten_seconds(self) -> None:
        loader = _make_loader()
        server = ControlServer(loader, dp=object())

        fake_reader = MagicMock()  # readline() никогда реально не await'ится — asyncio.wait_for замокан
        fake_reader.readline = MagicMock(return_value=object())
        written = []
        fake_writer = MagicMock()  # close()/write() — синхронные, как у настоящего StreamWriter
        fake_writer.write = lambda data: written.append(data)
        fake_writer.drain = AsyncMock()
        fake_writer.wait_closed = AsyncMock()

        with patch("asyncio.wait_for", side_effect=asyncio.TimeoutError):
            await server._handle_connection(fake_reader, fake_writer)

        response = json.loads(written[0].decode("utf-8"))
        self.assertFalse(response["ok"])
        self.assertIn("таймаут", response["error"])


class CommandLogicTests(unittest.IsolatedAsyncioTestCase):
    """Логика отдельных команд напрямую, без сокетов."""

    async def test_reload_missing_plugin_name(self) -> None:
        server = ControlServer(_make_loader(), dp=object())
        result = await server._handle_reload({"cmd": "reload"})
        self.assertFalse(result["ok"])
        self.assertIn("не указано", result["error"])

    async def test_reload_unknown_plugin(self) -> None:
        loader = _make_loader(known_plugin_names=["antispam"])
        server = ControlServer(loader, dp=object())
        result = await server._handle_reload({"cmd": "reload", "plugin": "ghost"})
        self.assertFalse(result["ok"])
        self.assertIn("ghost", result["error"])
        loader.reload_plugin.assert_not_called()

    async def test_reload_success(self) -> None:
        loader = _make_loader(known_plugin_names=["antispam"], reload_plugin_result=True)
        server = ControlServer(loader, dp=object())
        result = await server._handle_reload({"cmd": "reload", "plugin": "antispam"})
        self.assertEqual(result, {"ok": True, "plugin": "antispam", "reason": ""})

    async def test_reload_failure_includes_skip_reason(self) -> None:
        loader = _make_loader(
            known_plugin_names=["antispam"],
            reload_plugin_result=False,
            skip_reasons={"antispam": "manifest.json невалиден"},
        )
        server = ControlServer(loader, dp=object())
        result = await server._handle_reload({"cmd": "reload", "plugin": "antispam"})
        self.assertEqual(
            result, {"ok": False, "plugin": "antispam", "reason": "manifest.json невалиден"}
        )

    async def test_reload_all_all_succeed(self) -> None:
        loader = _make_loader(reload_all_result={"a": True, "b": True})
        server = ControlServer(loader, dp=object())
        result = await server._handle_reload_all({})
        self.assertEqual(result, {"ok": True, "results": {"a": True, "b": True}})

    async def test_reload_all_one_fails_overall_not_ok(self) -> None:
        loader = _make_loader(reload_all_result={"a": True, "b": False})
        server = ControlServer(loader, dp=object())
        result = await server._handle_reload_all({})
        self.assertFalse(result["ok"])
        self.assertEqual(result["results"], {"a": True, "b": False})

    async def test_status_merges_snapshot_fields(self) -> None:
        loader = _make_loader(status_snapshot={"loaded": ["a", "b"], "skipped": []})
        server = ControlServer(loader, dp=object())
        result = await server._handle_status({})
        self.assertEqual(result, {"ok": True, "loaded": ["a", "b"], "skipped": []})

    async def test_status_snapshot_containing_ok_key_no_longer_overrides_hardcoded_true(self) -> None:
        """
        Раньше {"ok": True, **snapshot} — если бы snapshot начал
        возвращать собственный ключ "ok", он молча ПЕРЕЗАПИСЫВАЛ бы
        хардкод True (порядок распаковки словаря). Теперь порядок
        обратный ({**snapshot, "ok": True}) — хардкод всегда побеждает.
        """
        loader = _make_loader(status_snapshot={"ok": False, "reason": "surprise"})
        server = ControlServer(loader, dp=object())
        result = await server._handle_status({})
        self.assertEqual(result, {"ok": True, "reason": "surprise"})


class ShutdownCommandTests(unittest.IsolatedAsyncioTestCase):
    async def test_shutdown_responds_ok_immediately_before_stopping_anything(self) -> None:
        dp = AsyncMock()
        server = ControlServer(_make_loader(), dp=dp, mode="polling")
        result = await server._handle_shutdown({})
        self.assertEqual(result, {"ok": True})
        dp.stop_polling.assert_not_called()  # ещё не наступило (задержка 0.1с)

    async def test_shutdown_polling_mode_calls_stop_polling_after_delay(self) -> None:
        dp = AsyncMock()
        server = ControlServer(_make_loader(), dp=dp, mode="polling")
        await server._handle_shutdown({})
        await asyncio.sleep(0.25)
        dp.stop_polling.assert_called_once()

    async def test_shutdown_webhook_mode_sets_stop_event_after_delay(self) -> None:
        stop_event = asyncio.Event()
        server = ControlServer(_make_loader(), dp=object(), mode="webhook", stop_event=stop_event)
        await server._handle_shutdown({})
        self.assertFalse(stop_event.is_set())
        await asyncio.sleep(0.25)
        self.assertTrue(stop_event.is_set())

    async def test_shutdown_webhook_mode_without_stop_event_logs_error_and_does_not_crash(self) -> None:
        server = ControlServer(_make_loader(), dp=object(), mode="webhook", stop_event=None)
        await server._handle_shutdown({})
        with self.assertLogs("control_server", level="ERROR"):
            await asyncio.sleep(0.25)  # не должно бросить, даже без stop_event


if __name__ == "__main__":
    unittest.main()
