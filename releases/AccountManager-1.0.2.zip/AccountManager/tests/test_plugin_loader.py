"""
tests/test_plugin_loader.py — core/plugin_loader.py: PluginLoader
(сканирование manifest.json -> совместимость с ядром -> pip-зависимости
-> топосортировка -> загрузка/выгрузка/reload плагинов).

Самый крупный и самый интеграционный модуль ядра — используются
настоящие временные каталоги плагинов, настоящий HookBus/PatchManager/
ServiceRegistry/Scheduler (не моки: это уже отдельно и тщательно
протестированные компоненты, здесь важно именно их совместное
поведение) и настоящее выполнение SQL через фейковый aiosqlite (см.
tests/_support/env.py) для персональных БД плагинов.
"""
from __future__ import annotations

import asyncio
import json
import sys
import tempfile
import textwrap
import unittest
import unittest.mock
from pathlib import Path

from tests._support import env

env.ensure_aiosqlite()

from core.config import Config  # noqa: E402
from core.hooks import HookBus  # noqa: E402
from core.patches import PatchManager  # noqa: E402
from core.plugin_loader import (  # noqa: E402
    PluginClassError,
    PluginLoader,
    PluginRecord,
    _kahn_sort,
    _load_plugin_class,
)
from core.scheduler import Scheduler  # noqa: E402
from core.services import ServiceRegistry  # noqa: E402
from core.db.sqlite_backend import SQLiteDatabase  # noqa: E402

_VALID_PLUGIN_PY = textwrap.dedent("""
    from plugins.base import BasePlugin

    class MyPlugin(BasePlugin):
        @property
        def name(self) -> str:
            return "test-plugin"

        @property
        def version(self) -> str:
            return "1.0.0"

        async def setup(self, ctx) -> None:
            self.ctx = ctx
""")


def make_loader() -> PluginLoader:
    return PluginLoader(hooks=HookBus(), patches=PatchManager(), services=ServiceRegistry(), scheduler=Scheduler())


def write_plugin(
    plugins_root: Path,
    folder_name: str,
    *,
    name: str | None = None,
    version: str = "1.0.0",
    plugin_py: str | None = _VALID_PLUGIN_PY,
    manifest_extra: dict | None = None,
    write_manifest: bool = True,
    manifest_raw: str | None = None,
) -> Path:
    d = plugins_root / folder_name
    d.mkdir(parents=True, exist_ok=True)
    if manifest_raw is not None:
        (d / "manifest.json").write_text(manifest_raw, encoding="utf-8")
    elif write_manifest:
        manifest = {"name": name or folder_name, "version": version}
        manifest.update(manifest_extra or {})
        (d / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    if plugin_py is not None:
        (d / "plugin.py").write_text(plugin_py, encoding="utf-8")
    return d


class LoadPluginClassTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self._mod_names: list[str] = []

    def tearDown(self) -> None:
        for name in self._mod_names:
            sys.modules.pop(name, None)

    def load(self, path: Path, module_name: str | None = None):
        mod_name = module_name or f"test_plugin_mod_{id(path)}_{len(self._mod_names)}"
        self._mod_names.append(mod_name)
        return _load_plugin_class(path, module_name=mod_name)

    def test_no_plugin_py_returns_none(self) -> None:
        d = self.root / "empty"
        d.mkdir()
        self.assertIsNone(self.load(d))

    def test_single_subclass_is_found_automatically(self) -> None:
        d = write_plugin(self.root, "p1")
        cls = self.load(d)
        self.assertEqual(cls.__name__, "MyPlugin")

    def test_zero_subclasses_returns_none(self) -> None:
        d = write_plugin(self.root, "p1", plugin_py="x = 1\n")
        self.assertIsNone(self.load(d))

    def test_explicit_plugin_attribute_is_used(self) -> None:
        code = textwrap.dedent("""
            from plugins.base import BasePlugin

            class A(BasePlugin):
                @property
                def name(self): return "a"
                @property
                def version(self): return "1.0.0"
                async def setup(self, ctx): pass

            class B(BasePlugin):
                @property
                def name(self): return "b"
                @property
                def version(self): return "1.0.0"
                async def setup(self, ctx): pass

            PLUGIN = B
        """)
        d = write_plugin(self.root, "p1", plugin_py=code)
        cls = self.load(d)
        self.assertEqual(cls.__name__, "B")

    def test_explicit_plugin_attribute_not_a_baseplugin_subclass_raises(self) -> None:
        code = textwrap.dedent("""
            PLUGIN = "not a class at all"
        """)
        d = write_plugin(self.root, "p1", plugin_py=code)
        with self.assertRaises(PluginClassError):
            self.load(d)

    def test_multiple_subclasses_without_plugin_attribute_raises_with_names(self) -> None:
        code = textwrap.dedent("""
            from plugins.base import BasePlugin

            class Alpha(BasePlugin):
                @property
                def name(self): return "a"
                @property
                def version(self): return "1.0.0"
                async def setup(self, ctx): pass

            class Beta(BasePlugin):
                @property
                def name(self): return "b"
                @property
                def version(self): return "1.0.0"
                async def setup(self, ctx): pass
        """)
        d = write_plugin(self.root, "p1", plugin_py=code)
        with self.assertRaises(PluginClassError) as ctx:
            self.load(d)
        self.assertIn("Alpha", str(ctx.exception))
        self.assertIn("Beta", str(ctx.exception))
        self.assertIn("PLUGIN = ", str(ctx.exception))

    def test_module_is_registered_in_sys_modules(self) -> None:
        d = write_plugin(self.root, "p1")
        mod_name = "test_sys_modules_check"
        self._mod_names.append(mod_name)
        _load_plugin_class(d, module_name=mod_name)
        self.assertIn(mod_name, sys.modules)

    def test_failed_exec_module_removes_partial_entry_from_sys_modules(self) -> None:
        d = write_plugin(self.root, "p1", plugin_py="raise RuntimeError('boom at import time')\n")
        mod_name = "test_failed_exec_module"
        self._mod_names.append(mod_name)
        with self.assertRaises(RuntimeError):
            _load_plugin_class(d, module_name=mod_name)
        self.assertNotIn(mod_name, sys.modules)

    def test_two_different_module_names_produce_independent_class_objects(self) -> None:
        d = write_plugin(self.root, "p1")
        cls1 = self.load(d)
        cls2 = self.load(d)
        self.assertIsNot(cls1, cls2)  # разные импорты одного и того же файла

    def test_class_imported_from_elsewhere_is_excluded_by_module_identity_check(self) -> None:
        # helper.py объявляет свой подкласс BasePlugin
        helper_dir = self.root / "helper_pkg"
        helper_dir.mkdir()
        (helper_dir / "__init__.py").write_text("", encoding="utf-8")
        helper_mod_name = "test_helper_module_for_identity_check"
        sys.modules.pop(helper_mod_name, None)
        import importlib.util as _ilu
        (helper_dir / "helper.py").write_text(textwrap.dedent("""
            from plugins.base import BasePlugin
            class Imported(BasePlugin):
                @property
                def name(self): return "imported"
                @property
                def version(self): return "1.0.0"
                async def setup(self, ctx): pass
        """), encoding="utf-8")
        spec = _ilu.spec_from_file_location(helper_mod_name, helper_dir / "helper.py")
        helper_module = _ilu.module_from_spec(spec)
        sys.modules[helper_mod_name] = helper_module
        spec.loader.exec_module(helper_module)
        self.addCleanup(sys.modules.pop, helper_mod_name, None)

        code = textwrap.dedent(f"""
            import sys
            Imported = sys.modules["{helper_mod_name}"].Imported

            from plugins.base import BasePlugin
            class Local(BasePlugin):
                @property
                def name(self): return "local"
                @property
                def version(self): return "1.0.0"
                async def setup(self, ctx): pass
        """)
        d = write_plugin(self.root, "p1", plugin_py=code)
        cls = self.load(d)
        self.assertEqual(cls.__name__, "Local")  # Imported не считается кандидатом


class KahnSortTests(unittest.TestCase):
    def test_no_dependencies_sorts_alphabetically(self) -> None:
        order, cycles = _kahn_sort({"c", "a", "b"}, {})
        self.assertEqual(order, ["a", "b", "c"])
        self.assertEqual(cycles, set())

    def test_linear_chain(self) -> None:
        # a зависит от b, b зависит от c -> порядок [c, b, a]
        order, cycles = _kahn_sort({"a", "b", "c"}, {"a": {"b"}, "b": {"c"}})
        self.assertEqual(order, ["c", "b", "a"])
        self.assertEqual(cycles, set())

    def test_diamond_dependency(self) -> None:
        order, cycles = _kahn_sort(
            {"a", "b", "c", "d"},
            {"a": {"c"}, "b": {"c"}, "d": {"a", "b"}},
        )
        self.assertEqual(order[0], "c")
        self.assertEqual(order[-1], "d")
        self.assertEqual(set(order[1:3]), {"a", "b"})
        self.assertEqual(cycles, set())

    def test_direct_cycle(self) -> None:
        order, cycles = _kahn_sort({"a", "b"}, {"a": {"b"}, "b": {"a"}})
        self.assertEqual(order, [])
        self.assertEqual(cycles, {"a", "b"})

    def test_partial_cycle_leaves_independent_node_ordered(self) -> None:
        order, cycles = _kahn_sort(
            {"a", "b", "independent"}, {"a": {"b"}, "b": {"a"}}
        )
        self.assertEqual(order, ["independent"])
        self.assertEqual(cycles, {"a", "b"})

    def test_predecessor_outside_node_set_is_ignored(self) -> None:
        order, cycles = _kahn_sort({"a"}, {"a": {"outside_the_set"}})
        self.assertEqual(order, ["a"])
        self.assertEqual(cycles, set())

    def test_self_referencing_node_is_a_cycle_of_one(self) -> None:
        order, cycles = _kahn_sort({"a"}, {"a": {"a"}})
        self.assertEqual(order, [])
        self.assertEqual(cycles, {"a"})


class PluginRecordTests(unittest.TestCase):
    def test_defaults_when_fields_absent(self) -> None:
        rec = PluginRecord("x", Path("/tmp/x"), {})
        self.assertEqual(rec.version, "0.0.0")
        self.assertEqual(rec.author, "")
        self.assertEqual(rec.description, "")
        self.assertEqual(rec.repository_url, "")
        self.assertEqual(rec.core_version_raw, "")
        self.assertEqual(rec.load_order, "after_bot")

    def test_after_target_parses_after_colon_syntax(self) -> None:
        rec = PluginRecord("x", Path("/tmp/x"), {"load_order": "after:foo"})
        self.assertEqual(rec.after_target, "foo")

    def test_after_target_strips_whitespace(self) -> None:
        rec = PluginRecord("x", Path("/tmp/x"), {"load_order": "after:  foo  "})
        self.assertEqual(rec.after_target, "foo")

    def test_after_target_none_for_before_bot_and_after_bot(self) -> None:
        self.assertIsNone(PluginRecord("x", Path("/tmp/x"), {"load_order": "before_bot"}).after_target)
        self.assertIsNone(PluginRecord("x", Path("/tmp/x"), {"load_order": "after_bot"}).after_target)

    def test_plugin_deps_and_pip_deps_parse_lists(self) -> None:
        rec = PluginRecord("x", Path("/tmp/x"), {
            "dependencies": {"plugins": ["antispam>=1.0"], "pip": ["aiogram>=3.15"]},
        })
        self.assertEqual([s.name for s in rec.plugin_deps()], ["antispam"])
        self.assertEqual([s.name for s in rec.pip_deps()], ["aiogram"])

    def test_missing_dependencies_key_yields_empty_lists(self) -> None:
        rec = PluginRecord("x", Path("/tmp/x"), {})
        self.assertEqual(rec.plugin_deps(), [])
        self.assertEqual(rec.pip_deps(), [])


class ScanTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.plugins_dir = Path(self._tmp.name)

    def test_basic_scan_populates_records(self) -> None:
        write_plugin(self.plugins_dir, "antispam", version="1.2.3")
        loader = make_loader()
        loader.scan(self.plugins_dir, [])
        self.assertIn("antispam", loader._records)
        self.assertEqual(loader._records["antispam"].version, "1.2.3")
        self.assertEqual(loader._skipped, set())

    def test_identity_is_manifest_name_not_folder_name(self) -> None:
        write_plugin(self.plugins_dir, "folder_x", name="real_name")
        loader = make_loader()
        loader.scan(self.plugins_dir, [])
        self.assertIn("real_name", loader._records)
        self.assertNotIn("folder_x", loader._records)

    def test_missing_name_field_falls_back_to_folder_name(self) -> None:
        d = self.plugins_dir / "folder_y"
        d.mkdir()
        (d / "manifest.json").write_text(json.dumps({"version": "1.0.0"}), encoding="utf-8")
        loader = make_loader()
        loader.scan(self.plugins_dir, [])
        self.assertIn("folder_y", loader._records)

    def test_enabled_false_excludes_plugin_entirely(self) -> None:
        write_plugin(self.plugins_dir, "antispam", manifest_extra={"enabled": False})
        loader = make_loader()
        loader.scan(self.plugins_dir, [])
        self.assertNotIn("antispam", loader._records)
        self.assertNotIn("antispam", loader._skipped)

    def test_disabled_plugins_list_excludes_plugin_entirely(self) -> None:
        write_plugin(self.plugins_dir, "antispam")
        loader = make_loader()
        loader.scan(self.plugins_dir, ["antispam"])
        self.assertNotIn("antispam", loader._records)
        self.assertNotIn("antispam", loader._skipped)

    def test_malformed_manifest_json_is_completely_excluded_not_even_skipped(self) -> None:
        write_plugin(self.plugins_dir, "broken", manifest_raw="{not valid json")
        loader = make_loader()
        loader.scan(self.plugins_dir, [])
        self.assertNotIn("broken", loader._records)
        self.assertNotIn("broken", loader._skipped)

    def test_folder_without_manifest_is_silently_ignored(self) -> None:
        write_plugin(self.plugins_dir, "no_manifest", write_manifest=False)
        loader = make_loader()
        loader.scan(self.plugins_dir, [])  # не должно бросить
        self.assertEqual(loader._records, {})

    def test_stray_file_in_plugins_dir_is_ignored(self) -> None:
        (self.plugins_dir / "readme.txt").write_text("x", encoding="utf-8")
        loader = make_loader()
        loader.scan(self.plugins_dir, [])  # не должно бросить
        self.assertEqual(loader._records, {})

    def test_name_collision_between_two_folders_skips_both(self) -> None:
        # Ровно сценарий из докстринга: "antispam_old" лексикографически
        # позже "antispam_new" — раньше это молча побеждало.
        write_plugin(self.plugins_dir, "antispam_new", name="antispam", version="2.0.0")
        write_plugin(self.plugins_dir, "antispam_old", name="antispam", version="1.0.0")
        loader = make_loader()
        loader.scan(self.plugins_dir, [])

        self.assertIn("antispam", loader._skipped)
        reason = loader._skip_reasons["antispam"]
        self.assertIn("antispam_new", reason)
        self.assertIn("antispam_old", reason)
        self.assertIn("v2.0.0", reason)
        self.assertIn("v1.0.0", reason)

    def test_three_way_collision_mentions_all_three(self) -> None:
        write_plugin(self.plugins_dir, "dup1", name="dup")
        write_plugin(self.plugins_dir, "dup2", name="dup")
        write_plugin(self.plugins_dir, "dup3", name="dup")
        loader = make_loader()
        loader.scan(self.plugins_dir, [])
        reason = loader._skip_reasons["dup"]
        for folder in ("dup1", "dup2", "dup3"):
            self.assertIn(folder, reason)

    def test_collision_does_not_affect_other_unrelated_plugins(self) -> None:
        write_plugin(self.plugins_dir, "dup1", name="dup")
        write_plugin(self.plugins_dir, "dup2", name="dup")
        write_plugin(self.plugins_dir, "unrelated")
        loader = make_loader()
        loader.scan(self.plugins_dir, [])
        self.assertIn("unrelated", loader._records)
        self.assertNotIn("unrelated", loader._skipped)


class CheckCoreCompatTests(unittest.TestCase):
    def make_loader_with(self, core_version_raw: str | None) -> PluginLoader:
        loader = make_loader()
        manifest = {"name": "p", "version": "1.0.0"}
        if core_version_raw is not None:
            manifest["core_version"] = core_version_raw
        loader._records["p"] = PluginRecord("p", Path("/tmp/p"), manifest)
        return loader

    def test_no_core_version_field_is_always_compatible(self) -> None:
        loader = self.make_loader_with(None)
        loader.check_core_compat()
        self.assertNotIn("p", loader._skipped)

    def test_compatible_core_version(self) -> None:
        import core as core_pkg
        loader = self.make_loader_with(f">={core_pkg.__version__}")
        loader.check_core_compat()
        self.assertNotIn("p", loader._skipped)

    def test_incompatible_core_version_is_skipped(self) -> None:
        loader = self.make_loader_with(">=999.0.0")
        loader.check_core_compat()
        self.assertIn("p", loader._skipped)
        self.assertIn("несовместим с ядром", loader._skip_reasons["p"])

    def test_malformed_core_version_specifier_is_skipped(self) -> None:
        loader = self.make_loader_with("not a valid specifier!!!")
        loader.check_core_compat()
        self.assertIn("p", loader._skipped)
        self.assertIn("некорректное поле core_version", loader._skip_reasons["p"])


class CheckPipDepsTests(unittest.TestCase):
    def make_loader_with_pip_deps(self, pip_deps: list[str]) -> PluginLoader:
        loader = make_loader()
        loader._records["p"] = PluginRecord(
            "p", Path("/tmp/p"),
            {"name": "p", "version": "1.0.0", "dependencies": {"pip": pip_deps}},
        )
        return loader

    def test_satisfied_pip_dependency_is_not_skipped(self) -> None:
        # packaging сам у нас установлен -- используем его как гарантированно существующий пакет
        loader = self.make_loader_with_pip_deps(["packaging"])
        loader.check_pip_deps()
        self.assertNotIn("p", loader._skipped)

    def test_missing_pip_dependency_is_skipped_with_install_suggestion(self) -> None:
        loader = self.make_loader_with_pip_deps(["totally-nonexistent-package-xyz-123"])
        loader.check_pip_deps()
        self.assertIn("p", loader._skipped)
        self.assertIn("pip install", loader._skip_reasons["p"])

    def test_first_failing_dep_short_circuits_remaining_checks(self) -> None:
        loader = self.make_loader_with_pip_deps([
            "totally-nonexistent-package-xyz-123", "also-nonexistent-abc-456",
        ])
        loader.check_pip_deps()
        # только ПЕРВАЯ причина зафиксирована (break после первого несоответствия)
        self.assertIn("totally-nonexistent-package-xyz-123", loader._skip_reasons["p"])
        self.assertNotIn("also-nonexistent-abc-456", loader._skip_reasons["p"])

    def test_malformed_pip_dependency_string_is_skipped(self) -> None:
        loader = self.make_loader_with_pip_deps([">=1.0 no name here"])
        loader.check_pip_deps()
        self.assertIn("p", loader._skipped)
        self.assertIn("некорректная pip-зависимость", loader._skip_reasons["p"])

    def test_no_pip_deps_is_not_skipped(self) -> None:
        loader = self.make_loader_with_pip_deps([])
        loader.check_pip_deps()
        self.assertNotIn("p", loader._skipped)


class ResolveOrderTests(unittest.TestCase):
    def make_loader_with_records(self, records: dict[str, dict]) -> PluginLoader:
        loader = make_loader()
        for name, manifest in records.items():
            full = {"name": name, "version": "1.0.0", **manifest}
            loader._records[name] = PluginRecord(name, Path(f"/tmp/{name}"), full)
        return loader

    def test_no_dependencies_all_load(self) -> None:
        loader = self.make_loader_with_records({"a": {}, "b": {}, "c": {}})
        loader.resolve_order()
        self.assertEqual(set(loader._load_order), {"a", "b", "c"})
        self.assertEqual(loader._skipped, set())

    def test_before_bot_loads_entirely_before_after_bot(self) -> None:
        loader = self.make_loader_with_records({
            "z_before": {"load_order": "before_bot"},
            "a_after": {"load_order": "after_bot"},
        })
        loader.resolve_order()
        self.assertEqual(loader._load_order, ["z_before", "a_after"])  # не алфавитный порядок!

    def test_dependency_on_missing_plugin_propagates_skip(self) -> None:
        loader = self.make_loader_with_records({
            "a": {"dependencies": {"plugins": ["ghost"]}},
        })
        loader.resolve_order()
        self.assertIn("a", loader._skipped)
        self.assertIn("ghost", loader._skip_reasons["a"])

    def test_dependency_on_already_skipped_plugin_propagates_transitively(self) -> None:
        loader = self.make_loader_with_records({
            "a": {"dependencies": {"plugins": ["b"]}},
            "b": {"core_version": ">=999.0.0"},  # несовместим -> будет skipped на compat-этапе
        })
        loader.check_core_compat()
        loader.resolve_order()
        self.assertIn("b", loader._skipped)
        self.assertIn("a", loader._skipped)
        self.assertIn("не загружен", loader._skip_reasons["a"])

    def test_dependency_version_mismatch_propagates_skip(self) -> None:
        loader = self.make_loader_with_records({
            "a": {"dependencies": {"plugins": ["b>=2.0.0"]}},
            "b": {"version": "1.0.0"},
        })
        loader.resolve_order()
        self.assertIn("a", loader._skipped)
        self.assertNotIn("b", loader._skipped)  # b сам по себе в порядке

    def test_after_target_missing_propagates_skip(self) -> None:
        loader = self.make_loader_with_records({
            "a": {"load_order": "after:ghost"},
        })
        loader.resolve_order()
        self.assertIn("a", loader._skipped)

    def test_after_target_referencing_before_bot_plugin_needs_no_special_edge(self) -> None:
        loader = self.make_loader_with_records({
            "early": {"load_order": "before_bot"},
            "late": {"load_order": "after:early"},
        })
        loader.resolve_order()
        self.assertEqual(loader._skipped, set())
        self.assertEqual(loader._load_order, ["early", "late"])

    def test_after_colon_syntax_always_lands_in_after_bot_group_regardless_of_target(self) -> None:
        loader = self.make_loader_with_records({
            "x": {"load_order": "after:nonexistent"},
            "before_one": {"load_order": "before_bot"},
        })
        loader.resolve_order()
        # before_one должен идти первым в любом случае, т.к. x лежит в after-группе
        self.assertEqual(loader._load_order, ["before_one"])  # x пропущен (ghost target)
        self.assertIn("x", loader._skipped)

    def test_cycle_within_before_bot_skips_only_cycle_members(self) -> None:
        loader = self.make_loader_with_records({
            "a": {"load_order": "before_bot", "dependencies": {"plugins": ["b"]}},
            "b": {"load_order": "before_bot", "dependencies": {"plugins": ["a"]}},
            "c": {"load_order": "before_bot"},
        })
        loader.resolve_order()
        self.assertIn("a", loader._skipped)
        self.assertIn("b", loader._skipped)
        self.assertNotIn("c", loader._skipped)
        self.assertEqual(loader._load_order, ["c"])

    def test_cycle_within_after_bot_skips_only_cycle_members(self) -> None:
        loader = self.make_loader_with_records({
            "a": {"dependencies": {"plugins": ["b"]}},
            "b": {"dependencies": {"plugins": ["a"]}},
            "c": {},
        })
        loader.resolve_order()
        self.assertIn("a", loader._skipped)
        self.assertIn("b", loader._skipped)
        self.assertEqual(loader._load_order, ["c"])

    def test_diamond_shaped_dependency_all_load_in_valid_order(self) -> None:
        loader = self.make_loader_with_records({
            "base": {},
            "mid_a": {"dependencies": {"plugins": ["base"]}},
            "mid_b": {"dependencies": {"plugins": ["base"]}},
            "top": {"dependencies": {"plugins": ["mid_a", "mid_b"]}},
        })
        loader.resolve_order()
        self.assertEqual(loader._skipped, set())
        order = loader._load_order
        self.assertLess(order.index("base"), order.index("mid_a"))
        self.assertLess(order.index("base"), order.index("mid_b"))
        self.assertLess(order.index("mid_a"), order.index("top"))
        self.assertLess(order.index("mid_b"), order.index("top"))


class PluginDatabaseCachingTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.plugins_dir = Path(self._tmp.name)

    def make_loader_ready_for_db(self) -> PluginLoader:
        loader = make_loader()
        loader._config = Config(bot_token="x")  # backend=sqlite по умолчанию
        return loader

    async def test_first_call_creates_and_connects(self) -> None:
        loader = self.make_loader_ready_for_db()
        rec = PluginRecord("p", self.plugins_dir / "p", {"name": "p", "version": "1.0.0"})
        db = await loader._get_plugin_database(rec)
        self.addAsyncCleanup(loader.close_all_plugin_databases)
        self.assertTrue((self.plugins_dir / "p" / "database" / "database.db").exists())
        self.assertIs(loader._plugin_dbs["p"], db)

    async def test_second_call_for_same_plugin_returns_cached_instance(self) -> None:
        loader = self.make_loader_ready_for_db()
        rec = PluginRecord("p", self.plugins_dir / "p", {"name": "p", "version": "1.0.0"})
        db1 = await loader._get_plugin_database(rec)
        db2 = await loader._get_plugin_database(rec)
        self.addAsyncCleanup(loader.close_all_plugin_databases)
        self.assertIs(db1, db2)

    async def test_different_plugins_get_different_database_instances(self) -> None:
        loader = self.make_loader_ready_for_db()
        rec_a = PluginRecord("a", self.plugins_dir / "a", {"name": "a", "version": "1.0.0"})
        rec_b = PluginRecord("b", self.plugins_dir / "b", {"name": "b", "version": "1.0.0"})
        db_a = await loader._get_plugin_database(rec_a)
        db_b = await loader._get_plugin_database(rec_b)
        self.addAsyncCleanup(loader.close_all_plugin_databases)
        self.assertIsNot(db_a, db_b)
        self.assertNotEqual(db_a.db_path, db_b.db_path)

    async def test_called_before_load_plugins_asserts(self) -> None:
        loader = make_loader()  # _config остался None
        rec = PluginRecord("p", self.plugins_dir / "p", {"name": "p", "version": "1.0.0"})
        with self.assertRaises(AssertionError):
            await loader._get_plugin_database(rec)

    async def test_close_all_clears_cache(self) -> None:
        loader = self.make_loader_ready_for_db()
        rec = PluginRecord("p", self.plugins_dir / "p", {"name": "p", "version": "1.0.0"})
        await loader._get_plugin_database(rec)
        await loader.close_all_plugin_databases()
        self.assertEqual(loader._plugin_dbs, {})

    async def test_close_all_is_resilient_to_one_db_failing_to_close(self) -> None:
        loader = self.make_loader_ready_for_db()
        rec_a = PluginRecord("a", self.plugins_dir / "a", {"name": "a", "version": "1.0.0"})
        rec_b = PluginRecord("b", self.plugins_dir / "b", {"name": "b", "version": "1.0.0"})
        db_a = await loader._get_plugin_database(rec_a)
        db_b = await loader._get_plugin_database(rec_b)

        async def broken_close():
            raise RuntimeError("close failed")
        loader._plugin_dbs["a"].close = broken_close

        with self.assertLogs("plugin_loader", level="ERROR"):
            await loader.close_all_plugin_databases()  # не должно бросить
        self.assertEqual(loader._plugin_dbs, {})  # обе всё равно вычищены из кэша

        # broken_close() выше намеренно подменяет публичный метод и поэтому
        # сам оставляет реальные aiosqlite-соединения открытыми. Закрываем их
        # напрямую после проверки resilience, чтобы тест не маскировал
        # собственный double под утечку приложения.
        await SQLiteDatabase.close(db_a)
        await SQLiteDatabase.close(db_b)


class VerifyAndRunMigrationsTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.plugins_dir = Path(self._tmp.name)

    async def make_connected_loader_and_db(self, folder_name: str = "p"):
        loader = make_loader()
        loader._config = Config(bot_token="x")
        plugin_dir = self.plugins_dir / folder_name
        rec = PluginRecord(folder_name, plugin_dir, {"name": folder_name, "version": "1.0.0"})
        db = await loader._get_plugin_database(rec)
        self.addAsyncCleanup(loader.close_all_plugin_databases)
        return loader, rec, db

    async def test_no_migrations_dir_returns_true(self) -> None:
        loader, rec, db = await self.make_connected_loader_and_db()
        result = await loader._verify_and_run_migrations(rec.name, rec, db)
        self.assertTrue(result)

    async def test_successful_migration_returns_true(self) -> None:
        loader, rec, db = await self.make_connected_loader_and_db()
        mig_dir = rec.path / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "0001_init.sql").write_text("CREATE TABLE t (id INTEGER PRIMARY KEY);", encoding="utf-8")
        result = await loader._verify_and_run_migrations(rec.name, rec, db)
        self.assertTrue(result)

    async def test_duplicate_migration_versions_skips_with_error(self) -> None:
        loader, rec, db = await self.make_connected_loader_and_db()
        mig_dir = rec.path / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "0001_a.sql").write_text("CREATE TABLE a (id INTEGER PRIMARY KEY);", encoding="utf-8")
        (mig_dir / "0001_b.sql").write_text("CREATE TABLE b (id INTEGER PRIMARY KEY);", encoding="utf-8")
        result = await loader._verify_and_run_migrations(rec.name, rec, db)
        self.assertFalse(result)
        self.assertIn(rec.name, loader._skipped)

    async def test_failing_migration_sql_skips_with_error(self) -> None:
        loader, rec, db = await self.make_connected_loader_and_db()
        mig_dir = rec.path / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "0001_broken.sql").write_text("INSERT INTO nonexistent VALUES (1);", encoding="utf-8")
        result = await loader._verify_and_run_migrations(rec.name, rec, db)
        self.assertFalse(result)
        self.assertIn("ошибка при применении миграций", loader._skip_reasons[rec.name])

    async def test_schema_version_mismatch_skips_without_going_through_skip_helper(self) -> None:
        """
        _verify_and_run_migrations добавляет в _skipped/_skip_reasons
        НАПРЯМУЮ на этой конкретной ветке (verify_schema_version вернул
        False), а не через self._skip() -- то есть НЕ идёт собственный
        warning/error лог уровня plugin_loader (verify_schema_version уже
        всё объяснил в своём собственном логе). Проверяем именно это.
        """
        loader, rec, db = await self.make_connected_loader_and_db()
        mig_dir = rec.path / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "0001_a.sql").write_text("CREATE TABLE a (id INTEGER PRIMARY KEY);", encoding="utf-8")
        await db.run_migrations(rec.name, mig_dir)
        # добавляем ВТОРОЙ файл миграции уже ПОСЛЕ применения первой,
        # так что на диске теперь есть немигрированная версия 2
        (mig_dir / "0002_b.sql").write_text("CREATE TABLE b (id INTEGER PRIMARY KEY);", encoding="utf-8")
        # НО искусственно ломаем schema_version, будто 2 была применена
        # без реального запуска -- проще: подделаем verify_schema_version
        import unittest.mock as _mock
        with _mock.patch.object(db, "verify_schema_version", return_value=False):
            result = await loader._verify_and_run_migrations(rec.name, rec, db)
        self.assertFalse(result)
        self.assertEqual(loader._skip_reasons[rec.name], "версия схемы БД не совпадает с миграциями на диске (см. лог).")


_HOOK_REGISTERING_PLUGIN_PY = textwrap.dedent("""
    from plugins.base import BasePlugin

    class MyPlugin(BasePlugin):
        @property
        def name(self) -> str:
            return "test-plugin"

        @property
        def version(self) -> str:
            return "1.0.0"

        async def setup(self, ctx) -> None:
            self.ctx = ctx
            self.handle = ctx.on_hook("some.event", lambda: "handled")
            ctx.provide_service("my.service", "some-value")

        async def teardown(self) -> None:
            pass
""")

_CRASHING_SETUP_PLUGIN_PY = textwrap.dedent("""
    from plugins.base import BasePlugin

    class MyPlugin(BasePlugin):
        @property
        def name(self) -> str:
            return "test-plugin"

        @property
        def version(self) -> str:
            return "1.0.0"

        async def setup(self, ctx) -> None:
            ctx.on_hook("some.event", lambda: "handled")
            ctx.provide_service("my.service", "some-value")
            raise RuntimeError("setup boom")
""")

_CRASHING_TEARDOWN_PLUGIN_PY = textwrap.dedent("""
    from plugins.base import BasePlugin

    class MyPlugin(BasePlugin):
        @property
        def name(self) -> str:
            return "test-plugin"

        @property
        def version(self) -> str:
            return "1.0.0"

        async def setup(self, ctx) -> None:
            self.ctx = ctx

        async def teardown(self) -> None:
            raise RuntimeError("teardown boom")
""")


def _versioned_plugin_py(marker: str) -> str:
    return textwrap.dedent(f"""
        from plugins.base import BasePlugin

        class MyPlugin(BasePlugin):
            @property
            def name(self) -> str:
                return "test-plugin"

            @property
            def version(self) -> str:
                return "1.0.0"

            async def setup(self, ctx) -> None:
                self.ctx = ctx
                self.marker = "{marker}"
    """)


class PluginLoaderIntegrationTestCase(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.plugins_dir = Path(self._tmp.name)

    async def run_pipeline_up_to_resolve(self, disabled: list[str] | None = None) -> PluginLoader:
        loader = make_loader()
        loader.scan(self.plugins_dir, disabled or [])
        loader.check_core_compat()
        loader.check_pip_deps()
        loader.resolve_order()
        return loader

    async def load_all(self, loader: PluginLoader, dp=None, bot=None, db=None, config=None):
        config = config or Config(bot_token="x")
        await loader.load_plugins(dp or object(), bot or object(), db or object(), config)
        self.addAsyncCleanup(loader.close_all_plugin_databases)


class LoadPluginsIntegrationTests(PluginLoaderIntegrationTestCase):
    async def test_happy_path_setup_is_called_with_context(self) -> None:
        write_plugin(self.plugins_dir, "p1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)

        rec = loader._records["p1"]
        self.assertIsNotNone(rec.instance)
        self.assertEqual(rec.instance.ctx.plugin_name, "p1")

    async def test_before_and_after_load_hooks_fire_in_order(self) -> None:
        write_plugin(self.plugins_dir, "p1")
        loader = await self.run_pipeline_up_to_resolve()
        order = []
        loader.hooks.on("core.plugin.before_load", lambda **kw: order.append(("before", kw["name"])), plugin="test")
        loader.hooks.on("core.plugin.after_load", lambda **kw: order.append(("after", kw["name"])), plugin="test")
        await self.load_all(loader)
        self.assertEqual(order, [("before", "p1"), ("after", "p1")])

    async def test_plugins_ready_hook_fires_with_loaded_and_skipped_lists(self) -> None:
        write_plugin(self.plugins_dir, "good")
        write_plugin(self.plugins_dir, "bad", plugin_py="x = 1")  # нет подкласса BasePlugin
        loader = await self.run_pipeline_up_to_resolve()
        seen = []
        loader.hooks.on(
            "core.plugins.ready",
            lambda **kw: seen.append((sorted(kw["loaded"]), sorted(kw["skipped"]))),
            plugin="test",
        )
        await self.load_all(loader)
        self.assertEqual(seen, [(["good"], ["bad"])])

    async def test_setup_failure_skips_plugin_and_cleans_up_partial_registrations(self) -> None:
        write_plugin(self.plugins_dir, "p1", plugin_py=_CRASHING_SETUP_PLUGIN_PY)
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)

        self.assertIn("p1", loader._skipped)
        self.assertIn("ошибка в setup()", loader._skip_reasons["p1"])
        # то, что плагин успел зарегистрировать ДО падения, откачено:
        self.assertFalse(loader.services.has("my.service"))
        self.assertEqual(loader.hooks.list_hooks("some.event"), {"some.event": []})

    async def test_setup_failure_emits_load_failed_hook(self) -> None:
        write_plugin(self.plugins_dir, "p1", plugin_py=_CRASHING_SETUP_PLUGIN_PY)
        loader = await self.run_pipeline_up_to_resolve()
        seen = []
        loader.hooks.on("core.plugin.load_failed", lambda **kw: seen.append(kw["name"]), plugin="test")
        await self.load_all(loader)
        self.assertEqual(seen, ["p1"])

    async def test_plugin_with_no_baseplugin_subclass_is_skipped(self) -> None:
        write_plugin(self.plugins_dir, "p1", plugin_py="x = 1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        self.assertIn("p1", loader._skipped)
        self.assertIn("не найден подкласс", loader._skip_reasons["p1"])

    async def test_already_skipped_plugin_is_never_passed_to_load_one(self) -> None:
        write_plugin(self.plugins_dir, "p1", manifest_extra={"core_version": ">=999.0.0"})
        loader = await self.run_pipeline_up_to_resolve()
        self.assertIn("p1", loader._skipped)  # уже пропущен на этапе check_core_compat

        calls = []
        original = loader._load_one

        async def spy(name):
            calls.append(name)
            return await original(name)
        loader._load_one = spy

        await self.load_all(loader)
        self.assertEqual(calls, [])  # _load_one ни разу не вызван для skipped


class TeardownIntegrationTests(PluginLoaderIntegrationTestCase):
    async def test_teardown_order_is_reverse_of_load_order(self) -> None:
        write_plugin(self.plugins_dir, "aaa", name="aaa")
        write_plugin(self.plugins_dir, "bbb", name="bbb")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)

        order = []
        loader.hooks.on("core.plugin.before_teardown", lambda **kw: order.append(kw["name"]), plugin="test")
        await loader.teardown_all()
        self.assertEqual(order, list(reversed(loader._load_order)))

    async def test_skipped_plugins_are_never_torn_down(self) -> None:
        write_plugin(self.plugins_dir, "p1", plugin_py="x = 1")  # будет skipped
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        seen = []
        loader.hooks.on("core.plugin.before_teardown", lambda **kw: seen.append(kw["name"]), plugin="test")
        await loader.teardown_all()
        self.assertEqual(seen, [])

    async def test_teardown_exception_is_logged_but_cleanup_and_hooks_still_happen(self) -> None:
        write_plugin(self.plugins_dir, "p1", plugin_py=_CRASHING_TEARDOWN_PLUGIN_PY)
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)

        after_teardown_seen = []
        loader.hooks.on("core.plugin.after_teardown", lambda **kw: after_teardown_seen.append(kw["name"]), plugin="test")

        with self.assertLogs("plugin_loader", level="ERROR"):
            await loader.teardown_all()  # не должно бросить

        self.assertIsNone(loader._records["p1"].instance)
        self.assertEqual(after_teardown_seen, ["p1"])

    async def test_after_teardown_hook_raising_does_not_stop_other_plugins_teardown(self) -> None:
        write_plugin(self.plugins_dir, "aaa", name="aaa")
        write_plugin(self.plugins_dir, "bbb", name="bbb")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)

        def bad_after_teardown(**kw):
            raise RuntimeError("hook boom")
        loader.hooks.on("core.plugin.after_teardown", bad_after_teardown, plugin="test")

        with self.assertLogs("hooks", level="ERROR"):
            await loader.teardown_all()  # не должно бросить, оба должны быть torn down

        self.assertIsNone(loader._records["aaa"].instance)
        self.assertIsNone(loader._records["bbb"].instance)


class ReloadPluginTests(PluginLoaderIntegrationTestCase):
    def setUp(self) -> None:
        super().setUp()
        # Без этого reload-тесты, которые дважды перезаписывают plugin.py
        # для одного и того же файла, время от времени ловят СОВЕРШЕННО
        # ПОСТОРОННЮЮ проблему: закешированный .pyc в __pycache__/,
        # провалидированный по mtime исходника. Если обе записи попадают
        # в одно и то же "деление" mtime файловой системы (что при
        # быстром выполнении теста весьма вероятно), Python отдаёт
        # СТАРЫЙ байткод, будто файл не менялся. Само по себе это
        # реальное и стоящее задокументировать поведение "живого"
        # reload_plugin() — см. отдельный тест ниже,
        # test_rapid_successive_edits_can_serve_stale_bytecode — но здесь
        # оно ТОЛЬКО мешает проверять логику самого PluginLoader.
        self._dont_write_bytecode_patch = unittest.mock.patch.object(sys, "dont_write_bytecode", True)
        self._dont_write_bytecode_patch.start()
        self.addCleanup(self._dont_write_bytecode_patch.stop)

    async def test_reload_before_load_plugins_raises_runtime_error(self) -> None:
        loader = make_loader()
        with self.assertRaises(RuntimeError):
            await loader.reload_plugin("anything")

    async def test_unknown_plugin_name_returns_false(self) -> None:
        write_plugin(self.plugins_dir, "p1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        result = await loader.reload_plugin("ghost")
        self.assertFalse(result)

    async def test_folder_removed_from_disk_since_scan_returns_false(self) -> None:
        write_plugin(self.plugins_dir, "p1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        import shutil as _shutil
        _shutil.rmtree(self.plugins_dir / "p1")
        result = await loader.reload_plugin("p1")
        self.assertFalse(result)

    async def test_successful_reload_picks_up_code_changes(self) -> None:
        d = write_plugin(self.plugins_dir, "p1", plugin_py=_versioned_plugin_py("v1"))
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        self.assertEqual(loader._records["p1"].instance.marker, "v1")

        (d / "plugin.py").write_text(_versioned_plugin_py("v2"), encoding="utf-8")
        result = await loader.reload_plugin("p1")

        self.assertTrue(result)
        self.assertEqual(loader._records["p1"].instance.marker, "v2")

    async def test_successful_reload_replaces_sys_modules_entry(self) -> None:
        d = write_plugin(self.plugins_dir, "p1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        old_module_name = loader._records["p1"].module_name
        self.assertIn(old_module_name, sys.modules)

        result = await loader.reload_plugin("p1")

        self.assertTrue(result)
        new_module_name = loader._records["p1"].module_name
        self.assertNotEqual(old_module_name, new_module_name)
        self.assertNotIn(old_module_name, sys.modules)
        self.assertIn(new_module_name, sys.modules)
        self.addCleanup(sys.modules.pop, new_module_name, None)

    async def test_reload_reuses_the_same_plugin_database_connection(self) -> None:
        write_plugin(self.plugins_dir, "p1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        db_before = loader._plugin_dbs["p1"]

        await loader.reload_plugin("p1")

        db_after = loader._plugin_dbs["p1"]
        self.assertIs(db_before, db_after)

    async def test_name_collision_appearing_after_initial_load_blocks_reload(self) -> None:
        """
        Регрессионный тест, явно упомянутый в докстринге reload_plugin:
        коллизия имени, возникшая ПОСЛЕ первичного scan(), должна
        блокировать reload, а не тихо перезагрузить одну из папок.
        """
        write_plugin(self.plugins_dir, "p1", name="antispam")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        self.assertIsNotNone(loader._records["antispam"].instance)

        # коллизия появляется ПОСЛЕ первичной загрузки
        write_plugin(self.plugins_dir, "p2", name="antispam")

        result = await loader.reload_plugin("antispam")

        self.assertFalse(result)
        self.assertIn("antispam", loader._skipped)
        self.assertIn("коллизия имени обнаружена заново", loader._skip_reasons["antispam"])

    async def test_reloading_a_previously_skipped_plugin_uses_cleanup_not_teardown(self) -> None:
        d = write_plugin(self.plugins_dir, "p1", plugin_py="x = 1")  # изначально skipped
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        self.assertIn("p1", loader._skipped)
        self.assertIsNone(loader._records["p1"].instance)

        teardown_calls = []
        loader.hooks.on("core.plugin.before_teardown", lambda **kw: teardown_calls.append(kw["name"]), plugin="test")

        (d / "plugin.py").write_text(_versioned_plugin_py("recovered"), encoding="utf-8")
        result = await loader.reload_plugin("p1")

        self.assertTrue(result)
        self.assertEqual(teardown_calls, [])  # никогда не имел instance -> teardown не звался
        self.assertNotIn("p1", loader._skipped)  # снят с пропущенных

    async def test_recovered_plugin_gets_appended_to_load_order(self) -> None:
        # Скипнут ДО resolve_order() (несовместимость с ядром) -> не
        # попадает в _load_order вообще (в отличие от "нет подкласса
        # BasePlugin", которое обнаруживается позже, уже ВНУТРИ
        # load_plugins(), когда план _load_order уже посчитан и плагин
        # там уже есть).
        write_plugin(self.plugins_dir, "p1", manifest_extra={"core_version": ">=999.0.0"})
        loader = await self.run_pipeline_up_to_resolve()
        self.assertIn("p1", loader._skipped)
        self.assertNotIn("p1", loader._load_order)
        await self.load_all(loader)

        write_plugin(self.plugins_dir, "p1", plugin_py=_versioned_plugin_py("v1"))  # версия ядра больше не указана
        await loader.reload_plugin("p1")

        self.assertIn("p1", loader._load_order)

    async def test_malformed_manifest_on_reload_fails_cleanly(self) -> None:
        write_plugin(self.plugins_dir, "p1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)

        (self.plugins_dir / "p1" / "manifest.json").write_text("{not valid json", encoding="utf-8")
        result = await loader.reload_plugin("p1")
        self.assertFalse(result)

    async def test_new_setup_failure_on_reload_cleans_up_and_pops_temp_module(self) -> None:
        d = write_plugin(self.plugins_dir, "p1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)

        (d / "plugin.py").write_text(_CRASHING_SETUP_PLUGIN_PY, encoding="utf-8")
        modules_before = set(sys.modules.keys())
        result = await loader.reload_plugin("p1")
        modules_after = set(sys.modules.keys())

        self.assertFalse(result)
        self.assertIn("p1", loader._skipped)
        self.assertFalse(loader.services.has("my.service"))  # откачено через _cleanup_extensions
        # никаких НОВЫХ модулей не осталось висеть в sys.modules
        self.assertEqual(modules_after - modules_before, set())

    async def test_reload_all_only_reloads_currently_active_plugins(self) -> None:
        write_plugin(self.plugins_dir, "good", name="good")
        write_plugin(self.plugins_dir, "bad", name="bad", plugin_py="x = 1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        self.assertIn("bad", loader._skipped)

        results = await loader.reload_all()

        self.assertEqual(set(results.keys()), {"good"})
        self.assertTrue(results["good"])

    async def test_reload_all_reports_mixed_success_and_failure(self) -> None:
        write_plugin(self.plugins_dir, "good", name="good")
        write_plugin(self.plugins_dir, "flaky", name="flaky")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)

        # ломаем "flaky" ПОСЛЕ первичной загрузки, до reload_all()
        (self.plugins_dir / "flaky" / "plugin.py").write_text(_CRASHING_SETUP_PLUGIN_PY, encoding="utf-8")

        results = await loader.reload_all()

        self.assertTrue(results["good"])
        self.assertFalse(results["flaky"])

    async def test_same_mtime_and_size_edit_no_longer_serves_stale_bytecode(self) -> None:
        """
        Раньше здесь был обнаруженный баг: байткод plugin.py кешируется
        Python'ом в __pycache__/*.pyc и считается валидным, если
        (mtime, размер) исходника совпадают с сохранёнными в заголовке
        .pyc — при отредактированном файле с ТОЧНО ТЕМ ЖЕ mtime и
        размером (здесь — принудительно через os.utime, чтобы тест был
        детерминирован) reload_plugin() подхватывал СТАРЫЙ код. Теперь
        _load_plugin_class() перед каждой загрузкой удаляет уже
        существующий кэш для конкретно этого файла и не даёт записать
        новый — reload() всегда компилирует то, что реально лежит на
        диске прямо сейчас.
        """
        import os
        with unittest.mock.patch.object(sys, "dont_write_bytecode", False):
            d = write_plugin(self.plugins_dir, "p1", plugin_py=_versioned_plugin_py("v1"))
            loader = await self.run_pipeline_up_to_resolve()
            await self.load_all(loader)
            self.assertEqual(loader._records["p1"].instance.marker, "v1")

            frozen_mtime_ns = (d / "plugin.py").stat().st_mtime_ns
            v1_size = (d / "plugin.py").stat().st_size

            (d / "plugin.py").write_text(_versioned_plugin_py("v2"), encoding="utf-8")
            self.assertEqual((d / "plugin.py").stat().st_size, v1_size)  # "v1"/"v2" — одинаковая длина
            os.utime(d / "plugin.py", ns=(frozen_mtime_ns, frozen_mtime_ns))  # то, что раньше маскировало изменение

            await loader.reload_plugin("p1")

            # Фикс: несмотря на одинаковый (mtime, размер), подхватился
            # РЕАЛЬНЫЙ текущий код с диска — "v2", а не закешированный "v1".
            self.assertEqual(loader._records["p1"].instance.marker, "v2")


class IntrospectionTests(PluginLoaderIntegrationTestCase):
    async def test_status_snapshot_shape(self) -> None:
        write_plugin(self.plugins_dir, "good", name="good", version="2.0.0")
        write_plugin(self.plugins_dir, "bad", name="bad", plugin_py="x = 1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)

        snap = loader.status_snapshot()
        self.assertEqual(snap["loaded"], [{"name": "good", "version": "2.0.0"}])
        self.assertEqual(snap["skipped"], {"bad": "не найден подкласс BasePlugin в plugin.py."})
        self.assertEqual(snap["load_order"], loader._load_order)

    async def test_status_snapshot_default_reason_when_skipped_without_explicit_reason(self) -> None:
        loader = make_loader()
        loader._records["ghost"] = PluginRecord("ghost", Path("/tmp/ghost"), {"name": "ghost", "version": "1.0.0"})
        loader._skipped.add("ghost")  # обходим self._skip() напрямую
        snap = loader.status_snapshot()
        self.assertEqual(snap["skipped"]["ghost"], "причина не зафиксирована")

    async def test_known_plugin_names_includes_both_loaded_and_skipped(self) -> None:
        write_plugin(self.plugins_dir, "good", name="good")
        write_plugin(self.plugins_dir, "bad", name="bad", plugin_py="x = 1")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        self.assertEqual(loader.known_plugin_names(), {"good", "bad"})

    async def test_summary_logs_without_crashing(self) -> None:
        write_plugin(self.plugins_dir, "good", name="good")
        loader = await self.run_pipeline_up_to_resolve()
        await self.load_all(loader)
        with self.assertLogs("plugin_loader", level="INFO"):
            loader.summary()  # не должно бросить


if __name__ == "__main__":
    unittest.main()
