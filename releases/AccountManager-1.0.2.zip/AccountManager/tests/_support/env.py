"""
tests/_support/env.py — тестовое окружение.

Делает две вещи, ДО того как любой тестовый модуль импортирует что-то
из core/:

  1. Кладёт корень проекта (папку, где лежит core/) в sys.path — тесты
     запускаются как `python -m unittest discover -s tests`, и без
     этого `import core.xxx` не найдёт пакет, если CWD не совпадает
     с корнем проекта.

  2. Если реальные aiogram/aiosqlite НЕ установлены в окружении, где
     запускаются тесты — подставляет в sys.modules собственные
     облегчённые повторные реализации ИЗ tests/_support/fakes/,
     покрывающие ровно тот срез API, которым реально пользуется
     core/middleware.py и core/db/sqlite_backend.py. Настоящие пакеты,
     если они установлены (как и предполагается requirements.txt на
     реальном хосте бота), ВСЕГДА в приоритете — фейки существуют
     только чтобы этот же тестовый набор можно было прогнать и в
     окружении, где aiogram/aiosqlite ещё не поставлены (например, в
     CI до `pip install -r requirements.txt`), не теряя при этом
     реальное покрытие SQL/middleware-логики моками вместо настоящего
     выполнения кода.

Импортируется как `from tests._support import env` в начале каждого
тестового файла, которому нужен доступ к core/ (и/или к aiogram/
aiosqlite) — сам факт импорта уже выполняет оба пункта выше.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


def _find_project_root() -> Path:
    here = Path(__file__).resolve()
    for candidate in (here.parent, *here.parents):
        if (candidate / "core" / "__init__.py").exists():
            return candidate
    raise RuntimeError(
        "Не удалось найти корень проекта AccountManager (папку с core/__init__.py) "
        f"среди родителей {here}. Убедитесь, что папка tests/ лежит внутри "
        "проекта (рядом с core/, main.py и т.п.)."
    )


PROJECT_ROOT = _find_project_root()
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def _real_module_importable(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError, ModuleNotFoundError):
        return False


def ensure_aiogram() -> bool:
    """
    True, если aiogram доступен после вызова (настоящий или фейковый).
    Настоящий пакет НИКОГДА не подменяется, если он импортируется.
    """
    if "aiogram" in sys.modules and not getattr(sys.modules["aiogram"], "__is_fake__", False):
        return True
    if _real_module_importable("aiogram"):
        return True
    from tests._support.fakes import aiogram as fake_aiogram
    fake_aiogram.install()
    return True


def ensure_aiosqlite() -> bool:
    """True, если aiosqlite доступен после вызова (настоящий или фейковый)."""
    if "aiosqlite" in sys.modules and not getattr(sys.modules["aiosqlite"], "__is_fake__", False):
        return True
    if _real_module_importable("aiosqlite"):
        return True
    from tests._support.fakes import aiosqlite as fake_aiosqlite
    fake_aiosqlite.install()
    return True
