"""
tests/_support/fakes/aiosqlite — минимальная но НАСТОЯЩАЯ async-обёртка
над stdlib sqlite3, покрывающая ровно тот срез API aiosqlite, которым
пользуется core/db/sqlite_backend.py (connect/execute/Row/close, и
execute() как awaitable И как async context manager одновременно —
именно так это работает в настоящем aiosqlite).

Устанавливается в sys.modules ТОЛЬКО если настоящий пакет aiosqlite не
импортируется (см. tests/_support/env.py) — на реальном хосте бота
(Termux, requirements.txt) этот файл никогда не используется. Здесь
он существует, чтобы core/db/sqlite_backend.py можно было тестировать
выполнением НАСТОЯЩЕГО SQL (реальные PRAGMA/WAL/ON CONFLICT/
транзакции), а не моком, который проверяет только «вызвали ли метод»,
а не «правильно ли сработал SQL».

Каждое соединение обслуживается СВОИМ выделенным потоком (через
ThreadPoolExecutor(max_workers=1)) — как и в настоящем aiosqlite,
это даёт: (а) один и тот же sqlite3.Connection трогает только один
поток за раз (sqlite3 с check_same_thread=False это разрешает, но не
гарантирует потокобезопасность при параллельном доступе — единственный
воркер это и обеспечивает), (б) вызовы на одном соединении строго
сериализуются в порядке отправки (FIFO у ThreadPoolExecutor с
max_workers=1), что даёт те же гарантии порядка, что и в проде.
"""
from __future__ import annotations

import asyncio
import sqlite3
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

__is_fake__ = True

Row = sqlite3.Row
OperationalError = sqlite3.OperationalError
IntegrityError = sqlite3.IntegrityError
Error = sqlite3.Error


class Cursor:
    """Обёртка над sqlite3.Cursor — все операции идут через поток владельца-Connection."""

    def __init__(self, raw_cursor: sqlite3.Cursor, owner: "Connection") -> None:
        self._raw = raw_cursor
        self._owner = owner

    async def fetchone(self) -> Any:
        return await self._owner._run(self._raw.fetchone)

    async def fetchall(self) -> list[Any]:
        return await self._owner._run(self._raw.fetchall)

    @property
    def lastrowid(self) -> Any:
        return self._raw.lastrowid

    @property
    def rowcount(self) -> int:
        return self._raw.rowcount

    async def close(self) -> None:
        await self._owner._run(self._raw.close)

    async def __aenter__(self) -> "Cursor":
        return self

    async def __aexit__(self, *exc_info: Any) -> bool:
        return False


class _ExecuteAwaitable:
    """
    То же поведение, что и настоящий aiosqlite: результат execute()
    можно и `await`-ить напрямую (получая Cursor), и использовать как
    `async with conn.execute(...) as cur:` — оба пути в
    core/db/sqlite_backend.py реально встречаются.
    """

    def __init__(self, owner: "Connection", sql: str, params: Any) -> None:
        self._owner = owner
        self._sql = sql
        self._params = params if params is not None else ()
        self._cursor: Cursor | None = None

    def _do_execute(self) -> Cursor:
        raw = self._owner._raw.execute(self._sql, self._params)
        return Cursor(raw, self._owner)

    def __await__(self):
        return self._owner._run(self._do_execute).__await__()

    async def __aenter__(self) -> Cursor:
        self._cursor = await self._owner._run(self._do_execute)
        return self._cursor

    async def __aexit__(self, *exc_info: Any) -> bool:
        return False


class Connection:
    def __init__(self, db_path: Path | str, isolation_level: str | None = None) -> None:
        self._db_path = str(db_path)
        self._isolation_level = isolation_level
        self._executor = ThreadPoolExecutor(max_workers=1)
        self._raw: sqlite3.Connection | None = None
        self._row_factory = None

    async def _run(self, fn, *a, **kw):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(self._executor, lambda: fn(*a, **kw))

    async def _connect(self) -> None:
        def _do() -> sqlite3.Connection:
            conn = sqlite3.connect(
                self._db_path,
                isolation_level=self._isolation_level,
                check_same_thread=False,
            )
            if self._row_factory is not None:
                conn.row_factory = self._row_factory
            return conn

        self._raw = await self._run(_do)

    @property
    def row_factory(self):
        return self._row_factory

    @row_factory.setter
    def row_factory(self, value) -> None:
        self._row_factory = value
        if self._raw is not None:
            self._raw.row_factory = value

    def execute(self, sql: str, params: Any = ()) -> _ExecuteAwaitable:
        return _ExecuteAwaitable(self, sql, params)

    async def close(self) -> None:
        if self._raw is not None:
            await self._run(self._raw.close)
            self._raw = None
        self._executor.shutdown(wait=True)

    async def __aenter__(self) -> "Connection":
        return self

    async def __aexit__(self, *exc_info: Any) -> bool:
        await self.close()
        return False


class _ConnectAwaitable:
    def __init__(self, db_path: Path | str, isolation_level: str | None) -> None:
        self._db_path = db_path
        self._isolation_level = isolation_level

    def __await__(self):
        return self._make().__await__()

    async def _make(self) -> Connection:
        conn = Connection(self._db_path, isolation_level=self._isolation_level)
        await conn._connect()
        return conn

    async def __aenter__(self) -> Connection:
        return await self._make()

    async def __aexit__(self, *exc_info: Any) -> bool:
        return False


def connect(db_path: Path | str, isolation_level: str | None = None) -> _ConnectAwaitable:
    return _ConnectAwaitable(db_path, isolation_level)


def install() -> None:
    """Регистрирует этот фейк в sys.modules под именем 'aiosqlite'."""
    import sys
    sys.modules["aiosqlite"] = sys.modules[__name__]
