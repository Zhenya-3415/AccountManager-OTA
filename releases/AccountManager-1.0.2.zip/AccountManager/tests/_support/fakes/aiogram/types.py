"""
tests/_support/fakes/aiogram/types.py — TelegramObject/Update/User.

Настоящие aiogram.types.* — pydantic-модели с десятками полей. Этот
фейк несёт только то, что реально читает core/middleware.py:
Update.{message,edited_message,...}.from_user и User.{id,is_bot,
username,first_name,last_name,language_code}. Значения, которые тест
не передал явно, по умолчанию None — как и в настоящем aiogram для
опциональных полей.
"""
from __future__ import annotations

from typing import Any


class TelegramObject:
    """Базовый маркерный класс — настоящий это pydantic BaseModel."""
    pass


class User(TelegramObject):
    def __init__(
        self,
        *,
        id: int,
        is_bot: bool = False,
        first_name: str = "",
        last_name: str | None = None,
        username: str | None = None,
        language_code: str | None = None,
    ) -> None:
        self.id = id
        self.is_bot = is_bot
        self.first_name = first_name
        self.last_name = last_name
        self.username = username
        self.language_code = language_code


# Атрибуты Update, которые могут нести from_user — тот же список, что
# в core/middleware.py:_UPDATE_ATTRS_WITH_USER (умышленно продублирован
# здесь, а не импортирован оттуда, чтобы фейк не зависел от core/ и
# тестировал core/middleware.py как настоящий сторонний тип данных).
_UPDATE_ATTRS_WITH_USER = (
    "message",
    "edited_message",
    "channel_post",
    "edited_channel_post",
    "callback_query",
    "inline_query",
    "chosen_inline_result",
    "shipping_query",
    "pre_checkout_query",
    "poll_answer",
    "my_chat_member",
    "chat_member",
    "chat_join_request",
)


class Update(TelegramObject):
    def __init__(self, update_id: int = 0, **kwargs: Any) -> None:
        self.update_id = update_id
        for attr in _UPDATE_ATTRS_WITH_USER:
            setattr(self, attr, kwargs.pop(attr, None))
        for key, value in kwargs.items():
            setattr(self, key, value)
