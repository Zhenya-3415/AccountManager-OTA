"""
tests/_support/fakes/aiogram — облегчённая замена aiogram для тестов
core/middleware.py, устанавливается в sys.modules ТОЛЬКО если настоящий
aiogram не импортируется (см. tests/_support/env.py). Покрывает ровно
то, что реально используется core/middleware.py: BaseMiddleware как
базовый класс и aiogram.types.{TelegramObject,Update,User}.
"""
from __future__ import annotations

__is_fake__ = True


class BaseMiddleware:
    """См. настоящий aiogram.BaseMiddleware — здесь достаточно самого протокола __call__."""

    async def __call__(self, handler, event, data):
        return await handler(event, data)


def install() -> None:
    """Регистрирует этот фейк и его подпакет .types в sys.modules."""
    import sys
    from tests._support.fakes.aiogram import types as fake_types

    sys.modules["aiogram"] = sys.modules[__name__]
    sys.modules["aiogram.types"] = fake_types
