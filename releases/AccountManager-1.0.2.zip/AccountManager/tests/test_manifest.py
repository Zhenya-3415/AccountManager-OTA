"""
tests/test_manifest.py — core/manifest.py: manifest_core.json loading
and build-integrity sha256 verification.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path

from tests._support import env  # noqa: F401

import core.manifest as mod
from core.manifest import (
    ManifestError,
    BuildIntegrityResult,
    compute_source_hash,
    display,
    iter_build_files,
    load_manifest,
    requirements_list,
    verify_build_integrity,
    UNKNOWN,
)


# ── helpers ──────────────────────────────────────────────────────

def _minimal_manifest(**overrides) -> dict:
    base = {
        "name": "Test FW",
        "description": "desc",
        "version": "1.0.0",
        "build_channel": "Stable",
        "authors": ["alice", "bob"],
        "requirements": ["aiogram>=3.15", "pytest>=7.4"],
        "repository_url": "https://github.com/test/fw",
        "ota_repository": "https://github.com/test/ota",
        "plugin_repository": "https://github.com/test/plugins",
        "sha256_hash": "",
    }
    base.update(overrides)
    return base


class WithTmpDir(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)
        self._orig = os.getcwd()
        os.chdir(self.root)
        self.addCleanup(os.chdir, self._orig)

    def write_manifest(self, data: dict, path: str = "manifest_core.json") -> Path:
        p = self.root / path
        p.write_text(json.dumps(data), encoding="utf-8")
        return p

    def write_py(self, rel: str, content: str = "# x") -> Path:
        p = self.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return p


# ════════════════════════════════════════════════════════════════
class TestLoadManifest(WithTmpDir):

    def test_raises_when_file_missing(self) -> None:
        with self.assertRaises(ManifestError) as ctx:
            load_manifest(self.root / "manifest_core.json")
        self.assertIn("не найден", str(ctx.exception))

    def test_raises_on_invalid_json(self) -> None:
        (self.root / "manifest_core.json").write_text("{bad", encoding="utf-8")
        with self.assertRaises(ManifestError) as ctx:
            load_manifest(self.root / "manifest_core.json")
        self.assertIn("невалидный JSON", str(ctx.exception))

    def test_raises_when_root_is_list(self) -> None:
        (self.root / "manifest_core.json").write_text("[1,2,3]", encoding="utf-8")
        with self.assertRaises(ManifestError) as ctx:
            load_manifest(self.root / "manifest_core.json")
        self.assertIn("JSON-объектом", str(ctx.exception))

    def test_returns_dict_for_valid_manifest(self) -> None:
        p = self.write_manifest(_minimal_manifest())
        result = load_manifest(p)
        self.assertIsInstance(result, dict)
        self.assertEqual(result["name"], "Test FW")

    def test_empty_dict_is_valid_json_object(self) -> None:
        p = self.write_manifest({})
        result = load_manifest(p)
        self.assertEqual(result, {})


# ════════════════════════════════════════════════════════════════
class TestDisplay(unittest.TestCase):

    def test_present_string_field(self) -> None:
        self.assertEqual(display({"name": "Foo"}, "name"), "Foo")

    def test_missing_key_returns_unknown(self) -> None:
        self.assertEqual(display({}, "missing"), UNKNOWN)

    def test_empty_string_returns_unknown(self) -> None:
        self.assertEqual(display({"key": ""}, "key"), UNKNOWN)

    def test_whitespace_only_returns_unknown(self) -> None:
        self.assertEqual(display({"key": "   "}, "key"), UNKNOWN)

    def test_list_joined_by_comma(self) -> None:
        self.assertEqual(display({"authors": ["a", "b"]}, "authors"), "a, b")

    def test_empty_list_returns_unknown(self) -> None:
        self.assertEqual(display({"authors": []}, "authors"), UNKNOWN)

    def test_list_with_blank_items_skips_blanks(self) -> None:
        self.assertEqual(display({"authors": ["a", "  ", "b"]}, "authors"), "a, b")

    def test_custom_default(self) -> None:
        self.assertEqual(display({}, "x", default="N/A"), "N/A")

    def test_none_value_returns_unknown(self) -> None:
        self.assertEqual(display({"key": None}, "key"), UNKNOWN)


# ════════════════════════════════════════════════════════════════
class TestRequirementsList(unittest.TestCase):

    def test_returns_list_of_strings(self) -> None:
        m = {"requirements": ["aiogram>=3.15", "pytest>=7.4"]}
        self.assertEqual(requirements_list(m), ["aiogram>=3.15", "pytest>=7.4"])

    def test_empty_list(self) -> None:
        self.assertEqual(requirements_list({"requirements": []}), [])

    def test_missing_key_gives_empty(self) -> None:
        self.assertEqual(requirements_list({}), [])

    def test_non_list_value_gives_empty(self) -> None:
        self.assertEqual(requirements_list({"requirements": "aiogram"}), [])

    def test_blank_entries_filtered(self) -> None:
        m = {"requirements": ["aiogram", "  ", "pytest"]}
        self.assertEqual(requirements_list(m), ["aiogram", "pytest"])


# ════════════════════════════════════════════════════════════════
class TestIterBuildFiles(WithTmpDir):

    def test_collects_single_file(self) -> None:
        self.write_py("main.py")
        files = iter_build_files(self.root)
        self.assertIn(self.root / "main.py", files)

    def test_collects_py_files_in_core(self) -> None:
        self.write_py("core/__init__.py")
        self.write_py("core/config.py")
        files = iter_build_files(self.root)
        self.assertIn(self.root / "core/__init__.py", files)
        self.assertIn(self.root / "core/config.py", files)

    def test_pycache_excluded(self) -> None:
        self.write_py("core/__pycache__/config.cpython-312.pyc", "bytecode")
        files = iter_build_files(self.root)
        names = [f.name for f in files]
        self.assertNotIn("config.cpython-312.pyc", names)

    def test_missing_files_silently_skipped(self) -> None:
        # Нет файлов вовсе — должен вернуть пустой список, не упасть
        files = iter_build_files(self.root)
        self.assertIsInstance(files, list)

    def test_files_sorted_deterministically(self) -> None:
        self.write_py("core/z.py")
        self.write_py("core/a.py")
        files = iter_build_files(self.root)
        paths_str = [f.relative_to(self.root).as_posix() for f in files]
        self.assertEqual(paths_str, sorted(paths_str))


# ════════════════════════════════════════════════════════════════
class TestComputeSourceHash(WithTmpDir):

    def test_returns_64_char_hex_string(self) -> None:
        self.write_py("main.py", "# hello")
        h = compute_source_hash(self.root)
        self.assertRegex(h, r"^[0-9a-f]{64}$")

    def test_same_content_same_hash(self) -> None:
        self.write_py("main.py", "# content")
        h1 = compute_source_hash(self.root)
        h2 = compute_source_hash(self.root)
        self.assertEqual(h1, h2)

    def test_changed_content_changes_hash(self) -> None:
        self.write_py("main.py", "# version 1")
        h1 = compute_source_hash(self.root)
        self.write_py("main.py", "# version 2")
        h2 = compute_source_hash(self.root)
        self.assertNotEqual(h1, h2)

    def test_renamed_file_changes_hash(self) -> None:
        self.write_py("main.py", "# same")
        h1 = compute_source_hash(self.root)
        # Переименование: нет main.py, зато есть core/main.py
        (self.root / "main.py").unlink()
        self.write_py("core/main.py", "# same")
        h2 = compute_source_hash(self.root)
        self.assertNotEqual(h1, h2)

    def test_empty_tree_still_returns_string(self) -> None:
        h = compute_source_hash(self.root)
        self.assertIsInstance(h, str)
        self.assertEqual(len(h), 64)


# ════════════════════════════════════════════════════════════════
class TestVerifyBuildIntegrity(WithTmpDir):

    def _make_tree_and_hash(self) -> tuple[dict, str]:
        self.write_py("main.py", "# bot")
        computed = compute_source_hash(self.root)
        manifest = _minimal_manifest(sha256_hash=computed)
        return manifest, computed

    def test_ok_when_hash_matches(self) -> None:
        manifest, _ = self._make_tree_and_hash()
        result = verify_build_integrity(manifest, self.root)
        self.assertTrue(result.ok)

    def test_ok_result_fields(self) -> None:
        manifest, computed = self._make_tree_and_hash()
        result = verify_build_integrity(manifest, self.root)
        self.assertEqual(result.computed, computed)
        self.assertEqual(result.declared, computed.lower())
        self.assertGreater(result.files_hashed, 0)

    def test_fails_when_hash_empty(self) -> None:
        manifest = _minimal_manifest(sha256_hash="")
        result = verify_build_integrity(manifest, self.root)
        self.assertFalse(result.ok)
        self.assertIn("не задан", result.reason)

    def test_fails_when_hash_wrong(self) -> None:
        manifest = _minimal_manifest(sha256_hash="deadbeef" * 8)
        result = verify_build_integrity(manifest, self.root)
        self.assertFalse(result.ok)
        self.assertIn("не совпадает", result.reason)

    def test_fails_when_sha256_hash_key_missing(self) -> None:
        manifest = _minimal_manifest()
        del manifest["sha256_hash"]
        result = verify_build_integrity(manifest, self.root)
        self.assertFalse(result.ok)

    def test_hash_comparison_is_case_insensitive(self) -> None:
        self.write_py("main.py", "# bot")
        computed = compute_source_hash(self.root)
        manifest = _minimal_manifest(sha256_hash=computed.upper())
        result = verify_build_integrity(manifest, self.root)
        self.assertTrue(result.ok)

    def test_adding_file_changes_hash_and_fails(self) -> None:
        manifest, _ = self._make_tree_and_hash()
        # Добавляем новый файл — хеш уже не совпадает
        self.write_py("core/new_module.py", "# new")
        result = verify_build_integrity(manifest, self.root)
        self.assertFalse(result.ok)

    def test_result_is_dataclass(self) -> None:
        manifest = _minimal_manifest(sha256_hash="")
        result = verify_build_integrity(manifest, self.root)
        self.assertIsInstance(result, BuildIntegrityResult)


if __name__ == "__main__":
    unittest.main()
