"""
tests/test_db_migrations.py — core/db/migrations.py: split_sql_statements
(ручной токенизатор SQL) + collect_migration_files + resolve_migration_dir.

Чистый модуль (regex + pathlib, без aiosqlite/aiogram) — здесь ожидается
максимальная плотность edge-case'ов для токенизатора: строки, кавычки-
идентификаторы, экранирование через удвоение кавычки, построчные и
блочные комментарии, dollar-quoting (Postgres) с пустым и именованным
тегом, и вложенные BEGIN/END (SQLite CREATE TRIGGER).
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from tests._support import env  # noqa: F401

from core.db.migrations import collect_migration_files, resolve_migration_dir, split_sql_statements


class BasicSplittingTests(unittest.TestCase):
    def test_single_statement_with_trailing_semicolon(self) -> None:
        self.assertEqual(split_sql_statements("SELECT 1;"), ["SELECT 1"])

    def test_two_statements(self) -> None:
        self.assertEqual(split_sql_statements("SELECT 1; SELECT 2;"), ["SELECT 1", "SELECT 2"])

    def test_missing_trailing_semicolon_still_captured(self) -> None:
        self.assertEqual(split_sql_statements("SELECT 1"), ["SELECT 1"])

    def test_empty_string_yields_no_statements(self) -> None:
        self.assertEqual(split_sql_statements(""), [])

    def test_whitespace_only_yields_no_statements(self) -> None:
        self.assertEqual(split_sql_statements("   \n\n  "), [])

    def test_only_comments_yields_no_statements(self) -> None:
        self.assertEqual(split_sql_statements("-- just a comment\n-- another one"), [])

    def test_multiple_blank_statements_between_semicolons_are_dropped(self) -> None:
        self.assertEqual(split_sql_statements("SELECT 1;;;SELECT 2;"), ["SELECT 1", "SELECT 2"])

    def test_realistic_create_table_parses_to_one_statement(self) -> None:
        sql = (
            "CREATE TABLE IF NOT EXISTS users (\n"
            "    user_id INTEGER PRIMARY KEY,\n"
            "    username TEXT\n"
            ");"
        )
        result = split_sql_statements(sql)
        self.assertEqual(len(result), 1)
        self.assertIn("CREATE TABLE IF NOT EXISTS users", result[0])


class StringAndQuotingTests(unittest.TestCase):
    def test_semicolon_inside_single_quoted_string_is_not_a_separator(self) -> None:
        result = split_sql_statements("INSERT INTO t VALUES ('a;b');")
        self.assertEqual(len(result), 1)
        self.assertIn("'a;b'", result[0])

    def test_doubled_quote_escape_inside_string_is_handled(self) -> None:
        result = split_sql_statements("INSERT INTO t VALUES ('a''b;c');")
        self.assertEqual(len(result), 1)
        self.assertIn("'a''b;c'", result[0])

    def test_semicolon_inside_double_quoted_identifier_is_not_a_separator(self) -> None:
        result = split_sql_statements('SELECT 1 AS "a;b";')
        self.assertEqual(len(result), 1)
        self.assertIn('"a;b"', result[0])


class CommentTests(unittest.TestCase):
    def test_line_comment_with_semicolon_inside_is_not_a_separator(self) -> None:
        sql = "-- comment; with semicolon\nSELECT 1;"
        result = split_sql_statements(sql)
        self.assertEqual(result, ["SELECT 1"])

    def test_block_comment_with_semicolon_inside_is_not_a_separator(self) -> None:
        sql = "/* comment; with\nmultiple; lines */ SELECT 1;"
        result = split_sql_statements(sql)
        self.assertEqual(result, ["SELECT 1"])

    def test_comment_before_statement_does_not_swallow_the_statement(self) -> None:
        sql = "-- header comment\nSELECT 1;"
        result = split_sql_statements(sql)
        self.assertEqual(result, ["SELECT 1"])

    def test_unterminated_block_comment_now_raises_a_clear_error(self) -> None:
        """
        Раньше /\\*.*?\\*/ требовал закрывающего */; если его не было
        вообще, регэксп не матчился НИ В ОДНОЙ позиции внутри
        "комментария", и текст внутри тихо разбирался как обычный SQL —
        включая ';' как настоящий разделитель (порча миграции без
        единого предупреждения). Теперь этот случай распознаётся явно
        и даёт понятную ошибку вместо молчаливого misparse.
        """
        sql = "/* never closed SELECT 1;"
        with self.assertRaises(ValueError) as ctx:
            split_sql_statements(sql)
        self.assertIn("омментари", str(ctx.exception))

    def test_well_formed_comments_are_unaffected_by_the_unterminated_check(self) -> None:
        self.assertEqual(split_sql_statements("/* fine */ SELECT 1;"), ["SELECT 1"])
        self.assertEqual(
            split_sql_statements("/* multi\nline; comment */ SELECT 1;"), ["SELECT 1"]
        )


class DollarQuotingTests(unittest.TestCase):
    def test_empty_tag_dollar_quoting_keeps_body_as_one_token(self) -> None:
        sql = (
            "CREATE FUNCTION f() RETURNS void AS $$ "
            "BEGIN INSERT INTO t VALUES (1); END; "
            "$$ LANGUAGE plpgsql;"
        )
        result = split_sql_statements(sql)
        self.assertEqual(len(result), 1)
        self.assertIn("INSERT INTO t VALUES (1);", result[0])
        self.assertIn("LANGUAGE plpgsql", result[0])

    def test_named_tag_dollar_quoting_keeps_body_as_one_token(self) -> None:
        sql = "CREATE FUNCTION f() AS $tag$ SELECT 1; SELECT 2; $tag$ LANGUAGE sql;"
        result = split_sql_statements(sql)
        self.assertEqual(len(result), 1)

    def test_different_tag_inside_does_not_prematurely_close_the_block(self) -> None:
        sql = "CREATE FUNCTION f() AS $outer$ inner text $inner$ still inside $outer$ LANGUAGE sql;"
        result = split_sql_statements(sql)
        self.assertEqual(len(result), 1)
        self.assertIn("still inside", result[0])


class BeginEndNestingTests(unittest.TestCase):
    def test_nested_begin_end_trigger_body_is_not_split_on_internal_semicolons(self) -> None:
        sql = "CREATE TRIGGER trg BEGIN BEGIN SELECT 1; END; SELECT 2; END; SELECT 3;"
        result = split_sql_statements(sql)
        self.assertEqual(len(result), 2)
        self.assertIn("CREATE TRIGGER trg BEGIN BEGIN SELECT 1; END; SELECT 2; END", result[0])
        self.assertEqual(result[1], "SELECT 3")

    def test_case_insensitive_begin_end(self) -> None:
        sql = "CREATE TRIGGER trg begin SELECT 1; end; SELECT 2;"
        result = split_sql_statements(sql)
        self.assertEqual(len(result), 2)

    def test_stray_end_before_any_begin_does_not_go_negative_or_crash(self) -> None:
        sql = "END; SELECT 1;"
        result = split_sql_statements(sql)  # не должно бросить
        self.assertEqual(result, ["END", "SELECT 1"])

    def test_word_boundary_prevents_false_positives_on_similar_words(self) -> None:
        sql = "SELECT BEGINNING, ENDING, APPEND FROM t;"
        result = split_sql_statements(sql)
        self.assertEqual(result, ["SELECT BEGINNING, ENDING, APPEND FROM t"])

    def test_simple_trigger_without_nesting(self) -> None:
        sql = "CREATE TRIGGER trg AFTER INSERT ON t BEGIN UPDATE t2 SET x = 1; END;"
        result = split_sql_statements(sql)
        self.assertEqual(len(result), 1)


class CollectMigrationFilesTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.mig_dir = Path(self._tmp.name)

    def touch(self, name: str, content: str = "SELECT 1;") -> None:
        (self.mig_dir / name).write_text(content, encoding="utf-8")

    def test_empty_directory_returns_empty_list(self) -> None:
        self.assertEqual(collect_migration_files(self.mig_dir, "ns"), [])

    def test_collects_and_sorts_by_version_numerically_not_lexically(self) -> None:
        self.touch("10_ten.sql")
        self.touch("2_two.sql")
        self.touch("1_one.sql")
        result = collect_migration_files(self.mig_dir, "ns")
        self.assertEqual([v for v, _ in result], [1, 2, 10])

    def test_non_matching_filenames_are_skipped_not_fatal(self) -> None:
        self.touch("0001_valid.sql")
        self.touch("readme.sql")  # нет ведущего номера
        result = collect_migration_files(self.mig_dir, "ns")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0][0], 1)

    def test_non_sql_files_are_ignored_entirely(self) -> None:
        self.touch("0001_valid.sql")
        (self.mig_dir / "readme.md").write_text("hello", encoding="utf-8")
        result = collect_migration_files(self.mig_dir, "ns")
        self.assertEqual(len(result), 1)

    def test_subdirectories_do_not_crash_or_get_included(self) -> None:
        self.touch("0001_valid.sql")
        (self.mig_dir / "postgres").mkdir()
        result = collect_migration_files(self.mig_dir, "ns")  # не должно бросить
        self.assertEqual(len(result), 1)

    def test_duplicate_version_numbers_raise_value_error(self) -> None:
        self.touch("0001_a.sql")
        self.touch("0001_b.sql")
        with self.assertRaises(ValueError) as ctx:
            collect_migration_files(self.mig_dir, "myplugin")
        self.assertIn("myplugin", str(ctx.exception))
        self.assertIn("1", str(ctx.exception))

    def test_zero_padded_and_unpadded_versions_both_parse_correctly(self) -> None:
        self.touch("0005_padded.sql")
        result = collect_migration_files(self.mig_dir, "ns")
        self.assertEqual(result[0][0], 5)


class ResolveMigrationDirTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.base_dir = Path(self._tmp.name)

    def test_sqlite_always_returns_base_dir(self) -> None:
        self.assertEqual(resolve_migration_dir(self.base_dir, "sqlite"), self.base_dir)

    def test_sqlite_ignores_a_sqlite_subfolder_even_if_present(self) -> None:
        (self.base_dir / "sqlite").mkdir()
        self.assertEqual(resolve_migration_dir(self.base_dir, "sqlite"), self.base_dir)

    def test_postgres_uses_subfolder_when_present(self) -> None:
        pg_dir = self.base_dir / "postgres"
        pg_dir.mkdir()
        self.assertEqual(resolve_migration_dir(self.base_dir, "postgres"), pg_dir)

    def test_postgres_falls_back_to_base_dir_when_subfolder_absent(self) -> None:
        self.assertEqual(resolve_migration_dir(self.base_dir, "postgres"), self.base_dir)

    def test_arbitrary_backend_name_also_checks_for_matching_subfolder(self) -> None:
        # Функция не захардкожена на "postgres" — работает для любого имени бэкенда.
        custom_dir = self.base_dir / "mysql"
        custom_dir.mkdir()
        self.assertEqual(resolve_migration_dir(self.base_dir, "mysql"), custom_dir)

    def test_arbitrary_backend_name_without_subfolder_falls_back(self) -> None:
        self.assertEqual(resolve_migration_dir(self.base_dir, "mysql"), self.base_dir)


if __name__ == "__main__":
    unittest.main()
