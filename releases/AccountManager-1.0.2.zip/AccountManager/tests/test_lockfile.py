"""
tests/test_lockfile.py — core/lockfile.py: plugins.lock.json
(снапшот версий + hold-семантика) и verify/drift-детекция.

Особое внимание — граничным случаям файловой системы (битый JSON,
JSON валиден, но не тот тип — список/строка вместо объекта) и
композиции нескольких плагинов сразу в verify_against_lock().
"""
from __future__ import annotations

import hashlib
import json
import tempfile
import time
import unittest
from importlib.metadata import PackageNotFoundError
from pathlib import Path
from unittest.mock import patch

from tests._support import env  # noqa: F401

import core.lockfile as lockfile
import core.plugin_installer as plugin_installer
import core as core_pkg
from core.dependencies import parse_dependency


class _FakeRecord:
    def __init__(self, path: Path, version: str, repository_url: str = "", pip_deps: list | None = None) -> None:
        self.path = path
        self.version = version
        self.repository_url = repository_url
        self._pip_deps = pip_deps or []

    def pip_deps(self):
        return self._pip_deps


class _FakeLoader:
    def __init__(self, records: dict[str, _FakeRecord], skipped: set | None = None) -> None:
        self._records = records
        self._skipped = skipped or set()


class LockfileTestCase(unittest.TestCase):
    """Общий setUp: изолированная временная директория для lock- и registry-файлов."""

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        tmp_dir = Path(self._tmp.name)

        self.lock_path = tmp_dir / "plugins.lock.json"
        self.registry_path = tmp_dir / "run" / "installed_plugins.json"

        self._patch_lock = patch.object(lockfile, "LOCK_FILE_PATH", self.lock_path)
        self._patch_registry = patch.object(plugin_installer, "INSTALLED_REGISTRY_PATH", self.registry_path)
        self._patch_lock.start()
        self._patch_registry.start()
        self.addCleanup(self._patch_lock.stop)
        self.addCleanup(self._patch_registry.stop)

        self.plugins_dir = tmp_dir / "plugins"
        self.plugins_dir.mkdir()

    def make_plugin_dir(self, name: str, manifest_text: str = "{}", plugin_py_text: str = "# plugin") -> Path:
        d = self.plugins_dir / name
        d.mkdir()
        (d / "manifest.json").write_text(manifest_text, encoding="utf-8")
        (d / "plugin.py").write_text(plugin_py_text, encoding="utf-8")
        return d


class ReadWriteLockTests(LockfileTestCase):
    def test_read_lock_missing_file_returns_none(self) -> None:
        self.assertIsNone(lockfile.read_lock())

    def test_read_lock_malformed_json_returns_none(self) -> None:
        self.lock_path.write_text("{not valid json", encoding="utf-8")
        self.assertIsNone(lockfile.read_lock())

    def test_write_then_read_roundtrip(self) -> None:
        data = {"locked": True, "plugins": {"antispam": {"version": "1.0.0"}}}
        lockfile.write_lock(data)
        self.assertEqual(lockfile.read_lock(), data)

    def test_write_lock_preserves_unicode_literally(self) -> None:
        lockfile.write_lock({"locked": True, "note": "Привет, мир"})
        raw = self.lock_path.read_text(encoding="utf-8")
        self.assertIn("Привет, мир", raw)
        self.assertNotIn("\\u", raw)

    def test_write_lock_is_pretty_printed(self) -> None:
        lockfile.write_lock({"locked": True})
        raw = self.lock_path.read_text(encoding="utf-8")
        self.assertIn("\n", raw)  # indent=2 подразумевает переносы строк

    def test_read_lock_valid_json_but_wrong_shape_is_not_a_dict(self) -> None:
        """
        Задокументированная слабость: read_lock() ловит только
        FileNotFoundError/JSONDecodeError. Если файл содержит валидный
        JSON, но не объект (например, список), read_lock() вернёт этот
        список как есть — вызывающий код (is_locked() и т.п.), который
        ожидает dict, упадёт на .get(). Тест фиксирует РЕАЛЬНОЕ текущее
        поведение, чтобы оно не изменилось незаметно.
        """
        self.lock_path.write_text("[1, 2, 3]", encoding="utf-8")
        self.assertEqual(lockfile.read_lock(), [1, 2, 3])


class IsLockedTests(LockfileTestCase):
    def test_no_file_means_not_locked(self) -> None:
        self.assertFalse(lockfile.is_locked())

    def test_locked_true(self) -> None:
        lockfile.write_lock({"locked": True})
        self.assertTrue(lockfile.is_locked())

    def test_locked_false(self) -> None:
        lockfile.write_lock({"locked": False})
        self.assertFalse(lockfile.is_locked())

    def test_missing_locked_key_defaults_to_not_locked(self) -> None:
        lockfile.write_lock({"plugins": {}})
        self.assertFalse(lockfile.is_locked())

    def test_malformed_json_treated_as_not_locked(self) -> None:
        self.lock_path.write_text("{{{broken", encoding="utf-8")
        self.assertFalse(lockfile.is_locked())

    def test_wrong_shaped_json_is_now_treated_as_not_locked(self) -> None:
        # Раньше is_locked() делал data.get("locked") без проверки типа
        # -> на списке падал AttributeError. Теперь проверяется
        # isinstance(data, dict) и просто возвращается False.
        self.lock_path.write_text("[1, 2, 3]", encoding="utf-8")
        self.assertFalse(lockfile.is_locked())


class SetLockedTests(LockfileTestCase):
    def test_no_file_returns_false_and_creates_nothing(self) -> None:
        result = lockfile.set_locked(True)
        self.assertFalse(result)
        self.assertFalse(self.lock_path.exists())

    def test_wrong_shaped_json_returns_false_without_crashing(self) -> None:
        self.lock_path.write_text("[1, 2, 3]", encoding="utf-8")
        self.assertFalse(lockfile.set_locked(True))

    def test_locking_existing_file(self) -> None:
        lockfile.write_lock({"locked": False, "plugins": {"x": 1}})
        result = lockfile.set_locked(True)
        self.assertTrue(result)
        data = lockfile.read_lock()
        self.assertTrue(data["locked"])
        self.assertEqual(data["plugins"], {"x": 1})  # прочие поля не тронуты

    def test_unlocking_preserves_history_fields(self) -> None:
        lockfile.write_lock({"locked": True, "created_at": 123.0, "plugins": {"x": 1}})
        lockfile.set_locked(False)
        data = lockfile.read_lock()
        self.assertFalse(data["locked"])
        self.assertEqual(data["created_at"], 123.0)
        self.assertEqual(data["plugins"], {"x": 1})

    def test_lock_unlock_roundtrip(self) -> None:
        lockfile.write_lock({"locked": False})
        lockfile.set_locked(True)
        self.assertTrue(lockfile.is_locked())
        lockfile.set_locked(False)
        self.assertFalse(lockfile.is_locked())


class HashPluginDirTests(LockfileTestCase):
    def test_empty_directory_hash_is_sha256_of_empty_input(self) -> None:
        empty_dir = self.plugins_dir / "empty"
        empty_dir.mkdir()
        expected = hashlib.sha256().hexdigest()[:16]
        self.assertEqual(lockfile._hash_plugin_dir(empty_dir), expected)

    def test_hash_is_deterministic_for_same_content(self) -> None:
        d1 = self.make_plugin_dir("p1", manifest_text='{"a": 1}', plugin_py_text="x = 1")
        d2 = self.make_plugin_dir("p2", manifest_text='{"a": 1}', plugin_py_text="x = 1")
        self.assertEqual(lockfile._hash_plugin_dir(d1), lockfile._hash_plugin_dir(d2))

    def test_hash_changes_when_manifest_changes(self) -> None:
        d = self.make_plugin_dir("p1", manifest_text='{"a": 1}')
        h1 = lockfile._hash_plugin_dir(d)
        (d / "manifest.json").write_text('{"a": 2}', encoding="utf-8")
        h2 = lockfile._hash_plugin_dir(d)
        self.assertNotEqual(h1, h2)

    def test_hash_changes_when_plugin_py_changes_but_manifest_same(self) -> None:
        d = self.make_plugin_dir("p1", manifest_text='{"a": 1}', plugin_py_text="x = 1")
        h1 = lockfile._hash_plugin_dir(d)
        (d / "plugin.py").write_text("x = 2", encoding="utf-8")
        h2 = lockfile._hash_plugin_dir(d)
        self.assertNotEqual(h1, h2)

    def test_hash_length_is_16_hex_chars(self) -> None:
        d = self.make_plugin_dir("p1")
        h = lockfile._hash_plugin_dir(d)
        self.assertEqual(len(h), 16)
        int(h, 16)  # не бросает — валидный hex


class GenerateLockTests(LockfileTestCase):
    def test_skipped_plugins_block_lock_generation(self) -> None:
        loader = _FakeLoader({}, skipped={"zeta", "alpha", "middle"})
        result = lockfile.generate_lock(loader)
        self.assertFalse(result.ok)
        self.assertIsNone(result.data)
        # sorted() -> alpha должен упоминаться раньше zeta в сообщении
        self.assertLess(result.error.index("alpha"), result.error.index("zeta"))

    def test_no_skipped_plugins_generates_data(self) -> None:
        d = self.make_plugin_dir("antispam")
        loader = _FakeLoader({"antispam": _FakeRecord(d, version="1.0.0")})
        with patch("time.time", return_value=1_700_000_000.0):
            result = lockfile.generate_lock(loader)
        self.assertTrue(result.ok)
        self.assertEqual(result.error, "")
        self.assertTrue(result.data["locked"])
        self.assertEqual(result.data["created_at"], 1_700_000_000.0)
        self.assertEqual(result.data["core_version"], core_pkg.__version__)
        self.assertIn("antispam", result.data["plugins"])
        self.assertEqual(result.data["plugins"]["antispam"]["version"], "1.0.0")

    def test_content_hash_recorded_in_lock_matches_hash_plugin_dir(self) -> None:
        d = self.make_plugin_dir("antispam", manifest_text='{"x":1}')
        loader = _FakeLoader({"antispam": _FakeRecord(d, version="1.0.0")})
        result = lockfile.generate_lock(loader)
        self.assertEqual(
            result.data["plugins"]["antispam"]["content_hash"],
            lockfile._hash_plugin_dir(d),
        )

    def test_repository_url_prefers_record_over_registry(self) -> None:
        d = self.make_plugin_dir("antispam")
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        self.registry_path.write_text(
            json.dumps({"antispam": {"repository_url": "https://registry/x", "commit_sha": "aaa"}}),
            encoding="utf-8",
        )
        loader = _FakeLoader({
            "antispam": _FakeRecord(d, version="1.0.0", repository_url="https://record/x"),
        })
        result = lockfile.generate_lock(loader)
        self.assertEqual(result.data["plugins"]["antispam"]["repository_url"], "https://record/x")
        self.assertEqual(result.data["plugins"]["antispam"]["commit_sha"], "aaa")

    def test_repository_url_falls_back_to_registry_when_record_empty(self) -> None:
        d = self.make_plugin_dir("antispam")
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        self.registry_path.write_text(
            json.dumps({"antispam": {"repository_url": "https://registry/x"}}),
            encoding="utf-8",
        )
        loader = _FakeLoader({"antispam": _FakeRecord(d, version="1.0.0", repository_url="")})
        result = lockfile.generate_lock(loader)
        self.assertEqual(result.data["plugins"]["antispam"]["repository_url"], "https://registry/x")

    def test_missing_registry_entry_defaults_commit_sha_to_empty_string(self) -> None:
        d = self.make_plugin_dir("antispam")
        loader = _FakeLoader({"antispam": _FakeRecord(d, version="1.0.0")})
        result = lockfile.generate_lock(loader)
        self.assertEqual(result.data["plugins"]["antispam"]["commit_sha"], "")

    def test_pip_dependency_version_recorded_when_installed(self) -> None:
        d = self.make_plugin_dir("antispam")
        loader = _FakeLoader({
            "antispam": _FakeRecord(d, version="1.0.0", pip_deps=[parse_dependency("somepkg>=1.0")]),
        })
        with patch("importlib.metadata.version", return_value="1.2.3"):
            result = lockfile.generate_lock(loader)
        self.assertEqual(result.data["pip_versions"]["somepkg"], "1.2.3")

    def test_pip_dependency_not_installed_records_question_mark(self) -> None:
        d = self.make_plugin_dir("antispam")
        loader = _FakeLoader({
            "antispam": _FakeRecord(d, version="1.0.0", pip_deps=[parse_dependency("ghost-pkg")]),
        })
        with patch("importlib.metadata.version", side_effect=PackageNotFoundError):
            result = lockfile.generate_lock(loader)
        self.assertEqual(result.data["pip_versions"]["ghost-pkg"], "?")

    def test_shared_pip_dependency_across_plugins_recorded_once(self) -> None:
        d1 = self.make_plugin_dir("pluginA")
        d2 = self.make_plugin_dir("pluginB")
        loader = _FakeLoader({
            "pluginA": _FakeRecord(d1, version="1.0.0", pip_deps=[parse_dependency("shared>=1.0")]),
            "pluginB": _FakeRecord(d2, version="1.0.0", pip_deps=[parse_dependency("shared>=1.0")]),
        })
        with patch("importlib.metadata.version", return_value="5.0.0") as mock_version:
            result = lockfile.generate_lock(loader)
        self.assertEqual(result.data["pip_versions"], {"shared": "5.0.0"})
        # первое вхождение выигрывает -> версия запрашивается лишь один раз
        mock_version.assert_called_once_with("shared")


class VerifyAgainstLockTests(LockfileTestCase):
    def test_no_lock_file_returns_none(self) -> None:
        loader = _FakeLoader({})
        self.assertIsNone(lockfile.verify_against_lock(loader))

    def test_core_version_mismatch_detected(self) -> None:
        lockfile.write_lock({"core_version": "1.9.0", "plugins": {}, "pip_versions": {}})
        result = lockfile.verify_against_lock(_FakeLoader({}))
        self.assertIn("1.9.0", result.core_version_mismatch)
        self.assertIn("1.0.0", result.core_version_mismatch)

    def test_core_version_match_gives_empty_mismatch_string(self) -> None:
        lockfile.write_lock({"core_version": core_pkg.__version__, "plugins": {}, "pip_versions": {}})
        result = lockfile.verify_against_lock(_FakeLoader({}))
        self.assertEqual(result.core_version_mismatch, "")

    def test_plugin_matching_lock_reports_match(self) -> None:
        d = self.make_plugin_dir("antispam", manifest_text='{"v":1}')
        content_hash = lockfile._hash_plugin_dir(d)
        lockfile.write_lock({
            "core_version": core_pkg.__version__,
            "plugins": {"antispam": {"version": "1.0.0", "content_hash": content_hash}},
            "pip_versions": {},
        })
        loader = _FakeLoader({"antispam": _FakeRecord(d, version="1.0.0")})
        result = lockfile.verify_against_lock(loader)
        entry = next(e for e in result.entries if e.name == "antispam")
        self.assertEqual(entry.status, "match")

    def test_new_plugin_not_in_lock_reports_new(self) -> None:
        d = self.make_plugin_dir("brandnew")
        lockfile.write_lock({"core_version": core_pkg.__version__, "plugins": {}, "pip_versions": {}})
        loader = _FakeLoader({"brandnew": _FakeRecord(d, version="1.0.0")})
        result = lockfile.verify_against_lock(loader)
        entry = next(e for e in result.entries if e.name == "brandnew")
        self.assertEqual(entry.status, "new")

    def test_version_changed_reports_version_changed_with_both_versions_in_detail(self) -> None:
        d = self.make_plugin_dir("antispam")
        lockfile.write_lock({
            "core_version": core_pkg.__version__,
            "plugins": {"antispam": {"version": "1.0.0", "content_hash": "whatever"}},
            "pip_versions": {},
        })
        loader = _FakeLoader({"antispam": _FakeRecord(d, version="2.0.0")})
        result = lockfile.verify_against_lock(loader)
        entry = next(e for e in result.entries if e.name == "antispam")
        self.assertEqual(entry.status, "version_changed")
        self.assertIn("1.0.0", entry.detail)
        self.assertIn("2.0.0", entry.detail)

    def test_content_changed_when_version_same_but_hash_differs(self) -> None:
        d = self.make_plugin_dir("antispam", manifest_text='{"v":1}')
        lockfile.write_lock({
            "core_version": core_pkg.__version__,
            "plugins": {"antispam": {"version": "1.0.0", "content_hash": "not-the-real-hash"}},
            "pip_versions": {},
        })
        loader = _FakeLoader({"antispam": _FakeRecord(d, version="1.0.0")})
        result = lockfile.verify_against_lock(loader)
        entry = next(e for e in result.entries if e.name == "antispam")
        self.assertEqual(entry.status, "content_changed")

    def test_missing_plugin_reports_missing(self) -> None:
        lockfile.write_lock({
            "core_version": core_pkg.__version__,
            "plugins": {"gone": {"version": "1.0.0", "content_hash": "x"}},
            "pip_versions": {},
        })
        loader = _FakeLoader({})
        result = lockfile.verify_against_lock(loader)
        entry = next(e for e in result.entries if e.name == "gone")
        self.assertEqual(entry.status, "missing")

    def test_pip_package_uninstalled_since_lock(self) -> None:
        lockfile.write_lock({
            "core_version": core_pkg.__version__, "plugins": {}, "pip_versions": {"ghost": "1.0.0"},
        })
        with patch("importlib.metadata.version", side_effect=PackageNotFoundError):
            result = lockfile.verify_against_lock(_FakeLoader({}))
        self.assertEqual(len(result.pip_mismatches), 1)
        self.assertIn("НЕ установлен", result.pip_mismatches[0])

    def test_pip_package_version_drifted(self) -> None:
        lockfile.write_lock({
            "core_version": core_pkg.__version__, "plugins": {}, "pip_versions": {"pkg": "1.0.0"},
        })
        with patch("importlib.metadata.version", return_value="2.0.0"):
            result = lockfile.verify_against_lock(_FakeLoader({}))
        self.assertEqual(len(result.pip_mismatches), 1)
        self.assertIn("1.0.0", result.pip_mismatches[0])
        self.assertIn("2.0.0", result.pip_mismatches[0])

    def test_pip_package_version_matches_no_mismatch(self) -> None:
        lockfile.write_lock({
            "core_version": core_pkg.__version__, "plugins": {}, "pip_versions": {"pkg": "1.0.0"},
        })
        with patch("importlib.metadata.version", return_value="1.0.0"):
            result = lockfile.verify_against_lock(_FakeLoader({}))
        self.assertEqual(result.pip_mismatches, [])

    def test_composite_scenario_with_all_statuses_at_once(self) -> None:
        d_match = self.make_plugin_dir("match_plugin", manifest_text='{"m":1}')
        d_changed = self.make_plugin_dir("changed_plugin")
        d_new = self.make_plugin_dir("new_plugin")
        lockfile.write_lock({
            "core_version": core_pkg.__version__,
            "plugins": {
                "match_plugin": {"version": "1.0.0", "content_hash": lockfile._hash_plugin_dir(d_match)},
                "changed_plugin": {"version": "1.0.0", "content_hash": "stale-hash"},
                "gone_plugin": {"version": "1.0.0", "content_hash": "x"},
            },
            "pip_versions": {},
        })
        loader = _FakeLoader({
            "match_plugin": _FakeRecord(d_match, version="1.0.0"),
            "changed_plugin": _FakeRecord(d_changed, version="1.0.0"),
            "new_plugin": _FakeRecord(d_new, version="1.0.0"),
        })
        result = lockfile.verify_against_lock(loader)
        statuses = {e.name: e.status for e in result.entries}
        self.assertEqual(statuses, {
            "match_plugin": "match",
            "changed_plugin": "content_changed",
            "gone_plugin": "missing",
            "new_plugin": "new",
        })


class CheckDriftAtStartupTests(LockfileTestCase):
    def test_not_locked_returns_none_even_with_drift_available(self) -> None:
        d = self.make_plugin_dir("antispam")
        lockfile.write_lock({
            "locked": False,
            "core_version": "9.9.9",  # явное расхождение, но не залочено
            "plugins": {},
            "pip_versions": {},
        })
        loader = _FakeLoader({"antispam": _FakeRecord(d, version="1.0.0")})
        self.assertIsNone(lockfile.check_drift_at_startup(loader))

    def test_no_lock_file_returns_none(self) -> None:
        self.assertIsNone(lockfile.check_drift_at_startup(_FakeLoader({})))

    def test_locked_with_verify_returning_none_is_handled_gracefully(self) -> None:
        lockfile.write_lock({"locked": True, "core_version": core_pkg.__version__, "plugins": {}, "pip_versions": {}})
        with patch("core.lockfile.verify_against_lock", return_value=None):
            self.assertIsNone(lockfile.check_drift_at_startup(_FakeLoader({})))

    def test_locked_with_no_drift_returns_none(self) -> None:
        d = self.make_plugin_dir("antispam")
        lockfile.write_lock({
            "locked": True,
            "core_version": core_pkg.__version__,
            "plugins": {"antispam": {"version": "1.0.0", "content_hash": lockfile._hash_plugin_dir(d)}},
            "pip_versions": {},
        })
        loader = _FakeLoader({"antispam": _FakeRecord(d, version="1.0.0")})
        self.assertIsNone(lockfile.check_drift_at_startup(loader))

    def test_locked_with_plugin_drift_returns_formatted_report(self) -> None:
        d = self.make_plugin_dir("antispam")
        lockfile.write_lock({
            "locked": True,
            "core_version": core_pkg.__version__,
            "plugins": {"antispam": {"version": "1.0.0", "content_hash": "stale"}},
            "pip_versions": {},
        })
        loader = _FakeLoader({"antispam": _FakeRecord(d, version="2.0.0")})
        report = lockfile.check_drift_at_startup(loader)
        self.assertIsNotNone(report)
        self.assertIn("antispam", report)
        self.assertIn("version_changed", report)
        self.assertIn("locked=true", report)
        self.assertIn("lock --yes", report)

    def test_locked_with_only_core_version_drift_still_reports(self) -> None:
        lockfile.write_lock({
            "locked": True, "core_version": "9.9.9", "plugins": {}, "pip_versions": {},
        })
        report = lockfile.check_drift_at_startup(_FakeLoader({}))
        self.assertIsNotNone(report)
        self.assertIn("ядро", report)

    def test_locked_with_only_pip_drift_still_reports(self) -> None:
        lockfile.write_lock({
            "locked": True, "core_version": core_pkg.__version__, "plugins": {}, "pip_versions": {"pkg": "1.0.0"},
        })
        with patch("importlib.metadata.version", return_value="9.9.9"):
            report = lockfile.check_drift_at_startup(_FakeLoader({}))
        self.assertIsNotNone(report)
        self.assertIn("pkg", report)
        self.assertIn("9.9.9", report)


if __name__ == "__main__":
    unittest.main()
