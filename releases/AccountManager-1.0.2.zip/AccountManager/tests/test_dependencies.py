"""
tests/test_dependencies.py — core/dependencies.py: разбор строк
зависимостей (PEP 440) и проверка версий pip-/plugin-/core-зависимостей.

Это самый "чистый" модуль ядра (нет ни aiogram, ни aiosqlite, ни
файловой системы) — соответственно, здесь ожидается максимальная
плотность edge-case'ов: некорректные версии, пустые строки, unicode
в именах, конфликты условий и т.п.
"""
from __future__ import annotations

import unittest
from unittest.mock import patch

from tests._support import env  # noqa: F401  (настраивает sys.path)

from packaging.specifiers import SpecifierSet
from packaging.version import Version

from core.dependencies import (
    DependencySpec,
    DependencySpecError,
    check_core_version,
    check_pip_dependency,
    check_plugin_version,
    parse_dependency,
    parse_dependency_list,
    parse_specifier_only,
    report_pip_conflicts,
)


class ParseDependencyTests(unittest.TestCase):
    """parse_dependency(): "имя[условие]" -> DependencySpec."""

    def test_bare_name_has_empty_specifier(self) -> None:
        spec = parse_dependency("aiogram")
        self.assertEqual(spec.name, "aiogram")
        self.assertEqual(spec.specifier, SpecifierSet())
        self.assertEqual(spec.raw, "aiogram")

    def test_name_with_version_condition(self) -> None:
        spec = parse_dependency("aiogram>=3.15,<4.0")
        self.assertEqual(spec.name, "aiogram")
        self.assertIn(Version("3.15.0"), spec.specifier)
        self.assertNotIn(Version("4.0.0"), spec.specifier)
        self.assertEqual(spec.raw, "aiogram>=3.15,<4.0")

    def test_whitespace_between_name_and_condition_is_stripped(self) -> None:
        spec = parse_dependency("aiogram   >=3.15")
        self.assertEqual(spec.name, "aiogram")
        self.assertIn(Version("3.15"), spec.specifier)

    def test_leading_and_trailing_whitespace_ignored(self) -> None:
        spec = parse_dependency("   aiogram>=3.15   ")
        self.assertEqual(spec.name, "aiogram")
        self.assertEqual(spec.raw, "aiogram>=3.15")

    def test_empty_string_raises(self) -> None:
        with self.assertRaises(DependencySpecError):
            parse_dependency("")

    def test_whitespace_only_string_raises(self) -> None:
        with self.assertRaises(DependencySpecError):
            parse_dependency("     ")

    def test_string_starting_with_operator_raises(self) -> None:
        # ">=1.0" без имени пакета вообще — не должно молча стать
        # пакетом с пустым именем.
        with self.assertRaises(DependencySpecError):
            parse_dependency(">=1.0")

    def test_malformed_specifier_raises(self) -> None:
        with self.assertRaises(DependencySpecError):
            parse_dependency("aiogram>=>=1.0")

    def test_double_condition_garbage_raises(self) -> None:
        with self.assertRaises(DependencySpecError):
            parse_dependency("aiogram==1.0.0==2.0.0")

    def test_name_with_dots_hyphens_underscores(self) -> None:
        spec = parse_dependency("python-dotenv>=1.0")
        self.assertEqual(spec.name, "python-dotenv")
        spec2 = parse_dependency("my_plugin.sub>=1.0")
        self.assertEqual(spec2.name, "my_plugin.sub")

    def test_unicode_name_now_gets_a_clear_name_related_error(self) -> None:
        """
        Раньше регэксп _NAME_RE обрывал группу имени на первом
        неascii-символе, а остаток строки тихо уходил в "условие
        версии" и там падал как невалидный specifier — сообщение об
        ошибке было про условие, а не про то, что не так само имя.
        Теперь parse_dependency() явно проверяет этот случай и даёт
        сообщение, которое хотя бы упоминает имя.
        """
        with self.assertRaises(DependencySpecError) as ctx:
            parse_dependency("café>=1.0")
        message = str(ctx.exception)
        self.assertIn("é", message)
        self.assertIn("caf", message)  # упомянуто как то, что распозналось как имя

    def test_specifier_with_internal_space_after_operator(self) -> None:
        # packaging обычно терпимо относится к пробелу после оператора
        # (">= 1.0"); фиксируем реальное поведение зависимости packaging,
        # используемой этим кодом, а не предполагаемое.
        try:
            spec = parse_dependency("aiogram>= 3.15")
        except DependencySpecError:
            self.skipTest("Установленная версия packaging не принимает пробел после оператора")
        else:
            self.assertIn(Version("3.15"), spec.specifier)

    def test_name_only_first_char_must_be_alnum(self) -> None:
        # "-foo" не должно матчиться как имя "-foo" (дефис не разрешён
        # первым символом) — вся строка проваливает regex.
        with self.assertRaises(DependencySpecError):
            parse_dependency("-foo>=1.0")


class ParseDependencyListTests(unittest.TestCase):
    def test_parses_all_entries_in_order(self) -> None:
        specs = parse_dependency_list(["aiogram>=3.15,<4.0", "requests", "packaging>=23.0"])
        self.assertEqual([s.name for s in specs], ["aiogram", "requests", "packaging"])

    def test_empty_list_returns_empty_list(self) -> None:
        self.assertEqual(parse_dependency_list([]), [])

    def test_stops_at_first_bad_entry(self) -> None:
        with self.assertRaises(DependencySpecError):
            parse_dependency_list(["aiogram", "!!!not-a-name!!!", "requests"])


class DependencySpecDataclassTests(unittest.TestCase):
    def test_is_frozen(self) -> None:
        spec = parse_dependency("aiogram")
        with self.assertRaises(Exception):
            spec.name = "other"  # type: ignore[misc]

    def test_auto_generated_raw_from_direct_construction(self) -> None:
        # raw="" по умолчанию -> __post_init__ собирает его из name+specifier,
        # если DependencySpec создан напрямую, а не через parse_dependency().
        spec = DependencySpec(name="foo", specifier=SpecifierSet(">=1.0"))
        self.assertEqual(spec.raw, "foo>=1.0")

    def test_auto_generated_raw_with_empty_specifier(self) -> None:
        spec = DependencySpec(name="foo")
        self.assertEqual(spec.raw, "foo")

    def test_explicit_raw_is_preserved_verbatim(self) -> None:
        # raw специально НЕ пересобирается из str(specifier), потому что
        # порядок условий в SpecifierSet при сериализации не гарантирован
        # (см. докстринг модуля) — переданный raw должен остаться как есть.
        spec = DependencySpec(name="foo", specifier=SpecifierSet(">=3.15,<4.0"), raw="foo>=3.15,<4.0")
        self.assertEqual(spec.raw, "foo>=3.15,<4.0")


class SatisfiedByTests(unittest.TestCase):
    def test_empty_specifier_always_satisfied(self) -> None:
        spec = parse_dependency("foo")
        ok, note = spec.satisfied_by("anything-not-even-pep440")
        self.assertTrue(ok)
        self.assertEqual(note, "")

    def test_version_within_range(self) -> None:
        spec = parse_dependency("foo>=1.0,<2.0")
        ok, note = spec.satisfied_by("1.5.0")
        self.assertTrue(ok)
        self.assertEqual(note, "")

    def test_version_outside_range(self) -> None:
        spec = parse_dependency("foo>=1.0,<2.0")
        ok, note = spec.satisfied_by("2.0.0")
        self.assertFalse(ok)
        self.assertEqual(note, "")

    def test_boundary_versions_are_inclusive_exclusive_correctly(self) -> None:
        spec = parse_dependency("foo>=1.0,<2.0")
        self.assertTrue(spec.satisfied_by("1.0.0")[0])   # >= включительно
        self.assertFalse(spec.satisfied_by("2.0.0")[0])  # < исключительно

    def test_unparseable_installed_version_does_not_block(self) -> None:
        # ok=True даже когда версия не PEP440 — не блокируем загрузку
        # из-за того, что МЫ не смогли её распарсить (см. докстринг).
        spec = parse_dependency("foo>=1.0")
        ok, note = spec.satisfied_by("not-a-version-at-all")
        self.assertTrue(ok)
        self.assertNotEqual(note, "")
        self.assertIn("PEP 440", note)

    def test_prerelease_matches_via_bare_membership_check(self) -> None:
        # satisfied_by() делает `parsed in self.specifier` БЕЗ явного
        # prereleases=False. Задокументированное поведение packaging
        # (см. SpecifierSet.contains docstring): при проверке ОДНОЙ
        # конкретной версии через `in`/.contains(prereleases=None) без
        # списка кандидатов для фильтрации применяется рекомендация
        # PEP 440 — пре-релиз считается подходящим. Другими словами:
        # "foo>=1.0" пропустит "2.0.0a1", хотя интуитивно можно было бы
        # ожидать обратного. Явно фиксируем это, а не полагаемся на
        # интуицию — при апгрейде packaging тест сразу покажет, если
        # поведение изменится.
        spec = parse_dependency("foo>=1.0")
        ok, note = spec.satisfied_by("2.0.0a1")
        self.assertTrue(ok)
        self.assertEqual(note, "")

    def test_prerelease_of_the_exclusive_upper_bound_itself_is_excluded(self) -> None:
        # PEP 440: "<2.0" как ВЕРХНЯЯ граница по умолчанию не пропускает
        # пре-релизы САМОЙ версии 2.0 (даже "2.0.0a1" < "2.0.0" численно) —
        # иначе исключающая верхняя граница неожиданно пропускала бы
        # "первые версии следующего релиза". Это НЕ то же самое, что
        # test_prerelease_matches_via_bare_membership_check выше (там
        # было ">=1.0" без верхней границы вовсе) — подтверждаем эмпирически,
        # а не по памяти о PEP 440.
        spec = parse_dependency("foo>=1.0,<2.0")
        ok, _ = spec.satisfied_by("2.0.0a1")
        self.assertFalse(ok)

    def test_prerelease_not_of_the_boundary_version_still_matches_in_range(self) -> None:
        # А пре-релиз версии, которая сама не является граничной,
        # спокойно проходит обе границы диапазона.
        spec = parse_dependency("foo>=1.0,<2.0")
        ok, _ = spec.satisfied_by("1.5.0a1")
        self.assertTrue(ok)


class CheckPipDependencyTests(unittest.TestCase):
    def test_package_not_installed(self) -> None:
        spec = parse_dependency("totally-nonexistent-package-xyz")
        with patch(
            "core.dependencies.installed_pip_version",
            side_effect=__import__("importlib.metadata", fromlist=["PackageNotFoundError"]).PackageNotFoundError,
        ):
            result = check_pip_dependency(spec)
        self.assertFalse(result.ok)
        self.assertIsNone(result.installed)
        self.assertIn("не установлен", result.reason)

    def test_package_installed_and_satisfies(self) -> None:
        spec = parse_dependency("somepkg>=1.0,<2.0")
        with patch("core.dependencies.installed_pip_version", return_value="1.5.0"):
            result = check_pip_dependency(spec)
        self.assertTrue(result.ok)
        self.assertEqual(result.installed, "1.5.0")

    def test_package_installed_but_wrong_version(self) -> None:
        spec = parse_dependency("somepkg>=1.0,<2.0")
        with patch("core.dependencies.installed_pip_version", return_value="3.0.0"):
            result = check_pip_dependency(spec)
        self.assertFalse(result.ok)
        self.assertEqual(result.installed, "3.0.0")
        self.assertIn("3.0.0", result.reason)
        self.assertIn("требуется", result.reason)

    def test_no_version_condition_always_ok_if_installed(self) -> None:
        spec = parse_dependency("somepkg")
        with patch("core.dependencies.installed_pip_version", return_value="0.0.1"):
            result = check_pip_dependency(spec)
        self.assertTrue(result.ok)


class CheckCoreVersionTests(unittest.TestCase):
    def test_empty_specifier_always_ok(self) -> None:
        ok, note = check_core_version(SpecifierSet(), "2.0.0")
        self.assertTrue(ok)
        self.assertEqual(note, "")

    def test_core_version_satisfies(self) -> None:
        ok, note = check_core_version(SpecifierSet(">=2.0.0,<3.0.0"), "2.5.0")
        self.assertTrue(ok)

    def test_core_version_too_old(self) -> None:
        ok, note = check_core_version(SpecifierSet(">=2.0.0,<3.0.0"), "1.9.0")
        self.assertFalse(ok)
        self.assertIn("1.9.0", note)

    def test_core_version_too_new(self) -> None:
        ok, note = check_core_version(SpecifierSet(">=2.0.0,<3.0.0"), "3.0.0")
        self.assertFalse(ok)

    def test_unparseable_core_version_does_not_block(self) -> None:
        ok, note = check_core_version(SpecifierSet(">=2.0.0"), "not-a-version")
        self.assertTrue(ok)
        self.assertIn("PEP 440", note)


class CheckPluginVersionTests(unittest.TestCase):
    def test_satisfied(self) -> None:
        ok, note = check_plugin_version("antispam", SpecifierSet(">=1.0.0"), "1.2.0")
        self.assertTrue(ok)
        self.assertEqual(note, "")

    def test_not_satisfied(self) -> None:
        ok, note = check_plugin_version("antispam", SpecifierSet(">=1.0.0"), "0.9.0")
        self.assertFalse(ok)
        self.assertIn("0.9.0", note)
        self.assertIn("1.0.0", note)

    def test_empty_specifier_always_ok(self) -> None:
        ok, note = check_plugin_version("antispam", SpecifierSet(), "0.0.1")
        self.assertTrue(ok)


class ParseSpecifierOnlyTests(unittest.TestCase):
    def test_empty_string_means_any_version(self) -> None:
        self.assertEqual(parse_specifier_only(""), SpecifierSet())

    def test_whitespace_only_means_any_version(self) -> None:
        self.assertEqual(parse_specifier_only("   "), SpecifierSet())

    def test_valid_specifier(self) -> None:
        spec = parse_specifier_only(">=2.0.0,<3.0.0")
        self.assertIn(Version("2.5.0"), spec)

    def test_invalid_specifier_raises(self) -> None:
        with self.assertRaises(DependencySpecError):
            parse_specifier_only("not a specifier at all !!!")


class ReportPipConflictsTests(unittest.TestCase):
    """
    report_pip_conflicts() ничего не возвращает — только логирует.
    Проверяем через мок логгера, что: (1) пакеты с < 2 требователями
    полностью игнорируются, (2) конфликтующие версии логируются как
    warning, (3) полностью совместимые — как debug, не warning.
    """

    def test_single_requirer_package_is_skipped_entirely(self) -> None:
        specs = {"pluginA": [parse_dependency("solo-pkg>=1.0")]}
        with patch("core.dependencies.installed_pip_version", return_value="1.0.0"), \
             patch("core.dependencies.logger") as mock_logger:
            report_pip_conflicts(specs)
        mock_logger.warning.assert_not_called()
        mock_logger.debug.assert_not_called()

    def test_two_requirers_incompatible_versions_logs_warning(self) -> None:
        specs = {
            "pluginA": [parse_dependency("shared>=3.15,<4.0")],
            "pluginB": [parse_dependency("shared<3.0")],
        }
        with patch("core.dependencies.installed_pip_version", return_value="3.15.0"), \
             patch("core.dependencies.logger") as mock_logger:
            report_pip_conflicts(specs)
        mock_logger.warning.assert_called_once()
        warning_text = mock_logger.warning.call_args[0][0]
        self.assertIn("shared", warning_text)
        self.assertIn("pluginB", warning_text)  # тот, чьё условие НЕ удовлетворено

    def test_two_requirers_compatible_versions_logs_debug_not_warning(self) -> None:
        specs = {
            "pluginA": [parse_dependency("shared>=1.0")],
            "pluginB": [parse_dependency("shared<5.0")],
        }
        with patch("core.dependencies.installed_pip_version", return_value="2.0.0"), \
             patch("core.dependencies.logger") as mock_logger:
            report_pip_conflicts(specs)
        mock_logger.warning.assert_not_called()
        mock_logger.debug.assert_called_once()

    def test_package_not_installed_with_multiple_requirers_is_unsatisfied_for_all(self) -> None:
        from importlib.metadata import PackageNotFoundError
        specs = {
            "pluginA": [parse_dependency("missing-pkg>=1.0")],
            "pluginB": [parse_dependency("missing-pkg>=2.0")],
        }
        with patch("core.dependencies.installed_pip_version", side_effect=PackageNotFoundError), \
             patch("core.dependencies.logger") as mock_logger:
            report_pip_conflicts(specs)
        mock_logger.warning.assert_called_once()
        text = mock_logger.warning.call_args[0][0]
        self.assertIn("pluginA", text)
        self.assertIn("pluginB", text)

    def test_results_sorted_by_package_name_for_deterministic_output(self) -> None:
        specs = {
            "pluginA": [parse_dependency("zzz-pkg>=1.0"), parse_dependency("aaa-pkg>=1.0")],
            "pluginB": [parse_dependency("zzz-pkg<1.0"), parse_dependency("aaa-pkg<1.0")],
        }
        with patch("core.dependencies.installed_pip_version", return_value="5.0.0"), \
             patch("core.dependencies.logger") as mock_logger:
            report_pip_conflicts(specs)
        # aaa-pkg должен логироваться раньше zzz-pkg (сортировка by package)
        calls = mock_logger.warning.call_args_list
        self.assertEqual(len(calls), 2)
        self.assertIn("aaa-pkg", calls[0][0][0])
        self.assertIn("zzz-pkg", calls[1][0][0])


if __name__ == "__main__":
    unittest.main()
