"""
tests/test_plugin_installer.py — core/plugin_installer.py: установка,
удаление, проверка обновлений плагинов (локально / GitHub).

Все сетевые операции идут через urllib.request.urlopen — мокается
напрямую (без реальной сети). Никакого subprocess/git: скачивание
делается через codeload.github.com zip, а не git clone, что и
позволяет тестировать это чистым мокингом urlopen.
"""
from __future__ import annotations

import ast  # noqa: F401  (использования нет, но полезно при отладке синтаксиса плагина)
import io
import json
import tempfile
import unittest
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from unittest.mock import patch

from tests._support import env  # noqa: F401

import core.plugin_installer as pi
from core.plugin_installer import (
    InstallResult,
    PluginInstallError,
    ValidationResult,
    check_for_update,
    download_github_zip,
    extract_zip_plugin_dir,
    fetch_latest_commit_sha,
    fetch_remote_manifest,
    fetch_repo_metadata,
    get_installation_info,
    install_from_github,
    install_from_local,
    parse_github_source,
    record_installation,
    remove_installation_record,
    uninstall,
    validate_plugin_folder,
)


class _FakeResponse:
    """Имитирует объект, который возвращает urllib.request.urlopen(): context manager + .read([size])."""

    def __init__(self, data: bytes, headers: dict | None = None) -> None:
        self._data = data
        self._pos = 0
        self.headers = headers or {}

    def read(self, size: int = -1) -> bytes:
        if size is None or size < 0:
            chunk = self._data[self._pos:]
            self._pos = len(self._data)
        else:
            chunk = self._data[self._pos:self._pos + size]
            self._pos += len(chunk)
        return chunk

    def __enter__(self) -> "_FakeResponse":
        return self

    def __exit__(self, *exc_info) -> bool:
        return False


def _http_error(code: int, headers: dict | None = None, reason: str = "error") -> urllib.error.HTTPError:
    return urllib.error.HTTPError("http://example.invalid", code, reason, headers or {}, None)


def _make_github_zip(top_level: str, files: dict[str, str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for rel_path, content in files.items():
            zf.writestr(f"{top_level}/{rel_path}", content)
    return buf.getvalue()


class ParseGithubSourceTests(unittest.TestCase):
    def test_owner_slash_repo(self) -> None:
        self.assertEqual(parse_github_source("owner/repo"), ("owner", "repo"))

    def test_full_https_url(self) -> None:
        self.assertEqual(parse_github_source("https://github.com/owner/repo"), ("owner", "repo"))

    def test_git_suffix_stripped(self) -> None:
        self.assertEqual(parse_github_source("https://github.com/owner/repo.git"), ("owner", "repo"))

    def test_trailing_slash_stripped(self) -> None:
        self.assertEqual(parse_github_source("https://github.com/owner/repo/"), ("owner", "repo"))

    def test_surrounding_whitespace_stripped(self) -> None:
        self.assertEqual(parse_github_source("  owner/repo  "), ("owner", "repo"))

    def test_dots_hyphens_underscores_allowed(self) -> None:
        self.assertEqual(parse_github_source("my-org.x/my_repo.js"), ("my-org.x", "my_repo.js"))

    def test_invalid_source_raises(self) -> None:
        with self.assertRaises(PluginInstallError):
            parse_github_source("not a valid source at all")

    def test_single_word_raises(self) -> None:
        with self.assertRaises(PluginInstallError):
            parse_github_source("justoneword")

    def test_empty_string_raises(self) -> None:
        with self.assertRaises(PluginInstallError):
            parse_github_source("")


class IsExhaustedRateLimitTests(unittest.TestCase):
    def test_403_with_zero_remaining_is_exhausted(self) -> None:
        exc = _http_error(403, headers={"X-RateLimit-Remaining": "0"})
        self.assertTrue(pi._is_exhausted_rate_limit(exc))

    def test_403_with_nonzero_remaining_is_not_exhausted(self) -> None:
        exc = _http_error(403, headers={"X-RateLimit-Remaining": "36"})
        self.assertFalse(pi._is_exhausted_rate_limit(exc))

    def test_403_without_header_at_all_is_not_exhausted(self) -> None:
        exc = _http_error(403, headers={})
        self.assertFalse(pi._is_exhausted_rate_limit(exc))

    def test_non_403_code_is_never_exhausted_regardless_of_headers(self) -> None:
        exc = _http_error(404, headers={"X-RateLimit-Remaining": "0"})
        self.assertFalse(pi._is_exhausted_rate_limit(exc))


class UrlopenWithRetryTests(unittest.TestCase):
    def test_success_on_first_attempt_no_sleep(self) -> None:
        resp = _FakeResponse(b"ok")
        with patch("core.plugin_installer.urllib.request.urlopen", return_value=resp), \
             patch("core.plugin_installer.time.sleep") as mock_sleep:
            result = pi._urlopen_with_retry(urllib.request.Request("http://example.invalid"), timeout=5)
        self.assertIs(result, resp)
        mock_sleep.assert_not_called()

    def test_retryable_error_then_success(self) -> None:
        resp = _FakeResponse(b"ok")
        with patch(
            "core.plugin_installer.urllib.request.urlopen",
            side_effect=[_http_error(503), resp],
        ), patch("core.plugin_installer.time.sleep") as mock_sleep:
            result = pi._urlopen_with_retry(urllib.request.Request("http://example.invalid"), timeout=5)
        self.assertIs(result, resp)
        mock_sleep.assert_called_once_with(1.5)

    def test_all_attempts_fail_raises_after_exactly_three_tries(self) -> None:
        errors = [_http_error(503), _http_error(502), _http_error(500)]
        with patch("core.plugin_installer.urllib.request.urlopen", side_effect=errors) as mock_urlopen, \
             patch("core.plugin_installer.time.sleep") as mock_sleep:
            with self.assertRaises(urllib.error.HTTPError) as ctx:
                pi._urlopen_with_retry(urllib.request.Request("http://example.invalid"), timeout=5)
        self.assertEqual(mock_urlopen.call_count, 3)
        self.assertEqual(mock_sleep.call_args_list, [((1.5,),), ((3.0,),)])
        self.assertEqual(ctx.exception.code, 500)  # именно ПОСЛЕДНЯЯ ошибка

    def test_non_retryable_code_raises_immediately_without_retry(self) -> None:
        with patch(
            "core.plugin_installer.urllib.request.urlopen", side_effect=_http_error(404)
        ) as mock_urlopen, patch("core.plugin_installer.time.sleep") as mock_sleep:
            with self.assertRaises(urllib.error.HTTPError):
                pi._urlopen_with_retry(urllib.request.Request("http://example.invalid"), timeout=5)
        self.assertEqual(mock_urlopen.call_count, 1)
        mock_sleep.assert_not_called()

    def test_exhausted_rate_limit_403_raises_immediately_despite_being_in_retryable_set(self) -> None:
        exc = _http_error(403, headers={"X-RateLimit-Remaining": "0"})
        with patch(
            "core.plugin_installer.urllib.request.urlopen", side_effect=exc
        ) as mock_urlopen, patch("core.plugin_installer.time.sleep") as mock_sleep:
            with self.assertRaises(urllib.error.HTTPError):
                pi._urlopen_with_retry(urllib.request.Request("http://example.invalid"), timeout=5)
        self.assertEqual(mock_urlopen.call_count, 1)
        mock_sleep.assert_not_called()

    def test_transient_403_not_exhausted_is_retried(self) -> None:
        resp = _FakeResponse(b"ok")
        exc = _http_error(403, headers={"X-RateLimit-Remaining": "36"})
        with patch(
            "core.plugin_installer.urllib.request.urlopen", side_effect=[exc, resp]
        ), patch("core.plugin_installer.time.sleep") as mock_sleep:
            result = pi._urlopen_with_retry(urllib.request.Request("http://example.invalid"), timeout=5)
        self.assertIs(result, resp)
        mock_sleep.assert_called_once()

    def test_url_error_is_retried_like_a_transient_failure(self) -> None:
        resp = _FakeResponse(b"ok")
        with patch(
            "core.plugin_installer.urllib.request.urlopen",
            side_effect=[urllib.error.URLError("no route to host"), resp],
        ), patch("core.plugin_installer.time.sleep") as mock_sleep:
            result = pi._urlopen_with_retry(urllib.request.Request("http://example.invalid"), timeout=5)
        self.assertIs(result, resp)
        mock_sleep.assert_called_once()


class GithubApiGetTests(unittest.TestCase):
    def test_success_returns_parsed_json(self) -> None:
        resp = _FakeResponse(json.dumps({"default_branch": "main"}).encode("utf-8"))
        with patch("core.plugin_installer.urllib.request.urlopen", return_value=resp):
            result = pi._github_api_get("/repos/owner/repo")
        self.assertEqual(result, {"default_branch": "main"})

    def test_exhausted_rate_limit_message(self) -> None:
        exc = _http_error(403, headers={"X-RateLimit-Remaining": "0"})
        with patch("core.plugin_installer.urllib.request.urlopen", side_effect=exc):
            with self.assertRaises(PluginInstallError) as ctx:
                pi._github_api_get("/repos/owner/repo")
        self.assertIn("исчерпан", str(ctx.exception))

    def test_transient_403_message_after_retries_exhausted(self) -> None:
        exc = _http_error(403, headers={"X-RateLimit-Remaining": "36"})
        with patch("core.plugin_installer.urllib.request.urlopen", side_effect=exc), \
             patch("core.plugin_installer.time.sleep"):
            with self.assertRaises(PluginInstallError) as ctx:
                pi._github_api_get("/repos/owner/repo")
        self.assertIn("временный сбой", str(ctx.exception))

    def test_404_message_includes_path(self) -> None:
        with patch("core.plugin_installer.urllib.request.urlopen", side_effect=_http_error(404)):
            with self.assertRaises(PluginInstallError) as ctx:
                pi._github_api_get("/repos/owner/missing")
        self.assertIn("не найдено", str(ctx.exception))
        self.assertIn("/repos/owner/missing", str(ctx.exception))

    def test_url_error_message(self) -> None:
        with patch(
            "core.plugin_installer.urllib.request.urlopen",
            side_effect=urllib.error.URLError("dns failure"),
        ), patch("core.plugin_installer.time.sleep"):
            with self.assertRaises(PluginInstallError) as ctx:
                pi._github_api_get("/repos/owner/repo")
        self.assertIn("нет соединения", str(ctx.exception))


class FetchHelpersTests(unittest.TestCase):
    def test_fetch_repo_metadata_uses_correct_path(self) -> None:
        with patch("core.plugin_installer._github_api_get", return_value={"x": 1}) as mock_get:
            fetch_repo_metadata("owner", "repo")
        mock_get.assert_called_once_with("/repos/owner/repo")

    def test_fetch_latest_commit_sha_success(self) -> None:
        with patch("core.plugin_installer._github_api_get", return_value={"sha": "abc123"}):
            self.assertEqual(fetch_latest_commit_sha("owner", "repo", "main"), "abc123")

    def test_fetch_latest_commit_sha_missing_sha_raises(self) -> None:
        with patch("core.plugin_installer._github_api_get", return_value={}):
            with self.assertRaises(PluginInstallError):
                fetch_latest_commit_sha("owner", "repo", "main")

    def test_compare_commits_uses_correct_path(self) -> None:
        with patch("core.plugin_installer._github_api_get", return_value={}) as mock_get:
            pi.compare_commits("owner", "repo", "abc", "def")
        mock_get.assert_called_once_with("/repos/owner/repo/compare/abc...def")


class FetchRemoteManifestTests(unittest.TestCase):
    def test_success_no_subdir(self) -> None:
        resp = _FakeResponse(json.dumps({"name": "x", "version": "1.0.0"}).encode("utf-8"))
        with patch("core.plugin_installer.urllib.request.urlopen", return_value=resp) as mock_urlopen:
            result = fetch_remote_manifest("owner", "repo", "main")
        self.assertEqual(result["name"], "x")
        requested_url = mock_urlopen.call_args[0][0].full_url
        self.assertEqual(requested_url, "https://raw.githubusercontent.com/owner/repo/main/manifest.json")

    def test_success_with_subdir_builds_correct_url(self) -> None:
        resp = _FakeResponse(b"{}")
        with patch("core.plugin_installer.urllib.request.urlopen", return_value=resp) as mock_urlopen:
            fetch_remote_manifest("owner", "repo", "main", subdir="/plugins/foo/")
        requested_url = mock_urlopen.call_args[0][0].full_url
        self.assertEqual(
            requested_url, "https://raw.githubusercontent.com/owner/repo/main/plugins/foo/manifest.json"
        )

    def test_404_mentions_subdir_when_given(self) -> None:
        with patch("core.plugin_installer.urllib.request.urlopen", side_effect=_http_error(404)):
            with self.assertRaises(PluginInstallError) as ctx:
                fetch_remote_manifest("owner", "repo", "main", subdir="foo")
        self.assertIn("subdir=foo", str(ctx.exception))

    def test_404_without_subdir_does_not_mention_it(self) -> None:
        with patch("core.plugin_installer.urllib.request.urlopen", side_effect=_http_error(404)):
            with self.assertRaises(PluginInstallError) as ctx:
                fetch_remote_manifest("owner", "repo", "main")
        self.assertNotIn("subdir", str(ctx.exception))

    def test_malformed_json_response_raises_plugin_install_error(self) -> None:
        resp = _FakeResponse(b"{not valid json")
        with patch("core.plugin_installer.urllib.request.urlopen", return_value=resp):
            with self.assertRaises(PluginInstallError):
                fetch_remote_manifest("owner", "repo", "main")


class DownloadGithubZipTests(unittest.TestCase):
    def test_success_writes_response_body_to_temp_file(self) -> None:
        payload = b"PK\x03\x04fake zip bytes"
        resp = _FakeResponse(payload)
        with patch("core.plugin_installer.urllib.request.urlopen", return_value=resp):
            tmp_path = download_github_zip("owner", "repo", "main")
        try:
            self.assertEqual(tmp_path.read_bytes(), payload)
        finally:
            tmp_path.unlink(missing_ok=True)

    def test_http_error_cleans_up_temp_file_and_raises(self) -> None:
        # 404 -- НЕ входит в _RETRYABLE_HTTP_CODES, значит без задержек
        with patch("core.plugin_installer.urllib.request.urlopen", side_effect=_http_error(404)):
            with self.assertRaises(PluginInstallError):
                download_github_zip("owner", "repo", "main")

    def test_http_error_calls_unlink_on_the_temp_file(self) -> None:
        with patch("core.plugin_installer.urllib.request.urlopen", side_effect=_http_error(404)), \
             patch.object(Path, "unlink") as mock_unlink:
            with self.assertRaises(PluginInstallError):
                download_github_zip("owner", "repo", "main")
        mock_unlink.assert_called_once_with(missing_ok=True)

    def test_url_error_also_cleans_up_and_raises(self) -> None:
        with patch(
            "core.plugin_installer.urllib.request.urlopen",
            side_effect=urllib.error.URLError("no route"),
        ), patch.object(Path, "unlink") as mock_unlink, \
             patch("core.plugin_installer.time.sleep"):  # URLError всегда "retryable" -- иначе 4.5с реальной задержки
            with self.assertRaises(PluginInstallError):
                download_github_zip("owner", "repo", "main")
        mock_unlink.assert_called_once_with(missing_ok=True)


class ExtractZipPluginDirTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.tmp_path = Path(self._tmp.name)

    def make_zip(self, entries: dict[str, str]) -> Path:
        zip_path = self.tmp_path / "src.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            for name, content in entries.items():
                zf.writestr(name, content)
        return zip_path

    def test_standard_github_structure(self) -> None:
        zip_path = self.make_zip({
            "myrepo-main/manifest.json": "{}",
            "myrepo-main/plugin.py": "# x",
        })
        dest = self.tmp_path / "dest"
        result = extract_zip_plugin_dir(zip_path, dest)
        self.assertEqual(result, dest / "myrepo-main")
        self.assertTrue((result / "manifest.json").exists())

    def test_with_subdir(self) -> None:
        zip_path = self.make_zip({
            "myrepo-main/plugins/foo/manifest.json": "{}",
            "myrepo-main/plugins/foo/plugin.py": "# x",
            "myrepo-main/README.md": "readme",
        })
        dest = self.tmp_path / "dest"
        result = extract_zip_plugin_dir(zip_path, dest, subdir="plugins/foo")
        self.assertEqual(result, dest / "myrepo-main" / "plugins" / "foo")
        self.assertTrue((result / "manifest.json").exists())

    def test_empty_archive_raises(self) -> None:
        zip_path = self.tmp_path / "empty.zip"
        with zipfile.ZipFile(zip_path, "w"):
            pass
        with self.assertRaises(PluginInstallError):
            extract_zip_plugin_dir(zip_path, self.tmp_path / "dest")

    def test_missing_requested_subdir_raises(self) -> None:
        zip_path = self.make_zip({"myrepo-main/manifest.json": "{}"})
        with self.assertRaises(PluginInstallError):
            extract_zip_plugin_dir(zip_path, self.tmp_path / "dest", subdir="does/not/exist")

    def test_multiple_top_level_entries_rejected(self) -> None:
        zip_path = self.make_zip({
            "repo-main/manifest.json": "{}",
            "some_other_top_level/file.txt": "x",
        })
        with self.assertRaises(PluginInstallError) as ctx:
            extract_zip_plugin_dir(zip_path, self.tmp_path / "dest")
        self.assertIn("структуре", str(ctx.exception))

    def test_works_without_explicit_directory_entries_in_zip(self) -> None:
        # writestr с путями файлов не создаёт отдельную запись-каталог —
        # это НЕ мешает, т.к. функция смотрит только на общий префикс путей.
        zip_path = self.make_zip({"repo-main/a/b/manifest.json": "{}"})
        dest = self.tmp_path / "dest"
        result = extract_zip_plugin_dir(zip_path, dest, subdir="a/b")
        self.assertTrue((result / "manifest.json").exists())


class ValidatePluginFolderTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name)

    def write_manifest(self, content: str) -> None:
        (self.path / "manifest.json").write_text(content, encoding="utf-8")

    def write_plugin_py(self, content: str) -> None:
        (self.path / "plugin.py").write_text(content, encoding="utf-8")

    def test_fully_valid_plugin(self) -> None:
        self.write_manifest('{"name": "x", "version": "1.0.0"}')
        self.write_plugin_py("x = 1")
        result = validate_plugin_folder(self.path)
        self.assertTrue(result.ok)
        self.assertEqual(result.errors, [])
        self.assertEqual(result.manifest["name"], "x")

    def test_missing_manifest(self) -> None:
        self.write_plugin_py("x = 1")
        result = validate_plugin_folder(self.path)
        self.assertFalse(result.ok)
        self.assertIsNone(result.manifest)
        self.assertTrue(any("manifest.json отсутствует" in e for e in result.errors))

    def test_malformed_manifest_json(self) -> None:
        self.write_manifest("{not valid")
        self.write_plugin_py("x = 1")
        result = validate_plugin_folder(self.path)
        self.assertFalse(result.ok)
        self.assertTrue(any("невалидный JSON" in e for e in result.errors))

    def test_manifest_missing_name_field(self) -> None:
        self.write_manifest('{"version": "1.0.0"}')
        self.write_plugin_py("x = 1")
        result = validate_plugin_folder(self.path)
        self.assertFalse(result.ok)
        self.assertTrue(any("«name»" in e for e in result.errors))

    def test_manifest_missing_version_field(self) -> None:
        self.write_manifest('{"name": "x"}')
        self.write_plugin_py("x = 1")
        result = validate_plugin_folder(self.path)
        self.assertFalse(result.ok)
        self.assertTrue(any("«version»" in e for e in result.errors))

    def test_manifest_missing_both_fields_reports_both(self) -> None:
        self.write_manifest("{}")
        self.write_plugin_py("x = 1")
        result = validate_plugin_folder(self.path)
        self.assertEqual(len(result.errors), 2)

    def test_manifest_valid_json_but_not_an_object_does_not_crash(self) -> None:
        self.write_manifest("[1, 2, 3]")
        self.write_plugin_py("x = 1")
        result = validate_plugin_folder(self.path)  # не должно бросить
        self.assertFalse(result.ok)

    def test_missing_plugin_py(self) -> None:
        self.write_manifest('{"name": "x", "version": "1.0.0"}')
        result = validate_plugin_folder(self.path)
        self.assertFalse(result.ok)
        self.assertTrue(any("plugin.py отсутствует" in e for e in result.errors))

    def test_plugin_py_syntax_error(self) -> None:
        self.write_manifest('{"name": "x", "version": "1.0.0"}')
        self.write_plugin_py("def broken(:\n    pass")
        result = validate_plugin_folder(self.path)
        self.assertFalse(result.ok)
        self.assertTrue(any("синтаксическую ошибку" in e for e in result.errors))

    def test_both_manifest_and_plugin_broken_reports_both(self) -> None:
        self.write_manifest("{not json")
        self.write_plugin_py("def broken(:\n    pass")
        result = validate_plugin_folder(self.path)
        self.assertEqual(len(result.errors), 2)

    def test_plugin_py_is_never_executed_only_parsed(self) -> None:
        self.write_manifest('{"name": "x", "version": "1.0.0"}')
        # Если бы это исполнялось, тест упал бы из-за побочного эффекта.
        self.write_plugin_py("import sys; sys.exit(1)")
        result = validate_plugin_folder(self.path)
        self.assertTrue(result.ok)


class NormalizePermissionsTests(unittest.TestCase):
    def test_makes_restricted_file_readable_and_writable_by_owner(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            f = path / "restricted.txt"
            f.write_text("x", encoding="utf-8")
            f.chmod(0o000)
            pi._normalize_permissions(path)
            mode = f.stat().st_mode
            self.assertTrue(mode & 0o400)  # S_IRUSR
            self.assertTrue(mode & 0o200)  # S_IWUSR

    def test_chmod_failure_on_one_file_does_not_crash_the_whole_pass(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            (path / "a.txt").write_text("a", encoding="utf-8")
            (path / "b.txt").write_text("b", encoding="utf-8")

            real_chmod = Path.chmod

            def flaky_chmod(self_path, mode):
                if self_path.name == "a.txt":
                    raise OSError("simulated failure")
                return real_chmod(self_path, mode)

            with patch.object(Path, "chmod", flaky_chmod):
                pi._normalize_permissions(path)  # не должно бросить


class FinalizeInstallTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.plugins_dir = self.root / "plugins"
        self.plugins_dir.mkdir()

    def make_source(self, name: str = "x", version: str = "1.0.0") -> Path:
        d = self.root / "source"
        d.mkdir()
        (d / "manifest.json").write_text(json.dumps({"name": name, "version": version}), encoding="utf-8")
        (d / "plugin.py").write_text("# x", encoding="utf-8")
        return d

    def test_invalid_source_returns_failure_without_copying(self) -> None:
        d = self.root / "bad_source"
        d.mkdir()
        result = pi._finalize_install(d, self.plugins_dir, name_override=None, overwrite=False)
        self.assertFalse(result.ok)
        self.assertEqual(list(self.plugins_dir.iterdir()), [])

    def test_successful_install_to_fresh_target(self) -> None:
        source = self.make_source(name="antispam", version="1.2.3")
        result = pi._finalize_install(source, self.plugins_dir, name_override=None, overwrite=False)
        self.assertTrue(result.ok)
        self.assertEqual(result.name, "antispam")
        self.assertEqual(result.installed_path, self.plugins_dir / "antispam")
        self.assertTrue((self.plugins_dir / "antispam" / "manifest.json").exists())

    def test_name_override_takes_priority_over_manifest_name(self) -> None:
        source = self.make_source(name="original_name")
        result = pi._finalize_install(source, self.plugins_dir, name_override="custom_name", overwrite=False)
        self.assertEqual(result.name, "custom_name")
        self.assertTrue((self.plugins_dir / "custom_name").exists())

    def test_existing_target_without_overwrite_fails(self) -> None:
        (self.plugins_dir / "antispam").mkdir()
        source = self.make_source(name="antispam")
        result = pi._finalize_install(source, self.plugins_dir, name_override=None, overwrite=False)
        self.assertFalse(result.ok)
        self.assertIn("antispam", result.message)

    def test_existing_target_with_overwrite_replaces_content(self) -> None:
        old_target = self.plugins_dir / "antispam"
        old_target.mkdir()
        (old_target / "old_only.txt").write_text("stale", encoding="utf-8")
        source = self.make_source(name="antispam", version="2.0.0")

        result = pi._finalize_install(source, self.plugins_dir, name_override=None, overwrite=True)

        self.assertTrue(result.ok)
        self.assertFalse((old_target / "old_only.txt").exists())
        self.assertTrue((old_target / "manifest.json").exists())


class InstallFromLocalTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.plugins_dir = self.root / "plugins"
        self.plugins_dir.mkdir()
        self._registry_patch = patch.object(pi, "INSTALLED_REGISTRY_PATH", self.root / "run" / "installed.json")
        self._registry_patch.start()
        self.addCleanup(self._registry_patch.stop)

    def test_nonexistent_source_fails(self) -> None:
        result = install_from_local(self.root / "does-not-exist", self.plugins_dir)
        self.assertFalse(result.ok)
        self.assertIn("не найден", result.message)

    def test_source_directory_installs_and_records(self) -> None:
        src = self.root / "src"
        src.mkdir()
        (src / "manifest.json").write_text(json.dumps({"name": "antispam", "version": "1.0.0"}), encoding="utf-8")
        (src / "plugin.py").write_text("# x", encoding="utf-8")

        result = install_from_local(src, self.plugins_dir)

        self.assertTrue(result.ok)
        self.assertEqual(get_installation_info("antispam")["source_type"], "local")

    def test_zip_with_manifest_at_root(self) -> None:
        zip_path = self.root / "plugin.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("manifest.json", json.dumps({"name": "antispam", "version": "1.0.0"}))
            zf.writestr("plugin.py", "# x")

        result = install_from_local(zip_path, self.plugins_dir)
        self.assertTrue(result.ok)
        self.assertTrue((self.plugins_dir / "antispam" / "manifest.json").exists())

    def test_zip_with_manifest_inside_single_subdir(self) -> None:
        zip_path = self.root / "plugin.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("antispam-main/manifest.json", json.dumps({"name": "antispam", "version": "1.0.0"}))
            zf.writestr("antispam-main/plugin.py", "# x")

        result = install_from_local(zip_path, self.plugins_dir)
        self.assertTrue(result.ok)
        self.assertTrue((self.plugins_dir / "antispam" / "manifest.json").exists())

    def test_zip_with_ambiguous_structure_fails_validation_cleanly(self) -> None:
        zip_path = self.root / "plugin.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("dir_a/file.txt", "x")
            zf.writestr("dir_b/file.txt", "y")  # два подкаталога -> нет однозначного кандидата

        result = install_from_local(zip_path, self.plugins_dir)  # не должно бросить
        self.assertFalse(result.ok)

    def test_neither_directory_nor_zip_fails(self) -> None:
        f = self.root / "notes.txt"
        f.write_text("just text", encoding="utf-8")
        result = install_from_local(f, self.plugins_dir)
        self.assertFalse(result.ok)
        self.assertIn("не директория и не .zip", result.message)

    def test_failed_install_does_not_record_installation(self) -> None:
        src = self.root / "bad_src"
        src.mkdir()  # без manifest.json -> провалит валидацию
        result = install_from_local(src, self.plugins_dir)
        self.assertFalse(result.ok)
        self.assertIsNone(get_installation_info(result.name or "bad_src"))


class InstallFromGithubTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.plugins_dir = self.root / "plugins"
        self.plugins_dir.mkdir()
        self._registry_patch = patch.object(pi, "INSTALLED_REGISTRY_PATH", self.root / "run" / "installed.json")
        self._registry_patch.start()
        self.addCleanup(self._registry_patch.stop)

    def test_explicit_ref_skips_repo_metadata_fetch(self) -> None:
        zip_bytes = _make_github_zip("antispam-mybranch", {
            "manifest.json": json.dumps({"name": "antispam", "version": "1.0.0"}),
            "plugin.py": "# x",
        })
        with patch("core.plugin_installer.fetch_repo_metadata") as mock_meta, \
             patch("core.plugin_installer.fetch_latest_commit_sha", return_value="deadbeef"), \
             patch("core.plugin_installer.urllib.request.urlopen", return_value=_FakeResponse(zip_bytes)):
            result = install_from_github("owner/antispam", self.plugins_dir, ref="mybranch")

        mock_meta.assert_not_called()
        self.assertTrue(result.ok)

    def test_no_ref_fetches_default_branch_first(self) -> None:
        zip_bytes = _make_github_zip("antispam-main", {
            "manifest.json": json.dumps({"name": "antispam", "version": "1.0.0"}),
            "plugin.py": "# x",
        })
        with patch("core.plugin_installer.fetch_repo_metadata", return_value={"default_branch": "main"}) as mock_meta, \
             patch("core.plugin_installer.fetch_latest_commit_sha", return_value="deadbeef") as mock_sha, \
             patch("core.plugin_installer.urllib.request.urlopen", return_value=_FakeResponse(zip_bytes)):
            result = install_from_github("owner/antispam", self.plugins_dir)

        mock_meta.assert_called_once_with("owner", "antispam")
        mock_sha.assert_called_once_with("owner", "antispam", "main")
        self.assertTrue(result.ok)

    def test_successful_install_records_github_metadata(self) -> None:
        zip_bytes = _make_github_zip("antispam-main", {
            "manifest.json": json.dumps({"name": "antispam", "version": "1.0.0"}),
            "plugin.py": "# x",
        })
        with patch("core.plugin_installer.fetch_repo_metadata", return_value={"default_branch": "main"}), \
             patch("core.plugin_installer.fetch_latest_commit_sha", return_value="deadbeef1234"), \
             patch("core.plugin_installer.urllib.request.urlopen", return_value=_FakeResponse(zip_bytes)):
            result = install_from_github("owner/antispam", self.plugins_dir)

        self.assertTrue(result.ok)
        self.assertEqual(result.commit_sha, "deadbeef1234")
        self.assertIn("deadbee", result.message)  # короткий sha (7 симв.) в сообщении
        info = get_installation_info("antispam")
        self.assertEqual(info["source_type"], "github")
        self.assertEqual(info["repository_url"], "https://github.com/owner/antispam")
        self.assertEqual(info["commit_sha"], "deadbeef1234")

    def test_subdir_is_passed_through_to_extraction(self) -> None:
        zip_bytes = _make_github_zip("monorepo-main", {
            "plugins/antispam/manifest.json": json.dumps({"name": "antispam", "version": "1.0.0"}),
            "plugins/antispam/plugin.py": "# x",
            "README.md": "readme",
        })
        with patch("core.plugin_installer.fetch_repo_metadata", return_value={"default_branch": "main"}), \
             patch("core.plugin_installer.fetch_latest_commit_sha", return_value="sha"), \
             patch("core.plugin_installer.urllib.request.urlopen", return_value=_FakeResponse(zip_bytes)):
            result = install_from_github("owner/monorepo", self.plugins_dir, subdir="plugins/antispam")

        self.assertTrue(result.ok)
        self.assertTrue((self.plugins_dir / "antispam" / "manifest.json").exists())

    def test_temp_zip_file_is_cleaned_up_even_when_extraction_fails(self) -> None:
        zip_bytes = _make_github_zip("antispam-main", {"manifest.json": "{}"})
        with patch("core.plugin_installer.fetch_repo_metadata", return_value={"default_branch": "main"}), \
             patch("core.plugin_installer.fetch_latest_commit_sha", return_value="sha"), \
             patch("core.plugin_installer.urllib.request.urlopen", return_value=_FakeResponse(zip_bytes)), \
             patch("core.plugin_installer.extract_zip_plugin_dir", side_effect=RuntimeError("boom")), \
             patch.object(Path, "unlink") as mock_unlink:
            with self.assertRaises(RuntimeError):
                install_from_github("owner/antispam", self.plugins_dir)
        mock_unlink.assert_called_once_with(missing_ok=True)


class UninstallTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.plugins_dir = self.root / "plugins"
        self.plugins_dir.mkdir()
        self._registry_patch = patch.object(pi, "INSTALLED_REGISTRY_PATH", self.root / "run" / "installed.json")
        self._registry_patch.start()
        self.addCleanup(self._registry_patch.stop)

    def test_nonexistent_plugin_fails(self) -> None:
        result = uninstall("ghost", self.plugins_dir)
        self.assertFalse(result.ok)
        self.assertIn("не найден", result.message)

    def test_existing_plugin_is_removed_and_deregistered(self) -> None:
        (self.plugins_dir / "antispam").mkdir()
        record_installation("antispam", source_type="local")

        result = uninstall("antispam", self.plugins_dir)

        self.assertTrue(result.ok)
        self.assertFalse((self.plugins_dir / "antispam").exists())
        self.assertIsNone(get_installation_info("antispam"))

    def test_uninstall_message_warns_that_db_tables_are_untouched(self) -> None:
        (self.plugins_dir / "antispam").mkdir()
        result = uninstall("antispam", self.plugins_dir)
        self.assertIn("НЕ тронуты", result.message)


class CheckForUpdateTests(unittest.TestCase):
    def test_has_update_when_versions_differ(self) -> None:
        with patch("core.plugin_installer.parse_github_source", return_value=("owner", "repo")), \
             patch("core.plugin_installer.fetch_repo_metadata", return_value={"default_branch": "main"}), \
             patch("core.plugin_installer.fetch_remote_manifest", return_value={"version": "2.0.0"}):
            result = check_for_update("antispam", "1.0.0", "owner/repo")
        self.assertTrue(result.has_update)
        self.assertEqual(result.remote_version, "2.0.0")

    def test_no_update_when_versions_match(self) -> None:
        with patch("core.plugin_installer.parse_github_source", return_value=("owner", "repo")), \
             patch("core.plugin_installer.fetch_repo_metadata", return_value={"default_branch": "main"}), \
             patch("core.plugin_installer.fetch_remote_manifest", return_value={"version": "1.0.0"}):
            result = check_for_update("antispam", "1.0.0", "owner/repo")
        self.assertFalse(result.has_update)

    def test_remote_manifest_without_version_field_reports_no_update(self) -> None:
        # даже хотя "" != "1.0.0" по строкам -- bool("") is False блокирует
        # ложное срабатывание "обновление есть" из-за отсутствующего поля.
        with patch("core.plugin_installer.parse_github_source", return_value=("owner", "repo")), \
             patch("core.plugin_installer.fetch_repo_metadata", return_value={"default_branch": "main"}), \
             patch("core.plugin_installer.fetch_remote_manifest", return_value={}):
            result = check_for_update("antispam", "1.0.0", "owner/repo")
        self.assertFalse(result.has_update)
        self.assertEqual(result.remote_version, "")

    def test_plugin_install_error_is_caught_and_returned_as_error_field(self) -> None:
        with patch("core.plugin_installer.parse_github_source", side_effect=PluginInstallError("bad source")):
            result = check_for_update("antispam", "1.0.0", "not-a-real-source")
        self.assertEqual(result.error, "bad source")
        self.assertFalse(result.has_update)


class InstalledRegistryTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self._registry_patch = patch.object(
            pi, "INSTALLED_REGISTRY_PATH", Path(self._tmp.name) / "run" / "installed.json"
        )
        self._registry_patch.start()
        self.addCleanup(self._registry_patch.stop)

    def test_get_info_for_unknown_plugin_is_none(self) -> None:
        self.assertIsNone(get_installation_info("ghost"))

    def test_record_then_get_round_trip(self) -> None:
        record_installation("antispam", source_type="github", repository_url="https://github.com/o/r", ref="main", commit_sha="abc")
        info = get_installation_info("antispam")
        self.assertEqual(info["source_type"], "github")
        self.assertEqual(info["repository_url"], "https://github.com/o/r")
        self.assertEqual(info["ref"], "main")
        self.assertEqual(info["commit_sha"], "abc")
        self.assertIn("installed_at", info)

    def test_re_recording_overwrites_previous_entry(self) -> None:
        record_installation("antispam", source_type="local")
        record_installation("antispam", source_type="github", repository_url="https://github.com/o/r")
        info = get_installation_info("antispam")
        self.assertEqual(info["source_type"], "github")

    def test_remove_nonexistent_record_is_a_safe_no_op(self) -> None:
        remove_installation_record("ghost")  # не должно бросить

    def test_remove_existing_record(self) -> None:
        record_installation("antispam", source_type="local")
        remove_installation_record("antispam")
        self.assertIsNone(get_installation_info("antispam"))


if __name__ == "__main__":
    unittest.main()
