"""
tests/test_services.py — core/services.py: ServiceRegistry.
"""
from __future__ import annotations

import unittest
from unittest.mock import patch

from tests._support import env  # noqa: F401

from core.services import ServiceNotFoundError, ServiceRegistry


class ProvideGetTests(unittest.TestCase):
    def test_provide_then_get_round_trip(self) -> None:
        reg = ServiceRegistry()
        reg.provide("antispam.check", lambda x: True, plugin="antispam")
        fn = reg.get("antispam.check")
        self.assertTrue(fn("anything"))

    def test_get_unknown_returns_none(self) -> None:
        reg = ServiceRegistry()
        self.assertIsNone(reg.get("nope"))

    def test_value_of_none_is_indistinguishable_from_missing_via_get(self) -> None:
        # Задокументированная неоднозначность API: get() не может отличить
        # "сервис зарегистрирован со значением None" от "сервиса вообще
        # нет" — для этого есть has().
        reg = ServiceRegistry()
        reg.provide("maybe.none", None, plugin="p")
        self.assertIsNone(reg.get("maybe.none"))
        self.assertTrue(reg.has("maybe.none"))

    def test_same_plugin_re_providing_does_not_warn(self) -> None:
        reg = ServiceRegistry()
        with patch("core.services.logger") as mock_logger:
            reg.provide("svc", "v1", plugin="p1")
            reg.provide("svc", "v2", plugin="p1")
        mock_logger.warning.assert_not_called()
        self.assertEqual(reg.get("svc"), "v2")

    def test_different_plugin_overriding_logs_warning(self) -> None:
        reg = ServiceRegistry()
        with patch("core.services.logger") as mock_logger:
            reg.provide("svc", "v1", plugin="p1")
            reg.provide("svc", "v2", plugin="p2")
        mock_logger.warning.assert_called_once()
        warning_text = mock_logger.warning.call_args[0][0]
        self.assertIn("p1", warning_text)
        self.assertIn("p2", warning_text)
        self.assertIn("svc", warning_text)
        self.assertEqual(reg.get("svc"), "v2")  # последний побеждает

    def test_provide_accepts_arbitrary_object_types(self) -> None:
        reg = ServiceRegistry()

        class Thing:
            pass

        obj = Thing()
        reg.provide("thing", obj, plugin="p")
        self.assertIs(reg.get("thing"), obj)


class RequireTests(unittest.TestCase):
    def test_require_found_returns_value(self) -> None:
        reg = ServiceRegistry()
        reg.provide("svc", 42, plugin="p")
        self.assertEqual(reg.require("svc"), 42)

    def test_require_missing_raises_service_not_found_error(self) -> None:
        reg = ServiceRegistry()
        with self.assertRaises(ServiceNotFoundError):
            reg.require("missing")

    def test_service_not_found_error_is_a_lookup_error(self) -> None:
        self.assertTrue(issubclass(ServiceNotFoundError, LookupError))

    def test_error_message_lists_available_services_sorted(self) -> None:
        reg = ServiceRegistry()
        reg.provide("zebra.svc", 1, plugin="p")
        reg.provide("alpha.svc", 2, plugin="p")
        with self.assertRaises(ServiceNotFoundError) as ctx:
            reg.require("missing.svc")
        message = str(ctx.exception)
        self.assertIn("missing.svc", message)
        self.assertLess(message.index("alpha.svc"), message.index("zebra.svc"))

    def test_error_message_when_registry_is_completely_empty(self) -> None:
        reg = ServiceRegistry()
        with self.assertRaises(ServiceNotFoundError) as ctx:
            reg.require("anything")
        self.assertIn("нет ни одного", str(ctx.exception))

    def test_require_returns_none_value_without_raising_if_explicitly_registered(self) -> None:
        # В отличие от get()'s неоднозначности, require() всё равно должен
        # ВЕРНУТЬ None (не бросить), если сервис зарегистрирован именно
        # со значением None — сервис "найден", просто его значение None.
        reg = ServiceRegistry()
        reg.provide("svc", None, plugin="p")
        self.assertIsNone(reg.require("svc"))


class HasTests(unittest.TestCase):
    def test_has_true_after_provide(self) -> None:
        reg = ServiceRegistry()
        reg.provide("svc", 1, plugin="p")
        self.assertTrue(reg.has("svc"))

    def test_has_false_for_unknown(self) -> None:
        reg = ServiceRegistry()
        self.assertFalse(reg.has("nope"))


class RemoveAllForTests(unittest.TestCase):
    def test_removes_only_matching_plugin_services(self) -> None:
        reg = ServiceRegistry()
        reg.provide("a", 1, plugin="p1")
        reg.provide("b", 2, plugin="p1")
        reg.provide("c", 3, plugin="p2")
        removed = reg.remove_all_for("p1")
        self.assertEqual(removed, 2)
        self.assertFalse(reg.has("a"))
        self.assertFalse(reg.has("b"))
        self.assertTrue(reg.has("c"))

    def test_returns_zero_for_plugin_with_no_services(self) -> None:
        reg = ServiceRegistry()
        reg.provide("a", 1, plugin="p1")
        self.assertEqual(reg.remove_all_for("ghost"), 0)
        self.assertTrue(reg.has("a"))  # ничего не тронуто

    def test_remove_all_for_on_empty_registry_returns_zero(self) -> None:
        reg = ServiceRegistry()
        self.assertEqual(reg.remove_all_for("anyone"), 0)


class ListServicesTests(unittest.TestCase):
    def test_lists_name_to_owning_plugin(self) -> None:
        reg = ServiceRegistry()
        reg.provide("svc.a", 1, plugin="p1")
        reg.provide("svc.b", 2, plugin="p2")
        self.assertEqual(reg.list_services(), {"svc.a": "p1", "svc.b": "p2"})

    def test_reflects_most_recent_owner_after_override(self) -> None:
        reg = ServiceRegistry()
        reg.provide("svc", 1, plugin="p1")
        reg.provide("svc", 2, plugin="p2")
        self.assertEqual(reg.list_services(), {"svc": "p2"})

    def test_empty_registry_lists_nothing(self) -> None:
        reg = ServiceRegistry()
        self.assertEqual(reg.list_services(), {})


if __name__ == "__main__":
    unittest.main()
