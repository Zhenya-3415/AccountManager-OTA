"""
tests/test_sqlite_backend.py — core/db/sqlite_backend.py: SQLiteDatabase.

Использует настоящий aiosqlite, если он установлен, иначе облегчённый
фейк (tests/_support/fakes/aiosqlite) — в обоих случаях выполняется
НАСТОЯЩИЙ SQL против настоящего файла SQLite во временной директории,
а не мок с заглушенными методами. Это единственный способ реально
проверить утверждения из докстринга модуля (WAL, один writer + пул
read-only reader'ов, сериализация записи через asyncio.Lock).
"""
from __future__ import annotations

import asyncio
import tempfile
import unittest
from pathlib import Path

from tests._support import env

env.ensure_aiosqlite()

from core.db.sqlite_backend import SQLiteDatabase  # noqa: E402


class SqliteDatabaseTestCase(unittest.IsolatedAsyncioTestCase):
    """Общий asyncSetUp/asyncTearDown: свежая БД в tmp-каталоге на тест."""

    reader_pool_size = 2

    async def asyncSetUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.db_path = Path(self._tmp.name) / "test.db"
        self.db = SQLiteDatabase(self.db_path, reader_pool_size=self.reader_pool_size)
        await self.db.connect()
        self.addAsyncCleanup(self.db.close)

    async def make_users_table(self) -> None:
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                language_code TEXT,
                last_seen_at TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)

    def write_migration(self, migration_dir: Path, filename: str, sql: str) -> None:
        migration_dir.mkdir(parents=True, exist_ok=True)
        (migration_dir / filename).write_text(sql, encoding="utf-8")


class LifecycleTests(SqliteDatabaseTestCase):
    async def test_connect_creates_db_file_and_parent_dirs(self) -> None:
        nested_path = Path(self._tmp.name) / "nested" / "dir" / "db.sqlite"
        db = SQLiteDatabase(nested_path, reader_pool_size=1)
        await db.connect()
        try:
            self.assertTrue(nested_path.exists())
        finally:
            await db.close()

    async def test_conn_property_raises_before_connect(self) -> None:
        db = SQLiteDatabase(Path(self._tmp.name) / "unconnected.db")
        with self.assertRaises(RuntimeError):
            _ = db.conn

    async def test_default_db_path_used_when_none_given(self) -> None:
        db = SQLiteDatabase()
        from core.db.sqlite_backend import DB_PATH
        self.assertEqual(db.db_path, DB_PATH)

    async def test_close_is_safe_to_call_and_db_becomes_unusable_after(self) -> None:
        await self.db.close()
        with self.assertRaises(RuntimeError):
            _ = self.db.conn


class BasicCrudTests(SqliteDatabaseTestCase):
    async def test_execute_and_fetchone_round_trip(self) -> None:
        await self.db.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, name TEXT)")
        await self.db.execute("INSERT INTO t (name) VALUES (?)", ("hello",))
        row = await self.db.fetchone("SELECT * FROM t WHERE name = ?", ("hello",))
        self.assertEqual(row["name"], "hello")

    async def test_fetchone_no_match_returns_none(self) -> None:
        await self.db.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, name TEXT)")
        row = await self.db.fetchone("SELECT * FROM t WHERE name = ?", ("nope",))
        self.assertIsNone(row)

    async def test_fetchall_returns_all_matching_rows(self) -> None:
        await self.db.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, name TEXT)")
        for name in ("a", "b", "c"):
            await self.db.execute("INSERT INTO t (name) VALUES (?)", (name,))
        rows = await self.db.fetchall("SELECT name FROM t ORDER BY name")
        self.assertEqual([r["name"] for r in rows], ["a", "b", "c"])

    async def test_execute_returning_gets_the_inserted_row_atomically(self) -> None:
        await self.db.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, name TEXT)")
        row = await self.db.execute_returning(
            "INSERT INTO t (name) VALUES (?) RETURNING id, name", ("hello",)
        )
        self.assertEqual(row["name"], "hello")
        self.assertIsNotNone(row["id"])


class ReadOnlyReaderPoolTests(SqliteDatabaseTestCase):
    async def test_reader_connection_cannot_write(self) -> None:
        await self.db.execute("CREATE TABLE t (id INTEGER PRIMARY KEY)")
        async with self.db._reader() as reader:
            with self.assertRaises(Exception) as ctx:
                await reader.execute("INSERT INTO t DEFAULT VALUES")
            self.assertIn("readonly", str(ctx.exception).lower())

    async def test_pool_of_size_one_blocks_second_concurrent_reader_until_first_released(self) -> None:
        db = SQLiteDatabase(Path(self._tmp.name) / "single_reader.db", reader_pool_size=1)
        await db.connect()
        self.addAsyncCleanup(db.close)

        first_acquired = asyncio.Event()
        release_first = asyncio.Event()
        second_acquired = asyncio.Event()

        async def hold_first_reader():
            async with db._reader():
                first_acquired.set()
                await release_first.wait()

        async def acquire_second_reader():
            await first_acquired.wait()
            async with db._reader():
                second_acquired.set()

        task1 = asyncio.create_task(hold_first_reader())
        task2 = asyncio.create_task(acquire_second_reader())

        await first_acquired.wait()
        # второй читатель НЕ должен получить соединение, пока первый его держит
        await asyncio.sleep(0.05)
        self.assertFalse(second_acquired.is_set())

        release_first.set()
        await asyncio.wait_for(second_acquired.wait(), timeout=2.0)
        await task1
        await task2

    async def test_active_readers_returns_pool_to_idle_state(self) -> None:
        async with self.db._reader():
            self.assertFalse(self.db._readers_idle.is_set())
        self.assertTrue(self.db._readers_idle.is_set())


class TransactionRollbackTests(SqliteDatabaseTestCase):
    async def test_failed_transaction_rolls_back_and_raises(self) -> None:
        await self.db.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, name TEXT NOT NULL)")
        with self.assertRaises(Exception):
            await self.db._run_in_transaction([
                ("INSERT INTO t (id, name) VALUES (1, 'ok')", ()),
                ("INSERT INTO t (id, name) VALUES (2, NULL)", ()),  # NOT NULL нарушен
            ])
        rows = await self.db.fetchall("SELECT * FROM t")
        self.assertEqual(rows, [])  # ПЕРВАЯ вставка тоже откатилась (это одна транзакция)

    async def test_db_remains_usable_after_a_rolled_back_transaction(self) -> None:
        await self.db.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, name TEXT NOT NULL)")
        with self.assertRaises(Exception):
            await self.db._run_in_transaction([("INSERT INTO t (id, name) VALUES (1, NULL)", ())])
        # соединение не осталось "залипшим" в незавершённой транзакции
        await self.db.execute("INSERT INTO t (id, name) VALUES (1, 'fine')", ())
        row = await self.db.fetchone("SELECT name FROM t WHERE id = 1")
        self.assertEqual(row["name"], "fine")


class ConcurrentWriteSerializationTests(SqliteDatabaseTestCase):
    async def test_many_concurrent_upserts_of_same_user_never_interleave_transactions(self) -> None:
        await self.make_users_table()
        # Если бы _write_lock не сериализовал BEGIN..COMMIT, конкурентные
        # апсерты одного user_id на одном соединении рано или поздно
        # выдали бы "cannot start a transaction within a transaction".
        await asyncio.gather(*[
            self.db.upsert_user(user_id=1, first_name=f"name-{i}") for i in range(30)
        ])
        row = await self.db.fetchone("SELECT * FROM users WHERE user_id = 1")
        self.assertIsNotNone(row)
        self.assertTrue(row["first_name"].startswith("name-"))

    async def test_many_concurrent_execute_returning_calls_each_get_their_own_row(self) -> None:
        await self.db.execute("CREATE TABLE t (id INTEGER PRIMARY KEY AUTOINCREMENT, tag TEXT)")

        async def insert(tag: str):
            return await self.db.execute_returning(
                "INSERT INTO t (tag) VALUES (?) RETURNING id, tag", (tag,)
            )

        results = await asyncio.gather(*[insert(f"tag-{i}") for i in range(20)])
        tags = {r["tag"] for r in results}
        self.assertEqual(tags, {f"tag-{i}" for i in range(20)})
        ids = [r["id"] for r in results]
        self.assertEqual(len(ids), len(set(ids)))  # все id уникальны, ничего не потерялось


class MigrationsTests(SqliteDatabaseTestCase):
    async def test_applies_pending_migrations_in_order(self) -> None:
        mig_dir = Path(self._tmp.name) / "migrations"
        self.write_migration(mig_dir, "0001_init.sql", "CREATE TABLE t (id INTEGER PRIMARY KEY);")
        self.write_migration(mig_dir, "0002_seed.sql", "INSERT INTO t (id) VALUES (1);")

        ok = await self.db.run_migrations("testplugin", mig_dir)
        self.assertTrue(ok)

        rows = await self.db.fetchall("SELECT * FROM t")
        self.assertEqual(len(rows), 1)

        versions = await self.db.fetchall(
            "SELECT version FROM schema_version WHERE namespace = ? ORDER BY version", ("testplugin",)
        )
        self.assertEqual([r["version"] for r in versions], [1, 2])

    async def test_running_migrations_twice_is_idempotent(self) -> None:
        mig_dir = Path(self._tmp.name) / "migrations"
        self.write_migration(mig_dir, "0001_init.sql", "CREATE TABLE t (id INTEGER PRIMARY KEY);")
        await self.db.run_migrations("testplugin", mig_dir)
        ok_second_time = await self.db.run_migrations("testplugin", mig_dir)
        self.assertTrue(ok_second_time)
        versions = await self.db.fetchall(
            "SELECT version FROM schema_version WHERE namespace = ?", ("testplugin",)
        )
        self.assertEqual(len(versions), 1)  # не применилась повторно

    async def test_missing_migration_dir_is_a_harmless_no_op(self) -> None:
        ok = await self.db.run_migrations("testplugin", Path(self._tmp.name) / "does-not-exist")
        self.assertTrue(ok)

    async def test_only_new_migrations_applied_on_subsequent_run(self) -> None:
        mig_dir = Path(self._tmp.name) / "migrations"
        self.write_migration(mig_dir, "0001_init.sql", "CREATE TABLE t (id INTEGER PRIMARY KEY);")
        await self.db.run_migrations("testplugin", mig_dir)

        self.write_migration(mig_dir, "0002_more.sql", "ALTER TABLE t ADD COLUMN name TEXT;")
        ok = await self.db.run_migrations("testplugin", mig_dir)
        self.assertTrue(ok)

        versions = await self.db.fetchall(
            "SELECT version FROM schema_version WHERE namespace = ? ORDER BY version", ("testplugin",)
        )
        self.assertEqual([r["version"] for r in versions], [1, 2])

    async def test_failing_migration_stops_and_keeps_earlier_ones_committed(self) -> None:
        mig_dir = Path(self._tmp.name) / "migrations"
        self.write_migration(mig_dir, "0001_init.sql", "CREATE TABLE t (id INTEGER PRIMARY KEY);")
        self.write_migration(mig_dir, "0002_broken.sql", "INSERT INTO nonexistent_table VALUES (1);")
        self.write_migration(mig_dir, "0003_never_reached.sql", "CREATE TABLE never_created (id INTEGER);")

        ok = await self.db.run_migrations("testplugin", mig_dir)
        self.assertFalse(ok)

        versions = await self.db.fetchall(
            "SELECT version FROM schema_version WHERE namespace = ? ORDER BY version", ("testplugin",)
        )
        self.assertEqual([r["version"] for r in versions], [1])  # только 0001 закоммичена

        tables = await self.db.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='never_created'"
        )
        self.assertEqual(tables, [])  # 0003 действительно не применилась

    async def test_duplicate_version_numbers_fail_cleanly(self) -> None:
        mig_dir = Path(self._tmp.name) / "migrations"
        self.write_migration(mig_dir, "0001_a.sql", "CREATE TABLE a (id INTEGER PRIMARY KEY);")
        self.write_migration(mig_dir, "0001_b.sql", "CREATE TABLE b (id INTEGER PRIMARY KEY);")
        ok = await self.db.run_migrations("testplugin", mig_dir)
        self.assertFalse(ok)

    async def test_comment_only_migration_still_records_its_version(self) -> None:
        mig_dir = Path(self._tmp.name) / "migrations"
        self.write_migration(mig_dir, "0001_noop.sql", "-- просто комментарий, без реального SQL\n")
        ok = await self.db.run_migrations("testplugin", mig_dir)
        self.assertTrue(ok)
        versions = await self.db.fetchall(
            "SELECT version FROM schema_version WHERE namespace = ?", ("testplugin",)
        )
        self.assertEqual([r["version"] for r in versions], [1])

    async def test_different_namespaces_track_versions_independently(self) -> None:
        mig_dir_a = Path(self._tmp.name) / "migrations_a"
        mig_dir_b = Path(self._tmp.name) / "migrations_b"
        self.write_migration(mig_dir_a, "0001_a.sql", "CREATE TABLE a (id INTEGER PRIMARY KEY);")
        self.write_migration(mig_dir_b, "0001_b.sql", "CREATE TABLE b (id INTEGER PRIMARY KEY);")
        self.write_migration(mig_dir_b, "0002_b.sql", "CREATE TABLE b2 (id INTEGER PRIMARY KEY);")

        await self.db.run_migrations("plugin_a", mig_dir_a)
        await self.db.run_migrations("plugin_b", mig_dir_b)

        rows_a = await self.db.fetchall("SELECT version FROM schema_version WHERE namespace = 'plugin_a'")
        rows_b = await self.db.fetchall("SELECT version FROM schema_version WHERE namespace = 'plugin_b'")
        self.assertEqual(len(rows_a), 1)
        self.assertEqual(len(rows_b), 2)


class VerifySchemaVersionTests(SqliteDatabaseTestCase):
    async def asyncSetUp(self) -> None:
        await super().asyncSetUp()
        mig_dir = Path(self._tmp.name) / "migrations"
        self.write_migration(mig_dir, "0001_a.sql", "CREATE TABLE a (id INTEGER PRIMARY KEY);")
        self.write_migration(mig_dir, "0002_b.sql", "CREATE TABLE b (id INTEGER PRIMARY KEY);")
        await self.db.run_migrations("testplugin", mig_dir)

    async def test_exact_match_returns_true(self) -> None:
        self.assertTrue(await self.db.verify_schema_version("testplugin", {1, 2}))

    async def test_missing_expected_version_returns_false(self) -> None:
        self.assertFalse(await self.db.verify_schema_version("testplugin", {1, 2, 3}))

    async def test_extra_applied_version_returns_false(self) -> None:
        self.assertFalse(await self.db.verify_schema_version("testplugin", {1}))

    async def test_unknown_namespace_with_no_applied_versions(self) -> None:
        self.assertFalse(await self.db.verify_schema_version("nobody", {1}))
        self.assertTrue(await self.db.verify_schema_version("nobody", set()))


class UpsertUserTests(SqliteDatabaseTestCase):
    async def asyncSetUp(self) -> None:
        await super().asyncSetUp()
        await self.make_users_table()

    async def test_first_upsert_inserts_a_new_row(self) -> None:
        await self.db.upsert_user(user_id=1, username="jsis", first_name="Jsis", last_name=None, language_code="ru")
        row = await self.db.fetchone("SELECT * FROM users WHERE user_id = 1")
        self.assertEqual(row["username"], "jsis")
        self.assertEqual(row["first_name"], "Jsis")
        self.assertIsNone(row["last_name"])

    async def test_second_upsert_updates_fields_but_keeps_created_at(self) -> None:
        await self.db.upsert_user(user_id=1, username="old", first_name="Old")
        first_row = await self.db.fetchone("SELECT * FROM users WHERE user_id = 1")

        await self.db.upsert_user(user_id=1, username="new", first_name="New")
        second_row = await self.db.fetchone("SELECT * FROM users WHERE user_id = 1")

        self.assertEqual(second_row["username"], "new")
        self.assertEqual(second_row["first_name"], "New")
        self.assertEqual(second_row["created_at"], first_row["created_at"])  # НЕ переписан

    async def test_missing_optional_fields_are_stored_as_null(self) -> None:
        await self.db.upsert_user(user_id=1)  # ни одного доп. поля
        row = await self.db.fetchone("SELECT * FROM users WHERE user_id = 1")
        self.assertIsNone(row["username"])
        self.assertIsNone(row["first_name"])
        self.assertIsNone(row["last_name"])
        self.assertIsNone(row["language_code"])

    async def test_unrelated_kwargs_are_silently_ignored(self) -> None:
        # upsert_user(**fields) не валидирует набор ключей -- лишние просто не используются.
        await self.db.upsert_user(user_id=1, username="jsis", this_key_does_not_exist="ignored")
        row = await self.db.fetchone("SELECT * FROM users WHERE user_id = 1")
        self.assertEqual(row["username"], "jsis")

    async def test_two_different_users_do_not_clash(self) -> None:
        await self.db.upsert_user(user_id=1, username="one")
        await self.db.upsert_user(user_id=2, username="two")
        rows = await self.db.fetchall("SELECT user_id, username FROM users ORDER BY user_id")
        self.assertEqual([(r["user_id"], r["username"]) for r in rows], [(1, "one"), (2, "two")])


if __name__ == "__main__":
    unittest.main()
