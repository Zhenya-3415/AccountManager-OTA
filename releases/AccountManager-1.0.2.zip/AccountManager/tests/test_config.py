"""
tests/test_config.py — core/config.py: configs/.env + configs/config.json -> Config.

load_config() читает CONFIG_PATH (configs/config.json) относительно
CWD и вызывает load_dotenv(dotenv_path=ENV_PATH) — оба теста
изолируются через os.chdir() во временную директорию ПЛЮС явный мок
load_dotenv() и os.environ, чтобы реальный .env/BOT_TOKEN разработчика
(если тесты когда-нибудь запустят прямо в корне проекта) не мог повлиять
на результат ни при каких обстоятельствах.
"""
from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tests._support import env  # noqa: F401

from core.config import Config, DatabaseConfig, PostgresConfig, WebhookConfig, _parse_database, _parse_webhook, load_config


class ConfigLoadTestCase(unittest.TestCase):
    """Общий setUp: chdir в пустой tmp-каталог + no-op load_dotenv() + чистый os.environ."""

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self._orig_cwd = os.getcwd()
        os.chdir(self._tmp.name)
        self.addCleanup(os.chdir, self._orig_cwd)

        self._dotenv_patch = patch("core.config.load_dotenv", return_value=False)
        self._dotenv_patch.start()
        self.addCleanup(self._dotenv_patch.stop)

    def write_config_json(self, data: dict) -> None:
        Path("configs").mkdir(exist_ok=True)
        Path("configs/config.json").write_text(json.dumps(data), encoding="utf-8")

    def env(self, **kwargs):
        """patch.dict context manager с чистым os.environ (только заданные ключи)."""
        return patch.dict(os.environ, kwargs, clear=True)


class DefaultDataclassTests(unittest.TestCase):
    def test_config_defaults(self) -> None:
        cfg = Config(bot_token="x")
        self.assertEqual(cfg.log_level, "DEBUG")
        self.assertEqual(cfg.disabled_plugins, [])
        self.assertEqual(cfg.mode, "polling")
        self.assertIsInstance(cfg.webhook, WebhookConfig)
        self.assertIsInstance(cfg.database, DatabaseConfig)

    def test_webhook_config_defaults(self) -> None:
        wc = WebhookConfig()
        self.assertEqual(wc.host, "0.0.0.0")
        self.assertEqual(wc.port, 8080)
        self.assertFalse(wc.drop_pending_updates)

    def test_database_config_defaults(self) -> None:
        dc = DatabaseConfig()
        self.assertEqual(dc.backend, "sqlite")
        self.assertEqual(dc.sqlite_core_reader_pool_size, 4)
        self.assertIsInstance(dc.postgres, PostgresConfig)

    def test_each_config_instance_gets_its_own_nested_dataclass(self) -> None:
        # т.к. field(default_factory=...) — а не общий мутабельный default
        c1, c2 = Config(bot_token="a"), Config(bot_token="b")
        c1.webhook.port = 9999
        self.assertEqual(c2.webhook.port, 8080)


class ParseWebhookTests(unittest.TestCase):
    def test_defaults_when_raw_is_empty(self) -> None:
        cfg = _parse_webhook({}, "TOKEN123")
        self.assertEqual(cfg.url, "")
        self.assertEqual(cfg.path, "/webhook/TOKEN123")
        self.assertEqual(cfg.host, "0.0.0.0")
        self.assertEqual(cfg.port, 8080)
        self.assertFalse(cfg.drop_pending_updates)

    def test_url_trailing_slash_stripped(self) -> None:
        cfg = _parse_webhook({"url": "https://example.com/"}, "TOKEN")
        self.assertEqual(cfg.url, "https://example.com")

    def test_url_multiple_trailing_slashes_all_stripped(self) -> None:
        cfg = _parse_webhook({"url": "https://example.com///"}, "TOKEN")
        self.assertEqual(cfg.url, "https://example.com")

    def test_explicit_path_overrides_token_default(self) -> None:
        cfg = _parse_webhook({"path": "/custom-path"}, "TOKEN")
        self.assertEqual(cfg.path, "/custom-path")

    def test_explicit_empty_path_falls_back_to_token_default_due_to_or(self) -> None:
        # raw.get("path") or f"/webhook/{token}" -> "" расценивается как
        # "не задано", а не как осознанный пустой путь. Задокументированное
        # поведение — фиксируем, чтобы не поменялось незаметно.
        cfg = _parse_webhook({"path": ""}, "TOKEN")
        self.assertEqual(cfg.path, "/webhook/TOKEN")

    def test_port_as_numeric_string_is_converted(self) -> None:
        cfg = _parse_webhook({"port": "9090"}, "TOKEN")
        self.assertEqual(cfg.port, 9090)
        self.assertIsInstance(cfg.port, int)

    def test_port_non_numeric_string_raises_value_error(self) -> None:
        with self.assertRaises(ValueError):
            _parse_webhook({"port": "not-a-port"}, "TOKEN")

    def test_drop_pending_updates_string_false_is_correctly_false(self) -> None:
        # Раньше bool("false") == True ловил тех, кто ждал JSON-семантику
        # строки "false" — теперь текстовые представления разбираются
        # осмысленно через _as_bool().
        cfg = _parse_webhook({"drop_pending_updates": "false"}, "TOKEN")
        self.assertFalse(cfg.drop_pending_updates)

    def test_drop_pending_updates_string_true_variants(self) -> None:
        for value in ("true", "True", "1", "yes", "on"):
            with self.subTest(value=value):
                cfg = _parse_webhook({"drop_pending_updates": value}, "TOKEN")
                self.assertTrue(cfg.drop_pending_updates)

    def test_drop_pending_updates_actual_json_boolean_false(self) -> None:
        cfg = _parse_webhook({"drop_pending_updates": False}, "TOKEN")
        self.assertFalse(cfg.drop_pending_updates)

    def test_secret_token_passthrough(self) -> None:
        cfg = _parse_webhook({"secret_token": "s3cr3t"}, "TOKEN")
        self.assertEqual(cfg.secret_token, "s3cr3t")


class ParseDatabaseTests(unittest.TestCase):
    def test_defaults_to_sqlite_when_empty(self) -> None:
        cfg = _parse_database({})
        self.assertEqual(cfg.backend, "sqlite")

    def test_postgres_without_dsn_raises(self) -> None:
        with self.assertRaises(RuntimeError):
            _parse_database({"backend": "postgres"})

    def test_postgres_with_dsn_succeeds(self) -> None:
        cfg = _parse_database({"backend": "postgres", "postgres": {"dsn": "postgresql://x"}})
        self.assertEqual(cfg.backend, "postgres")
        self.assertEqual(cfg.postgres.dsn, "postgresql://x")

    def test_backend_case_and_whitespace_normalized(self) -> None:
        cfg = _parse_database({"backend": "  SQLite  "})
        self.assertEqual(cfg.backend, "sqlite")

    def test_unsupported_backend_raises_with_helpful_message(self) -> None:
        with self.assertRaises(RuntimeError) as ctx:
            _parse_database({"backend": "mysql"})
        self.assertIn("mysql", str(ctx.exception))

    def test_explicit_null_postgres_block_does_not_crash(self) -> None:
        cfg = _parse_database({"backend": "sqlite", "postgres": None})
        self.assertEqual(cfg.postgres.dsn, "")

    def test_pool_sizes_as_strings_are_converted(self) -> None:
        cfg = _parse_database({
            "backend": "postgres",
            "postgres": {"dsn": "x", "pool_min_size": "2", "pool_max_size": "20"},
        })
        self.assertEqual(cfg.postgres.pool_min_size, 2)
        self.assertEqual(cfg.postgres.pool_max_size, 20)

    def test_sqlite_reader_pool_size_override(self) -> None:
        cfg = _parse_database({"backend": "sqlite", "sqlite_core_reader_pool_size": 10})
        self.assertEqual(cfg.sqlite_core_reader_pool_size, 10)

    def test_dsn_is_stripped(self) -> None:
        cfg = _parse_database({"backend": "postgres", "postgres": {"dsn": "  postgresql://x  "}})
        self.assertEqual(cfg.postgres.dsn, "postgresql://x")


class LoadConfigTokenTests(ConfigLoadTestCase):
    def test_missing_bot_token_raises(self) -> None:
        with self.env():
            with self.assertRaises(RuntimeError):
                load_config()

    def test_whitespace_only_bot_token_raises(self) -> None:
        with self.env(BOT_TOKEN="   "):
            with self.assertRaises(RuntimeError):
                load_config()

    def test_bot_token_is_stripped(self) -> None:
        with self.env(BOT_TOKEN="  12345:ABCDEF  "):
            cfg = load_config()
        self.assertEqual(cfg.bot_token, "12345:ABCDEF")


class LoadConfigDefaultsTests(ConfigLoadTestCase):
    def test_no_config_json_uses_all_defaults(self) -> None:
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.mode, "polling")
        self.assertEqual(cfg.disabled_plugins, [])
        self.assertEqual(cfg.database.backend, "sqlite")
        self.assertEqual(cfg.log_level, "DEBUG")

    def test_empty_config_json_object_uses_defaults(self) -> None:
        self.write_config_json({})
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.mode, "polling")

    def test_malformed_config_json_raises_json_decode_error(self) -> None:
        Path("configs").mkdir(exist_ok=True)
        Path("configs/config.json").write_text("{not valid json!!", encoding="utf-8")
        with self.env(BOT_TOKEN="TOKEN"):
            with self.assertRaises(json.JSONDecodeError):
                load_config()


class LoadConfigModeTests(ConfigLoadTestCase):
    def test_mode_case_insensitive(self) -> None:
        self.write_config_json({"mode": "WEBHOOK", "webhook": {"url": "https://x.example"}})
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.mode, "webhook")

    def test_webhook_mode_without_url_raises(self) -> None:
        self.write_config_json({"mode": "webhook"})
        with self.env(BOT_TOKEN="TOKEN"):
            with self.assertRaises(RuntimeError):
                load_config()

    def test_unsupported_mode_raises(self) -> None:
        self.write_config_json({"mode": "grpc"})
        with self.env(BOT_TOKEN="TOKEN"):
            with self.assertRaises(RuntimeError):
                load_config()

    def test_polling_mode_does_not_require_webhook_url(self) -> None:
        self.write_config_json({"mode": "polling"})
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()  # не должно бросить
        self.assertEqual(cfg.mode, "polling")

    def test_explicit_null_webhook_block_does_not_crash_in_polling_mode(self) -> None:
        self.write_config_json({"mode": "polling", "webhook": None})
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.webhook.path, "/webhook/TOKEN")

    def test_webhook_as_wrong_json_type_raises_clear_runtime_error(self) -> None:
        """
        Раньше _parse_webhook сразу делал raw.get(...) на том, что дали
        — "webhook": [...] (список, а не объект) падал AttributeError.
        Теперь load_config() сам проверяет тип и даёт понятную
        RuntimeError, объясняющую, что не так.
        """
        self.write_config_json({"mode": "polling", "webhook": ["not", "a", "dict"]})
        with self.env(BOT_TOKEN="TOKEN"):
            with self.assertRaises(RuntimeError) as ctx:
                load_config()
        self.assertIn("webhook", str(ctx.exception))

    def test_database_as_wrong_json_type_raises_clear_runtime_error(self) -> None:
        self.write_config_json({"mode": "polling", "database": "not-a-dict"})
        with self.env(BOT_TOKEN="TOKEN"):
            with self.assertRaises(RuntimeError) as ctx:
                load_config()
        self.assertIn("database", str(ctx.exception))


class LoadConfigDisabledPluginsTests(ConfigLoadTestCase):
    def test_normal_list_of_plugin_names(self) -> None:
        self.write_config_json({"disabled_plugins": ["antispam", "welcome"]})
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.disabled_plugins, ["antispam", "welcome"])

    def test_string_instead_of_list_is_wrapped_as_single_item_list(self) -> None:
        """
        Раньше list(raw.get("disabled_plugins", [])) на СТРОКЕ (а не
        списке) разбивал её на отдельные символы — "antispam" (забыли
        скобки) молча превращался в ['a','n','t',...], и плагин
        "antispam" НЕ отключался. Теперь строка оборачивается как ОДНО
        имя плагина.
        """
        self.write_config_json({"disabled_plugins": "antispam"})
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.disabled_plugins, ["antispam"])

    def test_empty_string_becomes_empty_list_not_a_list_with_empty_string(self) -> None:
        self.write_config_json({"disabled_plugins": ""})
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.disabled_plugins, [])

    def test_empty_list_when_key_absent(self) -> None:
        self.write_config_json({})
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.disabled_plugins, [])


class LoadConfigLogLevelTests(ConfigLoadTestCase):
    def test_default_log_level(self) -> None:
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.log_level, "DEBUG")

    def test_log_level_is_uppercased(self) -> None:
        self.write_config_json({"log_level": "info"})
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.log_level, "INFO")

    def test_all_valid_log_levels_accepted(self) -> None:
        for level in ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"):
            with self.subTest(level=level):
                self.write_config_json({"log_level": level.lower()})
                with self.env(BOT_TOKEN="TOKEN"):
                    cfg = load_config()
                self.assertEqual(cfg.log_level, level)

    def test_invalid_log_level_now_raises(self) -> None:
        # Раньше log_level, в отличие от mode/database.backend, вообще не
        # проверялся на допустимые значения — что угодно проходило дальше
        # к logging.basicConfig(). Теперь сверяется со списком уровней
        # stdlib logging.
        self.write_config_json({"log_level": "not-a-real-level"})
        with self.env(BOT_TOKEN="TOKEN"):
            with self.assertRaises(RuntimeError) as ctx:
                load_config()
        self.assertIn("not-a-real-level".upper(), str(ctx.exception))


class LoadConfigDatabaseIntegrationTests(ConfigLoadTestCase):
    def test_postgres_backend_without_dsn_raises_via_load_config(self) -> None:
        self.write_config_json({"database": {"backend": "postgres"}})
        with self.env(BOT_TOKEN="TOKEN"):
            with self.assertRaises(RuntimeError):
                load_config()

    def test_full_postgres_config_round_trips(self) -> None:
        self.write_config_json({
            "database": {
                "backend": "postgres",
                "postgres": {"dsn": "postgresql://u:p@host/db", "pool_min_size": 3, "pool_max_size": 15},
            }
        })
        with self.env(BOT_TOKEN="TOKEN"):
            cfg = load_config()
        self.assertEqual(cfg.database.backend, "postgres")
        self.assertEqual(cfg.database.postgres.dsn, "postgresql://u:p@host/db")
        self.assertEqual(cfg.database.postgres.pool_min_size, 3)
        self.assertEqual(cfg.database.postgres.pool_max_size, 15)


class LoadConfigFullIntegrationTest(ConfigLoadTestCase):
    def test_comprehensive_config_json_end_to_end(self) -> None:
        self.write_config_json({
            "mode": "webhook",
            "log_level": "warning",
            "disabled_plugins": ["a", "b"],
            "webhook": {
                "url": "https://bot.example.com/",
                "host": "127.0.0.1",
                "port": 9443,
                "secret_token": "s3cr3t",
                "drop_pending_updates": True,
            },
            "database": {
                "backend": "postgres",
                "sqlite_core_reader_pool_size": 8,
                "postgres": {"dsn": "postgresql://u:p@host/db"},
            },
        })
        with self.env(BOT_TOKEN="  my-token  "):
            cfg = load_config()

        self.assertEqual(cfg.bot_token, "my-token")
        self.assertEqual(cfg.mode, "webhook")
        self.assertEqual(cfg.log_level, "WARNING")
        self.assertEqual(cfg.disabled_plugins, ["a", "b"])
        self.assertEqual(cfg.webhook.url, "https://bot.example.com")
        self.assertEqual(cfg.webhook.host, "127.0.0.1")
        self.assertEqual(cfg.webhook.port, 9443)
        self.assertEqual(cfg.webhook.secret_token, "s3cr3t")
        self.assertTrue(cfg.webhook.drop_pending_updates)
        self.assertEqual(cfg.webhook.path, "/webhook/my-token")
        self.assertEqual(cfg.database.backend, "postgres")
        self.assertEqual(cfg.database.sqlite_core_reader_pool_size, 8)
        self.assertEqual(cfg.database.postgres.dsn, "postgresql://u:p@host/db")


if __name__ == "__main__":
    unittest.main()
