"""
main.py — точка входа AccountManager Framework.

Порядок инициализации:
  1. bootstrap        — проверка целостности файлов, папок, прав
  2. config           — чтение .env и config.json (в т.ч. mode:
                        polling/webhook и database.backend: sqlite/postgres)
  3. logger           — инициализация с уровнем из config
  4. database         — подключение (бэкенд выбирает
                        core/db/factory.py:create_database() по
                        config.database.backend) + миграции ядра (папка
                        миграций тоже выбирается под бэкенд, см.
                        core/db/migrations.py:resolve_migration_dir)
  5. hooks/patches/services/scheduler — общие шины расширения для всех
     плагинов (создаются здесь, а не внутри PluginLoader, чтобы
     core-код вроде UserUpsertMiddleware мог эмитить в тот же HookBus,
     на который подписываются плагины)
  6. bot + dispatcher
  7. plugin_loader    — сканирование, версия ядра, pip-зависимости,
                        порядок загрузки, миграции плагинов, setup().
                        Плагины регистрируют фоновые задачи через
                        ctx.schedule_* внутри setup() — сам scheduler
                        стартует ПОСЛЕ того, как все плагины загружены
                        (шаг 7б), чтобы задачи не начинали срабатывать
                        раньше, чем весь бот готов.
  8. control_server   — TCP на 127.0.0.1 для framework_manager.py restart
                        (перезагрузка плагинов без перезапуска процесса)
  9. bot start        — polling ИЛИ webhook, в зависимости от
                        config.mode. В обоих случаях команда "shutdown"
                        control-сервера приводит к одному и тому же
                        выходу из этого шага — см. core/control_server.py.

Graceful shutdown (в finally, СТРОГО по шагам, каждый — после
завершения предыдущего): остановить приём новых команд control-сервера
→ остановить планировщик (отменяет любые ещё не снятые задачи) →
teardown всех плагинов (обратный порядок загрузки, откат их
hooks/patches/services/scheduler-задач) → закрыть БД плагинов → закрыть
сессию бота → закрыть БД ядра → применить отложенные обновления
плагинов, если есть (core/update_staging.py). Порядок важен: apply идёт
САМЫМ ПОСЛЕДНИМ, когда БД/бот/control-сервер уже закрыты — если после
него происходит self-restart (os.execv), это должен быть единственный
"хвост", ничего больше не должно оставаться открытым.
"""
from __future__ import annotations

import asyncio
from pathlib import Path

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from core.bootstrap import run_bootstrap
from core.config import Config, load_config
from core.control_server import ControlServer
from core.db.factory import create_database
from core.db.migrations import resolve_migration_dir
from core.hooks import HookBus
from core.lockfile import check_drift_at_startup
from core.logger import get_logger, setup_logger, stop_logger
from core.middleware import UserUpsertMiddleware
from core.patches import PatchManager
from core.plugin_loader import PluginLoader
from core.scheduler import Scheduler
from core.services import ServiceRegistry
from core.update_staging import apply_staged_updates, restart_process


async def _run_webhook(
    bot: Bot,
    dp: Dispatcher,
    config: Config,
    stop_event: asyncio.Event,
    logger,
) -> None:
    """
    Поднимает aiohttp-сервер на config.webhook.host:port, выставляет
    вебхук у Telegram и блокируется до stop_event (взводится
    ControlServer._handle_shutdown, см. core/control_server.py — там же
    объяснение, почему в webhook-режиме нет dp.stop_polling()).

    Вебхук НЕ снимается автоматически при остановке (bot.delete_webhook()
    не вызывается) — обычный graceful shutdown/рестарт подразумевает,
    что бот снова поднимется с тем же config.webhook.url, и Telegram
    сам продолжит слать апдейты туда же; explicit delete_webhook нужен
    только если осознанно переключаетесь на polling — тогда достаточно
    один раз поменять config.json → mode на "polling" и перезапустить
    процесс, aiogram/Telegram сами не пришлют полинг, пока вебхук
    прописан, но explicit switch — забота человека, не auto-cleanup.
    """
    from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application
    from aiohttp import web

    app = web.Application()
    SimpleRequestHandler(
        dispatcher=dp,
        bot=bot,
        secret_token=config.webhook.secret_token or None,
    ).register(app, path=config.webhook.path)
    setup_application(app, dp, bot=bot)

    full_url = f"{config.webhook.url}{config.webhook.path}"
    await bot.set_webhook(
        url=full_url,
        secret_token=config.webhook.secret_token or None,
        drop_pending_updates=config.webhook.drop_pending_updates,
        allowed_updates=dp.resolve_used_update_types(),
    )

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, config.webhook.host, config.webhook.port)
    await site.start()
    logger.info(
        f"Бот запущен в режиме webhook: слушаю {config.webhook.host}:{config.webhook.port}, "
        f"вебхук выставлен на {full_url}"
    )
    try:
        await stop_event.wait()
    finally:
        await runner.cleanup()


async def main() -> None:
    # ── 1. Bootstrap ─────────────────────────────────────────
    run_bootstrap()

    # ── 2. Config ────────────────────────────────────────────
    config = load_config()

    # ── 3. Logger ────────────────────────────────────────────
    setup_logger(config.log_level)
    logger = get_logger("main")
    logger.info(
        f"AccountManager Framework запускается... (mode={config.mode}, "
        f"database.backend={config.database.backend})"
    )

    # ── 4. Database + миграции ядра ──────────────────────────
    db = create_database(
        namespace="core",
        config=config,
        sqlite_path=Path("database/database.db"),
        sqlite_reader_pool_size=config.database.sqlite_core_reader_pool_size,
        postgres_pool_min_size=config.database.postgres.pool_min_size,
        postgres_pool_max_size=config.database.postgres.pool_max_size,
    )
    await db.connect()

    core_migration_dir = resolve_migration_dir(
        Path("database/migrations"), config.database.backend
    )
    if not await db.run_migrations("core", core_migration_dir):
        logger.error("Не удалось применить базовые миграции ядра. Выход.")
        await db.close()
        return

    core_versions = {v for v, _ in db.collect_migration_files(core_migration_dir, "core")}
    if not await db.verify_schema_version("core", core_versions):
        logger.error("Версия схемы ядра не совпадает с миграциями на диске. Выход.")
        await db.close()
        return

    # ── 5. Общие шины расширения (hooks/patches/services/scheduler) ──
    hooks = HookBus()
    patches = PatchManager()
    services = ServiceRegistry()
    # db (БД ядра) — планировщик хранит в ней last_run_at персистентных
    # задач, чтобы переживать рестарт процесса без потери фазы
    # расписания. См. core/scheduler.py.
    scheduler = Scheduler(db=db)

    # ── 6. Bot + Dispatcher ──────────────────────────────────
    bot = Bot(
        token=config.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()

    # Core middleware: upsert пользователя при каждом апдейте +
    # уведомление подписчиков core.user.upserted через общий HookBus.
    dp.update.outer_middleware(UserUpsertMiddleware(db, hooks))

    # ── Sandbox ───────────────────────────────────────────────
    # Устанавливаем ПОСЛЕ регистрации UserUpsertMiddleware и ДО загрузки
    # плагинов. apply_sandbox() блокирует subprocess/exec audit events и
    # импорт ctypes/pty. Timeout middleware регистрируется ПОСЛЕ
    # UserUpsertMiddleware → wraps только то что внутри него (плагины).
    if config.sandbox.enabled:
        from core.sandbox import apply_sandbox, make_timeout_middleware
        apply_sandbox(config)
        if config.sandbox.handler_timeout_s > 0:
            dp.update.outer_middleware(
                make_timeout_middleware(config.sandbox.handler_timeout_s)()
            )
        logger.info(
            f"  Sandbox: таймаут={config.sandbox.handler_timeout_s}s, "
            f"блокировка системных вызовов={config.sandbox.block_system_calls}"
        )
    else:
        logger.warning("  Sandbox ОТКЛЮЧЁН (config.json → sandbox.enabled=false)")

    # ── 7. Plugin loader ──────────────────────────────────────
    loader = PluginLoader(hooks=hooks, patches=patches, services=services, scheduler=scheduler)
    loader.scan(Path("plugins"), config.disabled_plugins)
    loader.check_core_compat()
    loader.check_pip_deps()
    loader.resolve_order()

    drift_warning = check_drift_at_startup(loader)
    if drift_warning:
        logger.warning(drift_warning)

    # db здесь — БД ЯДРА; PluginLoader создаёт для каждого плагина
    # отдельную персональную БД и кладёт её в ctx.db, а этот db даёт
    # плагинам доступ как ctx.core_db (core/plugin_context.py).
    await loader.load_plugins(dp, bot, db, config)
    loader.summary()

    # ── 7б. Планировщик ────────────────────────────────────────
    # Запускается ПОСЛЕ загрузки плагинов — все ctx.schedule_*,
    # вызванные плагинами в setup(), уже зарегистрированы, start()
    # спавнит их разом. Задачи, зарегистрированные ПОСЛЕ этого (реже —
    # например, из обработчика команды), стартуют сразу при регистрации.
    await scheduler.start()

    # ── 8. Control-сервер (для framework_manager.py) ─────────────
    stop_event = asyncio.Event()
    control_server = ControlServer(loader, dp, mode=config.mode, stop_event=stop_event)
    await control_server.start()

    # ── 9. OTA: автопроверка при старте (опционально) ───────────
    if config.ota.auto_check_on_startup:
        try:
            from core.ota.checker import check_for_update
            from core.manifest import load_manifest, display, ManifestError
            _manifest = load_manifest()
            _cur_ver  = display(_manifest, "version", default="")
            _ota_repo = display(_manifest, "ota_repository", default="")
            _channel  = display(_manifest, "build_channel", default="Stable").lower()
            if _ota_repo and _cur_ver:
                _has_upd, _rel, _msg = check_for_update(_cur_ver, _ota_repo, _channel, timeout=5)
                if _has_upd and _rel:
                    logger.info(
                        f"[OTA] Доступна новая версия {_rel.version} [{_channel}]. "
                        f"Запустите: python framework_manager.py ota apply"
                    )
                else:
                    logger.debug(f"[OTA] {_msg}")
        except Exception as _ota_exc:
            logger.debug(f"[OTA] Не удалось проверить обновления при старте: {_ota_exc}")

    # ── 10. Polling или webhook ──────────────────────────────────
    logger.info("Бот запущен. Ожидание сообщений...")
    try:
        if config.mode == "webhook":
            await _run_webhook(bot, dp, config, stop_event, logger)
        else:
            await dp.start_polling(
                bot,
                allowed_updates=dp.resolve_used_update_types(),
            )
    finally:
        logger.info("Получен сигнал остановки. Graceful shutdown...")
        # Порядок ниже — намеренно последовательный, не параллельный:
        # каждый шаг должен полностью завершиться, прежде чем начнётся
        # следующий (см. докстринг модуля).
        logger.info("  [1/7] Останавливаю control-сервер...")
        await control_server.stop()
        logger.info("  [2/7] Останавливаю планировщик...")
        await scheduler.stop()
        logger.info("  [3/7] Останавливаю плагины...")
        await loader.teardown_all()
        logger.info("  [4/7] Закрываю БД плагинов...")
        await loader.close_all_plugin_databases()
        logger.info("  [5/7] Закрываю сессию бота...")
        await bot.session.close()
        logger.info("  [6/7] Закрываю базу данных ядра...")
        await db.close()
        logger.info("  [7/7] Проверяю отложенные обновления плагинов...")
        result = apply_staged_updates()
        if result.applied and result.ok:
            logger.info(
                f"Применены обновления: {', '.join(result.applied_plugins)}. "
                f"Перезапускаюсь для их загрузки..."
            )
            restart_process()  # не возвращается на POSIX (см. core/update_staging.py)
        elif result.applied and not result.ok:
            logger.error(
                "Отложенные обновления НЕ применены (ошибка валидации, подробности "
                "выше) — бот остановлен со СТАРЫМИ плагинами, ничего не сломано."
            )

        # ── OTA pending_promote хук ───────────────────────────────
        # Самый последний шаг: если OTA успешно прошла в слоте B и
        # администратор выбрал "применить при следующем перезапуске",
        # здесь мы копируем slots/b/ → slots/a/ + PROJECT_ROOT.
        # Выполняется ПОСЛЕ закрытия всех ресурсов (БД, бот, control-сервер)
        # — безопасно, sync, никаких asyncio. При ошибке — только лог.
        try:
            from core.ota.slot_manager import apply_pending_if_any
            if apply_pending_if_any():
                logger.info("[OTA] Отложенный промоут выполнен. При следующем старте будет активна новая версия.")
        except Exception as _ota_exc:
            logger.warning(f"[OTA] Ошибка при отложенном промоуте (не критично): {_ota_exc}")

        logger.info("Бот остановлен.")
        stop_logger()


if __name__ == "__main__":
    asyncio.run(main())
