"""
core/plugin_verifier.py — верификация подлинности плагинов.

Схема подписи — та же что у OTA-архивов (configs/keys/):
  1. Разработчик запускает: python scripts/sign_plugin.py plugins/antispam/
     → вычисляется plugin_hash (sha256 всех файлов плагина)
     → hash записывается в plugins/antispam/manifest.json → sha256_hash
     → создаётся plugins/antispam/manifest.json.sig (Ed25519-подпись hash-строки)

  2. При загрузке (core/plugin_loader.py), если sandbox.verify_plugin_signatures=true:
     a. Перечитываем файлы плагина, вычисляем hash заново
     b. Сравниваем с manifest.json → sha256_hash  (целостность файлов)
     c. Проверяем Ed25519 подпись в manifest.json.sig  (аутентичность)
     d. Если что-то не так — плагин пропускается с причиной

Публичный ключ: configs/keys/public.pem (тот же что для OTA).
Подписывать плагины может только тот, у кого есть configs/keys/private.pem.

Совместимость: если verify_plugin_signatures=false (дефолт) — этот модуль
вообще не вызывается, существующие плагины без подписи продолжают работать.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from core.ota.verifier import PUBKEY_PATH   # reuse: configs/keys/public.pem

SIG_FILENAME = "manifest.json.sig"

# Файлы которые ВХОДЯТ в хеш плагина
_INCLUDE_PATTERNS = ("*.py", "manifest.json")
# Файлы которые ИСКЛЮЧАЮТСЯ из хеша (сигнатура не может подписывать себя)
_EXCLUDE_NAMES   = frozenset({SIG_FILENAME})


@dataclass
class PluginVerifyResult:
    ok:          bool
    has_sig:     bool = False   # есть ли файл .sig вообще
    reason:      str  = ""
    files_hashed: int = 0


def iter_plugin_files(plugin_dir: Path) -> list[Path]:
    """
    Детерминированный список файлов плагина для хеширования.
    Включает *.py + manifest.json, исключает manifest.json.sig и __pycache__.
    """
    files: list[Path] = []
    for pattern in _INCLUDE_PATTERNS:
        for p in plugin_dir.rglob(pattern):
            if "__pycache__" in p.parts:
                continue
            if p.name in _EXCLUDE_NAMES:
                continue
            files.append(p)
    return sorted(files, key=lambda p: p.relative_to(plugin_dir).as_posix())


def compute_plugin_hash(plugin_dir: Path) -> str:
    """
    sha256 по (относительный_путь + содержимое) каждого файла плагина.

    manifest.json хешируется БЕЗ поля sha256_hash — это единственный
    способ избежать цикличной зависимости: хеш нельзя включать в объект,
    который он же и хеширует. Все остальные поля manifest.json (name,
    version, author и т.д.) защищены и не могут быть подменены.
    .py-файлы хешируются как есть.
    """
    h = hashlib.sha256()
    for p in iter_plugin_files(plugin_dir):
        rel = p.relative_to(plugin_dir).as_posix()
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        if p.name == "manifest.json":
            # Хешируем manifest без sha256_hash (иначе — цикл)
            try:
                data = json.loads(p.read_bytes().decode("utf-8"))
                data.pop("sha256_hash", None)
                # sort_keys — детерминированный JSON независимо от порядка полей
                content = json.dumps(data, sort_keys=True,
                                     ensure_ascii=False).encode("utf-8")
            except (json.JSONDecodeError, UnicodeDecodeError):
                content = p.read_bytes()   # fallback на сырые байты
            h.update(content)
        else:
            h.update(p.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


def verify_plugin(
    plugin_dir: Path,
    pubkey_path: Path = PUBKEY_PATH,
) -> PluginVerifyResult:
    """
    Полная верификация плагина:
      1. manifest.json → sha256_hash должен совпадать с реально вычисленным
      2. manifest.json.sig должна быть корректной Ed25519-подписью hash-строки
    """
    sig_path = plugin_dir / SIG_FILENAME
    has_sig  = sig_path.exists()

    # Файл подписи вообще отсутствует
    if not has_sig:
        return PluginVerifyResult(
            ok=False, has_sig=False,
            reason=(
                f"{SIG_FILENAME} не найден в {plugin_dir.name}/. "
                f"Подпишите плагин: python scripts/sign_plugin.py {plugin_dir}"
            ),
        )

    # Читаем объявленный хеш из manifest.json
    manifest_path = plugin_dir / "manifest.json"
    if not manifest_path.exists():
        return PluginVerifyResult(
            ok=False, has_sig=True,
            reason=f"manifest.json не найден в {plugin_dir.name}/."
        )

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return PluginVerifyResult(
            ok=False, has_sig=True,
            reason=f"manifest.json содержит невалидный JSON: {exc}"
        )

    declared = str(manifest.get("sha256_hash", "") or "").strip().lower()
    if not declared:
        return PluginVerifyResult(
            ok=False, has_sig=True,
            reason=(
                f"manifest.json → sha256_hash не задан в {plugin_dir.name}/. "
                f"Переподпишите плагин: python scripts/sign_plugin.py {plugin_dir}"
            ),
        )

    # Вычисляем реальный хеш файлов
    files = iter_plugin_files(plugin_dir)
    computed = compute_plugin_hash(plugin_dir)

    if computed != declared:
        return PluginVerifyResult(
            ok=False, has_sig=True, files_hashed=len(files),
            reason=(
                f"Файлы плагина {plugin_dir.name}/ изменились после подписи. "
                f"Объявлено: {declared[:16]}… Фактически: {computed[:16]}…"
            ),
        )

    # Проверяем Ed25519-подпись над hash-строкой
    try:
        from cryptography.hazmat.primitives.serialization import load_pem_public_key
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature
    except ImportError:
        return PluginVerifyResult(
            ok=False, has_sig=True, files_hashed=len(files),
            reason=(
                "Библиотека cryptography не установлена — невозможно проверить подпись. "
                "Выполните: python framework_manager.py deps --install"
            ),
        )

    if not pubkey_path.exists():
        return PluginVerifyResult(
            ok=False, has_sig=True, files_hashed=len(files),
            reason=(
                f"Публичный ключ не найден: {pubkey_path}. "
                f"Создайте пару ключей: python scripts/generate_keys.py"
            ),
        )

    try:
        key = load_pem_public_key(pubkey_path.read_bytes())
        if not isinstance(key, Ed25519PublicKey):
            return PluginVerifyResult(
                ok=False, has_sig=True, files_hashed=len(files),
                reason=f"{pubkey_path} содержит не Ed25519 ключ."
            )

        sig_bytes = sig_path.read_bytes()
        key.verify(sig_bytes, computed.encode("utf-8"))

    except InvalidSignature:
        return PluginVerifyResult(
            ok=False, has_sig=True, files_hashed=len(files),
            reason=(
                f"Подпись плагина {plugin_dir.name}/ НЕДЕЙСТВИТЕЛЬНА. "
                f"Файлы могли быть подменены или подпись создана другим ключом."
            ),
        )
    except Exception as exc:
        return PluginVerifyResult(
            ok=False, has_sig=True, files_hashed=len(files),
            reason=f"Ошибка проверки подписи: {exc}"
        )

    return PluginVerifyResult(ok=True, has_sig=True, files_hashed=len(files))
