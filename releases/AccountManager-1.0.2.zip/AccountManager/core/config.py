"""
core/config.py — загрузка конфигурации из configs/.env и configs/config.json.

Секции config.json (все необязательны, без файла работает на дефолтах):
  "mode"      — "polling" | "webhook"
  "webhook"   — {...} (только при mode="webhook")
  "database"  — {"backend": "sqlite"|"postgres", "postgres": {...}}
  "ota"       — параметры OTA A/B обновлений
  "process"   — управление перезапуском (systemctl/supervisor/plain)

── SLOT_ROOT / A/B изоляция ────────────────────────────────────────────
При OTA слот B запускается с CWD=slots/b/. Все относительные пути
(Path("configs"), Path("database"), ...) резолвятся автоматически.
SETTINGS_DIR/ENV_PATH/CONFIG_PATH тоже относительные — корректны
при любом CWD без изменений здесь.

── configs/ ───────────────────────────────────────────────────────────
.env и config.json переехали из корня в settings/.
ENV_PATH/CONFIG_PATH — единственное место, где зашиты пути;
core/bootstrap.py импортирует их отсюда же.

Переменные среды из .env:
  BOT_TOKEN       — обязателен
  BOT_TOKEN_TEST  — токен тестового бота (слот B + OTA-уведомления)
  ADMIN_CHAT_ID   — chat_id администратора для Telegram-уведомлений OTA
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

SETTINGS_DIR = Path("configs")
ENV_PATH     = SETTINGS_DIR / ".env"
CONFIG_PATH  = SETTINGS_DIR / "config.json"

_VALID_LOG_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}


def _as_bool(value: Any, default: bool = False) -> bool:
    """
    bool(...) на строке из JSON — классическая ловушка: bool("false")
    == True, потому что непустая строка truthy сама по себе, независимо
    от того, что в ней написано. Здесь разбираем осмысленные текстовые
    представления явно, а не просто приводим типы в лоб.
    """
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in ("true", "1", "yes", "on"):
            return True
        if lowered in ("false", "0", "no", "off", ""):
            return False
        return default
    return bool(value)


@dataclass
class WebhookConfig:
    """Актуален только при Config.mode == 'webhook'."""
    url: str = ""              # публичный базовый URL, напр. "https://bot.example.com"
    path: str = ""              # путь; по умолчанию вычисляется из bot_token в load_config()
    host: str = "0.0.0.0"       # на чём слушать aiohttp-серверу
    port: int = 8080
    secret_token: str = ""      # опционально — Telegram X-Telegram-Bot-Api-Secret-Token
    drop_pending_updates: bool = False


@dataclass
class PostgresConfig:
    dsn: str = ""
    pool_min_size: int = 1
    pool_max_size: int = 5


@dataclass
class DatabaseConfig:
    backend: str = "sqlite"     # "sqlite" | "postgres"
    postgres: PostgresConfig = field(default_factory=PostgresConfig)
    # reader_pool_size для БД ЯДРА при backend="sqlite" (плагины всегда
    # используют меньший _PLUGIN_DB_READER_POOL_SIZE из plugin_loader.py
    # независимо от этого значения — см. докстринг там).
    sqlite_core_reader_pool_size: int = 4


@dataclass
class OTAConfig:
    """Параметры OTA A/B обновлений (config.json → "ota": {...})."""
    # Сколько крашей слота B допускается до автоотката
    max_crashes: int = 3
    # Сколько секунд слот B должен проработать без краша для промоута
    test_duration_s: int = 300
    # True — спросить администратора "применить сейчас или при перезапуске?"
    # False — всегда pending_promote (применить при следующем shutdown A)
    interrupt_allowed: bool = True
    # Сколько секунд ждать ответа на вопрос до автовыбора "нет"
    interrupt_timeout_s: int = 60
    # True — проверять обновления при каждом старте бота
    auto_check_on_startup: bool = False
    # "log" — только лог; "telegram" — лог + Telegram (требует ADMIN_CHAT_ID)
    notify_on_rollback: str = "log"
    # Размер буфера скачивания framework.zip (КиБ).
    # 64 — хороший баланс между памятью и скоростью на большинстве каналов.
    # Уменьшите до 8–16 на медленных каналах или в Termux с ограниченной RAM.
    download_chunk_kb: int = 64
    # Интервал проверки живости слота B (секунды) — как часто poll() вызывается.
    poll_interval_s: int = 5
    # Сколько секунд ждать после старта слота B до начала мониторинга.
    # Даёт боту время инициализироваться (загрузить плагины, поднять БД).
    startup_grace_s: int = 10


@dataclass
class ProcessConfig:
    """
    Управление перезапуском процесса после промоута (config.json → "process": {...}).
    manager: "auto" | "systemctl" | "supervisor" | "plain"
      "auto" — детект: Termux→plain, systemctl доступен→systemctl, иначе plain.
    unit_name      — имя systemd-юнита (при manager="systemctl")
    supervisor_name— имя supervisor-программы (при manager="supervisor")
    """
    manager: str = "auto"
    unit_name: str = "accountmanager"
    supervisor_name: str = "accountmanager"


@dataclass
class SandboxConfig:
    """
    Мягкая изоляция плагинов (config.json → "sandbox": {...}).
    Подробности: core/sandbox.py.
    """
    # Включить защиты (False = sandbox отключён полностью)
    enabled: bool = True
    # Отменять хендлер плагина если он завис дольше N секунд (0 = без таймаута)
    handler_timeout_s: float = 30.0
    # Блокировать subprocess.Popen, os.system и execv-семейство через audit hook
    block_system_calls: bool = True
    # Дополнительные модули Python для блокировки через importlib (сверх дефолтных)
    extra_blocked_modules: list = None  # type: ignore[assignment]
    # Проверять подпись каждого плагина перед загрузкой.
    # Требует configs/keys/public.pem и manifest.json.sig в папке плагина.
    # False по умолчанию — обратная совместимость с неподписанными плагинами.
    verify_plugin_signatures: bool = False
    # Если True — плагин без подписи допускается с предупреждением (не блокируется).
    # Если False (дефолт при verify_plugin_signatures=True) — неподписанный плагин
    # блокируется так же как плагин с недействительной подписью.
    allow_unsigned_plugins: bool = False

    def __post_init__(self) -> None:
        if self.extra_blocked_modules is None:
            self.extra_blocked_modules = []


@dataclass
class Config:
    bot_token: str
    log_level: str = "DEBUG"
    disabled_plugins: list[str] = field(default_factory=list)
    mode: str = "polling"       # "polling" | "webhook"
    webhook: WebhookConfig = field(default_factory=WebhookConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    ota: OTAConfig = field(default_factory=OTAConfig)
    process: ProcessConfig = field(default_factory=ProcessConfig)
    sandbox: SandboxConfig = field(default_factory=SandboxConfig)
    # Заполняются из .env при load_config(), не из config.json
    bot_token_test: str = ""
    admin_chat_id: str = ""


def _parse_webhook(raw: dict, bot_token: str) -> WebhookConfig:
    cfg = WebhookConfig()
    cfg.url = str(raw.get("url", "")).rstrip("/")
    # Путь по умолчанию включает токен — так Telegram может слать
    # апдейты только тому, кто знает токен, даже если secret_token не
    # задан отдельно (тот же принцип, что и в официальных примерах
    # aiogram для webhook: путь = "/webhook/<token>", а не голый "/").
    cfg.path = str(raw.get("path") or f"/webhook/{bot_token}")
    cfg.host = str(raw.get("host", cfg.host))
    cfg.port = int(raw.get("port", cfg.port))
    cfg.secret_token = str(raw.get("secret_token", ""))
    cfg.drop_pending_updates = _as_bool(raw.get("drop_pending_updates", False))
    return cfg


def _parse_database(raw: dict) -> DatabaseConfig:
    cfg = DatabaseConfig()
    cfg.backend = str(raw.get("backend", cfg.backend)).strip().lower()
    if cfg.backend not in ("sqlite", "postgres"):
        raise RuntimeError(
            f'config.json → database.backend={cfg.backend!r} не поддерживается. '
            f'Допустимые значения: "sqlite", "postgres".'
        )
    cfg.sqlite_core_reader_pool_size = int(
        raw.get("sqlite_core_reader_pool_size", cfg.sqlite_core_reader_pool_size)
    )

    pg_raw = raw.get("postgres", {}) or {}
    pg = PostgresConfig()
    pg.dsn = str(pg_raw.get("dsn", "")).strip()
    pg.pool_min_size = int(pg_raw.get("pool_min_size", pg.pool_min_size))
    pg.pool_max_size = int(pg_raw.get("pool_max_size", pg.pool_max_size))
    cfg.postgres = pg

    if cfg.backend == "postgres" and not pg.dsn:
        raise RuntimeError(
            'config.json → database.backend="postgres", но database.postgres.dsn '
            'не задан. Пример: "postgresql://user:password@localhost:5432/accountmanager".'
        )
    return cfg


def _parse_sandbox(raw: dict) -> SandboxConfig:
    cfg = SandboxConfig()
    if "enabled" in raw:
        cfg.enabled = _as_bool(raw["enabled"], cfg.enabled)
    if "handler_timeout_s" in raw:
        cfg.handler_timeout_s = float(raw["handler_timeout_s"])
    if "block_system_calls" in raw:
        cfg.block_system_calls = _as_bool(raw["block_system_calls"], cfg.block_system_calls)
    if "extra_blocked_modules" in raw:
        v = raw["extra_blocked_modules"]
        cfg.extra_blocked_modules = list(v) if isinstance(v, list) else []
    if "verify_plugin_signatures" in raw:
        cfg.verify_plugin_signatures = _as_bool(raw["verify_plugin_signatures"], cfg.verify_plugin_signatures)
    if "allow_unsigned_plugins" in raw:
        cfg.allow_unsigned_plugins = _as_bool(raw["allow_unsigned_plugins"], cfg.allow_unsigned_plugins)
    return cfg


def _parse_ota(raw: dict) -> OTAConfig:
    cfg = OTAConfig()
    cfg.max_crashes         = int(raw.get("max_crashes",         cfg.max_crashes))
    cfg.test_duration_s     = int(raw.get("test_duration_s",     cfg.test_duration_s))
    cfg.interrupt_allowed   = _as_bool(raw.get("interrupt_allowed"),   cfg.interrupt_allowed)
    cfg.interrupt_timeout_s = int(raw.get("interrupt_timeout_s", cfg.interrupt_timeout_s))
    cfg.auto_check_on_startup = _as_bool(raw.get("auto_check_on_startup"), cfg.auto_check_on_startup)
    cfg.notify_on_rollback  = str(raw.get("notify_on_rollback",  cfg.notify_on_rollback))
    cfg.download_chunk_kb   = int(raw.get("download_chunk_kb",   cfg.download_chunk_kb))
    cfg.poll_interval_s     = int(raw.get("poll_interval_s",     cfg.poll_interval_s))
    cfg.startup_grace_s     = int(raw.get("startup_grace_s",     cfg.startup_grace_s))
    return cfg


def _parse_process(raw: dict) -> ProcessConfig:
    cfg = ProcessConfig()
    cfg.manager          = str(raw.get("manager",          cfg.manager)).strip().lower()
    cfg.unit_name        = str(raw.get("unit_name",        cfg.unit_name)).strip()
    cfg.supervisor_name  = str(raw.get("supervisor_name",  cfg.supervisor_name)).strip()
    if cfg.manager not in ("auto", "systemctl", "supervisor", "plain"):
        cfg.manager = "auto"
    return cfg


def load_config() -> Config:
    """
    Читает configs/.env через python-dotenv и configs/config.json.
    Возвращает Config с полными настройками.
    Ошибки здесь — фатальные (bootstrap должен был всё проверить раньше).
    """
    load_dotenv(dotenv_path=ENV_PATH)

    bot_token = os.getenv("BOT_TOKEN", "").strip()
    if not bot_token:
        raise RuntimeError(
            f"BOT_TOKEN не задан или пустой. Проверьте файл {ENV_PATH}."
        )

    raw: dict = {}
    config_path = CONFIG_PATH
    if config_path.exists():
        with open(config_path, encoding="utf-8") as fh:
            raw = json.load(fh)

    mode = str(raw.get("mode", "polling")).strip().lower()
    if mode not in ("polling", "webhook"):
        raise RuntimeError(
            f'config.json → mode={mode!r} не поддерживается. Допустимые значения: "polling", "webhook".'
        )

    log_level = str(raw.get("log_level", "DEBUG")).strip().upper()
    if log_level not in _VALID_LOG_LEVELS:
        raise RuntimeError(
            f'config.json → log_level={log_level!r} не поддерживается. '
            f'Допустимые значения: {", ".join(sorted(_VALID_LOG_LEVELS))}.'
        )

    raw_webhook = raw.get("webhook") or {}
    if not isinstance(raw_webhook, dict):
        raise RuntimeError(
            f'config.json → "webhook" должен быть объектом ({{...}}), получено: {type(raw_webhook).__name__}.'
        )
    webhook_cfg = _parse_webhook(raw_webhook, bot_token)
    if mode == "webhook" and not webhook_cfg.url:
        raise RuntimeError(
            'config.json → mode="webhook", но webhook.url не задан. '
            'Пример: "https://bot.example.com" (Telegram должен уметь достучаться до этого адреса).'
        )

    raw_database = raw.get("database") or {}
    if not isinstance(raw_database, dict):
        raise RuntimeError(
            f'config.json → "database" должен быть объектом ({{...}}), получено: {type(raw_database).__name__}.'
        )
    database_cfg = _parse_database(raw_database)

    raw_disabled = raw.get("disabled_plugins", [])
    if isinstance(raw_disabled, str):
        disabled_plugins = [raw_disabled] if raw_disabled.strip() else []
    else:
        disabled_plugins = list(raw_disabled)

    ota_cfg     = _parse_ota(raw.get("ota") or {})
    process_cfg  = _parse_process(raw.get("process") or {})
    sandbox_cfg   = _parse_sandbox(raw.get("sandbox") or {})

    return Config(
        bot_token=bot_token,
        log_level=log_level,
        disabled_plugins=disabled_plugins,
        mode=mode,
        webhook=webhook_cfg,
        database=database_cfg,
        ota=ota_cfg,
        process=process_cfg,
        sandbox=sandbox_cfg,
        bot_token_test=os.getenv("BOT_TOKEN_TEST", "").strip(),
        admin_chat_id=os.getenv("ADMIN_CHAT_ID", "").strip(),
    )
