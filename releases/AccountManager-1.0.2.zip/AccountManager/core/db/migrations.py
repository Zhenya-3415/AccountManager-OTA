"""
core/db/migrations.py — общие для всех бэкендов (SQLite/Postgres)
утилиты работы с .sql-миграциями: разбор файла на стейтменты и
разрешение того, ИЗ КАКОЙ папки их брать для текущего бэкенда.

Вынесено из core/database.py при добавлении Postgres-бэкенда, чтобы не
дублировать один и тот же парсер в core/db/sqlite_backend.py и
core/db/postgres_backend.py — сам разбор SQL-файла на стейтменты не
зависит от того, куда они дальше выполняются.

── Почему НЕТ автоматического SQLite -> Postgres перевода SQL ────────
Мог бы существовать "умный" транслятор диалектов (переписать
AUTOINCREMENT -> GENERATED ALWAYS AS IDENTITY и т.п.), но это ловушка:
он либо покрывает только простые случаи и молча ломается на сложных
(тихо создав не ту схему — худший из возможных исходов для миграций),
либо разрастается в отдельный SQL-парсер размером с сам проект. Плюс
есть различия, которые НЕЛЬЗЯ переписать текстовой заменой в принципе
— например, SQLite INTEGER PRIMARY KEY хранит целое произвольного
размера (до 8 байт), а Postgres INTEGER — ровно 4 байта: миграция
"users.user_id INTEGER" отлично работает в SQLite (Telegram user_id
уже превышает 2^31 у новых аккаунтов) и молча/шумно ломается в
Postgres. Это НЕ синтаксическая правка — правильный тип для Postgres
здесь BIGINT, и решить это может только автор миграции, не текстовый
транслятор.

Поэтому здесь — простое, предсказуемое правило: если у неймспейса
(ядро или плагин) есть отдельная папка миграций под конкретный бэкенд,
она используется; иначе — общая папка (и автор миграций сам отвечает
за то, чтобы SQL в ней подходил выбранному бэкенду):

    database/migrations/                  # общие/SQLite (как раньше)
    database/migrations/postgres/          # опционально — только для Postgres

    plugins/<name>/migrations/             # общие/SQLite (как раньше)
    plugins/<name>/migrations/postgres/     # опционально — только для Postgres

Ничего не меняется для плагинов, которые пишут только на SQLite —
у них просто никогда не будет папки .../migrations/postgres/, и
resolve_migration_dir() тихо вернёт исходную папку.
"""
from __future__ import annotations

import re
from pathlib import Path

_MIGRATION_FILENAME_RE = re.compile(r"^(\d+)_.+\.sql$")

# Стейтменты внутри .sql-файла миграции разбираются с учётом:
#  - '...'/"..." строк и кавычек-идентификаторов (';' внутри не разделитель)
#  - -- построчных и /* */ блочных комментариев
#  - $$...$$ и $tag$...$tag$ dollar-quoted строк (Postgres: тела функций/
#    триггеров) — без этого ';' и BEGIN/END внутри тела функции резали
#    бы её на куски точно так же, как раньше резался CREATE TRIGGER без
#    учёта вложенности BEGIN/END (см. историю этого файла)
_SQL_SKIP_RE = re.compile(
    r"'(?:[^']|'')*'"                  # 'string' с '' как экранированной кавычкой
    r'|"(?:[^"]|"")*"'                  # "quoted identifier"
    r"|--[^\n]*"                        # -- line comment
    r"|/\*.*?\*/"                       # /* block comment */
    r"|\$(\w*)\$.*?\$\1\$",  # $$...$$ / $tag$...$tag$ (Postgres) — \w* (not optional
                              # group) so the group always participates in the match,
                              # even when empty; a backreference to a group that never
                              # participated (e.g. via a `(...)?` that matched zero
                              # times) fails to match anything in Python's re, which
                              # silently broke plain "$$...$$" (empty tag) bodies.
    re.DOTALL,
)
_SQL_TOKEN_RE = re.compile(r";|\bBEGIN\b|\bEND\b", re.IGNORECASE)

# Публичный алиас — переиспользуется core/db/postgres_backend.py, чтобы
# перевод ?/:name плейсхолдеров в $1..$n обходил ровно те же строки/
# комментарии/dollar-quoting, что и разбор стейтментов здесь (один
# источник правды на то, "что в SQL-тексте является строкой/кавычкой",
# вместо второй похожей, но потенциально рассинхронизированной regex).
SQL_LITERAL_OR_COMMENT_RE = _SQL_SKIP_RE


def split_sql_statements(sql_text: str) -> list[str]:
    """
    Разбивает содержимое .sql-файла миграции на список top-level
    стейтментов (без завершающего ';').

    В отличие от наивного sql_text.split(';'):
      - ';' внутри '...'/"..." строк, $$...$$ dollar-quoting и внутри
        -- / /* */ комментариев не считается разделителем;
      - однострочный комментарий ПЕРЕД стейтментом не приводит к тому,
        что весь стейтмент молча выбрасывается целиком;
      - тело CREATE TRIGGER/FUNCTION ... BEGIN ... END (или $$...$$
        для Postgres) не разрывается по внутренним ';'.

    Пустые стейтменты (только из пробелов/комментариев) отбрасываются.
    """
    statements: list[str] = []
    buf: list[str] = []
    depth = 0
    pos = 0
    n = len(sql_text)

    def flush() -> None:
        stmt = "".join(buf).strip()
        if stmt:
            statements.append(stmt)
        buf.clear()

    while pos < n:
        skip_m = _SQL_SKIP_RE.match(sql_text, pos)
        if skip_m:
            token = skip_m.group(0)
            # Комментарии схлопываются в пробел (не влияют на смысл
            # стейтмента); строки/dollar-quoting сохраняются как есть
            # (их содержимое — часть стейтмента, не мусор для удаления).
            buf.append(" " if token.startswith(("--", "/*")) else token)
            pos = skip_m.end()
            continue

        if sql_text.startswith("/*", pos):
            # _SQL_SKIP_RE не смог смэтчить /\*.*?\*/ ИМЕННО здесь — при
            # DOTALL это возможно только если во всём остатке файла нет
            # закрывающего */. Раньше это молча деградировало: символы
            # незакрытого "комментария" разбирались как обычный SQL,
            # включая любые ';'/BEGIN/END внутри него как настоящие
            # разделители/операторы — тихая порча миграции вместо явной
            # ошибки в файле, который и так уже сломан.
            raise ValueError(
                f"Незакрытый блочный комментарий «/*» (позиция {pos}) — "
                f"не найдено соответствующего «*/» до конца файла."
            )

        next_skip = _SQL_SKIP_RE.search(sql_text, pos)
        search_end = next_skip.start() if next_skip else n

        i = pos
        for tok_m in _SQL_TOKEN_RE.finditer(sql_text, pos, search_end):
            buf.append(sql_text[i:tok_m.start()])
            token = tok_m.group(0)
            i = tok_m.end()

            if token == ";":
                if depth <= 0:
                    flush()
                else:
                    buf.append(";")
            elif token.upper() == "BEGIN":
                depth += 1
                buf.append(token)
            else:  # END
                depth = max(0, depth - 1)
                buf.append(token)

        buf.append(sql_text[i:search_end])
        pos = search_end

    flush()
    return statements


def collect_migration_files(migration_dir: Path, namespace: str) -> list[tuple[int, Path]]:
    """
    Возвращает [(версия, путь)], отсортированный по версии.
    Файлы с именем не вида "NNN_описание.sql" пропускаются с
    предупреждением, а не роняют загрузку миграций целиком.
    Дублирующиеся номера версий — фатальная ошибка (ValueError),
    т.к. иначе вторая миграция упадёт на UNIQUE(namespace, version)
    с непонятной для автора плагина ошибкой.
    """
    from core.logger import get_logger

    logger = get_logger("database")

    found: list[tuple[int, Path]] = []
    for f in sorted(migration_dir.iterdir()):
        if f.suffix != ".sql":
            continue
        m = _MIGRATION_FILENAME_RE.match(f.name)
        if not m:
            logger.warning(
                f"[{namespace}] Файл миграции «{f.name}» не соответствует "
                f"формату «NNNN_описание.sql» — пропущен."
            )
            continue
        found.append((int(m.group(1)), f))

    found.sort(key=lambda pair: pair[0])
    versions = [v for v, _ in found]
    dupes = {v for v in versions if versions.count(v) > 1}
    if dupes:
        raise ValueError(
            f"[{namespace}] Несколько файлов миграций делят один номер "
            f"версии: {sorted(dupes)}. Номера версий должны быть уникальны."
        )
    return found


def resolve_migration_dir(base_dir: Path, backend: str) -> Path:
    """
    Возвращает папку с миграциями, которую нужно применять для данного
    бэкенда: base_dir/<backend>/ (например migrations/postgres/), если
    она существует, иначе base_dir сам (общий/SQLite-путь по умолчанию
    — обратная совместимость со всеми плагинами, у которых такой папки
    никогда не было и не будет).

    backend="sqlite" никогда не ищет migrations/sqlite/ — SQLite это
    исходное, всегда общее поведение; отдельная подпапка имеет смысл
    только как ИСКЛЮЧЕНИЕ для несовместимого диалекта (сейчас — только
    Postgres).
    """
    if backend == "sqlite":
        return base_dir
    candidate = base_dir / backend
    return candidate if candidate.exists() else base_dir
