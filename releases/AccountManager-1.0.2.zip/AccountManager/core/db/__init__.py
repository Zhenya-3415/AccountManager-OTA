"""core/db — пакет бэкендов БД (SQLite/Postgres) за общим контрактом BaseDatabase."""
from __future__ import annotations

from core.db.base import BaseDatabase
from core.db.factory import create_database
from core.db.migrations import resolve_migration_dir, split_sql_statements

__all__ = [
    "BaseDatabase",
    "create_database",
    "resolve_migration_dir",
    "split_sql_statements",
]
