"""
core/db/factory.py — create_database(): единая точка выбора бэкенда БД.

И main.py (БД ядра), и core/plugin_loader.py (БД каждого плагина)
создают свою Database через эту функцию, а не импортируют
SQLiteDatabase/PostgresDatabase напрямую — весь код, которому нужна
БД, не должен знать, какой бэкенд выбран в config.json.
"""
from __future__ import annotations

from pathlib import Path

from core.config import Config
from core.db.base import BaseDatabase


def create_database(
    *,
    namespace: str,
    config: Config,
    sqlite_path: Path,
    sqlite_reader_pool_size: int = 4,
    postgres_pool_min_size: int = 1,
    postgres_pool_max_size: int = 5,
) -> BaseDatabase:
    """
    namespace — "core" для ядра или имя плагина. Используется как:
      - имя схемы Postgres (санитизируется, см. core/db/postgres_backend.py);
      - не влияет на путь SQLite (тот определяется sqlite_path целиком
        вызывающим кодом, как и раньше).

    sqlite_path нужен всегда, даже если выбран Postgres, — он идёт в
    resolve_migration_dir() и подобные места вызывающего кода
    (main.py/plugin_loader.py), которым нужен путь к папке плагина
    независимо от бэкенда БД.
    """
    backend = config.database.backend

    if backend == "sqlite":
        from core.db.sqlite_backend import SQLiteDatabase
        return SQLiteDatabase(sqlite_path, reader_pool_size=sqlite_reader_pool_size)

    if backend == "postgres":
        from core.db.postgres_backend import PostgresDatabase
        pg = config.database.postgres
        if pg is None or not pg.dsn:
            raise RuntimeError(
                "database.backend=\"postgres\" в config.json, но database.postgres.dsn "
                "не задан. Пример: \"postgresql://user:password@localhost:5432/accountmanager\"."
            )
        return PostgresDatabase(
            pg.dsn,
            schema=namespace,
            pool_min_size=postgres_pool_min_size,
            pool_max_size=postgres_pool_max_size,
        )

    raise ValueError(
        f"Неизвестный database.backend={backend!r} в config.json. "
        f"Допустимые значения: \"sqlite\", \"postgres\"."
    )
