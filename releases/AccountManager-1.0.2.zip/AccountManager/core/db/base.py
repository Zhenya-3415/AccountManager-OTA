"""
core/db/base.py — BaseDatabase: контракт, общий для всех бэкендов БД.

И core/db/sqlite_backend.py:SQLiteDatabase, и
core/db/postgres_backend.py:PostgresDatabase реализуют этот интерфейс
целиком — плагин, написанный против ctx.db/ctx.core_db, не должен
знать (и не может по коду отличить), какой бэкенд выбран в
config.json → database.backend. Это ЕДИНСТВЕННОЕ, что плагину гарантировано
одинаково между бэкендами; SQL внутри миграций плагина — уже нет (см.
core/db/migrations.py: resolve_migration_dir).
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Optional


class BaseDatabase(ABC):
    """Контракт БД, который видит плагин через ctx.db / ctx.core_db."""

    #: Имя бэкенда для логов/диагностики ("sqlite" | "postgres").
    backend_name: str = "base"

    @abstractmethod
    async def connect(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    async def execute(self, sql: str, params: tuple | dict[str, Any] = ()) -> Any:
        """Единичный write-стейтмент. Возвращаемое значение — курсор/результат, специфичный бэкенду."""
        ...

    @abstractmethod
    async def execute_returning(self, sql: str, params: tuple | dict[str, Any] = ()) -> Optional[Any]:
        """Write-запрос с RETURNING, возвращает первую строку атомарно."""
        ...

    @abstractmethod
    async def fetchone(self, sql: str, params: tuple | dict[str, Any] = ()) -> Optional[Any]:
        ...

    @abstractmethod
    async def fetchall(self, sql: str, params: tuple | dict[str, Any] = ()) -> list[Any]:
        ...

    @abstractmethod
    async def run_migrations(self, namespace: str, migration_dir: Path) -> bool:
        ...

    @abstractmethod
    async def verify_schema_version(self, namespace: str, expected_versions: set[int]) -> bool:
        ...

    @abstractmethod
    async def upsert_user(self, user_id: int, **fields: Any) -> None:
        ...

    @staticmethod
    def collect_migration_files(migration_dir: Path, namespace: str) -> list[tuple[int, Path]]:
        from core.db.migrations import collect_migration_files
        return collect_migration_files(migration_dir, namespace)
