"""
core/db/postgres_backend.py — PostgresDatabase: бэкенд БД поверх asyncpg.

Выбирается через config.json → database.backend = "postgres" (см.
core/config.py, core/db/factory.py). Реализует ТОТ ЖЕ контракт
BaseDatabase, что и core/db/sqlite_backend.py:SQLiteDatabase — плагин
пишет один и тот же await ctx.db.execute(...)/.fetchone(...)/...
независимо от бэкенда.

── Изоляция плагинов: схема, а не отдельная БД ────────────────────────
У SQLite-бэкенда изоляция "плагин не может задеть таблицы другого
плагина" достигается отдельным .db-файлом на каждый плагин. Для
Postgres аналог — не отдельная БД (CREATE DATABASE обычно требует
привилегий, которых на managed-Postgres типа RDS/Supabase/Timeweb
у обычного пользователя нет), а отдельная СХЕМА внутри одной БД:
каждый плагин получает CREATE SCHEMA IF NOT EXISTS "<sanitized_name>",
и его пул соединений подключается с search_path, выставленным ИМЕННО
на эту схему — плагин физически видит только свои таблицы (запрос без
явного указания схемы резолвится в его search_path), совершенно как с
отдельным файлом у SQLite.

Имя схемы санитизируется (sanitize_schema_name) — manifest.json → name
плагина не обязан быть валидным идентификатором Postgres (могут быть
дефисы, кириллица, что угодно); санитизация детерминирована и та же
самая при каждом запуске, так что схема не "переезжает" между
рестартами.

── Почему пул, а не один writer + читатели, как у SQLite ─────────────
Ограничение "один писатель" — особенность именно SQLite (файловая
блокировка). Postgres — полноценный MVCC: параллельные записи от
разных соединений — нормальный, поддерживаемый режим работы, отдельная
сериализация через свой asyncio.Lock тут не нужна и только вредила бы
throughput'у. Поэтому здесь один пул (asyncpg.Pool), read и write
запросы берут из него соединение как обычно; конфликты записи (если
случатся) — стандартная работа MVCC/isolation level Postgres, а не
что-то, что нужно предотвращать на уровне этого класса.

── Плейсхолдеры ──────────────────────────────────────────────────────
Остальной код проекта (core/database.py, миграции плагинов, PLUGIN_API.md)
исторически пишет запросы в SQLite-стиле: "?" позиционные или ":name"
именованные. asyncpg понимает только "$1, $2, ...". _to_asyncpg()
переводит один в другой на лету (см. ниже) — так один и тот же текст
запроса, если он не использует SQLite-специфичный SQL (см. предупреждение
в core/db/migrations.py про AUTOINCREMENT/INTEGER), можно направить в
любой бэкенд без переписывания вызывающего кода плагина.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from core.db.base import BaseDatabase
from core.db.migrations import (
    SQL_LITERAL_OR_COMMENT_RE,
    collect_migration_files,
    split_sql_statements,
)
from core.logger import get_logger

logger = get_logger("database")

_CREATE_SCHEMA_VERSION = """
CREATE TABLE IF NOT EXISTS schema_version (
    id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    namespace   TEXT    NOT NULL,
    version     INTEGER NOT NULL,
    applied_at  TEXT    NOT NULL,
    name        TEXT    NOT NULL,
    UNIQUE(namespace, version)
);
"""

_SCHEMA_NAME_RE = re.compile(r"[^a-z0-9_]+")
_QUESTION_MARK_RE = re.compile(r"\?")
_NAMED_PARAM_RE = re.compile(r":([A-Za-z_][A-Za-z0-9_]*)")


def sanitize_schema_name(name: str) -> str:
    """
    Приводит произвольное имя плагина к валидному Postgres-идентификатору:
    нижний регистр, только [a-z0-9_], не может начинаться с цифры,
    максимум 63 байта (лимит Postgres на длину идентификатора).

    Детерминировано — одно и то же имя плагина всегда даёт одну и ту же
    схему, так что миграции между рестартами не "теряются".
    """
    lowered = name.strip().lower()
    cleaned = _SCHEMA_NAME_RE.sub("_", lowered).strip("_")
    if not cleaned:
        raise ValueError(f"Имя «{name}» не удалось привести к имени схемы Postgres.")
    if cleaned[0].isdigit():
        cleaned = f"p_{cleaned}"
    return cleaned[:63]


def _to_asyncpg(sql: str, params: tuple | dict[str, Any]) -> tuple[str, list[Any]]:
    """Переводит SQLite-стиль плейсхолдеров (? / :name) в $1.. для asyncpg."""
    if isinstance(params, dict):
        return _convert_named(sql, params)
    return _convert_positional(sql, params)


def _convert_positional(sql: str, params: tuple) -> tuple[str, list[Any]]:
    out: list[str] = []
    pos = 0
    n = len(sql)
    idx = 0
    while pos < n:
        skip_m = SQL_LITERAL_OR_COMMENT_RE.match(sql, pos)
        if skip_m:
            out.append(skip_m.group(0))
            pos = skip_m.end()
            continue
        next_skip = SQL_LITERAL_OR_COMMENT_RE.search(sql, pos)
        search_end = next_skip.start() if next_skip else n

        last = pos
        for m in _QUESTION_MARK_RE.finditer(sql, pos, search_end):
            out.append(sql[last:m.start()])
            idx += 1
            out.append(f"${idx}")
            last = m.end()
        out.append(sql[last:search_end])
        pos = search_end

    if idx != len(params):
        raise ValueError(
            f"Запрос ожидает {idx} позиционных параметров, передано {len(params)}."
        )
    return "".join(out), list(params)


def _convert_named(sql: str, params: dict[str, Any]) -> tuple[str, list[Any]]:
    out: list[str] = []
    pos = 0
    n = len(sql)
    name_to_idx: dict[str, int] = {}
    args: list[Any] = []
    while pos < n:
        skip_m = SQL_LITERAL_OR_COMMENT_RE.match(sql, pos)
        if skip_m:
            out.append(skip_m.group(0))
            pos = skip_m.end()
            continue
        next_skip = SQL_LITERAL_OR_COMMENT_RE.search(sql, pos)
        search_end = next_skip.start() if next_skip else n

        last = pos
        for m in _NAMED_PARAM_RE.finditer(sql, pos, search_end):
            name = m.group(1)
            out.append(sql[last:m.start()])
            if name not in name_to_idx:
                if name not in params:
                    raise KeyError(f"Именованный параметр «:{name}» не передан в params.")
                name_to_idx[name] = len(args) + 1
                args.append(params[name])
            out.append(f"${name_to_idx[name]}")
            last = m.end()
        out.append(sql[last:search_end])
        pos = search_end

    return "".join(out), args


class PostgresDatabase(BaseDatabase):
    """Бэкенд БД поверх asyncpg. Одна схема на неймспейс (ядро или плагин) внутри общей БД."""

    backend_name = "postgres"

    def __init__(
        self,
        dsn: str,
        *,
        schema: str,
        pool_min_size: int = 1,
        pool_max_size: int = 5,
    ) -> None:
        self.dsn = dsn
        self.schema = sanitize_schema_name(schema)
        self._pool_min_size = pool_min_size
        self._pool_max_size = pool_max_size
        self._pool: Optional[Any] = None  # asyncpg.Pool — импортируется лениво в connect()

    # ── Жизненный цикл ───────────────────────────────────────

    async def connect(self) -> None:
        try:
            import asyncpg
        except ImportError as exc:
            raise RuntimeError(
                "database.backend=\"postgres\" в config.json, но пакет asyncpg не "
                "установлен. Поставьте его: pip install asyncpg --break-system-packages "
                "(на Termux может понадобиться clang: pkg install clang)."
            ) from exc

        # Схема должна существовать ДО того, как пул соединений начнёт
        # подключаться с search_path на неё — иначе первое же соединение
        # из пула упадёт (или молча уедет в public, если схемы нет и
        # Postgres откатится на следующий элемент search_path).
        bootstrap_conn = await asyncpg.connect(self.dsn)
        try:
            await bootstrap_conn.execute(f'CREATE SCHEMA IF NOT EXISTS "{self.schema}"')
        finally:
            await bootstrap_conn.close()

        self._pool = await asyncpg.create_pool(
            self.dsn,
            min_size=self._pool_min_size,
            max_size=self._pool_max_size,
            server_settings={"search_path": self.schema},
        )
        logger.info(
            f"[postgres] Подключено к схеме «{self.schema}» "
            f"(pool {self._pool_min_size}..{self._pool_max_size})."
        )

    async def close(self) -> None:
        if self._pool is not None:
            await self._pool.close()
            self._pool = None
            logger.info(f"[postgres] Пул для схемы «{self.schema}» закрыт.")

    @property
    def pool(self) -> Any:
        if self._pool is None:
            raise RuntimeError("База данных не подключена.")
        return self._pool

    # ── Базовые операции ─────────────────────────────────────

    async def execute(self, sql: str, params: tuple | dict[str, Any] = ()) -> Any:
        converted_sql, args = _to_asyncpg(sql, params)
        async with self.pool.acquire() as conn:
            return await conn.execute(converted_sql, *args)

    async def execute_returning(self, sql: str, params: tuple | dict[str, Any] = ()) -> Optional[Any]:
        converted_sql, args = _to_asyncpg(sql, params)
        async with self.pool.acquire() as conn:
            return await conn.fetchrow(converted_sql, *args)

    async def fetchone(self, sql: str, params: tuple | dict[str, Any] = ()) -> Optional[Any]:
        converted_sql, args = _to_asyncpg(sql, params)
        async with self.pool.acquire() as conn:
            return await conn.fetchrow(converted_sql, *args)

    async def fetchall(self, sql: str, params: tuple | dict[str, Any] = ()) -> list[Any]:
        converted_sql, args = _to_asyncpg(sql, params)
        async with self.pool.acquire() as conn:
            return await conn.fetch(converted_sql, *args)

    async def _run_in_transaction(self, statements: list[tuple[str, tuple | dict[str, Any]]]) -> None:
        async with self.pool.acquire() as conn:
            async with conn.transaction():
                for sql, params in statements:
                    converted_sql, args = _to_asyncpg(sql, params)
                    await conn.execute(converted_sql, *args)

    # ── Миграции ─────────────────────────────────────────────

    async def _ensure_schema_version_table(self) -> bool:
        try:
            await self._run_in_transaction([(_CREATE_SCHEMA_VERSION, ())])
            return True
        except Exception as exc:
            logger.error(f"[postgres] Не удалось создать schema_version: {exc}", exc_info=True)
            return False

    async def run_migrations(self, namespace: str, migration_dir: Path) -> bool:
        if not await self._ensure_schema_version_table():
            return False

        row = await self.fetchone(
            "SELECT COALESCE(MAX(version), 0) AS v FROM schema_version WHERE namespace = ?",
            (namespace,),
        )
        current: int = row["v"] if row else 0
        logger.info(f"[postgres][{namespace}] Текущая версия: {current}")

        if not migration_dir.exists():
            logger.info(f"[postgres][{namespace}] Директория миграций не найдена, пропуск.")
            return True

        try:
            all_files = collect_migration_files(migration_dir, namespace)
        except ValueError as exc:
            logger.error(str(exc))
            return False

        pending = [(v, f) for v, f in all_files if v > current]
        if not pending:
            logger.info(f"[postgres][{namespace}] Схема актуальна.")
            return True

        for version_num, migration_file in pending:
            logger.info(f"[postgres][{namespace}] Применяю {migration_file.name}...")
            try:
                sql_content = migration_file.read_text(encoding="utf-8")
                stmts = split_sql_statements(sql_content)
                now_iso = datetime.now(timezone.utc).isoformat()

                ops: list[tuple[str, tuple | dict[str, Any]]] = [(stmt, ()) for stmt in stmts]
                ops.append((
                    "INSERT INTO schema_version "
                    "(namespace, version, applied_at, name) VALUES (?, ?, ?, ?)",
                    (namespace, version_num, now_iso, migration_file.name),
                ))
                await self._run_in_transaction(ops)
                logger.info(
                    f"[postgres][{namespace}] Миграция {version_num:04d} применена. "
                    f"Версия: {version_num}"
                )
            except Exception as exc:
                logger.error(
                    f"[postgres][{namespace}] Ошибка при применении "
                    f"{migration_file.name}: {exc}",
                    exc_info=True,
                )
                return False

        return True

    async def verify_schema_version(self, namespace: str, expected_versions: set[int]) -> bool:
        rows = await self.fetchall(
            "SELECT version FROM schema_version WHERE namespace = ?", (namespace,)
        )
        applied = {r["version"] for r in rows}
        if applied == expected_versions:
            return True

        missing = sorted(expected_versions - applied)
        extra = sorted(applied - expected_versions)
        details = []
        if missing:
            details.append(f"не применены: {missing}")
        if extra:
            details.append(f"применены, но отсутствуют на диске: {extra}")
        logger.error(
            f"[postgres] Плагин «{namespace}» не загружен.\n"
            f"        Причина: версия схемы не совпадает ({'; '.join(details)}).\n"
            f"        Проверьте миграции плагина."
        )
        return False

    # ── Пользователи ─────────────────────────────────────────

    async def upsert_user(self, user_id: int, **fields: Any) -> None:
        now_iso = datetime.now(timezone.utc).isoformat()

        await self._run_in_transaction([
            (
                """
                INSERT INTO users (user_id, username, first_name, last_name,
                                   language_code, last_seen_at, created_at, updated_at)
                VALUES (:user_id, :username, :first_name, :last_name,
                        :language_code, :last_seen_at, :created_at, :updated_at)
                ON CONFLICT (user_id) DO UPDATE SET
                    username      = excluded.username,
                    first_name    = excluded.first_name,
                    last_name     = excluded.last_name,
                    language_code = excluded.language_code,
                    last_seen_at  = excluded.last_seen_at,
                    updated_at    = excluded.updated_at
                """,
                {
                    "user_id":       user_id,
                    "username":      fields.get("username"),
                    "first_name":    fields.get("first_name"),
                    "last_name":     fields.get("last_name"),
                    "language_code": fields.get("language_code"),
                    "last_seen_at":  now_iso,
                    "created_at":    now_iso,
                    "updated_at":    now_iso,
                },
            )
        ])
