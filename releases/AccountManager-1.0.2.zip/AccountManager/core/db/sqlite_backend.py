"""
core/db/sqlite_backend.py — SQLiteDatabase: бэкенд БД поверх aiosqlite.

Это исходная реализация Database из core/database.py (до появления
Postgres-бэкенда), перенесённая сюда и приведённая к контракту
core/db/base.py:BaseDatabase. Поведение НЕ изменилось — только
местоположение и имя класса (Database -> SQLiteDatabase; старое имя
Database остаётся доступно из core/database.py как алиас ради обратной
совместимости, см. докстринг там).

── Один writer, пул reader'ов ────────────────────────────────────────
У aiosqlite каждое соединение — это ОДИН свой фоновый поток и одна
FIFO-очередь задач: ЛЮБая операция на этом соединении (что чтение, что
запись) встаёт в эту очередь и ждёт своей позиции. Это эмпирически
проверено: одна запись на 200 000 строк заняла ~203мс, и 20 совсем не
связанных с ней чтений, запущенных ОДНОВРЕМЕННО, тоже заняли ~204мс
каждое — они физически стояли в очереди этого же потока, а WAL-режим
тут ни при чём, поскольку WAL даёт параллельность читателей и писателя
ТОЛЬКО между РАЗНЫМИ соединениями.

Поэтому здесь два вида соединений:
  - self._conn      — ОДИН writer. Через него же продолжают идти
                      RETURNING-запросы — их результат неотделим от
                      самой записи.
  - self._readers    — пул из reader_pool_size read-only соединений
                      (PRAGMA query_only=ON).

SQLite остаётся однописательным (ограничение самой SQLite) — все
операции записи сериализуются через self._write_lock.

── synchronous=NORMAL ────────────────────────────────────────────────
Официальная рекомендация SQLite для WAL-режима (~10x throughput против
FULL); риск — только последние несколько секунд не прошедших чекпоинт
транзакций при потере ПИТАНИЯ/падении ОС (не самого процесса). Для
гарантии durability даже при потере питания — Database(synchronous="FULL").

── Ограничение размера чисел ────────────────────────────────────────
SQLite INTEGER хранит целое произвольного размера (до 8 байт) — в
отличие от Postgres INTEGER (ровно 4 байта). Если план — когда-нибудь
переехать на Postgres-бэкенд для того же неймспейса, столбцы с
большими id (Telegram user_id уже превышает 2^31 у части аккаунтов)
должны быть BIGINT в postgres-варианте миграции, не INTEGER — это не
подхватится автоматически, см. core/db/migrations.py.
"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncIterator, Optional

import aiosqlite

from core.db.base import BaseDatabase
from core.db.migrations import collect_migration_files, split_sql_statements
from core.logger import get_logger

logger = get_logger("database")

# Путь к БД ядра по умолчанию.
DB_PATH = Path("database/database.db")

# Сколько read-only соединений держать в пуле по умолчанию.
_DEFAULT_READER_POOL_SIZE = 4

_CREATE_SCHEMA_VERSION = """
CREATE TABLE IF NOT EXISTS schema_version (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    namespace   TEXT    NOT NULL,
    version     INTEGER NOT NULL,
    applied_at  TEXT    NOT NULL,
    name        TEXT    NOT NULL,
    UNIQUE(namespace, version)
);
"""


class SQLiteDatabase(BaseDatabase):
    """Тонкая async-обёртка над aiosqlite: один writer + пул read-only reader'ов."""

    backend_name = "sqlite"

    def __init__(
        self,
        db_path: Path | str | None = None,
        *,
        reader_pool_size: int = _DEFAULT_READER_POOL_SIZE,
        synchronous: str = "NORMAL",
    ) -> None:
        self.db_path: Path = Path(db_path) if db_path is not None else DB_PATH

        self._conn: Optional[aiosqlite.Connection] = None
        self._write_lock = asyncio.Lock()

        self._reader_pool_size = reader_pool_size
        self._synchronous = synchronous
        self._readers: list[aiosqlite.Connection] = []
        self._reader_pool: Optional[asyncio.Queue[aiosqlite.Connection]] = None
        self._active_readers = 0
        self._readers_idle = asyncio.Event()
        self._readers_idle.set()

    # ── Жизненный цикл ───────────────────────────────────────

    async def connect(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        self._conn = await aiosqlite.connect(self.db_path, isolation_level=None)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA journal_mode=WAL")
        await self._conn.execute(f"PRAGMA synchronous={self._synchronous}")
        await self._conn.execute("PRAGMA foreign_keys=ON")

        self._reader_pool = asyncio.Queue()
        for _ in range(self._reader_pool_size):
            reader = await aiosqlite.connect(self.db_path, isolation_level=None)
            reader.row_factory = aiosqlite.Row
            await reader.execute("PRAGMA journal_mode=WAL")
            await reader.execute(f"PRAGMA synchronous={self._synchronous}")
            await reader.execute("PRAGMA query_only=ON")
            self._readers.append(reader)
            self._reader_pool.put_nowait(reader)

        logger.info(
            f"[sqlite] Соединение с базой данных «{self.db_path}» установлено "
            f"(1 writer + {self._reader_pool_size} reader, synchronous={self._synchronous})."
        )

    async def close(self) -> None:
        if self._reader_pool is not None:
            await self._readers_idle.wait()
        if self._conn:
            await self._conn.close()
            self._conn = None
        for reader in self._readers:
            await reader.close()
        self._readers.clear()
        self._reader_pool = None
        logger.info(f"[sqlite] Соединение с базой данных «{self.db_path}» закрыто.")

    # ── Базовые операции ─────────────────────────────────────

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("База данных не подключена.")
        return self._conn

    @asynccontextmanager
    async def _reader(self) -> AsyncIterator[aiosqlite.Connection]:
        if self._reader_pool is None:
            raise RuntimeError("База данных не подключена.")
        reader = await self._reader_pool.get()
        self._active_readers += 1
        self._readers_idle.clear()
        try:
            yield reader
        finally:
            self._active_readers -= 1
            self._reader_pool.put_nowait(reader)
            if self._active_readers == 0:
                self._readers_idle.set()

    async def execute(self, sql: str, params: tuple | dict[str, Any] = ()) -> aiosqlite.Cursor:
        async with self._write_lock:
            return await self.conn.execute(sql, params)

    async def execute_returning(self, sql: str, params: tuple | dict[str, Any] = ()) -> Optional[Any]:
        async with self._write_lock:
            async with self.conn.execute(sql, params) as cur:
                return await cur.fetchone()

    async def fetchone(self, sql: str, params: tuple | dict[str, Any] = ()) -> Optional[Any]:
        async with self._reader() as reader:
            async with reader.execute(sql, params) as cur:
                return await cur.fetchone()

    async def fetchall(self, sql: str, params: tuple | dict[str, Any] = ()) -> list[Any]:
        async with self._reader() as reader:
            async with reader.execute(sql, params) as cur:
                return await cur.fetchall()

    # ── Транзакционный хелпер ────────────────────────────────

    async def _run_in_transaction(self, statements: list[tuple[str, tuple | dict[str, Any]]]) -> None:
        async with self._write_lock:
            await self.conn.execute("BEGIN")
            try:
                for sql, params in statements:
                    await self.conn.execute(sql, params)
                await self.conn.execute("COMMIT")
            except Exception:
                try:
                    await self.conn.execute("ROLLBACK")
                except Exception:
                    logger.exception("[sqlite] Не удалось выполнить ROLLBACK после ошибки транзакции.")
                raise

    # ── Миграции ─────────────────────────────────────────────

    async def _ensure_schema_version_table(self) -> bool:
        try:
            await self._run_in_transaction([(_CREATE_SCHEMA_VERSION, ())])
            return True
        except Exception as exc:
            logger.error(f"[sqlite] Не удалось создать schema_version: {exc}", exc_info=True)
            return False

    async def run_migrations(self, namespace: str, migration_dir: Path) -> bool:
        if not await self._ensure_schema_version_table():
            return False

        row = await self.fetchone(
            "SELECT COALESCE(MAX(version), 0) FROM schema_version WHERE namespace = ?",
            (namespace,),
        )
        current: int = row[0] if row else 0
        logger.info(f"[sqlite][{namespace}] Текущая версия: {current}")

        if not migration_dir.exists():
            logger.info(f"[sqlite][{namespace}] Директория миграций не найдена, пропуск.")
            return True

        try:
            all_files = collect_migration_files(migration_dir, namespace)
        except ValueError as exc:
            logger.error(str(exc))
            return False

        pending = [(v, f) for v, f in all_files if v > current]
        if not pending:
            logger.info(f"[sqlite][{namespace}] Схема актуальна.")
            return True

        for version_num, migration_file in pending:
            logger.info(f"[sqlite][{namespace}] Применяю {migration_file.name}...")
            try:
                sql_content = migration_file.read_text(encoding="utf-8")
                stmts = split_sql_statements(sql_content)
                now_iso = datetime.now(timezone.utc).isoformat()

                ops: list[tuple[str, tuple | dict[str, Any]]] = [(stmt, ()) for stmt in stmts]
                ops.append((
                    "INSERT INTO schema_version "
                    "(namespace, version, applied_at, name) VALUES (?, ?, ?, ?)",
                    (namespace, version_num, now_iso, migration_file.name),
                ))
                await self._run_in_transaction(ops)
                logger.info(
                    f"[sqlite][{namespace}] Миграция {version_num:04d} применена. "
                    f"Версия: {version_num}"
                )
            except Exception as exc:
                logger.error(
                    f"[sqlite][{namespace}] Ошибка при применении "
                    f"{migration_file.name}: {exc}",
                    exc_info=True,
                )
                return False

        return True

    async def verify_schema_version(self, namespace: str, expected_versions: set[int]) -> bool:
        rows = await self.fetchall(
            "SELECT version FROM schema_version WHERE namespace = ?", (namespace,)
        )
        applied = {r["version"] for r in rows}
        if applied == expected_versions:
            return True

        missing = sorted(expected_versions - applied)
        extra = sorted(applied - expected_versions)
        details = []
        if missing:
            details.append(f"не применены: {missing}")
        if extra:
            details.append(f"применены, но отсутствуют на диске: {extra}")
        logger.error(
            f"[sqlite] Плагин «{namespace}» не загружен.\n"
            f"        Причина: версия схемы не совпадает ({'; '.join(details)}).\n"
            f"        Проверьте миграции плагина."
        )
        return False

    # ── Пользователи ─────────────────────────────────────────

    async def upsert_user(self, user_id: int, **fields: Any) -> None:
        now_iso = datetime.now(timezone.utc).isoformat()
        fields["last_seen_at"] = now_iso
        fields["updated_at"] = now_iso

        await self._run_in_transaction([
            (
                """
                INSERT INTO users (user_id, username, first_name, last_name,
                                   language_code, last_seen_at, created_at, updated_at)
                VALUES (:user_id, :username, :first_name, :last_name,
                        :language_code, :last_seen_at, :created_at, :updated_at)
                ON CONFLICT(user_id) DO UPDATE SET
                    username      = excluded.username,
                    first_name    = excluded.first_name,
                    last_name     = excluded.last_name,
                    language_code = excluded.language_code,
                    last_seen_at  = excluded.last_seen_at,
                    updated_at    = excluded.updated_at
                """,
                {
                    "user_id":       user_id,
                    "username":      fields.get("username"),
                    "first_name":    fields.get("first_name"),
                    "last_name":     fields.get("last_name"),
                    "language_code": fields.get("language_code"),
                    "last_seen_at":  now_iso,
                    "created_at":    now_iso,
                    "updated_at":    now_iso,
                },
            )
        ])
