"""
core/control_server.py — локальный control-сервер бота.

Даёт framework_manager.py (отдельный процесс) возможность командовать
уже запущенным ботом — сейчас: узнать, жив ли процесс, перезагрузить
один или все плагины, получить текущий статус. Без этого "restart на
лету" из отдельного CLI физически невозможен: процессы не разделяют
память, а polling бота не читает stdin никакого другого процесса.

TCP на 127.0.0.1, НЕ Unix-сокет — на Windows у asyncio ProactorEventLoop
(дефолтный event loop с Python 3.8) нет create_unix_server, даже когда
сама ОС Unix-сокеты умеет. Бот должен работать одинаково на
Windows/Linux/Termux, поэтому используется TCP-loopback — идентичное
поведение и API asyncio на всех трёх платформах, без ветвления по ОС.

Порт выбирает ОС (bind на порт 0) — фиксированный порт рисковал бы
конфликтом с чем-то ещё на машине. Реальный порт + PID записываются в
run/control.json при старте и удаляются при чистой остановке.
framework_manager.py по этому файлу узнаёт, куда подключаться, а по
УСПЕШНОМУ подключению (не по самому факту существования файла — он
мог остаться от нечистого завершения) — жив ли процесс на самом деле.

Протокол: одна JSON-строка — запрос, одна JSON-строка — ответ,
соединение на один запрос (никакой сессии/keep-alive — максимально
просто и без состояния на стороне сервера).

Команды: ping, reload (один плагин), reload_all, status, shutdown.

shutdown вызывает dp.stop_polling() — официальный, документированный,
кроссплатформенный способ аккуратно остановить start_polling() ИЗ
ТОГО ЖЕ процесса (проверено эмпирически: start_polling() после этого
корректно возвращается, дальше отрабатывает finally в main.py). Не
полагаемся на OS-сигналы: у aiogram сам add_signal_handler(SIGTERM,...)
на Windows бросает NotImplementedError и молча подавляется (сигналы
там в принципе не поддержаны так, как на Linux/Termux) — то есть
сигнал-based graceful stop ненадёжен именно там, где это нужнее всего
(кроссплатформенность Windows/Linux/Termux). Control-сокет работает
одинаково везде, поэтому именно через него — единственный надёжный
путь к "останови сам себя" на всех трёх платформах.

Доверие: сервер слушает только 127.0.0.1 — то есть команды может
слать только процесс на этой же машине. Отдельной аутентификации нет
— тот же trust model, что и у core/patches.py (безопасность здесь —
устойчивость и обратимость, а не защита от локального пользователя
той же машины).
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Awaitable, Callable

import core
from core.logger import get_logger
from core.plugin_loader import PluginLoader

if TYPE_CHECKING:
    # Только для тайп-хинта ControlServer.__init__ — реальный импорт
    # aiogram (20+ сек на Termux, см. докстринг модуля) здесь не нужен:
    # сам класс используется только внутри main.py, который aiogram и
    # так импортирует полностью. framework_manager.py (CLI) дёргает отсюда
    # только read_control_file(), а с `from __future__ import
    # annotations` (см. выше) строковая аннотация "Dispatcher" в
    # рантайме не вычисляется — достаточно объявления под TYPE_CHECKING.
    from aiogram import Dispatcher

logger = get_logger("control_server")

CONTROL_DIR = Path("run")
CONTROL_FILE = CONTROL_DIR / "control.json"

Handler = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


class ControlServer:
    """Управляется из main.py: start() после загрузки плагинов, stop() в graceful shutdown."""

    def __init__(
        self,
        loader: PluginLoader,
        dp: Dispatcher,
        *,
        mode: str = "polling",
        stop_event: asyncio.Event | None = None,
    ) -> None:
        self._loader = loader
        self._dp = dp
        self._mode = mode
        # Нужен только при mode="webhook" — см. _handle_shutdown ниже и
        # main.py: в webhook-режиме нет dp.start_polling(), которое
        # можно было бы остановить через dp.stop_polling(), поэтому
        # main.py вместо этого ждёт stop_event.wait() в своём цикле
        # обслуживания aiohttp-сервера.
        self._stop_event = stop_event
        self._server: asyncio.base_events.Server | None = None
        self._handlers: dict[str, Handler] = {
            "ping": self._handle_ping,
            "reload": self._handle_reload,
            "reload_all": self._handle_reload_all,
            "status": self._handle_status,
            "shutdown": self._handle_shutdown,
        }

    async def start(self) -> None:
        self._server = await asyncio.start_server(
            self._handle_connection, host="127.0.0.1", port=0
        )
        port = self._server.sockets[0].getsockname()[1]

        CONTROL_DIR.mkdir(parents=True, exist_ok=True)
        CONTROL_FILE.write_text(
            json.dumps({"pid": os.getpid(), "port": port, "started_at": time.time()}),
            encoding="utf-8",
        )
        logger.info(f"Control-сервер запущен на 127.0.0.1:{port} (run/control.json).")

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        try:
            CONTROL_FILE.unlink()
        except FileNotFoundError:
            pass
        logger.info("Control-сервер остановлен.")

    # ── Обработка соединений ─────────────────────────────────

    async def _handle_connection(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        try:
            line = await asyncio.wait_for(reader.readline(), timeout=10.0)
            request = json.loads(line.decode("utf-8"))
            cmd = request.get("cmd")
            handler = self._handlers.get(cmd)
            if handler is None:
                response = {"ok": False, "error": f"неизвестная команда «{cmd}»"}
            else:
                response = await handler(request)
        except asyncio.TimeoutError:
            response = {"ok": False, "error": "таймаут ожидания запроса"}
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            response = {"ok": False, "error": f"некорректный запрос: {exc}"}
        except Exception as exc:
            logger.error("Ошибка обработки запроса control-сервера.", exc_info=True)
            response = {"ok": False, "error": f"внутренняя ошибка: {exc}"}

        try:
            writer.write((json.dumps(response) + "\n").encode("utf-8"))
            await writer.drain()
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass

    # ── Команды ───────────────────────────────────────────────

    async def _handle_ping(self, _request: dict[str, Any]) -> dict[str, Any]:
        return {"ok": True, "pid": os.getpid(), "core_version": core.__version__}

    async def _handle_reload(self, request: dict[str, Any]) -> dict[str, Any]:
        name = request.get("plugin")
        if not name:
            return {"ok": False, "error": "не указано имя плагина"}
        if name not in self._loader.known_plugin_names():
            return {"ok": False, "error": f"плагин «{name}» неизвестен"}
        success = await self._loader.reload_plugin(name)
        reason = self._loader._skip_reasons.get(name, "") if not success else ""
        return {"ok": success, "plugin": name, "reason": reason}

    async def _handle_reload_all(self, _request: dict[str, Any]) -> dict[str, Any]:
        results = await self._loader.reload_all()
        return {"ok": all(results.values()), "results": results}

    async def _handle_status(self, _request: dict[str, Any]) -> dict[str, Any]:
        # "ok" — ПОСЛЕДНИМ в распаковке: если snapshot когда-нибудь
        # обзаведётся собственным ключом "ok", он не должен молча
        # перезаписать этот хардкод (порядок ключей в dict-литерале —
        # последний побеждает).
        return {**self._loader.status_snapshot(), "ok": True}

    async def _handle_shutdown(self, _request: dict[str, Any]) -> dict[str, Any]:
        # Отвечаем "ok" ДО остановки — после сигнала на остановку этот
        # же процесс уже занят graceful shutdown в main.py, отвечать
        # будет некому. Сам сигнал запускаем с небольшой задержкой,
        # чтобы точно успеть сначала отправить ответ.
        #
        # В polling-режиме (mode="polling") сигнал — это
        # dp.stop_polling(), как и раньше. В webhook-режиме
        # start_polling() вообще не вызывается — main.py вместо этого
        # ждёт stop_event.wait() внутри своего цикла обслуживания
        # aiohttp-сервера, поэтому здесь просто взводим тот event.
        loop = asyncio.get_running_loop()

        async def _do_stop() -> None:
            if self._mode == "webhook":
                if self._stop_event is not None:
                    self._stop_event.set()
                else:
                    logger.error(
                        "control-сервер: mode=\"webhook\", но stop_event не передан "
                        "в ControlServer — команда shutdown не может остановить процесс."
                    )
            else:
                await self._dp.stop_polling()

        loop.call_later(0.1, lambda: asyncio.ensure_future(_do_stop()))
        return {"ok": True}


def read_control_file() -> dict[str, Any] | None:
    """Читает run/control.json, если есть. Не гарантирует, что процесс жив — только что файл есть."""
    try:
        return json.loads(CONTROL_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return None
