"""
core/settings.py — настройки САМОГО МЕНЕДЖЕРА фреймворка (не бота).

configs/settings.json — "кфг менеджера" (см. ТЗ): язык интерфейса,
разрешён ли Nightly/Beta канал и в какой канал переключаться при OTA,
спрашивать ли подтверждение перед действиями, уровень логгера ДЛЯ
САМОГО МЕНЕДЖЕРА (не бота — у бота свой configs/config.json ->
log_level, см. core/config.py), режим разработчика и отключение
проверки подписи/хеша сборки (core/manifest.py).

Отличие от core/config.py (Config бота): Config читается один раз на
процесс main.py и требует валидный BOT_TOKEN — без него бот не
стартует. ManagerSettings читает framework_manager.py при каждом запуске
(отдельный короткоживущий процесс на каждую команду или TUI-сессию) и
полностью опционален — файла может не быть вовсе, тогда действуют
дефолты ниже, ровно как у config.json бота при его отсутствии.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Optional

SETTINGS_DIR = Path("configs")
SETTINGS_PATH = SETTINGS_DIR / "settings.json"

VALID_LOGGER_LEVELS: tuple[str, ...] = ("Disabled", "Debug", "Info", "Warning", "Error", "Critical")
VALID_BUILD_CHANNELS: tuple[str, ...] = ("Stable", "Beta", "Nightly")
VALID_LANGUAGES: tuple[str, ...] = ("rus", "eng")

# "Disabled" -> None означает "не настраивать файловый/консольный логгер
# менеджера вовсе" — не то же самое, что logging.CRITICAL (сообщения
# уровня CRITICAL всё ещё писались бы). Используется в framework_manager.py
# при инициализации логирования самого инструмента (не бота).
LOGGER_LEVEL_TO_LOGGING: dict[str, Optional[str]] = {
    "Disabled": None,
    "Debug": "DEBUG",
    "Info": "INFO",
    "Warning": "WARNING",
    "Error": "ERROR",
    "Critical": "CRITICAL",
}


def _as_bool(value: Any, default: bool = False) -> bool:
    """
    Та же логика, что core/config.py::_as_bool (bool("false") == True —
    классическая ловушка). Продублирована намеренно — двухстрочный
    хелпер не стоит того, чтобы связывать settings.py с config.py.
    """
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in ("true", "1", "yes", "on", "да"):
            return True
        if lowered in ("false", "0", "no", "off", "нет", ""):
            return False
        return default
    return bool(value)


@dataclass
class ManagerSettings:
    language: str = "rus"
    allow_nightly_beta: bool = False
    build_channel: str = "Stable"
    confirm_actions: bool = True
    logger_level: str = "Info"
    dev_mode: bool = False
    disable_signature_and_hash_check: bool = False

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def load_settings(path: Path = SETTINGS_PATH) -> ManagerSettings:
    """
    Файла может не быть — тогда чистые дефолты (как config.json бота).
    Невалидное ОТДЕЛЬНОЕ поле откатывается к дефолту ЭТОГО поля, а не
    всего файла целиком — одна опечатка (например, build_channel:
    "stabel") не должна тихо обнулить остальные настройки пользователя.
    """
    defaults = ManagerSettings()
    if not path.exists():
        return defaults
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return defaults
    if not isinstance(raw, dict):
        return defaults

    language = str(raw.get("language", defaults.language)).strip().lower()
    if language not in VALID_LANGUAGES:
        language = defaults.language

    build_channel = str(raw.get("build_channel", defaults.build_channel)).strip().capitalize()
    if build_channel not in VALID_BUILD_CHANNELS:
        build_channel = defaults.build_channel

    logger_level = str(raw.get("logger_level", defaults.logger_level)).strip().capitalize()
    if logger_level not in VALID_LOGGER_LEVELS:
        logger_level = defaults.logger_level

    return ManagerSettings(
        language=language,
        allow_nightly_beta=_as_bool(raw.get("allow_nightly_beta"), defaults.allow_nightly_beta),
        build_channel=build_channel,
        confirm_actions=_as_bool(raw.get("confirm_actions"), defaults.confirm_actions),
        logger_level=logger_level,
        dev_mode=_as_bool(raw.get("dev_mode"), defaults.dev_mode),
        disable_signature_and_hash_check=_as_bool(
            raw.get("disable_signature_and_hash_check"), defaults.disable_signature_and_hash_check
        ),
    )


def save_settings(settings: ManagerSettings, path: Path = SETTINGS_PATH) -> None:
    """Создаёт configs/ при необходимости (параллель bootstrap.py, но по требованию, а не только при старте бота)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(settings.as_dict(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
