"""
core/plugin_loader.py — загрузчик плагинов.

Пайплайн:
  1. scan()          — сканирует plugins/, читает manifest.json
  2. check_core_compat() — проверяет manifest.json -> core_version
                        против core.__version__ (core/__init__.py)
  3. check_pip_deps() — проверяет pip-зависимости (наличие И версию,
                        см. core/dependencies.py) через importlib.metadata,
                        сообщает о конфликтах версий между плагинами
  4. resolve_order()  — распространяет SKIPPED (в т.ч. по несовпадению
                        версии зависимого плагина), топосортирует по группам
  5. load_plugins()   — миграции → PluginContext → setup()
  6. teardown_all()   — teardown() в обратном порядке при остановке,
                        плюс откат hooks/patches/services плагина
  7. reload_plugin() / reload_all() — teardown + повторная загрузка
                        плагина(ов) без перезапуска процесса (см.
                        докстринг reload_plugin)

С этой версии setup()/teardown() плагина получают не 4 позиционных
параметра (dp, bot, db, config), а один PluginContext — см.
core/plugin_context.py. Там же лежат ctx.hooks/ctx.patches/ctx.services,
которыми плагин может подписываться на события ядра и безопасно
патчить его (core/hooks.py, core/patches.py, core/services.py).

── БД: одна на плагин, а не одна на всех ──────────────────────────
Раньше все плагины и ядро мигрировали в ОДИН shared Database (db,
переданный в load_plugins), различаясь только namespace в
schema_version. Теперь PluginLoader создаёт и подключает ОТДЕЛЬНЫЙ
экземпляр Database на каждый плагин — файл
<plugin_dir>/database/database.db — и именно его кладёт в ctx.db (а
БД ядра, тот самый прежний общий db, теперь доступна как ctx.core_db,
см. core/plugin_context.py). Миграции плагина (<plugin_dir>/migrations/,
если есть) применяются к ЕГО СОБСТВЕННОЙ БД, не к БД ядра.

Экземпляры Database на плагины кэшируются в self._plugin_dbs — один
раз подключены, дальше живут, пока не будет вызван
close_all_plugin_databases() (это делает вызывающий код, например
main.py, при остановке процесса — симметрично db.close() для БД
ядра). reload_plugin() переиспользует уже подключённый экземпляр, а не
переподключается — reload меняет только код плагина, соединение с его
БД не рвётся.

Зависимости в manifest.json (dependencies.pip / dependencies.plugins)
теперь могут содержать условие версии в формате PEP 440 — том же, что
requirements.txt: "aiogram>=3.15,<4.0", "antispam>=1.0.0". Строка без
условия по-прежнему означает «любая версия» — старые manifest.json не
требуют правки. Разбор и проверка — core/dependencies.py.

manifest.json -> core_version — то же самое, но для совместимости с
самим ядром: "core_version": ">=2.0.0,<3.0.0". Поле необязательно —
без него плагин считается совместимым с любой версией ядра (как
раньше, когда этой проверки не было вовсе).
"""
from __future__ import annotations

import importlib
import importlib.util
import itertools
import json
import sys
from collections import deque
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

import core
from core.config import Config
from core.db.base import BaseDatabase
from core.db.factory import create_database
from core.db.migrations import collect_migration_files, resolve_migration_dir
from core.dependencies import (
    DependencySpec,
    DependencySpecError,
    check_core_version,
    check_pip_dependency,
    check_plugin_version,
    parse_dependency_list,
    parse_specifier_only,
    report_pip_conflicts,
)
from core.hooks import HookBus
from core.logger import get_logger
from core.patches import PatchManager
from core.plugin_context import PluginContext
from core.scheduler import Scheduler
from core.services import ServiceRegistry
from plugins.base import BasePlugin

if TYPE_CHECKING:
    # Только тайп-хинты (self._dp/_bot, load_plugins()) — сами объекты
    # PluginLoader не создаёт и не вызывает, только сохраняет и
    # прокидывает дальше. Реальный импорт aiogram (20+ сек на Termux)
    # не нужен для framework_manager.py, который тянет этот модуль ради
    # PluginLoader; с `from __future__ import annotations` аннотации,
    # включая переменные внутри __init__, в рантайме не вычисляются.
    from aiogram import Bot, Dispatcher

logger = get_logger("plugin_loader")

_reload_counter = itertools.count(1)

# reader_pool_size для БД одного плагина. Меньше, чем у БД ядра
# (core/database.py: _DEFAULT_READER_POOL_SIZE=4) — БД ядра принимает
# трафик от middleware на КАЖДЫЙ апдейт плюс запросы всех плагинов,
# а БД отдельного плагина — только его собственную, обычно куда более
# редкую нагрузку. При желании конкретному плагину, где это не так,
# ничего не мешает завести собственный Database внутри самого плагина.
_PLUGIN_DB_READER_POOL_SIZE = 2


# ═══════════════════════════════════════════════════════════════
# PluginRecord
# ═══════════════════════════════════════════════════════════════

class PluginRecord:
    """Метаданные и runtime-состояние одного плагина."""

    def __init__(self, name: str, path: Path, manifest: dict) -> None:
        self.name = name
        self.path = path
        self.manifest = manifest
        self.instance: Optional[BasePlugin] = None
        self.module_name: Optional[str] = None  # для очистки sys.modules при reload

    @property
    def version(self) -> str:
        return self.manifest.get("version", "0.0.0")

    @property
    def author(self) -> str:
        return self.manifest.get("author", "")

    @property
    def description(self) -> str:
        return self.manifest.get("description", "")

    @property
    def repository_url(self) -> str:
        return self.manifest.get("repository_url", "")

    @property
    def core_version_raw(self) -> str:
        """Пустая строка — плагин не заявляет требований к ядру (совместим с любой)."""
        return self.manifest.get("core_version", "")

    @property
    def load_order(self) -> str:
        return self.manifest.get("load_order", "after_bot")

    @property
    def plugin_deps_raw(self) -> list[str]:
        return self.manifest.get("dependencies", {}).get("plugins", [])

    @property
    def pip_deps_raw(self) -> list[str]:
        return self.manifest.get("dependencies", {}).get("pip", [])

    def plugin_deps(self) -> list[DependencySpec]:
        """Может бросить DependencySpecError на некорректной строке в manifest.json."""
        return parse_dependency_list(self.plugin_deps_raw)

    def pip_deps(self) -> list[DependencySpec]:
        """Может бросить DependencySpecError на некорректной строке в manifest.json."""
        return parse_dependency_list(self.pip_deps_raw)

    @property
    def after_target(self) -> Optional[str]:
        """Возвращает имя таргета если load_order == 'after:<name>'."""
        lo = self.load_order
        return lo[6:].strip() if lo.startswith("after:") else None


# ═══════════════════════════════════════════════════════════════
# Вспомогательные функции
# ═══════════════════════════════════════════════════════════════


class PluginClassError(Exception):
    """plugin.py не содержит ровно один однозначный класс плагина."""


def _load_plugin_class(plugin_path: Path, *, module_name: str | None = None) -> Optional[type]:
    """
    Импортирует plugin.py и возвращает класс плагина.

    Порядок разрешения (по убыванию приоритета):
      1. Явный module-level атрибут `PLUGIN = ИмяКласса` — используется
         как есть, без всякой магии. Рекомендуемый способ для плагинов
         сложнее тривиальных (несколько классов, миксины, хелперы).
      2. Если PLUGIN не задан — ищутся конкретные подклассы BasePlugin,
         ОПРЕДЕЛЁННЫЕ ИМЕННО В ЭТОМ МОДУЛЕ (__module__ проверяется, чтобы
         импортированные для тайп-хинтов чужие классы не попадали в
         кандидаты). Если найден РОВНО один — используется он.
      3. Ноль или больше одного кандидата без PLUGIN — PluginClassError
         с понятным сообщением (раньше здесь молча брался «первый
         попавшийся» подкласс в алфавитном порядке dir(module), что
         зависело от имён классов и было легко сломать, добавив в
         plugin.py второй вспомогательный класс).

    module_name позволяет заново импортировать тот же файл под другим
    именем (нужно для reload_plugin — иначе Python возьмёт модуль из
    sys.modules и код не обновится).

    Модуль регистрируется в sys.modules ДО exec_module — как это делает
    сам importlib при обычных импортах. Без этого, если где-то ещё в
    коде (или в другом плагине) встретится обычный
    `import plugins.<name>.plugin`, Python не найдёт его в sys.modules
    и выполнит файл ЗАНОВО — в итоге получится ВТОРОЙ, отдельный
    объект класса с тем же именем, и `isinstance()`/сравнение классов
    между «тем, что загрузил PluginLoader» и «тем, что импортировали
    обычным import» неожиданно вернёт False. Также это стандартная
    практика для pickle/inspect и прочей интроспекции, ожидающей
    module.__name__ в sys.modules.
    Если exec_module падает — незавершённая запись убирается из
    sys.modules, чтобы не оставить там наполовину инициализированный
    модуль (обычный источник путаницы при повторных попытках импорта).
    """
    plugin_file = plugin_path / "plugin.py"
    if not plugin_file.exists():
        return None

    name = module_name or f"plugins.{plugin_path.name}.plugin"
    spec = importlib.util.spec_from_file_location(name, plugin_file)
    if spec is None or spec.loader is None:
        return None

    # Python кеширует байткод в __pycache__/*.pyc, провалидированный по
    # (mtime, размер) исходника. Плагины могут перезагружаться
    # (reload_plugin) чаще, чем меняется секундная сетка mtime файловой
    # системы — тогда обычный механизм импорта решит, что файл "не
    # менялся", и подсунет СТАРЫЙ закешированный код. Поэтому здесь: (1)
    # снимаем уже существующий кэш именно для этого файла перед импортом,
    # и (2) не даём записать новый на время этого конкретного exec_module
    # — каждая загрузка плагина всегда компилируется заново из того, что
    # реально лежит на диске прямо сейчас.
    try:
        cached = importlib.util.cache_from_source(str(plugin_file))
        Path(cached).unlink(missing_ok=True)
    except (OSError, ValueError):
        pass

    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    dont_write_bytecode_before = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)  # type: ignore[union-attr]
    except BaseException:
        sys.modules.pop(name, None)
        raise
    finally:
        sys.dont_write_bytecode = dont_write_bytecode_before

    explicit = getattr(module, "PLUGIN", None)
    if explicit is not None:
        if not (isinstance(explicit, type) and issubclass(explicit, BasePlugin)):
            raise PluginClassError(
                f"«{plugin_path.name}»: module-level PLUGIN задан, но это не "
                f"подкласс BasePlugin."
            )
        return explicit

    candidates = [
        attr for attr in vars(module).values()
        if (
            isinstance(attr, type)
            and issubclass(attr, BasePlugin)
            and attr is not BasePlugin
            and attr.__module__ == module.__name__
        )
    ]
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) == 0:
        return None
    names = ", ".join(c.__name__ for c in candidates)
    raise PluginClassError(
        f"«{plugin_path.name}»: найдено несколько подклассов BasePlugin "
        f"({names}) и не задан PLUGIN — непонятно, какой из них "
        f"использовать. Добавьте в plugin.py строку `PLUGIN = {candidates[0].__name__}`."
    )


def _kahn_sort(
    nodes: set[str],
    predecessors: dict[str, set[str]],
) -> tuple[list[str], set[str]]:
    """
    Топологическая сортировка алгоритмом Кана.
    Возвращает (порядок, участники_цикла).
    Детерминированный порядок: узлы с одинаковым in-degree сортируются лексически.
    """
    successors: dict[str, set[str]] = {n: set() for n in nodes}
    in_degree: dict[str, int] = {n: 0 for n in nodes}

    for node in nodes:
        for pred in predecessors.get(node, set()):
            if pred in nodes:          # только внутригрупповые рёбра
                successors[pred].add(node)
                in_degree[node] += 1

    queue: deque[str] = deque(sorted(n for n in nodes if in_degree[n] == 0))
    order: list[str] = []

    while queue:
        node = queue.popleft()
        order.append(node)
        for succ in sorted(successors[node]):
            in_degree[succ] -= 1
            if in_degree[succ] == 0:
                queue.append(succ)

    cycle_nodes = nodes - set(order)
    return order, cycle_nodes


# ═══════════════════════════════════════════════════════════════
# PluginLoader
# ═══════════════════════════════════════════════════════════════

class PluginLoader:

    def __init__(
        self, hooks: HookBus, patches: PatchManager, services: ServiceRegistry, scheduler: Scheduler
    ) -> None:
        self._records: dict[str, PluginRecord] = {}
        self._skipped: set[str] = set()
        self._skip_reasons: dict[str, str] = {}  # для status/deps — почему пропущен
        self._load_order: list[str] = []   # финальный порядок setup()

        self.hooks = hooks
        self.patches = patches
        self.services = services
        self.scheduler = scheduler

        # Сохраняются при первом load_plugins(), нужны для reload_plugin().
        self._dp: Optional[Dispatcher] = None
        self._bot: Optional[Bot] = None
        self._db: Optional[BaseDatabase] = None  # БД ЯДРА (ctx.core_db у плагинов)
        self._config: Optional[Config] = None

        # Персональная БД каждого плагина: имя плагина -> подключённый
        # BaseDatabase (SQLiteDatabase или PostgresDatabase — зависит от
        # config.database.backend). Заполняется лениво в
        # _get_plugin_database() при первой загрузке/reload плагина и
        # переиспользуется дальше — см. докстринг модуля.
        self._plugin_dbs: dict[str, BaseDatabase] = {}

        # Сохраняются при scan() — нужны reload_plugin(), чтобы заново
        # проверить коллизию имени прямо перед перезагрузкой, а не
        # доверять устаревшей self._records[name] (см. _scan_manifests).
        self._plugins_dir: Optional[Path] = None
        self._disabled_plugins: list[str] = []

    # ── Общий хелпер логирования отказа ──────────────────────

    def _skip(self, name: str, reason: str, *, level: str = "warning") -> None:
        log = logger.error if level == "error" else logger.warning
        log(f"Плагин «{name}» не инициализирован.\n        Причина: {reason}")
        self._skipped.add(name)
        self._skip_reasons[name] = reason

    # ── 1. Сканирование ──────────────────────────────────────

    def _scan_manifests(
        self, plugins_dir: Path, disabled_plugins: list[str]
    ) -> dict[str, list[PluginRecord]]:
        """
        Читает manifest.json из каждой папки plugins_dir, группируя
        по manifest.json → "name" (НЕ по имени папки). Возвращает ВСЕ
        найденные записи на каждое имя без исключения совпадений —
        это работа вызывающего кода (scan()/reload_plugin()) решить,
        что делать при len(records) > 1.

        Вынесено отдельно от scan(), чтобы reload_plugin() мог
        ПОВТОРНО проверить именно эту логику прямо перед перезагрузкой
        конкретного плагина — иначе reload_plugin полагался бы на
        self._records[name], которая при коллизии имени содержит
        ПРОИЗВОЛЬНУЮ из конфликтующих записей (только для отображения
        в status, см. scan()) и тихо перезагрузил бы её как ни в чём
        не бывало, обходя всю защиту от коллизий стороной.
        """
        candidates: dict[str, list[PluginRecord]] = {}

        for plugin_dir in sorted(plugins_dir.iterdir()):
            if not plugin_dir.is_dir():
                continue
            manifest_path = plugin_dir / "manifest.json"
            if not manifest_path.exists():
                continue

            try:
                manifest: dict = json.loads(
                    manifest_path.read_text(encoding="utf-8")
                )
            except json.JSONDecodeError as exc:
                logger.error(
                    f"Ошибка чтения manifest.json в «{plugin_dir.name}»: {exc}"
                )
                continue

            name: str = manifest.get("name", plugin_dir.name)

            if not manifest.get("enabled", True):
                logger.debug(
                    f"Плагин «{name}» отключён автором (enabled: false)."
                )
                continue

            if name in disabled_plugins:
                logger.info(
                    f"Плагин «{name}» отключён пользователем (disabled_plugins)."
                )
                continue

            # ── Верификация подписи плагина ──────────────────────────────
            # Выполняется только если sandbox.verify_plugin_signatures=true.
            # Результат: OK → продолжаем; ошибка → пропуск с причиной.
            if getattr(getattr(self, "_config", None), "sandbox", None) is not None:
                sb = self._config.sandbox  # type: ignore[union-attr]
                if sb.verify_plugin_signatures:
                    from core.plugin_verifier import verify_plugin
                    vr = verify_plugin(plugin_dir)
                    if not vr.ok:
                        if not vr.has_sig and sb.allow_unsigned_plugins:
                            logger.warning(
                                f"Плагин «{name}» не подписан — разрешён "
                                f"по allow_unsigned_plugins=true."
                            )
                        else:
                            logger.error(
                                f"Плагин «{name}» заблокирован: {vr.reason}"
                            )
                            self._skip(name, vr.reason)
                            continue

            candidates.setdefault(name, []).append(PluginRecord(name, plugin_dir, manifest))
            logger.debug(
                f"Найден плагин: «{name}» v{manifest.get('version', '?')} "
                f"(папка: {plugin_dir.name})"
            )

        return candidates

    def scan(self, plugins_dir: Path, disabled_plugins: list[str]) -> None:
        """
        Сканирует plugins_dir, читает manifest.json у каждой папки.

        Идентичность плагина — manifest.json → "name", НЕ имя папки.
        Если ДВЕ РАЗНЫЕ папки объявляют одинаковое "name" (например,
        осталась резервная копия рядом с обновлённой версией) — это
        раньше молча резолвилось как "выигрывает та папка, что позже
        по алфавиту при sorted(iterdir())", без единого предупреждения,
        причём совершенно НЕЗАВИСИМО от того, у кого версия старше —
        воспроизведено эмпирически: "antispam_old" (v1.0.0) побеждал
        "antispam_new" (v2.0.0) просто потому что "old" > "new"
        лексикографически. Опасно тем, что можно незаметно оказаться
        на старой версии, думая, что работает новая.

        Поэтому коллизия по имени теперь ловится явно: ни одна из
        конфликтующих папок не грузится (та же логика, что уже
        применяется к дублирующимся номерам версий миграций в
        Database.collect_migration_files — отказ вместо тихого
        выбора), а в лог идёт понятная ошибка с именами ВСЕХ
        конфликтующих папок и их версиями — решать, какую оставить,
        должен человек, а не алфавит.
        """
        self._plugins_dir = plugins_dir
        self._disabled_plugins = disabled_plugins
        candidates = self._scan_manifests(plugins_dir, disabled_plugins)

        for name, records in candidates.items():
            if len(records) == 1:
                self._records[name] = records[0]
                continue

            # Коллизия — ни одна из папок не грузится. records[0] всё
            # же кладём в _records, чтобы status/deps могли показать
            # хоть какую-то версию/автора рядом с причиной отказа —
            # но именно ЭТА версия не имеет отношения к тому, какая
            # папка "правильная": это только для отображения.
            details = ", ".join(f"«{r.path.name}» (v{r.version})" for r in records)
            self._records[name] = records[0]
            self._skip(
                name,
                f"обнаружено {len(records)} папки(ок) с одинаковым именем "
                f"плагина «{name}» в manifest.json: {details}. Ни одна не "
                f"загружена — удалите лишние вручную, алфавитный порядок "
                f"папок не должен решать, какая версия «настоящая».",
                level="error",
            )

    # ── 2. Совместимость с ядром ──────────────────────────────

    def check_core_compat(self) -> None:
        """
        Помечает плагины как SKIPPED, если manifest.json -> core_version
        не совместим с core.__version__. Идёт ПЕРЕД check_pip_deps() —
        нет смысла проверять pip-зависимости плагина, написанного для
        несовместимой версии ядра: его PluginContext всё равно может
        отличаться.
        """
        for name, rec in self._records.items():
            raw = rec.core_version_raw
            if not raw:
                continue
            try:
                specifier = parse_specifier_only(raw)
            except DependencySpecError as exc:
                self._skip(name, f"некорректное поле core_version в manifest.json: {exc}")
                continue
            ok, reason = check_core_version(specifier, core.__version__)
            if not ok:
                self._skip(name, f"несовместим с ядром ({reason}).")

    def check_pip_deps(self) -> None:
        """
        Помечает плагины как SKIPPED, если не хватает pip-библиотеки ИЛИ
        установленная версия не подходит под условие в manifest.json
        (например, "aiogram>=3.15,<4.0"). После поплагинной проверки
        логирует сводку по пакетам, которые требует больше одного
        плагина — так конфликт версий между плагинами виден целиком, а
        не как разрозненные «плагин X пропущен» без объяснения причины.
        """
        all_specs: dict[str, list[DependencySpec]] = {}

        for name, rec in self._records.items():
            try:
                specs = rec.pip_deps()
            except DependencySpecError as exc:
                self._skip(name, f"некорректная pip-зависимость в manifest.json: {exc}")
                continue

            all_specs[name] = specs
            for spec in specs:
                result = check_pip_dependency(spec)
                if not result.ok:
                    self._skip(
                        name,
                        f"pip-зависимость «{spec.raw}» не удовлетворена ({result.reason}).\n"
                        f"        Установите: pip install \"{spec.raw}\"",
                    )
                    break

        report_pip_conflicts(all_specs)

    # ── 3. Разрешение порядка загрузки ───────────────────────

    def resolve_order(self) -> None:
        """
        Шаг 1: Распространяет SKIPPED-статус по зависимостям (итеративно).
        Шаг 2: Разделяет на группы before_bot / after_bot.
        Шаг 3: Топосортирует каждую группу; обнаруживает циклы.
        """
        self._propagate_skips()

        active = {n for n in self._records if n not in self._skipped}

        before: set[str] = {n for n in active if self._records[n].load_order == "before_bot"}
        after: set[str] = active - before

        # ── before_bot ────────────────────────────────────────
        ordered_before, cycles_b = self._sort_group(
            group=before,
            already_loaded=set(),
        )
        if cycles_b:
            logger.error(
                f"Обнаружен цикл зависимостей (before_bot): "
                f"{', '.join(sorted(cycles_b))}. Все участники пропущены."
            )
            self._skipped |= cycles_b
            for n in cycles_b:
                self._skip_reasons[n] = (
                    f"цикл зависимостей (before_bot) с участием: {', '.join(sorted(cycles_b))}."
                )

        # ── after_bot (включая after:<name>) ─────────────────
        # Убираем плагины, которые ссылаются через after:<name>
        # на плагин из before_bot, ставший SKIPPED в cycles_b
        for name in list(after):
            if name in self._skipped:
                continue
            target = self._records[name].after_target
            if target is not None and target in self._skipped:
                self._skip(name, f"load_order=after:{target} — плагин не загружен.")

        after_active = after - self._skipped
        ordered_after, cycles_a = self._sort_group(
            group=after_active,
            already_loaded=set(ordered_before),
        )
        if cycles_a:
            logger.error(
                f"Обнаружен цикл зависимостей (after_bot): "
                f"{', '.join(sorted(cycles_a))}. Все участники пропущены."
            )
            self._skipped |= cycles_a
            for n in cycles_a:
                self._skip_reasons[n] = (
                    f"цикл зависимостей (after_bot) с участием: {', '.join(sorted(cycles_a))}."
                )

        self._load_order = (
            [n for n in ordered_before if n not in self._skipped]
            + [n for n in ordered_after if n not in self._skipped]
        )

    def _propagate_skips(self) -> None:
        """
        Итеративно помечает плагины как SKIPPED, если их зависимость
        (plugin dep или after:<name>) уже SKIPPED, не найдена, или
        найдена, но её версия не удовлетворяет условию в manifest.json
        (например, требуется "antispam>=2.0.0", а установлена 1.0.0).
        Продолжает до стабильного состояния.
        """
        changed = True
        while changed:
            changed = False
            for name, rec in self._records.items():
                if name in self._skipped:
                    continue

                try:
                    dep_specs = rec.plugin_deps()
                except DependencySpecError as exc:
                    self._skip(name, f"некорректная plugin-зависимость в manifest.json: {exc}")
                    changed = True
                    continue

                for spec in dep_specs:
                    dep_name = spec.name
                    if dep_name not in self._records:
                        self._skip(name, f"требует плагин «{dep_name}» — не найден.")
                        changed = True
                        break
                    if dep_name in self._skipped:
                        self._skip(name, f"требует плагин «{dep_name}» — он не загружен.")
                        changed = True
                        break
                    dep_version = self._records[dep_name].version
                    ok, reason = check_plugin_version(dep_name, spec.specifier, dep_version)
                    if not ok:
                        self._skip(
                            name,
                            f"требует плагин «{dep_name}» версии {spec.specifier} ({reason}).",
                        )
                        changed = True
                        break

                if name in self._skipped:
                    continue

                target = rec.after_target
                if target is not None:
                    if target not in self._records:
                        self._skip(name, f"load_order=after:{target} — плагин не найден.")
                        changed = True
                    elif target in self._skipped:
                        self._skip(name, f"load_order=after:{target} — плагин не загружен.")
                        changed = True

    def _sort_group(
        self,
        group: set[str],
        already_loaded: set[str],
    ) -> tuple[list[str], set[str]]:
        """
        Строит граф предшественников для группы и запускает Кана.

        already_loaded: плагины из предыдущей группы (before_bot),
        они уже готовы — зависимость от них удовлетворена без ребра в графе.
        """
        predecessors: dict[str, set[str]] = {n: set() for n in group}

        for name in group:
            rec = self._records[name]

            # К этому моменту _propagate_skips уже прогнал rec.plugin_deps()
            # для каждого активного (не skipped) плагина без ошибки —
            # вызов здесь безопасен и распарсит те же строки так же.
            for spec in rec.plugin_deps():
                dep = spec.name
                if dep in group:
                    predecessors[name].add(dep)
                # dep in already_loaded → уже загружен, ребро не нужно
                # dep больше нигде не встречается → отловлено в
                # _propagate_skips, сюда такой name вообще не дойдёт

            target = rec.after_target
            if target is not None and target in group:
                predecessors[name].add(target)

        return _kahn_sort(group, predecessors)

    # ── 4. Загрузка плагинов ─────────────────────────────────

    async def _get_plugin_database(self, rec: PluginRecord) -> BaseDatabase:
        """
        Возвращает подключённую персональную БД плагина, создавая и
        подключая её при первом обращении и переиспользуя дальше из
        кэша self._plugin_dbs. Вызывается ДО _make_context — ctx.db
        должен быть уже подключённым объектом, а не заглушкой.

        Бэкенд (SQLite-файл или Postgres-схема) берётся из
        self._config.database.backend — единая настройка на весь
        процесс, плагин не выбирает бэкенд сам (иначе один плагин на
        SQLite и другой на Postgres в одном боте — источник путаницы
        без всякой пользы). create_database() из core/db/factory.py
        решает, какой класс создать.

        Создаётся для КАЖДОГО загружаемого плагина, даже если у него
        нет папки migrations/ — так ctx.db у плагина всегда рабочий
        объект без необходимости плагину проверять его на None.
        """
        cached = self._plugin_dbs.get(rec.name)
        if cached is not None:
            return cached

        assert self._config is not None, "_get_plugin_database вызван до load_plugins()"
        db_path = rec.path / "database" / "database.db"
        db = create_database(
            namespace=rec.name,
            config=self._config,
            sqlite_path=db_path,
            sqlite_reader_pool_size=_PLUGIN_DB_READER_POOL_SIZE,
            postgres_pool_min_size=1,
            postgres_pool_max_size=3,
        )
        await db.connect()
        self._plugin_dbs[rec.name] = db
        return db

    async def close_all_plugin_databases(self) -> None:
        """
        Закрывает соединения всех подключённых персональных БД плагинов.

        Не вызывается автоматически из teardown_all()/_teardown_one() —
        reload_plugin() намеренно НЕ закрывает БД плагина между
        перезагрузками (меняется только код плагина, соединение с его
        БД должно пережить reload). Вызывающий код (main.py) должен
        вызвать этот метод при остановке всего процесса — симметрично
        db.close() для БД ядра.
        """
        for name, db in self._plugin_dbs.items():
            try:
                await db.close()
            except Exception:
                logger.error(f"Ошибка при закрытии БД плагина «{name}».", exc_info=True)
        self._plugin_dbs.clear()

    def _make_context(self, rec: PluginRecord, plugin_db: BaseDatabase) -> PluginContext:
        assert (
            self._dp is not None
            and self._bot is not None
            and self._db is not None
            and self._config is not None
        ), "_make_context вызван до load_plugins()"
        return PluginContext(
            dp=self._dp,
            bot=self._bot,
            db=plugin_db,       # персональная БД ЭТОГО плагина
            core_db=self._db,   # БД ядра — см. core/plugin_context.py
            config=self._config,
            hooks=self.hooks,
            patches=self.patches,
            services=self.services,
            scheduler=self.scheduler,
            plugin_name=rec.name,
            plugin_dir=rec.path,
            logger=get_logger(rec.name),
        )

    async def _verify_and_run_migrations(
        self, name: str, rec: PluginRecord, plugin_db: BaseDatabase
    ) -> bool:
        """
        True — миграции в порядке (или их нет). False — плагин пора
        пропустить. Мигрирует plugin_db плагина (его СОБСТВЕННУЮ БД),
        а не БД ядра.

        Папка миграций выбирается под текущий бэкенд через
        resolve_migration_dir(): <plugin>/migrations/postgres/, если
        она есть и backend="postgres", иначе <plugin>/migrations/ как
        и раньше — см. core/db/migrations.py про то, почему нет
        автоматического перевода SQLite SQL в Postgres.
        """
        base_migration_dir = rec.path / "migrations"
        backend = self._config.database.backend if self._config is not None else "sqlite"
        migration_dir = resolve_migration_dir(base_migration_dir, backend)
        if not migration_dir.exists():
            return True

        try:
            all_files = collect_migration_files(migration_dir, name)
        except ValueError as exc:
            self._skip(name, str(exc), level="error")
            return False
        if not all_files:
            return True

        if not await plugin_db.run_migrations(name, migration_dir):
            self._skip(name, "ошибка при применении миграций (см. лог выше).", level="error")
            return False

        expected_versions = {v for v, _ in all_files}
        if not await plugin_db.verify_schema_version(name, expected_versions):
            # verify_schema_version уже залогировал причину подробно —
            # здесь только короткая сводка для status/deps.
            self._skipped.add(name)
            self._skip_reasons[name] = "версия схемы БД не совпадает с миграциями на диске (см. лог)."
            return False

        return True

    async def load_plugins(
        self,
        dp: Dispatcher,
        bot: Bot,
        db: BaseDatabase,
        config: Config,
    ) -> None:
        """Для каждого плагина в _load_order: миграции → PluginContext → setup()."""
        self._dp, self._bot, self._db, self._config = dp, bot, db, config

        for name in self._load_order:
            if name in self._skipped:
                continue
            await self._load_one(name)

        loaded = [n for n in self._load_order if n not in self._skipped]
        skipped = sorted(self._skipped)
        await self.hooks.emit("core.plugins.ready", loaded=loaded, skipped=skipped)

    async def _load_one(self, name: str) -> None:
        rec = self._records[name]

        try:
            plugin_db = await self._get_plugin_database(rec)
        except Exception as exc:
            self._skip(name, f"не удалось подключиться к БД плагина: {exc}", level="error")
            logger.error(f"Плагин «{name}»: ошибка подключения к БД.", exc_info=True)
            return

        if not await self._verify_and_run_migrations(name, rec, plugin_db):
            return

        try:
            default_module_name = f"plugins.{rec.path.name}.plugin"
            plugin_class = _load_plugin_class(rec.path, module_name=default_module_name)
        except PluginClassError as exc:
            self._skip(name, str(exc), level="error")
            return
        if plugin_class is None:
            self._skip(name, "не найден подкласс BasePlugin в plugin.py.", level="error")
            return

        await self.hooks.emit("core.plugin.before_load", name=name, record=rec)
        try:
            instance = plugin_class()
            ctx = self._make_context(rec, plugin_db)
            await instance.setup(ctx)
            rec.instance = instance
            rec.module_name = default_module_name
            logger.info(f"Плагин «{name}» v{rec.version} загружен.")
        except Exception as exc:
            self._skip(name, f"ошибка в setup(): {exc}", level="error")
            logger.error(f"Плагин «{name}»: ошибка в setup().", exc_info=True)
            await self.hooks.emit("core.plugin.load_failed", name=name, error=exc)
            # Патчи/подписки/сервисы, которые плагин успел установить до
            # падения setup(), — не оставляем висеть в неопределённом
            # состоянии наполовину настроенного плагина.
            self._cleanup_extensions(name)
            return

        await self.hooks.emit("core.plugin.after_load", name=name, record=rec, instance=instance)

    def _cleanup_extensions(self, name: str) -> None:
        """Откатывает всё, что плагин мог зарегистрировать: patches/hooks/services/scheduler-задачи."""
        self.patches.revert_plugin(name)
        self.hooks.remove_all_for(name)
        self.services.remove_all_for(name)
        self.scheduler.remove_all_for(name)

    # ── 5. Teardown ───────────────────────────────────────────

    async def teardown_all(self) -> None:
        """Вызывает teardown() у плагинов в порядке, обратном загрузке."""
        for name in reversed(self._load_order):
            if name in self._skipped:
                continue
            await self._teardown_one(name)

    async def _teardown_one(self, name: str) -> None:
        rec = self._records[name]
        if rec.instance is None:
            return
        await self.hooks.emit("core.plugin.before_teardown", name=name)
        logger.info(f"Остановка плагина «{name}»...")
        try:
            await rec.instance.teardown()
            logger.info(f"Плагин «{name}» остановлен.")
        except Exception as exc:
            logger.error(
                f"Ошибка при остановке плагина «{name}»: {exc}",
                exc_info=True,
            )
        finally:
            # Симметрично setup(): что бы плагин ни поднял (hooks, patches,
            # services), после teardown от него не должно остаться следов —
            # иначе патч уже выгруженного плагина продолжит перехватывать
            # вызовы ядра, ссылаясь на не пойми какое состояние.
            self._cleanup_extensions(name)
            rec.instance = None
            try:
                await self.hooks.emit("core.plugin.after_teardown", name=name)
            except Exception as exc:
                logger.error(
                    f"Ошибка hook after_teardown для плагина «{name}»: {exc}",
                    exc_info=True,
                )

    # ── 6. Reload одного плагина ──────────────────────────────

    async def reload_plugin(self, name: str) -> bool:
        """
        Перезагружает один плагин без перезапуска процесса: teardown
        текущего instance (с откатом его hooks/patches/services) →
        повторное чтение manifest.json → повторный импорт plugin.py
        (под новым уникальным module-именем — иначе Python отдал бы
        старый модуль из sys.modules и изменения в файле не подхватились
        бы) → миграции → новый PluginContext → setup().

        ОГРАНИЧЕНИЕ: не пересчитывает топологический порядок загрузки
        всей системы плагинов — если поменялись dependencies/load_order
        в manifest.json так, что порядок относительно ДРУГИХ плагинов
        должен был бы измениться, это не будет учтено (плагин остаётся
        на своём прежнем месте в _load_order, либо, если раньше был
        пропущен, добавляется в конец). Для полного пересчёта порядка
        перезапустите процесс. Подходит для типичного цикла разработки
        одного плагина, а не для смены графа зависимостей на лету.

        Возвращает True при успешной перезагрузке.
        """
        if self._dp is None:
            raise RuntimeError("reload_plugin вызван до load_plugins().")

        rec = self._records.get(name)
        if rec is None:
            logger.error(f"reload_plugin: плагин «{name}» неизвестен (не найден при scan()).")
            return False

        # Повторная проверка коллизии имени ПРЯМО СЕЙЧАС — self._records[name]
        # мог быть создан ещё при исходном scan() и с тех пор не обновлялся.
        # Без этой проверки reload_plugin() тихо перезагружал бы ОДНУ из
        # конфликтующих папок (records[0], выбранную только для отображения
        # в status при исходном scan()), полностью в обход всей защиты от
        # коллизий имён — найдено ровно так: сквозной тест воспроизвёл
        # коллизию, вызвал reload_plugin() на неё и получил успех вместо
        # ожидаемого отказа.
        if self._plugins_dir is not None:
            current = self._scan_manifests(self._plugins_dir, self._disabled_plugins)
            matching = current.get(name, [])
            if len(matching) != 1:
                if matching:
                    details = ", ".join(f"«{r.path.name}» (v{r.version})" for r in matching)
                    reason = f"коллизия имени обнаружена заново при reload: {details}."
                else:
                    reason = "папка плагина не найдена на диске при повторной проверке для reload."
                self._skip(name, reason, level="error")
                return False
            # _scan_manifests всегда создаёт СВЕЖИЙ PluginRecord
            # (instance=None) — если не перенести старые instance/
            # module_name на него, проверка ниже "rec.instance is not
            # None" всегда окажется ложной, и teardown уже запущенного
            # инстанса перед reload молча не произойдёт.
            fresh_rec = matching[0]
            fresh_rec.instance = rec.instance
            fresh_rec.module_name = rec.module_name
            rec = fresh_rec
            self._records[name] = rec

        manifest_path = rec.path / "manifest.json"
        try:
            rec.manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.error(f"reload_plugin «{name}»: не удалось перечитать manifest.json: {exc}")
            return False

        if rec.instance is not None:
            await self._teardown_one(name)
        else:
            # Даже если раньше был SKIPPED, на всякий случай подчищаем —
            # мог успеть частично настроиться перед падением setup().
            self._cleanup_extensions(name)

        self._skipped.discard(name)
        self._skip_reasons.pop(name, None)

        try:
            # Переиспользует уже подключённый экземпляр из
            # self._plugin_dbs, если плагин грузился раньше — reload не
            # рвёт соединение с БД плагина, меняется только код.
            plugin_db = await self._get_plugin_database(rec)
        except Exception as exc:
            self._skip(name, f"не удалось подключиться к БД плагина: {exc}", level="error")
            logger.error(f"Плагин «{name}»: ошибка подключения к БД при reload.", exc_info=True)
            return False

        if not await self._verify_and_run_migrations(name, rec, plugin_db):
            return False

        module_name = f"plugins.{rec.path.name}.plugin.reload{next(_reload_counter)}"
        try:
            plugin_class = _load_plugin_class(rec.path, module_name=module_name)
        except PluginClassError as exc:
            self._skip(name, str(exc), level="error")
            return False
        if plugin_class is None:
            self._skip(name, "не найден подкласс BasePlugin в plugin.py.", level="error")
            return False

        try:
            instance = plugin_class()
            ctx = self._make_context(rec, plugin_db)
            await instance.setup(ctx)
        except Exception as exc:
            self._skip(name, f"ошибка в setup() при reload: {exc}", level="error")
            logger.error(f"Плагин «{name}»: ошибка в setup() при reload.", exc_info=True)
            self._cleanup_extensions(name)
            sys.modules.pop(module_name, None)
            return False

        # Старый модуль (прошлая версия кода плагина) больше не нужен —
        # без этого sys.modules бесконечно рос бы с каждым reload().
        if rec.module_name and rec.module_name != module_name:
            sys.modules.pop(rec.module_name, None)

        rec.instance = instance
        rec.module_name = module_name
        if name not in self._load_order:
            self._load_order.append(name)
        logger.info(f"Плагин «{name}» v{rec.version} перезагружен.")
        return True

    async def reload_all(self) -> dict[str, bool]:
        """
        Перезагружает КАЖДЫЙ сейчас активный (не skipped) плагин, по
        одному, в текущем порядке загрузки. Не трогает уже пропущенные
        плагины — это не попытка "почини всё", а обновление кода уже
        загруженных. Возвращает {имя: успех}.
        """
        targets = [n for n in self._load_order if n not in self._skipped]
        results: dict[str, bool] = {}
        for name in targets:
            results[name] = await self.reload_plugin(name)
        return results

    # ── Интроспекция для framework_manager.py / control-сервера ──

    def status_snapshot(self) -> dict[str, Any]:
        """
        Текущее состояние загрузчика одним объектом — без похода в
        логи. Используется control-сервером (core/control_server.py)
        и статическим анализом в framework_manager.py.
        """
        loaded = [n for n in self._load_order if n not in self._skipped]
        return {
            "loaded": [
                {"name": n, "version": self._records[n].version}
                for n in loaded
            ],
            "skipped": {
                n: self._skip_reasons.get(n, "причина не зафиксирована")
                for n in sorted(self._skipped)
            },
            "load_order": list(self._load_order),
        }

    def known_plugin_names(self) -> set[str]:
        """Все имена, что нашлись при scan() — независимо от того, загружены они или пропущены."""
        return set(self._records.keys())

    # ── Итог ─────────────────────────────────────────────────

    def summary(self) -> None:
        loaded = [n for n in self._load_order if n not in self._skipped]
        skipped = sorted(self._skipped)
        logger.info(
            f"Загружено плагинов: {len(loaded)} | "
            f"Пропущено: {len(skipped)}"
        )
        if loaded:
            logger.info(f"Загружены: {', '.join(loaded)}")
        if skipped:
            logger.info(f"Пропущены: {', '.join(skipped)}")
