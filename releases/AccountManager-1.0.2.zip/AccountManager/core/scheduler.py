"""
core/scheduler.py — Scheduler: асинхронный планировщик фоновых задач.

Зачем это ядру: раньше у плагина не было способа сказать "делай X
каждые N секунд/по такому-то расписанию", кроме как руками поднять
asyncio.create_task(...) в setup() и не забыть погасить его в
teardown(). Легко забыть, легко получить утечку таски при reload_plugin
(setup() вызовется заново, старая таска — если не отменена явно —
продолжит жить и задвоится). Scheduler убирает это в общую,
протестированную один раз инфраструктуру — по аналогии с
core/hooks.py (события) и core/patches.py (патчи): плагин регистрирует
задачу через ctx.schedule_*, PluginLoader сам гасит её при
teardown/reload (см. remove_all_for), как уже делает для hooks/patches/
services.

Три вида задач:
  - interval  — каждые N секунд, с опциональным джиттером и защитой от
                дрейфа (следующий запуск считается от ЗАПЛАНИРОВАННОГО
                времени предыдущего, а не от момента, когда предыдущий
                запуск фактически завершился — иначе задача, которая
                сама выполняется 2 секунды, работающая "каждые 60
                секунд", через 1000 запусков накопит заметный сдвиг).
  - cron      — по cron-подобному расписанию (минута час день месяц
                день_недели), см. _CronExpression.
  - once      — один раз, через delay секунд или в заданный момент.

"Умная" часть — переживание рестарта процесса (misfire/catch-up):
если Scheduler создан с db (обычно — БД ядра, core_db), время
последнего запуска каждой персистентной задачи (persist=True, по
умолчанию для interval/cron) сохраняется в таблицу scheduler_state.
После рестарта следующий запуск считается ОТ СОХРАНЁННОГО последнего
запуска, а не от "только что стартовали, значит первый запуск через
полный интервал":
  - misfire_policy="run_once" (по умолчанию) — если время следующего
    запуска уже в прошлом (бот был выключен дольше интервала), задача
    выполняется один раз сразу при старте, затем возвращается к
    обычному расписанию. Подходит для задач вроде "проверить
    просроченные VPN-подписки" — пропустить такую проверку из-за того,
    что бот был выключен, нежелательно.
  - misfire_policy="skip" — пропущенные запуски просто пропускаются,
    следующий запуск — по обычному расписанию от текущего момента.
    Подходит для задач, где повторный запуск не идемпотентен или
    неважен (например, "напомнить о чём-то раз в день" — если бот не
    работал сутки, слать напоминание в ту же секунду, как поднялся, а
    не по расписанию, обычно не нужно).

Изоляция ошибок — как и hooks/patches: исключение в задаче логируется
с указанием плагина и job_id, но не останавливает планировщик и не
роняет бота (см. HookBus, core/hooks.py — тот же принцип).

Защита от наложения — по умолчанию max_concurrent=1: если предыдущий
запуск задачи ещё выполняется (например, тяжёлая рассылка не успела
закончиться за отведённый интервал), следующий тик пропускается с
предупреждением в лог, а не запускает параллельную копию.
"""
from __future__ import annotations

import asyncio
import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable, Optional, Union

from core.logger import get_logger

logger = get_logger("scheduler")

JobCallback = Callable[[], Union[Awaitable[Any], Any]]

_CREATE_SCHEDULER_STATE = """
CREATE TABLE IF NOT EXISTS scheduler_state (
    job_id      TEXT PRIMARY KEY,
    last_run_at TEXT NOT NULL
);
"""


# ═══════════════════════════════════════════════════════════════
# Простой 5-полевой cron (минута час день_месяца месяц день_недели)
# ═══════════════════════════════════════════════════════════════

class CronSyntaxError(ValueError):
    """Некорректное cron-выражение."""


class _CronField:
    """Одно поле cron-выражения: '*', '*/N', 'a-b', 'a,b,c' или их комбинация через запятую."""

    def __init__(self, expr: str, lo: int, hi: int) -> None:
        self.allowed: set[int] = set()
        for part in expr.split(","):
            part = part.strip()
            if not part:
                raise CronSyntaxError(f"Пустой элемент в поле «{expr}».")
            step = 1
            if "/" in part:
                base, step_s = part.split("/", 1)
                try:
                    step = int(step_s)
                except ValueError:
                    raise CronSyntaxError(f"Некорректный шаг в «{part}».")
                if step <= 0:
                    raise CronSyntaxError(f"Шаг должен быть положительным в «{part}».")
            else:
                base = part

            if base == "*":
                lo_r, hi_r = lo, hi
            elif "-" in base:
                a, b = base.split("-", 1)
                try:
                    lo_r, hi_r = int(a), int(b)
                except ValueError:
                    raise CronSyntaxError(f"Некорректный диапазон «{base}».")
            else:
                try:
                    lo_r = hi_r = int(base)
                except ValueError:
                    raise CronSyntaxError(f"Некорректное значение «{base}».")

            if not (lo <= lo_r <= hi) or not (lo <= hi_r <= hi) or lo_r > hi_r:
                raise CronSyntaxError(
                    f"Значение «{base}» вне допустимого диапазона [{lo}, {hi}]."
                )
            self.allowed.update(range(lo_r, hi_r + 1, step))

    def matches(self, value: int) -> bool:
        return value in self.allowed


class _CronExpression:
    """
    Пять полей через пробел: минута(0-59) час(0-23) день_месяца(1-31)
    месяц(1-12) день_недели(0-6, 0=воскресенье — как cron(1)/Telegram
    не при чём, это просто самый распространённый конвенш).
    Без имён месяцев/дней недели (JAN, MON и т.п.) — не нужны для
    задач бота, а лишний парсинг — лишний риск багов.
    """

    def __init__(self, expr: str) -> None:
        parts = expr.split()
        if len(parts) != 5:
            raise CronSyntaxError(
                f"Cron-выражение «{expr}» должно содержать ровно 5 полей "
                f"(минута час день_месяца месяц день_недели), получено {len(parts)}."
            )
        minute, hour, dom, month, dow = parts
        self.minute = _CronField(minute, 0, 59)
        self.hour = _CronField(hour, 0, 23)
        self.dom = _CronField(dom, 1, 31)
        self.month = _CronField(month, 1, 12)
        self.dow = _CronField(dow, 0, 6)

    def matches(self, dt: datetime) -> bool:
        # isoweekday(): 1=понедельник..7=воскресенье -> приводим к 0=воскресенье..6=суббота
        dow = dt.isoweekday() % 7
        return (
            self.minute.matches(dt.minute)
            and self.hour.matches(dt.hour)
            and self.dom.matches(dt.day)
            and self.month.matches(dt.month)
            and self.dow.matches(dow)
        )

    def next_after(self, after: datetime, *, limit_minutes: int = 366 * 24 * 60) -> datetime:
        """Следующий момент (с точностью до минуты, секунды=0), строго позже after."""
        candidate = (after + timedelta(minutes=1)).replace(second=0, microsecond=0)
        for _ in range(limit_minutes):
            if self.matches(candidate):
                return candidate
            candidate += timedelta(minutes=1)
        raise RuntimeError(
            "Не удалось найти следующий момент для cron-выражения в пределах года — "
            "проверьте, не противоречат ли друг другу поля (например, 31 февраля)."
        )


# ═══════════════════════════════════════════════════════════════
# JobHandle / _Job
# ═══════════════════════════════════════════════════════════════

@dataclass(slots=True)
class JobHandle:
    """Возвращается из ctx.schedule_*, передаётся в ctx.cancel_job()."""
    job_id: str
    plugin: str


@dataclass(slots=True)
class _Job:
    job_id: str
    plugin: str
    kind: str  # "interval" | "cron" | "once"
    callback: JobCallback
    persist: bool
    misfire_policy: str  # "run_once" | "skip"
    max_concurrent: int
    jitter: float
    interval_seconds: Optional[float] = None
    cron: Optional[_CronExpression] = None
    run_at: Optional[datetime] = None
    task: Optional[asyncio.Task] = None
    running_count: int = 0
    cancelled: bool = False


# ═══════════════════════════════════════════════════════════════
# Scheduler
# ═══════════════════════════════════════════════════════════════

class Scheduler:
    """
    Общий на весь процесс, как HookBus/PatchManager/ServiceRegistry.
    Создаётся в main.py, кладётся в PluginContext (ctx.scheduler) —
    но обычно плагин использует обёртки ctx.schedule_interval/
    schedule_cron/schedule_once, а не сам объект напрямую (они сами
    подставляют plugin=self.plugin_name, как и остальные ctx.* обёртки).
    """

    def __init__(self, db: Optional[Any] = None) -> None:
        # db — БД ядра (core_db), опционально. Без неё планировщик
        # работает точно так же, но без переживания рестарта: после
        # каждого перезапуска процесса персистентные задачи считают,
        # что "последнего запуска никогда не было", и either запускаются
        # сразу (run_once) либо ждут полный интервал от старта (skip) —
        # см. _initial_last_run.
        self._db = db
        self._jobs: dict[str, _Job] = {}
        self._started = False

    # ── Жизненный цикл ───────────────────────────────────────

    async def start(self) -> None:
        """Вызывается из main.py ПОСЛЕ подключения db (если она передана) и её миграций."""
        if self._db is not None:
            await self._db.execute(_CREATE_SCHEDULER_STATE)
        self._started = True
        for job in self._jobs.values():
            self._spawn(job)
        logger.info(f"Планировщик запущен ({len(self._jobs)} задач).")

    async def stop(self) -> None:
        """Отменяет все задачи и ждёт их завершения. Вызывается в graceful shutdown."""
        tasks = [job.task for job in self._jobs.values() if job.task is not None]
        for job in self._jobs.values():
            job.cancelled = True
            if job.task is not None:
                job.task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        logger.info("Планировщик остановлен.")

    # ── Регистрация задач ────────────────────────────────────

    def interval(
        self,
        job_id: str,
        seconds: float,
        callback: JobCallback,
        *,
        plugin: str,
        jitter: float = 0.0,
        misfire_policy: str = "run_once",
        max_concurrent: int = 1,
        persist: bool = True,
    ) -> JobHandle:
        if seconds <= 0:
            raise ValueError("interval: seconds должен быть положительным.")
        if misfire_policy not in ("run_once", "skip"):
            raise ValueError('misfire_policy должен быть "run_once" или "skip".')
        if max_concurrent < 1:
            raise ValueError(
                f"max_concurrent должен быть >= 1 (получено {max_concurrent}) — "
                f"значение <= 0 означало бы, что задача не выполнится вообще ни разу."
            )
        full_id = f"{plugin}.{job_id}"
        job = _Job(
            job_id=full_id, plugin=plugin, kind="interval", callback=callback,
            persist=persist, misfire_policy=misfire_policy,
            max_concurrent=max_concurrent, jitter=jitter, interval_seconds=seconds,
        )
        self._register(job)
        return JobHandle(full_id, plugin)

    def cron(
        self,
        job_id: str,
        expr: str,
        callback: JobCallback,
        *,
        plugin: str,
        misfire_policy: str = "skip",
        max_concurrent: int = 1,
        persist: bool = True,
    ) -> JobHandle:
        if misfire_policy not in ("run_once", "skip"):
            raise ValueError('misfire_policy должен быть "run_once" или "skip".')
        if max_concurrent < 1:
            raise ValueError(
                f"max_concurrent должен быть >= 1 (получено {max_concurrent}) — "
                f"значение <= 0 означало бы, что задача не выполнится вообще ни разу."
            )
        full_id = f"{plugin}.{job_id}"
        job = _Job(
            job_id=full_id, plugin=plugin, kind="cron", callback=callback,
            persist=persist, misfire_policy=misfire_policy,
            max_concurrent=max_concurrent, jitter=0.0, cron=_CronExpression(expr),
        )
        self._register(job)
        return JobHandle(full_id, plugin)

    def once(
        self,
        job_id: str,
        when: Union[float, datetime],
        callback: JobCallback,
        *,
        plugin: str,
    ) -> JobHandle:
        """when — задержка в секундах (float) или конкретный datetime (aware, UTC рекомендуется)."""
        full_id = f"{plugin}.{job_id}"
        run_at = (
            datetime.now(timezone.utc) + timedelta(seconds=when)
            if isinstance(when, (int, float))
            else when
        )
        job = _Job(
            job_id=full_id, plugin=plugin, kind="once", callback=callback,
            persist=False, misfire_policy="skip", max_concurrent=1, jitter=0.0,
            run_at=run_at,
        )
        self._register(job)
        return JobHandle(full_id, plugin)

    def _register(self, job: _Job) -> None:
        if job.job_id in self._jobs:
            raise ValueError(
                f"Задача «{job.job_id}» уже зарегистрирована — используйте другое "
                f"имя или сначала cancel() старую."
            )
        self._jobs[job.job_id] = job
        if self._started:
            self._spawn(job)

    # ── Отмена ────────────────────────────────────────────────

    def cancel(self, handle: JobHandle) -> bool:
        job = self._jobs.pop(handle.job_id, None)
        if job is None:
            return False
        job.cancelled = True
        if job.task is not None:
            job.task.cancel()
        return True

    def remove_all_for(self, plugin: str) -> int:
        """Отменяет все задачи плагина. Вызывается PluginLoader при teardown/reload — плагину делать это самому не нужно."""
        to_remove = [jid for jid, j in self._jobs.items() if j.plugin == plugin]
        for jid in to_remove:
            job = self._jobs.pop(jid)
            job.cancelled = True
            if job.task is not None:
                job.task.cancel()
        if to_remove:
            logger.debug(f"Плагин «{plugin}»: снято {len(to_remove)} задач планировщика.")
        return len(to_remove)

    def list_jobs(self) -> list[dict[str, Any]]:
        """Для диагностики / framework_manager.py status."""
        return [
            {"job_id": j.job_id, "plugin": j.plugin, "kind": j.kind, "running": j.running_count > 0}
            for j in self._jobs.values()
        ]

    # ── Персистентность (misfire/catch-up) ──────────────────────

    async def _load_last_run(self, job_id: str) -> Optional[datetime]:
        if self._db is None:
            return None
        row = await self._db.fetchone(
            "SELECT last_run_at FROM scheduler_state WHERE job_id = ?", (job_id,)
        )
        if row is None:
            return None
        try:
            return datetime.fromisoformat(row["last_run_at"])
        except (KeyError, TypeError, ValueError):
            return None

    async def _save_last_run(self, job_id: str, when: datetime) -> None:
        if self._db is None:
            return
        await self._db.execute(
            """
            INSERT INTO scheduler_state (job_id, last_run_at) VALUES (:job_id, :when)
            ON CONFLICT(job_id) DO UPDATE SET last_run_at = excluded.last_run_at
            """,
            {"job_id": job_id, "when": when.isoformat()},
        )

    # ── Исполнение ────────────────────────────────────────────

    def _spawn(self, job: _Job) -> None:
        job.task = asyncio.create_task(self._run_job(job), name=f"scheduler:{job.job_id}")

    async def _run_job(self, job: _Job) -> None:
        try:
            if job.kind == "once":
                await self._wait_until(job.run_at)
                if job.cancelled:
                    return
                await self._fire(job)
                self._jobs.pop(job.job_id, None)
                return

            next_run = await self._initial_next_run(job)
            while not job.cancelled:
                await self._wait_until(next_run)
                if job.cancelled:
                    return
                await self._fire(job)
                next_run = self._compute_next(job, after=next_run)
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception(f"Планировщик: необработанная ошибка в цикле задачи «{job.job_id}».")

    async def _initial_next_run(self, job: _Job) -> datetime:
        """
        Первый запуск после старта/регистрации. Если задача персистентна
        и раньше уже когда-то запускалась (см. scheduler_state), решает
        misfire по last_run_at + интервал/cron против "сейчас" — см.
        докстринг модуля.
        """
        now = datetime.now(timezone.utc)
        last_run = await self._load_last_run(job.job_id) if job.persist else None

        if last_run is None:
            return self._compute_next(job, after=now, from_scratch=True)

        scheduled_next = self._compute_next(job, after=last_run)
        if scheduled_next <= now:
            if job.misfire_policy == "run_once":
                # Пропущенный запуск наверстывается немедленно (без
                # джиттера — это не обычный тик, а "погашение долга").
                return now
            # skip: пропускаем всё пропущенное, следующий — по
            # обычному расписанию от текущего момента.
            return self._compute_next(job, after=now, from_scratch=True)
        return scheduled_next

    def _compute_next(self, job: _Job, *, after: datetime, from_scratch: bool = False) -> datetime:
        if job.kind == "interval":
            base = after
            next_run = base + timedelta(seconds=job.interval_seconds)
            if job.jitter > 0:
                next_run += timedelta(seconds=random.uniform(0, job.jitter))
            return next_run
        if job.kind == "cron":
            return job.cron.next_after(after)
        raise AssertionError(f"_compute_next вызван для kind={job.kind!r}")

    async def _wait_until(self, when: datetime) -> None:
        while True:
            delay = (when - datetime.now(timezone.utc)).total_seconds()
            if delay <= 0:
                return
            # Спим порциями не длиннее часа — не ради точности (asyncio.sleep
            # и так точен), а чтобы cancel() не приходилось ждать сна
            # произвольной длины при остановке/reload плагина.
            await asyncio.sleep(min(delay, 3600))

    async def _fire(self, job: _Job) -> None:
        if job.running_count >= job.max_concurrent:
            logger.warning(
                f"Планировщик: задача «{job.job_id}» пропущена — предыдущий "
                f"запуск ({job.running_count}) ещё не завершился (max_concurrent={job.max_concurrent})."
            )
            return

        job.running_count += 1
        fired_at = datetime.now(timezone.utc)
        try:
            result = job.callback()
            if asyncio.iscoroutine(result):
                await result
        except Exception:
            logger.exception(
                f"Планировщик: ошибка в задаче «{job.job_id}» (плагин «{job.plugin}»)."
            )
        finally:
            job.running_count -= 1

        if job.persist:
            try:
                await self._save_last_run(job.job_id, fired_at)
            except Exception:
                logger.exception(f"Планировщик: не удалось сохранить last_run_at для «{job.job_id}».")
