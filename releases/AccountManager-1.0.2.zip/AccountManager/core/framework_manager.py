#!/usr/bin/env python3
"""
core/framework_manager.py — команды Менеджера Фреймворка AccountManager.

Все команды доступны через framework_manager.py (корневой файл) или
напрямую: python -m core.framework_manager <команда> [аргументы].

Полный список команд и флагов: python framework_manager.py --help
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Any, Optional

def _find_project_root(start: Path) -> Path:
    """
    Обычно этот файл лежит в корне проекта — PROJECT_ROOT было бы
    просто его собственной папкой. Но если он оказался вложен на
    уровень глубже (например, копия внутри core/ — так одно время и
    было с этим самым файлом), одного `.parent` недостаточно:
    относительные пути (plugins/, run/control.json, plugin_list.json,
    downloaded_updates/) должны указывать туда же, куда и main.py, а
    не внутрь core/. Ищем вверх по дереву папку, где лежат main.py И
    core/__init__.py одновременно — это и есть настоящий корень
    проекта, независимо от того, где физически лежит сам этот файл.
    """
    for candidate in (start, *start.parents):
        if (candidate / "main.py").exists() and (candidate / "core" / "__init__.py").exists():
            return candidate
    return start  # не нашли — ведём себя как раньше, тем, что дальше хотя бы не упадёт на импорте


PROJECT_ROOT = _find_project_root(Path(__file__).resolve().parent)
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from core.control_server import read_control_file  # noqa: E402
from core.dependencies import report_pip_conflicts  # noqa: E402
from core.hooks import HookBus  # noqa: E402
from core.patches import PatchManager  # noqa: E402
from core.plugin_loader import PluginLoader  # noqa: E402
from core.services import ServiceRegistry  # noqa: E402
from core.scheduler import Scheduler  # noqa: E402


# ═══════════════════════════════════════════════════════════════
# Статический анализ (не требует запущенного бота)
# ═══════════════════════════════════════════════════════════════

def build_static_loader() -> PluginLoader:
    """
    scan() + check_core_compat() + check_pip_deps() + resolve_order() —
    БЕЗ load_plugins(), поэтому не нужны реальный токен бота или
    подключение к БД. Ровно то, что видел бы main.py на старте, минус
    сам запуск.
    """
    loader = PluginLoader(
        hooks=HookBus(),
        patches=PatchManager(),
        services=ServiceRegistry(),
        scheduler=Scheduler(),
    )
    loader.scan(PROJECT_ROOT / "plugins", [])
    loader.check_core_compat()
    loader.check_pip_deps()
    loader.resolve_order()
    return loader


async def send_control_command(port: int, request: dict[str, Any], timeout: float = 5.0) -> dict[str, Any]:
    reader, writer = await asyncio.open_connection("127.0.0.1", port)
    try:
        writer.write((json.dumps(request) + "\n").encode("utf-8"))
        await writer.drain()
        line = await asyncio.wait_for(reader.readline(), timeout=timeout)
        return json.loads(line.decode("utf-8"))
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass


def get_live_bot_info() -> Optional[dict[str, Any]]:
    """
    {'pid', 'port', ...} если бот реально отвечает на ping ПРЯМО
    СЕЙЧАС, иначе None — наличие run/control.json само по себе ничего
    не гарантирует (мог остаться от нечистого завершения процесса).
    """
    info = read_control_file()
    if info is None:
        return None
    try:
        response = asyncio.run(send_control_command(info["port"], {"cmd": "ping"}))
    except (ConnectionRefusedError, OSError, asyncio.TimeoutError, json.JSONDecodeError):
        return None
    return info if response.get("ok") else None


# ═══════════════════════════════════════════════════════════════
# status
# ═══════════════════════════════════════════════════════════════

def _print_framework_status_header(live: Optional[dict[str, Any]], loader: "PluginLoader") -> None:
    """
    Блок «=== Информация о Фреймворке ===» + «=== Информация о плагинах ===»,
    который появляется в начале вывода cmd_status (и отдельно в TUI
    через экран «Посмотреть информацию и состояние»).
    """
    from core.manifest import UNKNOWN, display, load_manifest, verify_build_integrity, ManifestError
    try:
        manifest = load_manifest()
    except ManifestError:
        manifest = {}

    print("=== Информация о Фреймворке ===\n")
    print(f"Имя:         {display(manifest, 'name')}")
    print(f"Описание:    {display(manifest, 'description')}")
    print(f"Версия:      {display(manifest, 'version')}")
    print(f"Авторы:      {display(manifest, 'authors')}")
    print()
    if live:
        print(f"Статус:      запущен (pid {live['pid']}, порт {live['port']})")
    else:
        print("Статус:      выключен")
    print()
    loaded_count = len(loader._records) - len(loader._skipped)
    skipped_count = len(loader._skipped)
    print("=== Информация о плагинах ===\n")
    print(f"Список всего загруженных плагинов: {loaded_count}")
    print(f"Список пропущенных плагинов:       {skipped_count}")
    print()


def cmd_status(args: argparse.Namespace) -> int:
    loader = build_static_loader()
    live = get_live_bot_info()

    names = sorted(loader._records.keys())
    if args.name:
        if args.name not in loader._records:
            print(f"Плагин «{args.name}» не найден (нет такой папки в plugins/).")
            return 1
        names = [args.name]

    if args.filter == "running":
        names = [n for n in names if n not in loader._skipped]
    elif args.filter == "skipped":
        names = [n for n in names if n in loader._skipped]

    _print_framework_status_header(live, loader)

    if live:
        print(f"● Бот запущен (pid {live['pid']}, control-порт {live['port']})\n")
    else:
        print("○ Бот не запущен (или control-сервер недоступен) — показан статический анализ\n")

    all_pip_specs: dict[str, list] = {}
    for name in names:
        rec = loader._records[name]
        skipped = name in loader._skipped
        marker = "✗ пропущен" if skipped else "✓ загружен"
        print(f"{name} ({rec.version})  {marker}")
        if rec.author:
            print(f"    автор: {rec.author}")
        if rec.description:
            print(f"    {rec.description}")

        try:
            pip_specs = rec.pip_deps()
        except Exception:
            pip_specs = []
        try:
            plugin_specs = rec.plugin_deps()
        except Exception:
            plugin_specs = []
        all_pip_specs[name] = pip_specs

        if pip_specs:
            print("    pip:")
            for spec in pip_specs:
                from core.dependencies import check_pip_dependency
                result = check_pip_dependency(spec)
                status = "OK" if result.ok else f"НЕ УДОВЛЕТВОРЕНО: {result.reason}"
                print(f"      - {spec.raw}  [{status}]")
        if plugin_specs:
            print("    plugins:")
            for spec in plugin_specs:
                dep_rec = loader._records.get(spec.name)
                if dep_rec is None:
                    print(f"      - {spec.raw}  [НЕ НАЙДЕН]")
                else:
                    from core.dependencies import check_plugin_version
                    ok, reason = check_plugin_version(spec.name, spec.specifier, dep_rec.version)
                    print(f"      - {spec.raw}  [{'OK' if ok else 'НЕ УДОВЛЕТВОРЕНО: ' + reason}]")

        if skipped:
            print(f"    причина: {loader._skip_reasons.get(name, '?')}")
        print()

    # Вердикт: конфликты pip-версий между показанными плагинами.
    import io
    import logging
    buf = io.StringIO()
    handler = logging.StreamHandler(buf)
    handler.setLevel(logging.WARNING)
    dep_logger = logging.getLogger("dependencies")
    dep_logger.addHandler(handler)
    try:
        report_pip_conflicts(all_pip_specs)
    finally:
        dep_logger.removeHandler(handler)
    conflicts = buf.getvalue().strip()
    if conflicts:
        print("⚠ конфликты:")
        print(conflicts)
    else:
        print("Конфликтов версий не обнаружено.")

    return 0


# ═══════════════════════════════════════════════════════════════
# restart + вспомогательное: пронумерованное меню выбора
# ═══════════════════════════════════════════════════════════════

def _prompt_multi_select(count: int) -> list[int]:
    """
    0-based индексы выбранных пунктов. Пустой список — отмена.
    Простой пронумерованный список вместо curses-TUI — единственное,
    что одинаково надёжно работает в cmd.exe, PowerShell, bash и
    Termux одновременно (нет зависимости от возможностей терминала).
    """
    print("Номера через запятую/пробел, «all» — все, «0» — отмена:")
    raw = input("> ").strip().lower()
    if raw in ("0", "", "cancel", "отмена"):
        return []
    if raw == "all":
        return list(range(count))
    picked: list[int] = []
    for token in raw.replace(",", " ").split():
        if not token.isdigit() or not (1 <= int(token) <= count):
            print(f"Некорректный номер: «{token}» — отмена.")
            return []
        picked.append(int(token) - 1)
    return picked


def _select_from_menu(options: list[str], loader: PluginLoader) -> list[str]:
    print("Доступные плагины для перезагрузки:")
    for i, name in enumerate(options, start=1):
        rec = loader._records[name]
        state = "загружен" if name not in loader._skipped else "пропущен"
        print(f"  {i}) {name} ({rec.version}) — {state}")
    idxs = _prompt_multi_select(len(options))
    return [options[i] for i in idxs]


def cmd_restart(args: argparse.Namespace) -> int:
    live = get_live_bot_info()
    if live is None:
        print(
            "Бот не запущен (или control-сервер недоступен) — перезагружать нечего.\n"
            "restart работает только для уже запущенного процесса."
        )
        return 1

    loader = build_static_loader()  # только чтобы показать меню/имена, не для самой перезагрузки
    loaded_names = [n for n in loader._records if n not in loader._skipped]

    if args.all:
        targets = loaded_names
    elif args.name:
        if args.name not in loader._records:
            print(f"Плагин «{args.name}» не найден.")
            return 1
        targets = [args.name]
    else:
        targets = _select_from_menu(sorted(loader._records.keys()), loader)
        if not targets:
            print("Отменено.")
            return 0

    port = live["port"]
    if len(targets) == 1 and not args.all:
        resp = asyncio.run(send_control_command(port, {"cmd": "reload", "plugin": targets[0]}))
        if resp.get("ok"):
            print(f"✓ «{targets[0]}» перезагружен.")
            return 0
        print(f"✗ «{targets[0]}» не перезагружен: {resp.get('error') or resp.get('reason')}")
        return 1

    if args.all:
        resp = asyncio.run(send_control_command(port, {"cmd": "reload_all"}))
        results = resp.get("results", {})
    else:
        results = {}
        for name in targets:
            r = asyncio.run(send_control_command(port, {"cmd": "reload", "plugin": name}))
            results[name] = r.get("ok", False)

    for name, ok in results.items():
        print(f"{'✓' if ok else '✗'} {name}")
    return 0 if all(results.values()) else 1


# ═══════════════════════════════════════════════════════════════
# install / uninstall
# ═══════════════════════════════════════════════════════════════

DEFAULT_CATALOG_PATH = PROJECT_ROOT / "plugin_list.json"
STAGING_DIR = PROJECT_ROOT / "downloaded_updates"

_TRUST_WARNING = (
    "ВНИМАНИЕ: код плагина выполняется с полными правами процесса — песочницы\n"
    "нет и не планируется (та же модель доверия, что у всей системы патчей\n"
    "ядра). Устанавливайте только то, чему доверяете.\n"
)


def load_catalog(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        print(f"Каталог «{path}» не найден.")
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"Каталог «{path}» содержит невалидный JSON: {exc}")
        return []
    return data.get("plugins", [])


def _print_catalog_entry(i: int, entry: dict[str, Any]) -> None:
    print(f"  {i}) {entry.get('name', '?')} ({entry.get('version', '?')})")
    if entry.get("author"):
        print(f"      автор: {entry['author']}")
    if entry.get("description"):
        print(f"      {entry['description']}")
    if entry.get("last_updated"):
        print(f"      обновлено: {entry['last_updated']}")


def cmd_install(args: argparse.Namespace) -> int:
    if not args.yes:
        print(
            "Отменено: install требует флаг --yes.\n"
            "  --yes            подтвердить установку (обязателен)\n"
            "  --file ПУТЬ      каталог плагинов вместо plugin_list.json\n"
            "  --ref ВЕТКА      конкретная ветка/тег для источника с GitHub\n"
            "  --subdir ПУТЬ    подпапка репозитория, если плагин не в корне\n"
            "  --overwrite      заменить уже установленный плагин с тем же именем\n"
            "Примеры:\n"
            "  python framework_manager.py install --yes antispam\n"
            "  python framework_manager.py install --yes owner/repo\n"
            "  python framework_manager.py install --yes /путь/к/папке-плагина\n"
            "  python framework_manager.py install --yes    (меню из каталога)"
        )
        return 1

    from core.lockfile import is_locked
    if is_locked():
        print(
            "Отменено: плагины залочены (`lock`). Выполните `unlock --yes`, "
            "прежде чем устанавливать/менять что-либо."
        )
        return 1

    from core.plugin_installer import PluginInstallError, install_from_github, install_from_local

    catalog_path = Path(args.file) if args.file else DEFAULT_CATALOG_PATH
    targets: list[dict[str, Any]] = []

    if args.source:
        local_path = Path(args.source)
        if local_path.exists():
            targets = [{"kind": "local", "source": str(local_path)}]
        elif args.source.startswith("http") or "/" in args.source:
            targets = [{"kind": "github", "source": args.source}]
        else:
            entries = load_catalog(catalog_path)
            match = next((e for e in entries if e.get("name") == args.source), None)
            if match is None or not match.get("repository_url"):
                print(
                    f"«{args.source}» не найден ни как локальный путь, ни как "
                    f"github-ссылка, ни (с repository_url) в каталоге «{catalog_path}»."
                )
                return 1
            targets = [{"kind": "github", "source": match["repository_url"], "name_override": match.get("name")}]
    else:
        entries = load_catalog(catalog_path)
        if not entries:
            print("Каталог пуст или не найден — указывать нечего. Передайте источник явно или --file.")
            return 1
        print(f"Доступные плагины ({catalog_path}):\n")
        for i, e in enumerate(entries, 1):
            _print_catalog_entry(i, e)
            print()
        idxs = _prompt_multi_select(len(entries))
        if not idxs:
            print("Отменено.")
            return 0
        targets = [
            {"kind": "github", "source": entries[i]["repository_url"], "name_override": entries[i].get("name")}
            for i in idxs
            if entries[i].get("repository_url")
        ]
        if not targets:
            print("Выбранные записи каталога не содержат repository_url — нечего устанавливать.")
            return 1

    live = get_live_bot_info()
    plugins_dir = STAGING_DIR if live else (PROJECT_ROOT / "plugins")
    if live:
        print(
            f"● Бот запущен (pid {live['pid']}) — устанавливать в plugins/ напрямую небезопасно.\n"
            f"  Плагин(ы) будут скачаны в downloaded_updates/, но автоприменение при\n"
            f"  следующей остановке бота ЕЩЁ НЕ реализовано (следующий этап). Пока что\n"
            f"  плагин останется в staging до ручного применения.\n"
        )

    print(_TRUST_WARNING)

    all_ok = True
    for t in targets:
        try:
            if t["kind"] == "local":
                result = install_from_local(
                    Path(t["source"]), plugins_dir,
                    name_override=t.get("name_override"), overwrite=args.overwrite,
                )
            else:
                result = install_from_github(
                    t["source"], plugins_dir, ref=args.ref, subdir=args.subdir or "",
                    name_override=t.get("name_override"), overwrite=args.overwrite,
                )
        except PluginInstallError as exc:
            print(f"✗ {t['source']}: {exc}")
            all_ok = False
            continue
        print(f"{'✓' if result.ok else '✗'} {result.message}")
        all_ok = all_ok and result.ok

    if all_ok and not live:
        print("\nГотово. Плагин(ы) появятся при следующем запуске бота (или уже подхвачены, если это первичный старт).")
    return 0 if all_ok else 1


def cmd_uninstall(args: argparse.Namespace) -> int:
    if not args.yes:
        print(
            "Отменено: uninstall требует флаг --yes.\n"
            "  --yes    подтвердить удаление (обязателен)\n"
            "Примеры:\n"
            "  python framework_manager.py uninstall --yes antispam\n"
            "  python framework_manager.py uninstall --yes    (меню из установленных)"
        )
        return 1

    live = get_live_bot_info()
    if live:
        print(
            f"● Бот запущен (pid {live['pid']}) — удаление файлов плагина, который бот\n"
            f"  прямо сейчас использует, небезопасно, а отложенное удаление (как для\n"
            f"  install) ещё не реализовано. Остановите бота и повторите."
        )
        return 1

    from core.plugin_installer import uninstall as do_uninstall

    loader = build_static_loader()
    names = sorted(loader._records.keys())

    if args.name:
        if args.name not in loader._records:
            print(f"Плагин «{args.name}» не найден.")
            return 1
        targets = [args.name]
    else:
        if not names:
            print("Нет установленных плагинов.")
            return 0
        print("Установленные плагины:\n")
        for i, name in enumerate(names, 1):
            rec = loader._records[name]
            print(f"  {i}) {name} ({rec.version})")
            if rec.author:
                print(f"      автор: {rec.author}")
            if rec.description:
                print(f"      {rec.description}")
        idxs = _prompt_multi_select(len(names))
        if not idxs:
            print("Отменено.")
            return 0
        targets = [names[i] for i in idxs]

    all_ok = True
    for name in targets:
        result = do_uninstall(name, PROJECT_ROOT / "plugins")
        print(f"{'✓' if result.ok else '✗'} {result.message}")
        all_ok = all_ok and result.ok
    return 0 if all_ok else 1


# ═══════════════════════════════════════════════════════════════
# lock / unlock / verify
# ═══════════════════════════════════════════════════════════════

def cmd_lock(args: argparse.Namespace) -> int:
    if not args.yes:
        print("Отменено: lock требует флаг --yes.\nПример: python framework_manager.py lock --yes")
        return 1

    from core.lockfile import generate_lock, write_lock

    loader = build_static_loader()
    result = generate_lock(loader)
    if not result.ok:
        print(f"Отменено: {result.error}")
        return 1
    write_lock(result.data)
    print(
        f"Зафиксировано {len(result.data['plugins'])} плагин(ов) и "
        f"{len(result.data['pip_versions'])} pip-пакет(ов) в plugins.lock.json.\n"
        f"install/update откажутся вносить изменения, пока не будет `unlock --yes`."
    )
    return 0


def cmd_unlock(args: argparse.Namespace) -> int:
    if not args.yes:
        print("Отменено: unlock требует флаг --yes.\nПример: python framework_manager.py unlock --yes")
        return 1

    from core.lockfile import set_locked
    if not set_locked(False):
        print("Нечего разлочивать — plugins.lock.json не найден (используйте `lock` сначала).")
        return 1
    print("Разлочено. install/update снова разрешены.")
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    from core.lockfile import verify_against_lock

    loader = build_static_loader()
    result = verify_against_lock(loader)
    if result is None:
        print("plugins.lock.json не найден — нечего сверять (используйте `lock --yes` сначала).")
        return 1

    if result.core_version_mismatch:
        print(f"⚠ ядро: {result.core_version_mismatch}")

    any_issue = bool(result.core_version_mismatch)
    for e in result.entries:
        if e.status == "match":
            print(f"✓ {e.name} — совпадает")
        else:
            any_issue = True
            print(f"⚠ {e.name} — {e.detail}")

    for m in result.pip_mismatches:
        any_issue = True
        print(f"⚠ {m}")

    if not any_issue:
        print("\nВсё совпадает с plugins.lock.json.")
    return 0 if not any_issue else 1


# ═══════════════════════════════════════════════════════════════
# update
# ═══════════════════════════════════════════════════════════════

def cmd_update(args: argparse.Namespace) -> int:
    if not (args.yes or args.noconfirm):
        print(
            "Отменено: update требует --yes (или --noconfirm для полностью "
            "автоматического режима без вопросов по каждому плагину).\n"
            "Примеры:\n"
            "  python framework_manager.py update --yes antispam\n"
            "  python framework_manager.py update --yes            (меню по всем с обновлениями)\n"
            "  python framework_manager.py update --noconfirm       (всё автоматически, без вопросов)"
        )
        return 1

    from core.lockfile import is_locked
    if is_locked():
        print("Отменено: плагины залочены (`lock`). Выполните `unlock --yes` перед обновлением.")
        return 1

    from core.plugin_installer import (
        PluginInstallError, check_for_update, compare_commits,
        fetch_latest_commit_sha, get_installation_info, install_from_github, parse_github_source,
    )

    loader = build_static_loader()
    candidates = [args.name] if args.name else sorted(loader._records.keys())
    if args.name and args.name not in loader._records:
        print(f"Плагин «{args.name}» не найден.")
        return 1

    checkable: list[tuple[str, Any, Any]] = []
    for name in candidates:
        rec = loader._records[name]
        if not rec.repository_url:
            continue
        result = check_for_update(name, rec.version, rec.repository_url)
        if result.error:
            print(f"⚠ {name}: не удалось проверить обновление ({result.error})")
            continue
        if result.has_update:
            checkable.append((name, rec, result))

    if not checkable:
        print("Обновлений не найдено.")
        return 0

    if not args.name and not args.noconfirm:
        print("Доступны обновления:\n")
        for i, (name, rec, result) in enumerate(checkable, 1):
            print(f"  {i}) {name}: {rec.version} -> {result.remote_version}")
        idxs = _prompt_multi_select(len(checkable))
        if not idxs:
            print("Отменено.")
            return 0
        checkable = [checkable[i] for i in idxs]

    live = get_live_bot_info()
    plugins_dir = STAGING_DIR if live else (PROJECT_ROOT / "plugins")
    if live:
        print(f"● Бот запущен (pid {live['pid']}) — обновления будут скачаны в downloaded_updates/.\n")

    all_ok = True
    for name, rec, result in checkable:
        print(f"\n=== {name}: {rec.version} -> {result.remote_version} ===")

        info = get_installation_info(name)
        try:
            owner, repo = parse_github_source(rec.repository_url)
            new_sha = fetch_latest_commit_sha(owner, repo, result.ref)
            if info and info.get("commit_sha"):
                diff = compare_commits(owner, repo, info["commit_sha"], new_sha)
                commits = diff.get("commits", [])
                print(f"Изменения ({diff.get('ahead_by', len(commits))} коммит(ов)):")
                for c in commits[:10]:
                    msg = c["commit"]["message"].splitlines()[0]
                    print(f"  - {c['sha'][:7]} {msg}")
                files = [f["filename"] for f in diff.get("files", [])]
                if files:
                    print(f"Изменённые файлы: {', '.join(files)}")
            else:
                print("(коммит установки не отслежен — детальный diff недоступен, есть только версия)")
        except PluginInstallError as exc:
            print(f"(не удалось получить diff: {exc})")

        if not args.noconfirm:
            answer = input(f"Применить обновление «{name}»? [y/N] > ").strip().lower()
            if answer not in ("y", "yes", "д", "да"):
                print("Пропущено.")
                continue

        try:
            # name_override=rec.path.name — ОБЯЗАТЕЛЬНО: update должен
            # заменить ИМЕННО ТУ папку, где плагин уже лежит, а не
            # создать новую по имени из свежескачанного manifest.json.
            # Без этого — если при install когда-то использовали --name
            # (папка называется не так, как manifest.json → "name") —
            # update создал бы ВТОРУЮ папку рядом со старой, и обе стали
            # бы объявлять одно и то же manifest-имя: ровно та коллизия,
            # которую scan() теперь ловит явным отказом (см. docstring
            # PluginLoader.scan) — но лучше не доводить до неё, а сразу
            # обновлять на место. Воспроизведено и проверено тестом.
            install_result = install_from_github(
                rec.repository_url, plugins_dir, ref=result.ref,
                name_override=rec.path.name, overwrite=True,
            )
        except PluginInstallError as exc:
            print(f"✗ {name}: {exc}")
            all_ok = False
            continue
        print(f"{'✓' if install_result.ok else '✗'} {install_result.message}")
        all_ok = all_ok and install_result.ok

    return 0 if all_ok else 1


# ═══════════════════════════════════════════════════════════════
# info (framework information screen — CLI version of TUI screen 1)
# ═══════════════════════════════════════════════════════════════

def cmd_info(args: argparse.Namespace) -> int:  # noqa: ARG001
    """
    «python framework_manager.py info» — Информация о сборке и её целостности
    (то же самое, что пункт 1 → «Посмотреть информацию и состояние» в TUI).
    """
    from core.manifest import (
        UNKNOWN, display, load_manifest, verify_build_integrity, ManifestError,
    )
    try:
        manifest = load_manifest()
    except ManifestError as exc:
        print(f"Ошибка: {exc}")
        return 1

    live = get_live_bot_info()

    print("=== Информация о Фреймворке ===\n")
    print(f"Название:                {display(manifest, 'name')}")
    print(f"Описание:                {display(manifest, 'description')}")
    print(f"Версия:                  {display(manifest, 'version')}")
    print(f"Авторы:                  {display(manifest, 'authors')}")
    _sha = display(manifest, 'sha256_hash')
    _sha_display = _sha if _sha != "неизвестно" else "⚠ не задан — бот не запустится (запустите: hash --generate)"
    print(f"sha256-хеш:              {_sha_display}")
    print()
    status_str = f"запущен (pid {live['pid']}, порт {live['port']})" if live else "выключен"
    print(f"Статус:                  {status_str}")
    print(f"Официальная подпись:     не реализовано (заготовка)")
    print(f"Главный репозиторий:     {display(manifest, 'repository_url')}")
    print(f"Репозиторий OTA:         {display(manifest, 'ota_repository')}")
    print(f"Репозиторий плагинов:    {display(manifest, 'plugin_repository')}")
    print()

    integrity = verify_build_integrity(manifest)
    if integrity.ok:
        print(f"✓ Целостность сборки подтверждена (хеш совпадает, {integrity.files_hashed} файлов).")
    else:
        print(f"✗ Целостность сборки НЕ подтверждена: {integrity.reason}")

    return 0


# ═══════════════════════════════════════════════════════════════
# hash  (generate / verify build integrity hash)
# ═══════════════════════════════════════════════════════════════

def cmd_hash(args: argparse.Namespace) -> int:
    from core.manifest import (
        compute_source_hash, iter_build_files, load_manifest, verify_build_integrity,
        ManifestError,
    )
    import json as _json

    if args.generate:
        files = iter_build_files()
        h = compute_source_hash()
        try:
            raw = _json.loads(Path("manifest_core.json").read_text(encoding="utf-8"))
        except (FileNotFoundError, _json.JSONDecodeError) as exc:
            print(f"Ошибка чтения manifest_core.json: {exc}")
            return 1
        raw["sha256_hash"] = h
        Path("manifest_core.json").write_text(
            _json.dumps(raw, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        print(f"✓ sha256_hash обновлён в manifest_core.json ({len(files)} файлов):\n  {h}")
        return 0

    if args.verify:
        try:
            manifest = load_manifest()
        except ManifestError as exc:
            print(f"Ошибка: {exc}")
            return 1
        result = verify_build_integrity(manifest)
        if result.ok:
            print(f"✓ Целостность подтверждена ({result.files_hashed} файлов).\n  {result.computed}")
            return 0
        else:
            print(f"✗ {result.reason}")
            return 1

    print("Укажите --generate (записать хеш) или --verify (проверить).")
    return 1


# ═══════════════════════════════════════════════════════════════
# test  (run pytest / unittest from tests/)
# ═══════════════════════════════════════════════════════════════

def cmd_test(args: argparse.Namespace) -> int:  # noqa: ARG001
    import subprocess
    import datetime

    logs_dir = Path("logs") / "tests"
    logs_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    log_path = logs_dir / f"test-log-{stamp}.log"

    # pytest.ini живёт в tests/ — передаём -c tests/pytest.ini
    # Fallback на unittest discover, если pytest не установлен.
    pytest_ini = Path("tests") / "pytest.ini"
    if pytest_ini.exists():
        cmd = [sys.executable, "-m", "pytest", "tests/",
               f"--log-file={log_path}", "--log-file-level=DEBUG",
               "-v", "--tb=short"]
        runner_name = "pytest"
    else:
        print("tests/pytest.ini не найден — используется python -m unittest discover.")
        cmd = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"]
        runner_name = "unittest"

    print(f"Запускаю тесты ({runner_name}) из tests/...\n")
    result = subprocess.run(cmd)

    if runner_name == "pytest":
        print(f"\nЛог сохранён → {log_path}")
    if result.returncode == 0:
        print("✓ Все тесты пройдены.")
    else:
        print("✗ Есть проваленные тесты.")
    return result.returncode


# ═══════════════════════════════════════════════════════════════
# deps  (install requirements from manifest_core.json)
# ═══════════════════════════════════════════════════════════════

def cmd_deps(args: argparse.Namespace) -> int:
    from core.manifest import load_manifest, pip_install_command, requirements_list, ManifestError
    import subprocess

    try:
        manifest = load_manifest()
    except ManifestError as exc:
        print(f"Ошибка: {exc}")
        return 1

    reqs = requirements_list(manifest)
    if not reqs:
        print("manifest_core.json → requirements пуст — нечего устанавливать.")
        return 0

    if args.list:
        print("Зависимости из manifest_core.json:")
        for r in reqs:
            print(f"  {r}")
        return 0

    if args.install:
        cmd = pip_install_command(manifest)
        print(f"Устанавливаю: {' '.join(cmd[3:])}\n")
        result = subprocess.run(cmd)
        return result.returncode

    print("Укажите --install (установить) или --list (показать список).")
    return 1


# ═══════════════════════════════════════════════════════════════
# ota  (Over-the-air update orchestration)
# ═══════════════════════════════════════════════════════════════

def cmd_ota(args: argparse.Namespace) -> int:  # noqa: C901
    """
    python framework_manager.py ota [--check|--download|--apply|--promote|--rollback|--status|--init-slots]
    """
    from core.manifest import load_manifest, display, ManifestError
    from core.ota.slot_manager import (
        load_state, set_status, init_slots, prepare_slot_b,
        promote_b_to_a, rollback, SLOT_B_DIR,
    )

    try:
        manifest = load_manifest()
    except ManifestError as exc:
        print(f"Ошибка манифеста: {exc}")
        return 1

    current_version = display(manifest, "version")
    ota_repo        = display(manifest, "ota_repository", default="")
    channel         = display(manifest, "build_channel", default="Stable").lower()

    # ── --status ────────────────────────────────────────────
    if args.ota_action == "status":
        state = load_state()
        print("=== OTA статус ===")
        print(f"Статус:           {state.status}")
        print(f"Активный слот:    {state.active_slot}")
        print(f"Ожидающий слот:   {state.pending_slot or '—'}")
        print(f"Ожидающая версия: {state.pending_version or '—'}")
        print(f"Тест начат:       {state.test_started_at or '—'}")
        # max_crashes убран из OTAState — значение живёт в config.ota.max_crashes
        print(f"Крашей:           {state.crash_count}")
        if state.last_error:
            print(f"Последняя ошибка: {state.last_error}")
        return 0

    # ── --init-slots ─────────────────────────────────────────
    if args.ota_action == "init-slots":
        print("Инициализирую slots/a/ из текущих файлов...")
        init_slots()
        print("✓ slots/a/ готов. Скопируйте configs/.env в slots/a/configs/.env")
        return 0

    # ── --check ──────────────────────────────────────────────
    if args.ota_action == "check":
        from core.ota.checker import check_for_update
        has_update, release, msg = check_for_update(current_version, ota_repo, channel)
        print(msg)
        return 0 if has_update else 1

    # ── --download ───────────────────────────────────────────
    if args.ota_action == "download":
        from core.ota.checker import check_for_update
        from core.ota.downloader import download_release
        from pathlib import Path as _Path

        has_update, release, msg = check_for_update(current_version, ota_repo, channel)
        if not has_update:
            print(msg)
            # release is not None означает что канал достижим, просто версия актуальна
            return 0 if release is not None else 1
        print(msg)

        dest = _Path("slots") / "b" / "_incoming"
        set_status("downloading")
        try:
            from core.config import load_config as _lc
            _chunk_kb = _lc().ota.download_chunk_kb
        except Exception:
            _chunk_kb = 64
        result = download_release(release, dest, chunk_kb=_chunk_kb, progress_cb=print)
        if not result.ok:
            set_status("failed", last_error=result.reason)
            print(f"✗ {result.reason}")
            return 1
        set_status("verifying")
        print("✓ Скачано. Запустите: python framework_manager.py ota --apply")
        return 0

    # ── --apply ──────────────────────────────────────────────
    if args.ota_action == "apply":
        from pathlib import Path as _Path
        from core.ota.verifier import full_verify_and_extract, OTAVerifyError
        from core.ota.checker import check_for_update

        incoming = _Path("slots") / "b" / "_incoming"
        zip_path = incoming / "framework.zip"
        sig_path = incoming / "framework.zip.sig"

        if not zip_path.exists():
            print("Архив не найден. Сначала запустите: python framework_manager.py ota --download")
            return 1

        # Попытаемся получить версию из скачанного manifest или из релиза
        has_update, release, _ = check_for_update(current_version, ota_repo, channel)
        version = release.version if release else "?"

        # Проверяем .env для BOT_TOKEN_TEST
        from dotenv import load_dotenv as _ld
        import os as _os
        from core.config import ENV_PATH
        _ld(dotenv_path=ENV_PATH)
        bot_token_test = _os.getenv("BOT_TOKEN_TEST", "").strip()
        if not bot_token_test:
            print("BOT_TOKEN_TEST не задан в configs/.env — невозможно запустить тест слота B.")
            return 1

        # Верификация + распаковка
        unpack_dir = _Path("slots") / "b" / "_unpacked"
        set_status("verifying")
        try:
            full_verify_and_extract(zip_path, sig_path, unpack_dir, progress_cb=print)
        except OTAVerifyError as exc:
            set_status("failed", last_error=str(exc))
            print(f"✗ Верификация провалилась: {exc}")
            return 1

        # Готовим слот B
        prepare_slot_b(unpack_dir, version, bot_token_test)
        print(f"\n✓ Слот B подготовлен. Запускаю тест версии {version}...")

        # Запуск теста
        from core.ota.test_runner import run_slot_b_test
        from core.config import load_config
        try:
            cfg = load_config()
            max_crashes = cfg.ota.max_crashes
            duration    = cfg.ota.test_duration_s
            _poll       = cfg.ota.poll_interval_s
            _grace      = cfg.ota.startup_grace_s
        except Exception:
            max_crashes = 3
            duration    = 300
            _poll, _grace = 5, 10
        result = run_slot_b_test(SLOT_B_DIR, max_crashes, duration,
                                  poll_interval_s=_poll, startup_grace_s=_grace,
                                  progress_cb=print)

        if result.outcome == "rollback":
            rollback(result.reason)
            print(f"✗ Откат: {result.reason}")
            return 1

        # Тест прошёл — спрашиваем о промоуте
        set_status("ready_to_promote")
        try:
            cfg = load_config()
            interrupt_allowed  = cfg.ota.interrupt_allowed
            interrupt_timeout  = cfg.ota.interrupt_timeout_s
            bot_token_test_cfg = cfg.bot_token_test
            admin_chat_id      = cfg.admin_chat_id
        except Exception:
            interrupt_allowed  = True
            interrupt_timeout  = 60
            bot_token_test_cfg = bot_token_test
            admin_chat_id      = ""

        if interrupt_allowed:
            from core.ota.notifier import ask_interrupt_promote, notify_promote_done, notify_rollback as _nr
            apply_now = ask_interrupt_promote(
                version, release.description if release else "",
                bot_token_test_cfg, admin_chat_id, interrupt_timeout,
            )
        else:
            apply_now = False

        if apply_now:
            set_status("promoting")
            print("Останавливаю слот A и применяю обновление...")
            from core.ota.process_manager import stop_slot_a, restart_slot_a
            try:
                _pcfg = load_config().process
                _mgr, _unit, _svc = _pcfg.manager, _pcfg.unit_name, _pcfg.supervisor_name
            except Exception:
                _mgr, _unit, _svc = "auto", "accountmanager", "accountmanager"

            print(stop_slot_a(_mgr, _unit, _svc))
            promote_b_to_a()
            print(restart_slot_a(manager=_mgr, unit_name=_unit, supervisor_name=_svc))
            from core.ota.notifier import notify_promote_done
            notify_promote_done(version, bot_token_test_cfg, admin_chat_id)
            print(f"✓ Версия {version} применена и активна.")
        else:
            set_status("pending_promote")
            print(f"✓ Версия {version} будет применена при следующей остановке бота.")
        return 0

    # ── --promote (принудительно) ────────────────────────────
    if args.ota_action == "promote":
        state = load_state()
        if state.status not in ("ready_to_promote", "pending_promote"):
            print(f"Промоут недоступен в текущем статусе: {state.status}")
            return 1
        promote_b_to_a()
        print(f"✓ Промоут выполнен. Версия {state.pending_version} теперь активна.")
        return 0

    # ── --rollback (принудительно) ───────────────────────────
    if args.ota_action == "rollback":
        state = load_state()
        rollback("Принудительный откат через CLI")
        print(f"✓ Откат выполнен. Слот A ({state.active_slot}) не затронут.")
        return 0

    print("Укажите действие: --check, --download, --apply, --promote, --rollback, --status, --init-slots")
    return 1


# ═══════════════════════════════════════════════════════════════
# argparse
# ═══════════════════════════════════════════════════════════════

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="framework_manager.py",
        description="Менеджер Фреймворка AccountManager.",
    )
    sub = p.add_subparsers(dest="command", required=True)

    p_status = sub.add_parser("status", help="статус плагинов + дерево зависимостей")
    p_status.add_argument("--name", help="показать только один плагин")
    p_status.add_argument("--filter", choices=["running", "skipped"], help="показать только загруженные/пропущенные")
    p_status.set_defaults(func=cmd_status)

    p_restart = sub.add_parser("restart", help="перезагрузить плагин(ы) в уже запущенном боте")
    group = p_restart.add_mutually_exclusive_group()
    group.add_argument("name", nargs="?", help="имя плагина")
    group.add_argument("--all", action="store_true", help="перезагрузить все загруженные плагины")
    p_restart.set_defaults(func=cmd_restart)

    p_install = sub.add_parser("install", help="установить плагин (локально или с GitHub)")
    p_install.add_argument("source", nargs="?", help="локальный путь, owner/repo, URL, или имя из каталога")
    p_install.add_argument("--yes", action="store_true", help="подтверждение (обязательно)")
    p_install.add_argument("--file", help="каталог плагинов вместо plugin_list.json")
    p_install.add_argument("--ref", help="ветка/тег для источника с GitHub")
    p_install.add_argument("--subdir", help="подпапка репозитория, если плагин не в корне")
    p_install.add_argument("--overwrite", action="store_true", help="заменить уже установленный плагин")
    p_install.set_defaults(func=cmd_install)

    p_uninstall = sub.add_parser("uninstall", help="удалить плагин (не трогает таблицы БД)")
    p_uninstall.add_argument("name", nargs="?", help="имя плагина")
    p_uninstall.add_argument("--yes", action="store_true", help="подтверждение (обязательно)")
    p_uninstall.set_defaults(func=cmd_uninstall)

    p_lock = sub.add_parser("lock", help="зафиксировать текущие версии плагинов и pip-пакетов")
    p_lock.add_argument("--yes", action="store_true", help="подтверждение (обязательно)")
    p_lock.set_defaults(func=cmd_lock)

    p_unlock = sub.add_parser("unlock", help="снять фиксацию — разрешить install/update снова")
    p_unlock.add_argument("--yes", action="store_true", help="подтверждение (обязательно)")
    p_unlock.set_defaults(func=cmd_unlock)

    p_verify = sub.add_parser("verify", help="сверить текущее состояние с plugins.lock.json")
    p_verify.set_defaults(func=cmd_verify)

    p_update = sub.add_parser("update", help="проверить и применить обновления плагинов с GitHub")
    p_update.add_argument("name", nargs="?", help="имя плагина")
    p_update.add_argument("--yes", action="store_true", help="подтверждение (обязательно, либо --noconfirm)")
    p_update.add_argument(
        "--noconfirm", "-y", action="store_true",
        help="полностью автоматически — без вопроса по каждому плагину (аналог apt -y)",
    )
    p_update.set_defaults(func=cmd_update)

    p_info = sub.add_parser("info", help="информация о сборке фреймворка и целостность")
    p_info.set_defaults(func=cmd_info)

    p_hash = sub.add_parser("hash", help="управление sha256-хешем сборки в manifest_core.json")
    p_hash.add_argument("--generate", action="store_true", help="вычислить и записать хеш в manifest_core.json")
    p_hash.add_argument("--verify",   action="store_true", help="проверить хеш из манифеста против текущих файлов")
    p_hash.set_defaults(func=cmd_hash)

    p_test = sub.add_parser("test", help="запустить тесты фреймворка из tests/")
    p_test.set_defaults(func=cmd_test)

    p_deps = sub.add_parser("deps", help="зависимости из manifest_core.json → requirements")
    p_deps.add_argument("--install", action="store_true", help="установить через pip")
    p_deps.add_argument("--list",    action="store_true", help="показать список зависимостей")
    p_deps.set_defaults(func=cmd_deps)

    p_ota = sub.add_parser("ota", help="управление OTA A/B обновлениями фреймворка")
    p_ota.add_argument(
        "ota_action",
        choices=["check", "download", "apply", "promote", "rollback", "status", "init-slots"],
        help=(
            "check=проверить | download=скачать | apply=тест+промоут | "
            "promote=принудительный промоут | rollback=откат | "
            "status=статус | init-slots=инициализация слотов"
        ),
    )
    p_ota.set_defaults(func=cmd_ota)

    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
