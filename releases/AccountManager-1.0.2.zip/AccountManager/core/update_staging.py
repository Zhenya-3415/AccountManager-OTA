"""
core/update_staging.py — применение отложенных обновлений плагинов
при graceful shutdown.

Workflow: install/update, пока бот запущен, кладёт файлы в
downloaded_updates/<name>/, а не прямо в plugins/ (см.
framework_manager.py: cmd_install). При штатной остановке (main.py,
САМЫЙ ПОСЛЕДНИЙ шаг graceful shutdown — после закрытия БД, сессии
бота и control-сервера) эта отложенная установка применяется:

  1. Если downloaded_updates/ пуст или не существует — делать нечего,
     обычное завершение процесса, БЕЗ перезапуска.

  2. Если есть что применять — СНАЧАЛА валидируются ВСЕ staged-плагины
     (manifest.json + синтаксис plugin.py — та же проверка, что уже
     прошли на этапе install/update, здесь повторно как защита от
     повреждения файлов между скачиванием и применением). Если хоть
     ОДИН не проходит — вся операция отменяется ЦЕЛИКОМ: plugins/ не
     трогается вообще, проблемный плагин остаётся в
     downloaded_updates/ для разбора, обычное завершение БЕЗ
     перезапуска. Частичное применение здесь недопустимо: лучше не
     обновить ничего, чем обновить наполовину и не суметь стартовать.

  3. Только если ВСЕ валидны — бэкап ТЕКУЩЕЙ plugins/ в
     plugins/plugins_old.zip (перезаписывает предыдущий бэкап —
     хранится только самый свежий, как и просили; это не история
     версий, а страховка на один шаг назад). Бэкап — ВСЕГДА первое
     деструктивное... точнее, первое ЛЮБОЕ изменение на диске: если
     дальше что-то пойдёт не так, у пользователя остаётся способ
     вручную распаковать архив обратно.

  4. Каждый staged-плагин переносится из downloaded_updates/<name>/ в
     plugins/<name>/ (замещая старую версию с тем же именем, если
     была — ровно то же самое, что install --overwrite).

  5. downloaded_updates/ очищается.

  6. Процесс перезапускает сам себя (os.execv) — ТОЛЬКО если что-то
     реально применялось, а не при каждой обычной остановке: иначе
     штатный Ctrl+C "останови бота" на Linux/Termux превратился бы в
     "бот сам себя перезапускает и не желает останавливаться".
     os.execv на POSIX (Linux/Termux) заменяет образ процесса на
     месте (тот же PID); на Windows CPython эмулирует это через
     spawn нового процесса + немедленный exit текущего (задокументи-
     рованное поведение самого os.execv, не наша самодеятельность) —
     функциональный результат одинаков ("бот перезапустился с новым
     кодом плагинов"), просто PID на Windows меняется.
"""
from __future__ import annotations

import os
import shutil
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from core.logger import get_logger

logger = get_logger("update_staging")

# Абсолютный путь к запущенному скрипту — считается ОДИН РАЗ здесь,
# при импорте модуля (то есть практически в самом начале жизни
# процесса, до того как что-либо успело сменить cwd). os.execv ниже
# использует именно это, а не os.path.abspath(sys.argv[0]) в момент
# вызова restart_process() — если бы cwd процесса к тому моменту
# успел измениться, sys.argv[0] (если это относительный путь) стал бы
# резолвиться уже НЕ туда, куда нужно. Найдено ровно так — end-to-end
# тестом с реальным os.execv, где сценарий запускался из одной
# директории с чужим cwd.
_ENTRY_SCRIPT_ABS = os.path.abspath(sys.argv[0]) if sys.argv else ""

STAGING_DIR = Path("downloaded_updates")
PLUGINS_DIR = Path("plugins")
BACKUP_PATH = Path("plugins/plugins_old.zip")


@dataclass
class ApplyResult:
    applied: bool                    # было ли вообще что применять
    ok: bool = True                  # применилось ли успешно (имеет смысл только если applied=True)
    applied_plugins: list[str] = field(default_factory=list)
    error: str = ""


def has_staged_updates(staging_dir: Path = STAGING_DIR) -> bool:
    return staging_dir.exists() and any(p.is_dir() for p in staging_dir.iterdir())


def _validate_all_staged(staging_dir: Path) -> tuple[bool, list[str]]:
    from core.plugin_installer import validate_plugin_folder
    errors: list[str] = []
    for p in sorted(staging_dir.iterdir()):
        if not p.is_dir():
            continue
        v = validate_plugin_folder(p)
        if not v.ok:
            errors.append(f"«{p.name}»: {'; '.join(v.errors)}")
    return (not errors), errors


def _backup_plugins(plugins_dir: Path, backup_path: Path) -> None:
    backup_path.parent.mkdir(parents=True, exist_ok=True)
    resolved_backup = backup_path.resolve()
    with zipfile.ZipFile(backup_path, "w", zipfile.ZIP_DEFLATED) as zf:
        if plugins_dir.exists():
            for f in plugins_dir.rglob("*"):
                if f.is_file() and f.resolve() != resolved_backup:
                    zf.write(f, f.relative_to(plugins_dir))


def apply_staged_updates(
    plugins_dir: Path = PLUGINS_DIR,
    staging_dir: Path = STAGING_DIR,
    backup_path: Path = BACKUP_PATH,
) -> ApplyResult:
    """
    Синхронная функция (не async) — вызывается из main.py в самом
    конце graceful shutdown, когда event loop уже, по сути, не нужен
    (следующий шаг после успешного применения — os.execv, который
    вообще не возвращает управление в текущий процесс на POSIX).
    """
    if not has_staged_updates(staging_dir):
        return ApplyResult(applied=False)

    ok, errors = _validate_all_staged(staging_dir)
    if not ok:
        logger.error(
            "Отложенные обновления НЕ применены — валидация не пройдена:\n  "
            + "\n  ".join(errors)
            + f"\nplugins/ не тронут. Содержимое {staging_dir}/ оставлено для разбора."
        )
        return ApplyResult(applied=False, ok=False, error="; ".join(errors))

    logger.info(f"Бэкап текущей {plugins_dir}/ в {backup_path}...")
    _backup_plugins(plugins_dir, backup_path)

    applied: list[str] = []
    for p in sorted(staging_dir.iterdir()):
        if not p.is_dir():
            continue
        target = plugins_dir / p.name
        if target.exists():
            shutil.rmtree(target)
        shutil.move(str(p), str(target))
        applied.append(p.name)
        logger.info(f"Применено обновление: «{p.name}».")

    shutil.rmtree(staging_dir, ignore_errors=True)
    return ApplyResult(applied=True, ok=True, applied_plugins=applied)


def restart_process() -> None:
    """
    Перезапускает текущий процесс с теми же argv. На POSIX не
    возвращает управление вызывающему коду (процесс замещается) — эта
    функция логически "не возвращается"; на Windows возвращает
    управление только если сам execv не удался (см. докстринг модуля).

    Использует _ENTRY_SCRIPT_ABS (абсолютный путь, вычисленный при
    импорте модуля), а не sys.argv[0] заново — если argv[0] задан
    относительным путём (обычный случай: `python main.py`), а cwd
    процесса к моменту вызова этой функции успел измениться, повторное
    вычисление abspath() от argv[0] сейчас резолвило бы уже не туда.
    """
    args = [sys.executable, _ENTRY_SCRIPT_ABS] + sys.argv[1:]
    logger.info(f"Перезапуск процесса (os.execv): {args}")
    os.execv(sys.executable, args)
