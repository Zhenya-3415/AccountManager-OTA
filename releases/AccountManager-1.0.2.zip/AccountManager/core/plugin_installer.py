"""
core/plugin_installer.py — установка, удаление и проверка обновлений
плагинов: локально (папка или .zip) и с GitHub.

Источники для install:
  - локальный путь к директории или .zip-файлу
  - "owner/repo", "https://github.com/owner/repo" (ветка/тег — из
    GitHub API default_branch, если не указан --ref явно)

ВАЖНО про доверие: plugin.py выполняется с полными правами процесса
(вся архитектура core/patches.py построена на том, что плагин может
патчить что угодно в ядре). Установка ЛЮБОГО плагина, из любого
источника — это решение доверять его коду; песочницы тут нет и не
планируется (см. общую философию проекта: "безопасно" значит
"устойчиво и обратимо", а не "защищено от автора плагина"). Функции
этого модуля явно предупреждают об этом в возвращаемых сообщениях,
а не делают вид, что установка откуда угодно безопасна по умолчанию.

GitHub REST API анонимно ограничен 60 запросами/час (проверено
эмпирически на 2026-07-21: GET /rate_limit -> limit=60). Функции здесь
экономят запросы где возможно: сам manifest.json тянется через
raw.githubusercontent.com (НЕ считается в квоту api.github.com — тоже
проверено эмпирически), а api.github.com дёргается только за тем, что
больше нигде не достать (default_branch, sha, compare-диф).
"""
from __future__ import annotations

import ast
import json
import re
import shutil
import stat
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from core.logger import get_logger

logger = get_logger("plugin_installer")

_USER_AGENT = "AccountManager-plugin-manager"
_REQUIRED_MANIFEST_FIELDS = ("name", "version")
_GITHUB_SOURCE_RE = re.compile(
    r"^(?:https?://github\.com/)?([A-Za-z0-9._-]+)/([A-Za-z0-9._-]+?)(?:\.git)?/?$"
)

# HTTP-коды, на которые ИМЕЕТ смысл повторить запрос: перегрузка/сбой на
# стороне GitHub или прокси между нами и им, а не наша ошибка запроса.
# 404 и прочие 4xx сюда НЕ входят — повтор точно не поможет.
_RETRYABLE_HTTP_CODES = frozenset({403, 429, 500, 502, 503, 504})
_RETRY_BACKOFF_SECONDS = (1.5, 3.0)  # 2 повторные попытки, итого 3


class PluginInstallError(Exception):
    """Ошибка установки/удаления — не пропускает молча, но и не крашит framework_manager.py."""


def _is_exhausted_rate_limit(exc: urllib.error.HTTPError) -> bool:
    """
    403 бывает двух разных природ: реально исчерпанный анонимный лимит
    (GitHub тогда явно шлёт X-RateLimit-Remaining: 0 — повторять смысла
    нет, ждать минимум до сброса окна) и единичный транзиентный сбой на
    границе сети (тот же запрос секундой позже нередко проходит —
    воспроизведено эмпирически 2026-08-15: 2 успеха из 3 подряд
    идентичных запросов при остатке квоты 36/60, то есть 403 НЕ был
    связан с лимитом вовсе). Различаем по заголовку, а не гадаем.
    """
    return exc.code == 403 and exc.headers.get("X-RateLimit-Remaining") == "0"


def _urlopen_with_retry(req: urllib.request.Request, *, timeout: float):
    """
    До len(_RETRY_BACKOFF_SECONDS) повторных попыток с бэкоффом — ТОЛЬКО
    для транзиентных условий (см. _RETRYABLE_HTTP_CODES и
    _is_exhausted_rate_limit). Настоящее исчерпание квоты и любая
    постоянная ошибка (404 и т.п.) пробрасываются немедленно, без
    единой лишней попытки. Финальная ошибка (после всех попыток или
    сразу для непостоянной) пробрасывается КАК ЕСТЬ — перевод в
    PluginInstallError с точным сообщением остаётся на вызывающей
    стороне, у каждой свой контекст (404 в fetch_remote_manifest значит
    не то же самое, что 404 в _github_api_get).
    """
    for attempt, _ in enumerate((*_RETRY_BACKOFF_SECONDS, None)):
        try:
            return urllib.request.urlopen(req, timeout=timeout)
        except urllib.error.HTTPError as exc:
            if exc.code not in _RETRYABLE_HTTP_CODES or _is_exhausted_rate_limit(exc):
                raise
            if attempt >= len(_RETRY_BACKOFF_SECONDS):
                raise
            delay = _RETRY_BACKOFF_SECONDS[attempt]
            logger.warning(f"Транзиентный HTTP {exc.code} от {req.full_url} — повтор через {delay}с.")
            time.sleep(delay)
        except urllib.error.URLError as exc:
            if attempt >= len(_RETRY_BACKOFF_SECONDS):
                raise
            delay = _RETRY_BACKOFF_SECONDS[attempt]
            logger.warning(f"Сетевая ошибка ({exc.reason}) при обращении к {req.full_url} — повтор через {delay}с.")
            time.sleep(delay)
    raise AssertionError("unreachable")  # цикл либо возвращает, либо бросает выше


# ═══════════════════════════════════════════════════════════════
# GitHub — низкоуровневые вызовы
# ═══════════════════════════════════════════════════════════════

def parse_github_source(source: str) -> tuple[str, str]:
    """"owner/repo" | "https://github.com/owner/repo[.git]" -> (owner, repo)."""
    m = _GITHUB_SOURCE_RE.match(source.strip())
    if not m:
        raise PluginInstallError(
            f"не похоже на источник GitHub: «{source}» (ожидается owner/repo "
            f"или https://github.com/owner/repo)"
        )
    return m.group(1), m.group(2)


def _github_api_get(path: str) -> dict[str, Any]:
    url = f"https://api.github.com{path}"
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    try:
        with _urlopen_with_retry(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        if exc.code == 403:
            if _is_exhausted_rate_limit(exc):
                raise PluginInstallError(
                    "GitHub API: анонимный лимит 60 запросов/час исчерпан "
                    "(X-RateLimit-Remaining: 0). Подождите сброса окна."
                ) from exc
            raise PluginInstallError(
                "GitHub API вернул 403 (не из-за лимита — квота не исчерпана) "
                "даже после повторных попыток. Похоже на временный сбой сети "
                "или самого GitHub — повторите чуть позже."
            ) from exc
        if exc.code == 404:
            raise PluginInstallError(f"GitHub API: не найдено ({path}).") from exc
        raise PluginInstallError(f"GitHub API вернул {exc.code}: {exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise PluginInstallError(f"нет соединения с GitHub: {exc.reason}") from exc


def fetch_repo_metadata(owner: str, repo: str) -> dict[str, Any]:
    """GET /repos/{owner}/{repo} — default_branch, pushed_at, description и т.п."""
    return _github_api_get(f"/repos/{owner}/{repo}")


def fetch_latest_commit_sha(owner: str, repo: str, ref: str) -> str:
    data = _github_api_get(f"/repos/{owner}/{repo}/commits/{ref}")
    sha = data.get("sha")
    if not sha:
        raise PluginInstallError(f"не удалось получить commit SHA для {owner}/{repo}@{ref}")
    return sha


def compare_commits(owner: str, repo: str, base: str, head: str) -> dict[str, Any]:
    """GET /repos/{owner}/{repo}/compare/{base}...{head} — коммиты + изменённые файлы между ними."""
    return _github_api_get(f"/repos/{owner}/{repo}/compare/{base}...{head}")


def fetch_remote_manifest(owner: str, repo: str, ref: str, subdir: str = "") -> dict[str, Any]:
    """
    GET raw.githubusercontent.com/.../manifest.json — НЕ через api.github.com,
    не расходует лимит в 60 запросов/час (проверено эмпирически).
    """
    prefix = f"{subdir.strip('/')}/" if subdir else ""
    url = f"https://raw.githubusercontent.com/{owner}/{repo}/{ref}/{prefix}manifest.json"
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    try:
        with _urlopen_with_retry(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise PluginInstallError(
                f"manifest.json не найден в {owner}/{repo}@{ref}"
                + (f" (subdir={subdir})" if subdir else "")
            ) from exc
        raise PluginInstallError(f"не удалось получить manifest.json: HTTP {exc.code}") from exc
    except (urllib.error.URLError, json.JSONDecodeError) as exc:
        raise PluginInstallError(f"не удалось получить/разобрать manifest.json: {exc}") from exc


def download_github_zip(owner: str, repo: str, ref: str) -> Path:
    """
    Скачивает архив ветки/тега/коммита через codeload.github.com (не
    api.github.com — отдельный CDN, не JSON API) во временный файл.
    Структура архива (проверено эмпирически): один каталог верхнего
    уровня "{repo}-{ref}/" со всем содержимым внутри.
    """
    url = f"https://codeload.github.com/{owner}/{repo}/zip/{ref}"
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    tmp = Path(tempfile.mkstemp(suffix=".zip")[1])
    try:
        with _urlopen_with_retry(req, timeout=60) as resp, open(tmp, "wb") as f:
            shutil.copyfileobj(resp, f)
    except urllib.error.HTTPError as exc:
        tmp.unlink(missing_ok=True)
        raise PluginInstallError(f"не удалось скачать архив {owner}/{repo}@{ref}: HTTP {exc.code}") from exc
    except urllib.error.URLError as exc:
        tmp.unlink(missing_ok=True)
        raise PluginInstallError(f"не удалось скачать архив {owner}/{repo}@{ref}: {exc.reason}") from exc
    return tmp


# ═══════════════════════════════════════════════════════════════
# Извлечение и валидация
# ═══════════════════════════════════════════════════════════════

def extract_zip_plugin_dir(zip_path: Path, dest: Path, subdir: str = "") -> Path:
    """
    Распаковывает zip во временную dest, находит папку плагина внутри
    единственного каталога верхнего уровня архива (+ опциональный
    subdir, если репозиторий содержит несколько плагинов). Возвращает
    путь к найденной папке плагина.
    """
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
        if not names:
            raise PluginInstallError("архив пуст.")
        top_level = names[0].split("/")[0]
        if not all(n.startswith(top_level + "/") or n == top_level for n in names):
            raise PluginInstallError(
                "архив не соответствует ожидаемой структуре GitHub-zip "
                "(один каталог верхнего уровня)."
            )
        zf.extractall(dest)

    plugin_dir = dest / top_level
    if subdir:
        plugin_dir = plugin_dir / subdir.strip("/")
    if not plugin_dir.is_dir():
        raise PluginInstallError(f"каталог «{subdir or '.'}» не найден в архиве.")
    return plugin_dir


@dataclass
class ValidationResult:
    ok: bool
    manifest: Optional[dict[str, Any]] = None
    errors: list[str] = field(default_factory=list)


def validate_plugin_folder(path: Path) -> ValidationResult:
    """
    Минимальная проверка перед установкой: manifest.json — валидный
    JSON с обязательными полями (name, version); plugin.py существует
    и хотя бы синтаксически корректен (ast.parse — без исполнения кода,
    исполнять чужой код на этапе установки не нужно и небезопаснее,
    чем просто скопировать файлы).
    """
    errors: list[str] = []
    manifest_path = path / "manifest.json"
    plugin_path = path / "plugin.py"

    manifest: Optional[dict[str, Any]] = None
    if not manifest_path.exists():
        errors.append("manifest.json отсутствует.")
    else:
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            errors.append(f"manifest.json содержит невалидный JSON: {exc}")
        else:
            for f_name in _REQUIRED_MANIFEST_FIELDS:
                if f_name not in manifest:
                    errors.append(f"manifest.json: отсутствует обязательное поле «{f_name}».")

    if not plugin_path.exists():
        errors.append("plugin.py отсутствует.")
    else:
        try:
            ast.parse(plugin_path.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            errors.append(f"plugin.py содержит синтаксическую ошибку: {exc}")

    return ValidationResult(ok=not errors, manifest=manifest, errors=errors)


def _normalize_permissions(path: Path) -> None:
    """POSIX: делает все файлы читаемыми владельцем после распаковки архива."""
    for p in path.rglob("*"):
        try:
            if p.is_file():
                p.chmod(p.stat().st_mode | stat.S_IRUSR | stat.S_IWUSR)
            elif p.is_dir():
                p.chmod(p.stat().st_mode | stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
        except OSError:
            pass  # Windows и т.п. — не критично, не блокируем установку


# ═══════════════════════════════════════════════════════════════
# Install / Uninstall
# ═══════════════════════════════════════════════════════════════

@dataclass
class InstallResult:
    ok: bool
    name: str = ""
    message: str = ""
    installed_path: Optional[Path] = None
    manifest: Optional[dict[str, Any]] = None
    commit_sha: Optional[str] = None


def _finalize_install(
    source_dir: Path,
    plugins_dir: Path,
    *,
    name_override: Optional[str],
    overwrite: bool,
    commit_sha: Optional[str] = None,
) -> InstallResult:
    validation = validate_plugin_folder(source_dir)
    if not validation.ok:
        return InstallResult(ok=False, message="; ".join(validation.errors))

    name = name_override or validation.manifest["name"]
    target = plugins_dir / name
    if target.exists() and not overwrite:
        return InstallResult(
            ok=False, name=name,
            message=f"плагин «{name}» уже установлен (используйте overwrite, чтобы заменить).",
        )

    _normalize_permissions(source_dir)

    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(source_dir, target)

    return InstallResult(
        ok=True, name=name, installed_path=target,
        manifest=validation.manifest, commit_sha=commit_sha,
        message=f"плагин «{name}» установлен в {target}.",
    )


def install_from_local(
    source: Path, plugins_dir: Path, *, name_override: Optional[str] = None, overwrite: bool = False
) -> InstallResult:
    """source — директория с manifest.json+plugin.py, либо .zip с той же структурой внутри."""
    if not source.exists():
        return InstallResult(ok=False, message=f"источник «{source}» не найден.")

    if source.is_file() and source.suffix == ".zip":
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            with zipfile.ZipFile(source) as zf:
                zf.extractall(tmp_path)
            # либо manifest.json прямо в корне zip, либо внутри одного подкаталога
            candidate = tmp_path
            if not (candidate / "manifest.json").exists():
                subdirs = [p for p in tmp_path.iterdir() if p.is_dir()]
                if len(subdirs) == 1:
                    candidate = subdirs[0]
            result = _finalize_install(candidate, plugins_dir, name_override=name_override, overwrite=overwrite)
            if result.ok:
                record_installation(result.name, source_type="local")
            return result

    if source.is_dir():
        result = _finalize_install(source, plugins_dir, name_override=name_override, overwrite=overwrite)
        if result.ok:
            record_installation(result.name, source_type="local")
        return result

    return InstallResult(ok=False, message=f"«{source}» — не директория и не .zip файл.")


def install_from_github(
    source: str,
    plugins_dir: Path,
    *,
    ref: Optional[str] = None,
    subdir: str = "",
    name_override: Optional[str] = None,
    overwrite: bool = False,
) -> InstallResult:
    owner, repo = parse_github_source(source)

    if ref is None:
        meta = fetch_repo_metadata(owner, repo)
        ref = meta.get("default_branch", "main")

    commit_sha = fetch_latest_commit_sha(owner, repo, ref)
    zip_path = download_github_zip(owner, repo, ref)
    try:
        with tempfile.TemporaryDirectory() as tmp:
            plugin_dir = extract_zip_plugin_dir(zip_path, Path(tmp), subdir=subdir)
            result = _finalize_install(
                plugin_dir, plugins_dir, name_override=name_override,
                overwrite=overwrite, commit_sha=commit_sha,
            )
    finally:
        zip_path.unlink(missing_ok=True)

    if result.ok:
        result.message += f" (GitHub: {owner}/{repo}@{ref}, commit {commit_sha[:7]})"
        record_installation(
            result.name, source_type="github",
            repository_url=f"https://github.com/{owner}/{repo}", ref=ref, commit_sha=commit_sha,
        )
    return result


def uninstall(name: str, plugins_dir: Path) -> InstallResult:
    """
    Удаляет папку плагина. НЕ трогает таблицы БД плагина (namespace
    в schema_version) — вниз-миграций в проекте принципиально нет
    (слишком легко необратимо потерять данные), поэтому решение "стереть
    и данные тоже" оставлено человеку, а не автоматике.
    """
    target = plugins_dir / name
    if not target.exists():
        return InstallResult(ok=False, name=name, message=f"плагин «{name}» не найден в {plugins_dir}.")
    shutil.rmtree(target)
    remove_installation_record(name)
    return InstallResult(
        ok=True, name=name,
        message=(
            f"плагин «{name}» удалён из {plugins_dir}. "
            f"Таблицы БД (namespace «{name}», если были миграции) НЕ тронуты — "
            f"убрать их можно только вручную."
        ),
    )


# ═══════════════════════════════════════════════════════════════
# Проверка обновлений
# ═══════════════════════════════════════════════════════════════

@dataclass
class UpdateCheckResult:
    name: str
    current_version: str
    remote_version: str = ""
    has_update: bool = False
    remote_manifest: Optional[dict[str, Any]] = None
    ref: str = ""
    error: str = ""


def check_for_update(name: str, current_version: str, repository_url: str) -> UpdateCheckResult:
    """Сверяет current_version с version из удалённого manifest.json по repository_url."""
    try:
        owner, repo = parse_github_source(repository_url)
        meta = fetch_repo_metadata(owner, repo)
        ref = meta.get("default_branch", "main")
        remote_manifest = fetch_remote_manifest(owner, repo, ref)
    except PluginInstallError as exc:
        return UpdateCheckResult(name=name, current_version=current_version, error=str(exc))

    remote_version = remote_manifest.get("version", "")
    return UpdateCheckResult(
        name=name,
        current_version=current_version,
        remote_version=remote_version,
        has_update=remote_version != current_version and bool(remote_version),
        remote_manifest=remote_manifest,
        ref=ref,
    )


# ═══════════════════════════════════════════════════════════════
# Метаданные установки — откуда взялся плагин, какой commit
# ═══════════════════════════════════════════════════════════════
#
# Нужны для diff-превью в update ("что изменилось с момента установки")
# — сравнить коммиты можно только если знать, ОТКУДА стартовать.
# manifest.json — файл автора плагина, не место для этого; отдельный
# run/installed_plugins.json — служебные данные самого AccountManager Framework,
# как и run/control.json.

INSTALLED_REGISTRY_PATH = Path("run/installed_plugins.json")


def _load_installed_registry() -> dict[str, dict[str, Any]]:
    try:
        return json.loads(INSTALLED_REGISTRY_PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _save_installed_registry(data: dict[str, dict[str, Any]]) -> None:
    INSTALLED_REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    INSTALLED_REGISTRY_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def record_installation(
    name: str,
    *,
    source_type: str,  # "local" | "github"
    repository_url: str = "",
    ref: str = "",
    commit_sha: str = "",
) -> None:
    import time
    data = _load_installed_registry()
    data[name] = {
        "source_type": source_type,
        "repository_url": repository_url,
        "ref": ref,
        "commit_sha": commit_sha,
        "installed_at": time.time(),
    }
    _save_installed_registry(data)


def get_installation_info(name: str) -> Optional[dict[str, Any]]:
    return _load_installed_registry().get(name)


def remove_installation_record(name: str) -> None:
    data = _load_installed_registry()
    if name in data:
        del data[name]
        _save_installed_registry(data)
