"""
core/middleware.py — core-мидлварь.

UserUpsertMiddleware: при каждом входящем апдейте извлекает from_user
и делает upsert в таблицу users. Регистрируется в main.py как
dp.update.outer_middleware().

Если передан hooks (core/hooks.py: HookBus), после успешного upsert
эмитится "core.user.upserted" — плагины могут подписаться на него
через ctx.on_hook("core.user.upserted", ...) вместо того, чтобы писать
свою копию логики upsert. Для более глубокого вмешательства (например,
изменить сами данные ДО записи, а не просто узнать о ней постфактум)
используйте ctx.patch_before/around на Database.upsert_user напрямую
(core/patches.py) — hooks здесь принципиально «только уведомление».
"""
from __future__ import annotations

from typing import Any, Awaitable, Callable, Optional

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Update, User

from core.database import Database
from core.hooks import HookBus
from core.logger import get_logger

logger = get_logger("middleware")

# Атрибуты Update, которые могут содержать from_user
_UPDATE_ATTRS_WITH_USER = (
    "message",
    "edited_message",
    "channel_post",
    "edited_channel_post",
    "callback_query",
    "inline_query",
    "chosen_inline_result",
    "shipping_query",
    "pre_checkout_query",
    "poll_answer",
    "my_chat_member",
    "chat_member",
    "chat_join_request",
)


def _extract_user(update: Update) -> User | None:
    """Извлекает from_user из любого типа апдейта."""
    for attr in _UPDATE_ATTRS_WITH_USER:
        obj = getattr(update, attr, None)
        if obj is None:
            continue
        user: User | None = getattr(obj, "from_user", None)
        if user is not None:
            return user
    return None


class UserUpsertMiddleware(BaseMiddleware):
    """
    Outer middleware на уровне dp.update.
    Обновляет запись пользователя в БД при каждом апдейте.
    Боты игнорируются.
    """

    def __init__(self, db: Database, hooks: Optional[HookBus] = None) -> None:
        self._db = db
        self._hooks = hooks

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        if isinstance(event, Update):
            user = _extract_user(event)
            if user is not None and not user.is_bot:
                upsert_ok = False
                try:
                    await self._db.upsert_user(
                        user_id=user.id,
                        username=user.username,
                        first_name=user.first_name,
                        last_name=user.last_name,
                        language_code=user.language_code,
                    )
                    upsert_ok = True
                except Exception as exc:
                    # Не прерываем обработку апдейта из-за ошибки в upsert
                    logger.warning(
                        f"upsert_user user_id={user.id} не выполнен: {exc}"
                    )

                # Отдельный try/except: если сам upsert прошёл успешно, а
                # упал именно emit() у подписчиков "core.user.upserted",
                # лог не должен винить в этом upsert_user — раньше оба
                # вызова были в одном try, и сообщение об ошибке
                # неверно утверждало, что "upsert_user не выполнен", хотя
                # запись в БД реально прошла.
                if upsert_ok and self._hooks is not None:
                    try:
                        await self._hooks.emit("core.user.upserted", user=user)
                    except Exception as exc:
                        logger.warning(
                            f"core.user.upserted (user_id={user.id}) обработан с "
                            f"ошибкой в одном из подписчиков; сам upsert_user "
                            f"выполнен успешно: {exc}"
                        )

        return await handler(event, data)