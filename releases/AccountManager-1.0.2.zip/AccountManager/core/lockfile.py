"""
core/lockfile.py — plugins.lock.json: снапшот версий для
воспроизводимости + hold-семантика (apt-mark-hold).

lock (снапшот + hold):
  Фиксирует РОВНО то, что сейчас реально загружается без конфликтов:
  версия+commit каждого плагина, версии всех pip-пакетов, которые
  плагины требуют, версия ядра. Отказывается писать lock, если сейчас
  есть пропущенные плагины или конфликты версий — фиксировать
  нечего, снапшот заведомо нерабочего состояния бесполезен.
  "locked": true в файле — install/update ДОЛЖНЫ отказываться менять
  что-либо, пока не будет unlock (та же идея, что apt-mark-hold).

unlock:
  Снимает "locked" (снапшот в файле остаётся как есть — это история,
  не удаляется).

verify:
  Сравнивает ТЕКУЩЕЕ состояние с зафиксированным в lock-файле, ничего
  не меняет — только отчёт о расхождениях (версии плагинов, версии
  pip-пакетов, изменился ли код плагина без бампа версии — по хэшу
  содержимого plugin.py+manifest.json).
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

LOCK_FILE_PATH = Path("plugins.lock.json")


def _hash_plugin_dir(path: Path) -> str:
    """
    Простой хэш содержимого manifest.json + plugin.py — не крипто-
    стойкость важна, а обнаружение "код поменяли, версию не бампнули".
    """
    h = hashlib.sha256()
    for fname in ("manifest.json", "plugin.py"):
        fpath = path / fname
        if fpath.exists():
            h.update(fpath.read_bytes())
    return h.hexdigest()[:16]


def read_lock() -> Optional[dict[str, Any]]:
    try:
        return json.loads(LOCK_FILE_PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def write_lock(data: dict[str, Any]) -> None:
    LOCK_FILE_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def is_locked() -> bool:
    data = read_lock()
    if not isinstance(data, dict):
        # Файл существует и это валидный JSON, но не объект (например,
        # список) — .get() на нём раньше падал AttributeError вместо
        # того, чтобы просто считаться "не залочено".
        return False
    return bool(data.get("locked"))


def set_locked(value: bool) -> bool:
    """Возвращает False, если lock-файла ещё нет вовсе (нечего [раз]locked-ить),
    либо его содержимое повреждено/не является объектом."""
    data = read_lock()
    if not isinstance(data, dict):
        return False
    data["locked"] = value
    write_lock(data)
    return True


@dataclass
class LockGenerationResult:
    ok: bool
    data: Optional[dict[str, Any]] = None
    error: str = ""


def generate_lock(loader: Any) -> LockGenerationResult:
    """
    loader — уже прогнанный через scan()+check_core_compat()+
    check_pip_deps()+resolve_order() PluginLoader. Отказывается
    фиксировать состояние с пропущенными плагинами.
    """
    if loader._skipped:
        return LockGenerationResult(
            ok=False,
            error=(
                f"есть пропущенные плагины ({', '.join(sorted(loader._skipped))}) — "
                f"фиксировать нерабочее состояние бессмысленно. Смотрите `status`."
            ),
        )

    from core.plugin_installer import get_installation_info

    plugins_data: dict[str, Any] = {}
    pip_versions: dict[str, str] = {}

    for name, rec in loader._records.items():
        info = get_installation_info(name) or {}
        plugins_data[name] = {
            "version": rec.version,
            "commit_sha": info.get("commit_sha", ""),
            "repository_url": rec.repository_url or info.get("repository_url", ""),
            "content_hash": _hash_plugin_dir(rec.path),
        }
        for spec in rec.pip_deps():
            if spec.name not in pip_versions:
                try:
                    from importlib.metadata import version as installed_version
                    pip_versions[spec.name] = installed_version(spec.name)
                except Exception:
                    pip_versions[spec.name] = "?"

    import core as core_pkg
    data = {
        "locked": True,
        "created_at": time.time(),
        "core_version": core_pkg.__version__,
        "plugins": plugins_data,
        "pip_versions": pip_versions,
    }
    return LockGenerationResult(ok=True, data=data)


@dataclass
class VerifyEntry:
    name: str
    status: str  # "match" | "version_changed" | "content_changed" | "missing" | "new"
    detail: str = ""


@dataclass
class VerifyResult:
    entries: list[VerifyEntry] = field(default_factory=list)
    pip_mismatches: list[str] = field(default_factory=list)
    core_version_mismatch: str = ""


def verify_against_lock(loader: Any) -> Optional[VerifyResult]:
    """None, если lock-файла нет вообще."""
    locked = read_lock()
    if locked is None:
        return None

    import core as core_pkg
    result = VerifyResult()
    if locked.get("core_version") != core_pkg.__version__:
        result.core_version_mismatch = f"залочено {locked.get('core_version')}, сейчас {core_pkg.__version__}"

    locked_plugins: dict[str, Any] = locked.get("plugins", {})
    seen = set()
    for name, rec in loader._records.items():
        seen.add(name)
        if name not in locked_plugins:
            result.entries.append(VerifyEntry(name, "new", "не было в lock-файле на момент фиксации"))
            continue
        lp = locked_plugins[name]
        current_hash = _hash_plugin_dir(rec.path)
        if lp.get("version") != rec.version:
            result.entries.append(VerifyEntry(
                name, "version_changed", f"залочено {lp.get('version')}, сейчас {rec.version}"
            ))
        elif lp.get("content_hash") != current_hash:
            result.entries.append(VerifyEntry(
                name, "content_changed", "версия та же, но содержимое (manifest.json/plugin.py) отличается"
            ))
        else:
            result.entries.append(VerifyEntry(name, "match"))

    for name in locked_plugins:
        if name not in seen:
            result.entries.append(VerifyEntry(name, "missing", "был в lock-файле, сейчас не установлен"))

    from importlib.metadata import PackageNotFoundError, version as installed_version
    for pkg, locked_version in locked.get("pip_versions", {}).items():
        try:
            current = installed_version(pkg)
        except PackageNotFoundError:
            result.pip_mismatches.append(f"«{pkg}»: залочено {locked_version}, сейчас НЕ установлен")
            continue
        if current != locked_version:
            result.pip_mismatches.append(f"«{pkg}»: залочено {locked_version}, установлено {current}")

    return result


def check_drift_at_startup(loader: Any) -> Optional[str]:
    """
    Вызывается из main.py сразу после loader.resolve_order(), до
    load_plugins(). is_locked()/verify_against_lock() сами по себе
    ничего не блокируют и не проверяются нигде, кроме команд
    framework_manager.py — то есть "lock" технически не мешает просто
    вручную закинуть/поменять папку в plugins/ в обход install/update
    (та же ситуация, что у apt-mark hold: не защита от dpkg -i руками,
    а протокол работы через штатный инструмент). Но раз это можно
    сделать НЕЗАМЕТНО — сам бот, при каждом старте, пока залочено,
    сверяет то, что РЕАЛЬНО собирается загрузить, с тем, что было
    зафиксировано, и громко предупреждает при расхождении. Это не
    останавливает загрузку (философия проекта — предупреждать, а не
    блокировать без явного запроса пользователя), но расхождение
    больше не может остаться незамеченным в логах.

    Возвращает готовую строку для лога, либо None, если незачем
    (не залочено, лока нет, либо всё совпадает).
    """
    if not is_locked():
        return None
    result = verify_against_lock(loader)
    if result is None:
        return None

    drifted = [e for e in result.entries if e.status != "match"]
    if not drifted and not result.pip_mismatches and not result.core_version_mismatch:
        return None

    lines = [f"  - плагин «{e.name}»: {e.status} ({e.detail})" for e in drifted]
    lines += [f"  - {m}" for m in result.pip_mismatches]
    if result.core_version_mismatch:
        lines.append(f"  - ядро: {result.core_version_mismatch}")

    return (
        "Плагины залочены (plugins.lock.json: locked=true), но обнаружено "
        "расхождение с зафиксированным состоянием — возможно, что-то "
        "установили/изменили в обход framework_manager.py (например, скопировали "
        "файлы в plugins/ вручную):\n" + "\n".join(lines) +
        "\nЗагрузка продолжится как есть — если расхождение осознанное, "
        "запустите `lock --yes` заново, чтобы зафиксировать текущее состояние."
    )
