"""
core/tui.py — curses TUI для Менеджера Фреймворка AccountManager.

Запускается через «python framework_manager.py --tui».

Архитектура — конечный автомат с явным стеком экранов (self._stack):
каждый экран — метод _screen_*(). Навигация:
  ↑/↓ (или k/j)  — переместить курсор
  Enter / цифра  — выбрать пункт
  q / Esc / 0    — вернуться (pop стека)

Раскладка:
  Все экраны используют одну функцию _draw_frame() для рамки + заголовка.
  Экран разбивки плагинов (_screen_plugin_split) — 2 панели в стиле archinstall:
    левая (~35%) — прокручиваемый список, правая (~65%) — детали выбранного.

Fallback:
  При отсутствии или поломке curses (Windows без windows-curses, headless
  Termux, IDE-консоль) ловим Exception в launch_tui() и падаем на
  _text_menu() — простое пронумерованное текстовое меню с той же логикой,
  но без графики. Уже запущенный плагин-менеджер при этом не падает.
"""
from __future__ import annotations

import curses
import datetime
import os
import subprocess
import sys
import textwrap
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Optional

# ── Ленивые импорты из core (core/ и PROJECT_ROOT уже в sys.path
#    когда нас импортирует framework_manager.py) ───────────────────


def _get_manifest() -> dict[str, Any]:
    from core.manifest import load_manifest, ManifestError
    try:
        return load_manifest()
    except ManifestError:
        return {}


def _get_settings():
    from core.settings import load_settings
    return load_settings()


def _get_loader():
    from core.framework_manager import build_static_loader
    return build_static_loader()


def _get_live():
    from core.framework_manager import get_live_bot_info
    return get_live_bot_info()


def _display(manifest: dict, key: str) -> str:
    from core.manifest import display
    return display(manifest, key)


# ══════════════════════════════════════════════════════════════════
# Константы
# ══════════════════════════════════════════════════════════════════

# Цвета (инициализируются в _init_colors)
_C_HEADER   = 1   # белый на синем
_C_SELECTED = 2   # чёрный на зелёном
_C_BORDER   = 3   # синий на дефолтном
_C_OK       = 4   # зелёный
_C_ERR      = 5   # красный
_C_DIM      = 6   # тёмно-серый (dim)

_ESC = 27


def _init_colors() -> None:
    curses.start_color()
    curses.use_default_colors()
    curses.init_pair(_C_HEADER,   curses.COLOR_WHITE,  curses.COLOR_BLUE)
    curses.init_pair(_C_SELECTED, curses.COLOR_BLACK,  curses.COLOR_GREEN)
    curses.init_pair(_C_BORDER,   curses.COLOR_BLUE,   -1)
    curses.init_pair(_C_OK,       curses.COLOR_GREEN,  -1)
    curses.init_pair(_C_ERR,      curses.COLOR_RED,    -1)
    curses.init_pair(_C_DIM,      curses.COLOR_BLACK,  -1)


# ══════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════

def _safe_addstr(win, y: int, x: int, text: str, attr: int = 0) -> None:
    """addstr, игнорирующий выход за границы терминала."""
    h, w = win.getmaxyx()
    if y < 0 or y >= h or x < 0 or x >= w:
        return
    available = w - x
    if available <= 0:
        return
    try:
        win.addstr(y, x, text[:available], attr)
    except curses.error:
        pass


def _draw_frame(stdscr, title: str) -> tuple[int, int, int, int]:
    """
    Рисует рамку и заголовок, возвращает (top, left, h, w) внутренней области.
    """
    stdscr.clear()
    H, W = stdscr.getmaxyx()

    # Заголовок-бар
    header = f" {title} "
    pad = max(0, (W - len(header)) // 2)
    _safe_addstr(stdscr, 0, 0, " " * W, curses.color_pair(_C_HEADER) | curses.A_BOLD)
    _safe_addstr(stdscr, 0, pad, header, curses.color_pair(_C_HEADER) | curses.A_BOLD)

    # Нижняя подсказка
    hint = " [q/ESC/0] Назад   [↑↓] Навигация   [Enter/цифра] Выбор "
    _safe_addstr(stdscr, H - 1, 0, hint[:W].ljust(W), curses.color_pair(_C_BORDER))

    return 1, 0, H - 2, W


def _wait_key(stdscr) -> None:
    """Пауза «нажмите любую клавишу»."""
    H, W = stdscr.getmaxyx()
    _safe_addstr(stdscr, H - 1, 0,
                 " Нажмите любую клавишу, чтобы продолжить... ".ljust(W),
                 curses.color_pair(_C_BORDER))
    stdscr.refresh()
    stdscr.getch()


def _is_back(key: int) -> bool:
    return key in (_ESC, ord('q'), ord('Q'), ord('0'))


def _draw_menu(stdscr, top: int, left: int, inner_h: int, inner_w: int,
               items: list[str], cursor: int, offset: int = 0) -> None:
    """Рисует пронумерованный список с подсвеченным курсором."""
    for i, item in enumerate(items):
        y = top + 1 + i - offset
        if y < top + 1 or y >= top + inner_h:
            continue
        label = f"  {i + 1}. {item}"
        attr = curses.color_pair(_C_SELECTED) | curses.A_BOLD if i == cursor else 0
        _safe_addstr(stdscr, y, left + 2, label[:inner_w - 4].ljust(inner_w - 4), attr)


def _run_menu(stdscr, title: str, items: list[str]) -> int:
    """
    Полноэкранное пронумерованное меню. Возвращает 0-based индекс
    выбранного пункта или -1 если пользователь вышел.
    """
    cursor = 0
    while True:
        top, left, inner_h, inner_w = _draw_frame(stdscr, title)
        visible = inner_h - 2
        offset = max(0, cursor - visible + 1)
        _draw_menu(stdscr, top, left, inner_h, inner_w, items, cursor, offset)
        stdscr.refresh()

        key = stdscr.getch()
        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            return -1
        if key in (curses.KEY_UP, ord('k')) and cursor > 0:
            cursor -= 1
        elif key in (curses.KEY_DOWN, ord('j')) and cursor < len(items) - 1:
            cursor += 1
        elif key in (curses.KEY_ENTER, 10, 13):
            return cursor
        elif ord('1') <= key <= ord('9'):
            idx = key - ord('1')
            if 0 <= idx < len(items):
                return idx


# ══════════════════════════════════════════════════════════════════
# Экраны — Управление фреймворком
# ══════════════════════════════════════════════════════════════════

def _screen_framework_info(stdscr) -> None:
    from core.manifest import verify_build_integrity

    manifest = _get_manifest()
    live = _get_live()

    while True:
        top, left, inner_h, inner_w = _draw_frame(stdscr, "Информация о фреймворке")
        loader = _get_loader()
        loaded_n = len(loader._records) - len(loader._skipped)
        skipped_n = len(loader._skipped)

        lines = [
            ("Название",             _display(manifest, "name")),
            ("Описание",             _display(manifest, "description")),
            ("Версия",               _display(manifest, "version")),
            ("Авторы",               _display(manifest, "authors")),
            ("sha256-хеш",           (
                lambda h: h if h != "неизвестно"
                else "⚠ не задан — бот не запустится"
            )(_display(manifest, "sha256_hash"))),
            ("", ""),
            ("Статус",               ("запущен (pid " + str(live.get("pid", "?")) + ")")
                                     if live else "выключен"),
            ("Официальная подпись",  "не реализовано (заготовка)"),
            ("Главный репозиторий",  _display(manifest, "repository_url")),
            ("Репозиторий OTA",      _display(manifest, "ota_repository")),
            ("Репозиторий плагинов", _display(manifest, "plugin_repository")),
            ("", ""),
            ("Загружено плагинов",   str(loaded_n)),
            ("Пропущено плагинов",   str(skipped_n)),
        ]

        y = top + 1
        for label, value in lines:
            if y >= top + inner_h - 1:
                break
            if not label:
                y += 1
                continue
            field = f"  {label}:"
            _safe_addstr(stdscr, y, left, field, curses.A_BOLD)
            val_x = left + 26
            val_w = inner_w - 26
            for chunk in textwrap.wrap(value, val_w) or [value]:
                if y >= top + inner_h - 1:
                    break
                _safe_addstr(stdscr, y, val_x, chunk)
                y += 1

        # строка целостности
        if manifest:
            integrity = verify_build_integrity(manifest)
            y = min(y + 1, top + inner_h - 2)
            if integrity.ok:
                msg = f"  ✓ Целостность сборки подтверждена ({integrity.files_hashed} файлов)"
                _safe_addstr(stdscr, y, left, msg, curses.color_pair(_C_OK) | curses.A_BOLD)
            else:
                msg = f"  ✗ Хеш не совпадает — запустите: python framework_manager.py hash --generate"
                _safe_addstr(stdscr, y, left, msg[:inner_w], curses.color_pair(_C_ERR) | curses.A_BOLD)

        stdscr.refresh()
        key = stdscr.getch()
        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            return


def _screen_ota(stdscr) -> None:
    """
    Полноценный OTA-экран: инфо-блок состояния + меню действий.
    Каждое действие выходит из curses, запускает CLI-команду,
    возвращается обратно в TUI — самый надёжный способ передать
    прогресс (скачивание, тест) без дублирования логики.
    """
    import subprocess as _sp

    OTA_ACTIONS = [
        ("check",    "Проверить наличие обновлений"),
        ("download", "Скачать и верифицировать"),
        ("apply",    "Тест в слоте B + применить"),
        ("rollback", "Принудительный откат"),
        ("promote",  "Принудительный промоут B→A"),
        ("status",   "Показать статус OTA"),
        ("init-slots", "Инициализировать слоты (первый раз)"),
    ]

    cursor = 0
    while True:
        manifest   = _get_manifest()
        cur_ver    = _display(manifest, "version")
        channel    = _display(manifest, "build_channel", default="Stable")
        ota_repo   = _display(manifest, "ota_repository")

        try:
            from core.ota.slot_manager import load_state
            state = load_state()
        except Exception:
            state = None

        top, left, inner_h, inner_w = _draw_frame(stdscr, "Обновления по воздуху (OTA)")

        # ── инфо-блок ──────────────────────────────────────────
        info = [
            f"  Версия:        {cur_ver}  [{channel}]",
            f"  Репозиторий:   {ota_repo[:inner_w - 18]}",
        ]
        if state:
            info += [
                f"  Слот A:        {'активен' if state.active_slot == 'a' else '—'}",
                f"  OTA статус:    {state.status}",
            ]
            if state.pending_version:
                info.append(f"  Ожидает:       v{state.pending_version}")
            if state.crash_count:
                info.append(f"  Крашей:        {state.crash_count}/{state.max_crashes}")
            if state.last_error:
                info.append(f"  Ошибка:        {state.last_error[:inner_w - 18]}")

        y = top + 1
        for line in info:
            if y >= top + inner_h - 1:
                break
            _safe_addstr(stdscr, y, left, line[:inner_w])
            y += 1

        sep_y = y
        _safe_addstr(stdscr, sep_y, left + 2, "─" * (inner_w - 4),
                     curses.color_pair(_C_BORDER))
        y = sep_y + 1

        # ── меню действий ──────────────────────────────────────
        menu_start = y
        for i, (_, label) in enumerate(OTA_ACTIONS):
            ry = menu_start + i
            if ry >= top + inner_h - 1:
                break
            txt  = f"  {'→' if i == cursor else ' '}  {i + 1}. {label}"
            attr = (curses.color_pair(_C_SELECTED) | curses.A_BOLD) if i == cursor else 0
            _safe_addstr(stdscr, ry, left, txt[:inner_w].ljust(inner_w - 1), attr)

        stdscr.refresh()
        key = stdscr.getch()

        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            return

        chosen: int = -1
        if key in (curses.KEY_UP, ord("k")) and cursor > 0:
            cursor -= 1
        elif key in (curses.KEY_DOWN, ord("j")) and cursor < len(OTA_ACTIONS) - 1:
            cursor += 1
        elif key in (curses.KEY_ENTER, 10, 13):
            chosen = cursor
        elif ord("1") <= key <= ord("9"):
            idx = key - ord("1")
            if 0 <= idx < len(OTA_ACTIONS):
                chosen = idx

        if chosen < 0:
            continue

        action_key, action_label = OTA_ACTIONS[chosen]

        # Выходим из curses, запускаем CLI, возвращаемся
        curses.endwin()
        print("\n─── " + action_label + " ───")
        _sp.run([sys.executable, "framework_manager.py", "ota", action_key])
        input("\nНажмите Enter, чтобы вернуться в меню...")
        # Переинициализируем curses
        new_scr = curses.initscr()
        _init_colors()
        curses.cbreak()
        curses.noecho()
        new_scr.keypad(True)
        curses.curs_set(0)
        stdscr = new_scr


def _screen_tests(stdscr) -> None:
    """Запускает тесты, показывает результат в прокручиваемом окне."""
    H, W = stdscr.getmaxyx()
    _draw_frame(stdscr, "Тесты фреймворка")

    logs_dir = Path("logs") / "tests"
    logs_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    log_path = logs_dir / f"test-log-{stamp}.log"

    pytest_ini = Path("tests") / "pytest.ini"
    if pytest_ini.exists():
        cmd = [sys.executable, "-m", "pytest", "tests/", "-v", "--tb=short",
               f"--log-file={log_path}", "--log-file-level=DEBUG"]
    else:
        cmd = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"]

    _safe_addstr(stdscr, 2, 2, "Запускаю тесты...")
    stdscr.refresh()

    curses.endwin()
    result = subprocess.run(cmd)
    stdscr = curses.initscr()
    _init_colors()
    curses.cbreak()
    curses.noecho()
    stdscr.keypad(True)

    while True:
        top, left, inner_h, inner_w = _draw_frame(stdscr, "Тесты фреймворка")
        if result.returncode == 0:
            msg = "  ✓ Все тесты пройдены."
            _safe_addstr(stdscr, top + 2, left, msg, curses.color_pair(_C_OK) | curses.A_BOLD)
        else:
            msg = "  ✗ Есть проваленные тесты."
            _safe_addstr(stdscr, top + 2, left, msg, curses.color_pair(_C_ERR) | curses.A_BOLD)
        _safe_addstr(stdscr, top + 4, left, f"  Лог сохранён → {log_path}"[:inner_w])
        _wait_key(stdscr)
        return


def _screen_framework_menu(stdscr) -> None:
    items = [
        "Посмотреть информацию и состояние",
        "Обновления по воздуху (OTA)",
        "Провести тесты фреймворка",
    ]
    handlers = [_screen_framework_info, _screen_ota, _screen_tests]
    while True:
        choice = _run_menu(stdscr, "Управление фреймворком", items)
        if choice < 0:
            return
        handlers[choice](stdscr)


# ══════════════════════════════════════════════════════════════════
# Экраны — Управление плагинами
# ══════════════════════════════════════════════════════════════════

def _screen_plugin_split(stdscr, title: str, plugin_names: list[str], loader) -> None:
    """
    Разделённый вид в стиле archinstall:
      левая панель (~35%) — прокручиваемый список плагинов
      правая панель (~65%) — детали выбранного

    Навигация: ↑/↓, q/Esc/0 — назад.
    """
    if not plugin_names:
        while True:
            top, left, inner_h, inner_w = _draw_frame(stdscr, title)
            _safe_addstr(stdscr, top + 2, left + 2, "(список пуст)")
            stdscr.refresh()
            key = stdscr.getch()
            if key == curses.KEY_RESIZE:
                continue
            if _is_back(key):
                return

    cursor = 0
    while True:
        H, W = stdscr.getmaxyx()
        stdscr.clear()

        # Заголовок
        hdr = f" {title} "
        _safe_addstr(stdscr, 0, max(0, (W - len(hdr)) // 2), hdr,
                     curses.color_pair(_C_HEADER) | curses.A_BOLD)

        # Разделитель панелей
        split_x = max(20, W * 35 // 100)
        inner_h = H - 2
        for row in range(1, H - 1):
            _safe_addstr(stdscr, row, split_x, "│", curses.color_pair(_C_BORDER))

        # Левая панель — список
        visible = inner_h - 1
        offset = max(0, cursor - visible + 1)
        for i, name in enumerate(plugin_names):
            row = 1 + i - offset
            if row < 1 or row >= H - 1:
                continue
            skipped = name in loader._skipped
            marker = "✗" if skipped else "✓"
            label = f" {marker} {name}"
            attr = (curses.color_pair(_C_SELECTED) | curses.A_BOLD) if i == cursor else 0
            _safe_addstr(stdscr, row, 0, label[:split_x].ljust(split_x), attr)

        # Правая панель — детали
        name = plugin_names[cursor]
        rec = loader._records.get(name)
        right_x = split_x + 2
        right_w = W - right_x - 1

        details: list[tuple[str, str]] = []
        if rec:
            pip_deps_list  = rec.pip_deps_raw
            plug_deps_list = rec.plugin_deps_raw
            details = [
                ("Имя",                    rec.name),
                ("Описание",               rec.description or "—"),
                ("Версия",                 rec.version     or "—"),
                ("Автор",                  rec.author      or "—"),
                ("Зависимости (плагинов)", ", ".join(plug_deps_list) or "нет"),
                ("Зависимости (pip)",      ", ".join(pip_deps_list)  or "нет"),
                ("Статус",                 "✗ пропущен" if name in loader._skipped else "✓ загружен"),
            ]
            if name in loader._skipped:
                details.append(("Причина",
                                loader._skip_reasons.get(name, "неизвестно")))
        else:
            details = [("Имя", name), ("Данные", "не загружены")]

        detail_y = 1
        for label, value in details:
            if detail_y >= H - 1:
                break
            field = f"{label}:"
            _safe_addstr(stdscr, detail_y, right_x, field, curses.A_BOLD)
            detail_y += 1
            for chunk in textwrap.wrap(value, right_w) or [value]:
                if detail_y >= H - 1:
                    break
                _safe_addstr(stdscr, detail_y, right_x + 2, chunk[:right_w - 2])
                detail_y += 1
            detail_y += 1

        hint = " [↑↓] Навигация   [q/0/ESC] Назад "
        _safe_addstr(stdscr, H - 1, 0, hint[:W].ljust(W), curses.color_pair(_C_BORDER))
        stdscr.refresh()

        key = stdscr.getch()
        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            return
        if key in (curses.KEY_UP, ord('k')) and cursor > 0:
            cursor -= 1
        elif key in (curses.KEY_DOWN, ord('j')) and cursor < len(plugin_names) - 1:
            cursor += 1


def _screen_plugin_list(stdscr) -> None:
    loader = _get_loader()
    loaded  = sorted(n for n in loader._records if n not in loader._skipped)
    skipped = sorted(loader._skipped.keys())
    installed = sorted(loader._records.keys())

    items = [
        f"Показать загруженные плагины   ({len(loaded)})",
        f"Показать пропущенные плагины   ({len(skipped)})",
        f"Показать все установленные     ({len(installed)})",
    ]
    lists = [loaded, skipped, installed]
    titles = [
        "Загруженные плагины (running)",
        "Пропущенные плагины (skipped)",
        "Все установленные плагины",
    ]

    while True:
        top, left, inner_h, inner_w = _draw_frame(stdscr, "Список плагинов")

        # Сводка
        _safe_addstr(stdscr, top + 1, left + 2,
                     f"Загружено (running): {len(loaded)}   "
                     f"Пропущено (skipped): {len(skipped)}   "
                     f"Установлено: {len(installed)}", curses.A_BOLD)

        cursor = min(getattr(_screen_plugin_list, "_cursor", 0), max(0, len(items) - 1))
        _draw_menu(stdscr, top + 2, left, inner_h - 3, inner_w, items, cursor)
        stdscr.refresh()

        key = stdscr.getch()
        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            _screen_plugin_list._cursor = 0
            return
        if key in (curses.KEY_UP, ord('k')) and cursor > 0:
            cursor -= 1
            _screen_plugin_list._cursor = cursor
        elif key in (curses.KEY_DOWN, ord('j')) and cursor < len(items) - 1:
            cursor += 1
            _screen_plugin_list._cursor = cursor
        elif key in (curses.KEY_ENTER, 10, 13):
            _screen_plugin_split(stdscr, titles[cursor], lists[cursor], loader)
        elif ord('1') <= key <= ord('3'):
            idx = key - ord('1')
            _screen_plugin_split(stdscr, titles[idx], lists[idx], loader)


_screen_plugin_list._cursor = 0  # type: ignore[attr-defined]


def _screen_plugin_install(stdscr) -> None:
    """Установка/обновление/удаление/отключение плагинов."""
    while True:
        top, left, inner_h, inner_w = _draw_frame(stdscr, "Установка, обновление и удаление")
        lines = [
            "  Управление через CLI (--tui делегирует сложные действия командам):",
            "",
            "  Установить:  python framework_manager.py install --yes <источник>",
            "  Удалить:     python framework_manager.py uninstall --yes <имя>",
            "  Обновить:    python framework_manager.py update --yes [<имя>]",
            "  Залочить:    python framework_manager.py lock --yes",
            "  Разлочить:   python framework_manager.py unlock --yes",
            "",
            "  Для интерактивного меню (без --tui) не указывайте имя плагина —",
            "  появится список с множественным выбором.",
        ]
        for i, ln in enumerate(lines):
            if top + 2 + i >= top + inner_h:
                break
            _safe_addstr(stdscr, top + 2 + i, left, ln[:inner_w])
        stdscr.refresh()
        key = stdscr.getch()
        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            return


def _screen_docs(stdscr) -> None:
    manifest = _get_manifest()
    plugin_repo = (manifest.get("plugin_repository") or "").strip()
    doc_file = Path("PLUGIN_API.md")

    while True:
        top, left, inner_h, inner_w = _draw_frame(stdscr, "Документация разработчика")
        if not plugin_repo:
            _safe_addstr(stdscr, top + 2, left + 2,
                         "В manifest_core.json не задан plugin_repository — документация недоступна.",
                         curses.color_pair(_C_ERR))
            stdscr.refresh()
            key = stdscr.getch()
            if key == curses.KEY_RESIZE:
                continue
            return

        lines = [
            f"  Репозиторий плагинов: {plugin_repo}",
            "",
            f"  Документ PLUGIN_API.md {'найден локально.' if doc_file.exists() else 'НЕ найден локально.'}",
            "",
            "  Нажмите [d] — скачать/обновить PLUGIN_API.md из репозитория",
        ]
        for i, ln in enumerate(lines):
            if top + 2 + i >= top + inner_h:
                break
            _safe_addstr(stdscr, top + 2 + i, left, ln[:inner_w])
        stdscr.refresh()

        key = stdscr.getch()
        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            return
        if key in (ord('d'), ord('D')):
            # Скачиваем PLUGIN_API.md из корня репозитория (raw GitHub)
            _safe_addstr(stdscr, top + 8, left + 2, "Скачиваю PLUGIN_API.md...")
            stdscr.refresh()
            # Конвертируем github.com/owner/repo → raw URL
            raw_url = plugin_repo.rstrip("/")
            if "github.com" in raw_url:
                raw_url = raw_url.replace("github.com", "raw.githubusercontent.com")
                raw_url += "/HEAD/PLUGIN_API.md"
            else:
                raw_url += "/PLUGIN_API.md"
            try:
                resp = urllib.request.urlopen(raw_url, timeout=10)
                content = resp.read().decode("utf-8")
                doc_file.write_text(content, encoding="utf-8")
                _safe_addstr(stdscr, top + 9, left + 2,
                             "✓ PLUGIN_API.md сохранён.", curses.color_pair(_C_OK) | curses.A_BOLD)
            except (urllib.error.URLError, OSError) as exc:
                _safe_addstr(stdscr, top + 9, left + 2,
                             f"✗ Ошибка: {exc}"[:inner_w], curses.color_pair(_C_ERR))
            stdscr.refresh()
            _wait_key(stdscr)


def _screen_plugin_menu(stdscr) -> None:
    items = [
        "Список плагинов и их состояния",
        "Установка, обновление и удаление",
        "Посмотреть документацию (PLUGIN_API.md)",
    ]
    handlers = [_screen_plugin_list, _screen_plugin_install, _screen_docs]
    while True:
        choice = _run_menu(stdscr, "Управление плагинами", items)
        if choice < 0:
            return
        handlers[choice](stdscr)


# ══════════════════════════════════════════════════════════════════
# Экраны — Глобальные настройки и помощь
# ══════════════════════════════════════════════════════════════════

def _screen_settings(stdscr) -> None:
    from core.settings import (
        load_settings, save_settings,
        VALID_BUILD_CHANNELS, VALID_LOGGER_LEVELS,
    )

    settings = load_settings()

    # Поля которые можно редактировать
    def _toggle_bool(val: bool) -> bool:
        return not val

    def _cycle_channel(current: str) -> str:
        idx = VALID_BUILD_CHANNELS.index(current) if current in VALID_BUILD_CHANNELS else 0
        return VALID_BUILD_CHANNELS[(idx + 1) % len(VALID_BUILD_CHANNELS)]

    def _cycle_level(current: str) -> str:
        idx = VALID_LOGGER_LEVELS.index(current) if current in VALID_LOGGER_LEVELS else 2
        return VALID_LOGGER_LEVELS[(idx + 1) % len(VALID_LOGGER_LEVELS)]

    cursor = 0
    FIELDS = [
        "allow_nightly_beta",
        "build_channel",
        "confirm_actions",
        "logger_level",
    ]

    while True:
        top, left, inner_h, inner_w = _draw_frame(stdscr, "Настройки и безопасность")

        rows = [
            ("Разрешить Nightly/Beta сборки",     str(settings.allow_nightly_beta)),
            ("Канал сборки",                       settings.build_channel),
            ("Запрашивать подтверждения",          str(settings.confirm_actions)),
            ("Уровень логгера",                    settings.logger_level),
        ]
        _safe_addstr(stdscr, top + 1, left + 2,
                     "  [Enter/Space] переключить   [s] сохранить   [q/0] назад",
                     curses.color_pair(_C_DIM))

        for i, (label, value) in enumerate(rows):
            y = top + 3 + i
            if y >= top + inner_h - 1:
                break
            attr = curses.color_pair(_C_SELECTED) | curses.A_BOLD if i == cursor else 0
            line = f"  {label:<40}  {value}"
            _safe_addstr(stdscr, y, left, line[:inner_w].ljust(inner_w - 1), attr)

        stdscr.refresh()
        key = stdscr.getch()
        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            return
        if key in (curses.KEY_UP, ord('k')) and cursor > 0:
            cursor -= 1
        elif key in (curses.KEY_DOWN, ord('j')) and cursor < len(FIELDS) - 1:
            cursor += 1
        elif key in (curses.KEY_ENTER, 10, 13, ord(' ')):
            field = FIELDS[cursor]
            if field == "allow_nightly_beta":
                settings.allow_nightly_beta = _toggle_bool(settings.allow_nightly_beta)
            elif field == "build_channel":
                settings.build_channel = _cycle_channel(settings.build_channel)
            elif field == "confirm_actions":
                settings.confirm_actions = _toggle_bool(settings.confirm_actions)
            elif field == "logger_level":
                settings.logger_level = _cycle_level(settings.logger_level)
        elif key == ord('s'):
            save_settings(settings)
            _safe_addstr(stdscr, top + inner_h - 2, left + 2,
                         "✓ Сохранено в configs/settings.json", curses.color_pair(_C_OK) | curses.A_BOLD)
            stdscr.refresh()
            curses.napms(1200)


def _screen_help(stdscr) -> None:
    from core.localization import read_help_text
    text = read_help_text()
    lines = text.splitlines()

    scroll = 0
    while True:
        top, left, inner_h, inner_w = _draw_frame(stdscr, "Помощь / Техподдержка")
        visible = inner_h - 1
        for i, line in enumerate(lines[scroll: scroll + visible]):
            _safe_addstr(stdscr, top + 1 + i, left + 1, line[:inner_w - 2])
        # Индикатор прокрутки
        if len(lines) > visible:
            pct = scroll * 100 // max(1, len(lines) - visible)
            _safe_addstr(stdscr, top + inner_h - 1, left + inner_w - 8,
                         f" {pct:3d}% ", curses.color_pair(_C_DIM))
        stdscr.refresh()
        key = stdscr.getch()
        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            return
        if key in (curses.KEY_UP, ord('k')) and scroll > 0:
            scroll -= 1
        elif key in (curses.KEY_DOWN, ord('j'), curses.KEY_NPAGE):
            scroll = min(scroll + 1, max(0, len(lines) - visible))
        elif key == curses.KEY_PPAGE:
            scroll = max(0, scroll - visible)


def _screen_sandbox(stdscr) -> None:
    """Настройки sandbox и верификации плагинов (читает/пишет configs/config.json)."""
    import json as _json
    from core.config import CONFIG_PATH, SandboxConfig

    def _load_sandbox() -> SandboxConfig:
        try:
            raw = _json.loads(Path(CONFIG_PATH).read_text(encoding="utf-8"))
            from core.config import _parse_sandbox
            return _parse_sandbox(raw.get("sandbox") or {})
        except Exception:
            return SandboxConfig()

    def _save_sandbox(sb: SandboxConfig) -> None:
        try:
            path = Path(CONFIG_PATH)
            raw = {}
            if path.exists():
                raw = _json.loads(path.read_text(encoding="utf-8"))
            raw["sandbox"] = {
                "enabled": sb.enabled,
                "handler_timeout_s": sb.handler_timeout_s,
                "block_system_calls": sb.block_system_calls,
                "extra_blocked_modules": sb.extra_blocked_modules,
                "verify_plugin_signatures": sb.verify_plugin_signatures,
                "allow_unsigned_plugins": sb.allow_unsigned_plugins,
            }
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(
                _json.dumps(raw, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
            )
        except Exception as exc:
            pass  # показываем ошибку в TUI ниже

    sb = _load_sandbox()
    cursor = 0

    FIELDS = [
        "enabled",
        "block_system_calls",
        "verify_plugin_signatures",
        "allow_unsigned_plugins",
    ]

    while True:
        top, left, inner_h, inner_w = _draw_frame(stdscr, "Безопасность и Sandbox")

        rows = [
            ("Sandbox включён",                              str(sb.enabled)),
            ("Блокировать системные вызовы (subprocess/exec)",str(sb.block_system_calls)),
            ("Верификация подписей плагинов",                str(sb.verify_plugin_signatures)),
            ("Разрешить неподписанные плагины (WARNING)",    str(sb.allow_unsigned_plugins)),
        ]

        _safe_addstr(stdscr, top + 1, left + 2,
                     "  [Enter/Space] переключить   [s] сохранить   [q/0] назад",
                     curses.color_pair(_C_DIM))
        _safe_addstr(stdscr, top + 2, left + 2,
                     "  ⚠ Изменения вступают в силу после перезапуска бота.",
                     curses.color_pair(_C_ERR))

        for i, (label, value) in enumerate(rows):
            y = top + 4 + i
            if y >= top + inner_h - 1:
                break
            attr = curses.color_pair(_C_SELECTED) | curses.A_BOLD if i == cursor else 0
            line = f"  {label:<50}  {value}"
            _safe_addstr(stdscr, y, left, line[:inner_w].ljust(inner_w - 1), attr)

        stdscr.refresh()
        key = stdscr.getch()
        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            return
        if key in (curses.KEY_UP, ord('k')) and cursor > 0:
            cursor -= 1
        elif key in (curses.KEY_DOWN, ord('j')) and cursor < len(FIELDS) - 1:
            cursor += 1
        elif key in (curses.KEY_ENTER, 10, 13, ord(' ')):
            field = FIELDS[cursor]
            if field == "enabled":
                sb.enabled = not sb.enabled
            elif field == "block_system_calls":
                sb.block_system_calls = not sb.block_system_calls
            elif field == "verify_plugin_signatures":
                sb.verify_plugin_signatures = not sb.verify_plugin_signatures
            elif field == "allow_unsigned_plugins":
                sb.allow_unsigned_plugins = not sb.allow_unsigned_plugins
        elif key == ord('s'):
            _save_sandbox(sb)
            _safe_addstr(stdscr, top + inner_h - 2, left + 2,
                         "✓ Сохранено в configs/config.json",
                         curses.color_pair(_C_OK) | curses.A_BOLD)
            stdscr.refresh()
            curses.napms(1200)


def _screen_developer(stdscr) -> None:
    from core.settings import load_settings, save_settings

    settings = load_settings()
    FIELDS = ["dev_mode", "disable_signature_and_hash_check"]
    cursor = 0

    while True:
        top, left, inner_h, inner_w = _draw_frame(stdscr, "Для разработчиков")

        rows = [
            ("Режим разработчика (принудительный DEBUG)",     str(settings.dev_mode)),
            ("Отключить проверку подписи и хеша сборки",      str(settings.disable_signature_and_hash_check)),
        ]
        _safe_addstr(stdscr, top + 1, left + 2,
                     "  ⚠ ВНИМАНИЕ: эти опции только для разработки, не для боевых серверов.",
                     curses.color_pair(_C_ERR))
        _safe_addstr(stdscr, top + 2, left + 2,
                     "  [Enter/Space] переключить   [s] сохранить   [q/0] назад",
                     curses.color_pair(_C_DIM))

        for i, (label, value) in enumerate(rows):
            y = top + 4 + i
            if y >= top + inner_h - 1:
                break
            attr = curses.color_pair(_C_SELECTED) | curses.A_BOLD if i == cursor else 0
            line = f"  {label:<50}  {value}"
            _safe_addstr(stdscr, y, left, line[:inner_w].ljust(inner_w - 1), attr)

        stdscr.refresh()
        key = stdscr.getch()
        if key == curses.KEY_RESIZE:
            continue
        if _is_back(key):
            return
        if key in (curses.KEY_UP, ord('k')) and cursor > 0:
            cursor -= 1
        elif key in (curses.KEY_DOWN, ord('j')) and cursor < len(FIELDS) - 1:
            cursor += 1
        elif key in (curses.KEY_ENTER, 10, 13, ord(' ')):
            if FIELDS[cursor] == "dev_mode":
                settings.dev_mode = not settings.dev_mode
            elif FIELDS[cursor] == "disable_signature_and_hash_check":
                settings.disable_signature_and_hash_check = not settings.disable_signature_and_hash_check
        elif key == ord('s'):
            save_settings(settings)
            _safe_addstr(stdscr, top + inner_h - 2, left + 2,
                         "✓ Сохранено в configs/settings.json", curses.color_pair(_C_OK) | curses.A_BOLD)
            stdscr.refresh()
            curses.napms(1200)


def _screen_global_menu(stdscr) -> None:
    items = [
        "Настройки и безопасность",
        "Помощь по использованию / техподдержка",
        "Для разработчиков",
        "Безопасность и Sandbox",
    ]
    handlers = [_screen_settings, _screen_help, _screen_developer, _screen_sandbox]
    while True:
        choice = _run_menu(stdscr, "Глобальные настройки и помощь", items)
        if choice < 0:
            return
        handlers[choice](stdscr)


# ══════════════════════════════════════════════════════════════════
# Главное меню
# ══════════════════════════════════════════════════════════════════

def _main_loop(stdscr) -> None:
    curses.cbreak()
    curses.noecho()
    stdscr.keypad(True)
    curses.curs_set(0)
    _init_colors()

    items = [
        "Управление фреймворком",
        "Управление плагинами",
        "Глобальные настройки и помощь",
        "Выход из менеджера",
    ]
    handlers: list[Any] = [
        _screen_framework_menu,
        _screen_plugin_menu,
        _screen_global_menu,
        None,  # выход
    ]

    cursor = 0
    while True:
        H, W = stdscr.getmaxyx()
        stdscr.clear()

        # Заголовок
        title = " Менеджер Фреймворка AccountManager "
        _safe_addstr(stdscr, 0, max(0, (W - len(title)) // 2), title,
                     curses.color_pair(_C_HEADER) | curses.A_BOLD)

        manifest = _get_manifest()
        ver  = _display(manifest, "version")
        chan = _display(manifest, "build_channel")
        live = _get_live()
        stat = ("● запущен" if live else "○ выключен")
        sub  = f" v{ver}  [{chan}]   Бот: {stat} "
        _safe_addstr(stdscr, 1, max(0, (W - len(sub)) // 2), sub, curses.A_DIM)

        for i, item in enumerate(items):
            y = 4 + i * 2
            if y >= H - 2:
                break
            label = f"  {'→' if i == cursor else ' '}  {i + 1}. {item}"
            attr = curses.color_pair(_C_SELECTED) | curses.A_BOLD if i == cursor else 0
            _safe_addstr(stdscr, y, 2, label[:W - 4].ljust(W - 4), attr)

        hint = " [↑↓] Навигация   [Enter/цифра] Выбор   [q/0] Выход "
        _safe_addstr(stdscr, H - 1, 0, hint[:W].ljust(W), curses.color_pair(_C_BORDER))

        stdscr.refresh()
        key = stdscr.getch()

        if key == curses.KEY_RESIZE:
            continue
        if key in (_ESC, ord('q'), ord('Q')) or (key == ord('0')):
            return  # выход
        if key in (curses.KEY_UP, ord('k')) and cursor > 0:
            cursor -= 1
        elif key in (curses.KEY_DOWN, ord('j')) and cursor < len(items) - 1:
            cursor += 1
        elif key in (curses.KEY_ENTER, 10, 13):
            if handlers[cursor] is None:
                return
            handlers[cursor](stdscr)
        elif ord('1') <= key <= ord('4'):
            idx = key - ord('1')
            if 0 <= idx < len(items):
                if handlers[idx] is None:
                    return
                handlers[idx](stdscr)


# ══════════════════════════════════════════════════════════════════
# Text-mode fallback (без curses)
# ══════════════════════════════════════════════════════════════════

def _text_menu() -> None:
    """Текстовый fallback: то же дерево меню через print/input."""
    from core.manifest import display as disp, load_manifest, ManifestError

    try:
        manifest = load_manifest()
    except ManifestError:
        manifest = {}

    def _header(title: str) -> None:
        print(f"\n{'=' * 60}")
        print(f"  {title}")
        print('=' * 60)

    def _pick(options: list[str], back_label: str = "Назад") -> int:
        """Возвращает 1-based выбор или 0 для назад."""
        for i, o in enumerate(options, 1):
            print(f"  {i}. {o}")
        print(f"  0. {back_label}")
        while True:
            raw = input("> ").strip()
            if raw.isdigit():
                n = int(raw)
                if 0 <= n <= len(options):
                    return n
            print("  Некорректный выбор.")

    def framework_menu() -> None:
        while True:
            _header("Управление фреймворком")
            choice = _pick([
                "Посмотреть информацию и состояние",
                "Обновления по воздуху (OTA)",
                "Провести тесты фреймворка",
            ])
            if choice == 0:
                return
            if choice == 1:
                _header("Информация о фреймворке")
                for key, label in [
                    ("name", "Название"), ("description", "Описание"),
                    ("version", "Версия"), ("authors", "Авторы"),
                    ("sha256_hash", "sha256-хеш"),
                ]:
                    print(f"  {label}: {disp(manifest, key)}")
                print(f"\n  Главный репозиторий:    {disp(manifest, 'repository_url')}")
                print(f"  Репозиторий OTA:        {disp(manifest, 'ota_repository')}")
                print(f"  Репозиторий плагинов:   {disp(manifest, 'plugin_repository')}")
            elif choice == 2:
                import subprocess as _sp2
            print("\n  Доступные OTA-действия:")
            for i, a in enumerate(["check","download","apply","rollback","promote","status","init-slots"], 1):
                print(f"    {i}. {a}")
            choice_ota = input("  Выберите (0=назад): ").strip()
            ota_actions = ["check","download","apply","rollback","promote","status","init-slots"]
            if choice_ota.isdigit() and 1 <= int(choice_ota) <= len(ota_actions):
                _sp2.run([sys.executable, "framework_manager.py", "ota", ota_actions[int(choice_ota)-1]])
            elif choice == 3:
                from core.framework_manager import cmd_test
                import argparse
                cmd_test(argparse.Namespace())

    def plugin_menu() -> None:
        while True:
            _header("Управление плагинами")
            choice = _pick([
                "Список плагинов и их состояния",
                "Установка, обновление и удаление",
                "Посмотреть документацию",
            ])
            if choice == 0:
                return
            if choice == 1:
                from core.framework_manager import cmd_status
                import argparse
                cmd_status(argparse.Namespace(name=None, filter=None))
            elif choice == 2:
                print("  Используйте CLI: python framework_manager.py install/uninstall/update --yes ...")
            elif choice == 3:
                from core.framework_manager import cmd_info
                import argparse
                cmd_info(argparse.Namespace())

    def global_menu() -> None:
        from core.settings import load_settings, save_settings
        while True:
            _header("Глобальные настройки и помощь")
            choice = _pick([
                "Настройки и безопасность",
                "Помощь по использованию",
                "Для разработчиков",
            ])
            if choice == 0:
                return
            if choice == 1:
                settings = load_settings()
                print(f"  Канал сборки:        {settings.build_channel}")
                print(f"  Уровень логгера:     {settings.logger_level}")
                print(f"  Подтверждения:       {settings.confirm_actions}")
                print(f"  Nightly/Beta:        {settings.allow_nightly_beta}")
            elif choice == 2:
                from core.localization import read_help_text
                print(read_help_text())
            elif choice == 3:
                print("  Режим разработчика: используйте configs/settings.json → dev_mode=true")
            elif choice == 4:
                import json as _j
                from core.config import CONFIG_PATH
                p = Path(CONFIG_PATH)
                raw = _j.loads(p.read_text()) if p.exists() else {}
                sb = raw.get("sandbox", {})
                print(f"  Sandbox enabled:                {sb.get('enabled', True)}")
                print(f"  block_system_calls:             {sb.get('block_system_calls', True)}")
                print(f"  verify_plugin_signatures:       {sb.get('verify_plugin_signatures', False)}")
                print(f"  allow_unsigned_plugins:         {sb.get('allow_unsigned_plugins', False)}")
                print("  Изменить: отредактируйте configs/config.json → sandbox.*")

    while True:
        _header("Менеджер Фреймворка AccountManager")
        choice = _pick([
            "Управление фреймворком",
            "Управление плагинами",
            "Глобальные настройки и помощь",
        ], back_label="Выход из менеджера")
        if choice == 0:
            print("До свидания.")
            return
        [framework_menu, plugin_menu, global_menu][choice - 1]()


# ══════════════════════════════════════════════════════════════════
# Точка входа
# ══════════════════════════════════════════════════════════════════

def launch_tui() -> None:
    """
    Запускает curses-TUI. При любом сбое инициализации curses
    (Windows без windows-curses, headless, IDE-консоль) переходит
    на текстовый fallback.
    """
    try:
        curses.wrapper(_main_loop)
    except (curses.error, Exception) as exc:
        # Убеждаемся, что терминал в нормальном состоянии перед fallback
        try:
            curses.endwin()
        except Exception:
            pass
        # Если ошибка не связана с отсутствием терминала — сообщаем
        if "setupterm" not in str(exc).lower() and "no terminal" not in str(exc).lower():
            print(f"[TUI] curses недоступен ({exc}), переключаюсь в текстовый режим.\n")
        _text_menu()
