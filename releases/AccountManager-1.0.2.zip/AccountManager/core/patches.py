"""
core/patches.py — управляемые патчи ядра (PatchManager).

Это механизм, которым плагин может ИЗМЕНИТЬ поведение ядра (а не
только на него подписаться, см. core/hooks.py). Обычный monkey-patch
в Python — это `SomeClass.method = new_func`: работает, но небезопасно,
если так делают два плагина сразу (второй молча стирает патч первого),
и не даёт откатить один конкретный патч, не трогая остальные.

PatchManager решает обе проблемы:

  1. Патчи на один и тот же (target, attr) СКЛАДЫВАЮТСЯ в цепочку по
     порядку установки, а не перезаписывают друг друга. Патч плагина Б
     оборачивает то, что получилось после патча плагина А (который, в
     свою очередь, оборачивает истинный оригинал).
  2. Любой патч можно снять индивидуально (patches.revert(handle)) —
     цепочка перестраивается заново из оставшихся слоёв поверх
     истинного оригинала, независимо от порядка снятия.
  3. При выгрузке/перезагрузке плагина (PluginLoader) все его патчи
     снимаются автоматически (revert_plugin) — не остаётся «зомби»-
     патчей от уже выгруженного кода.

Четыре режима (все — методы PatchManager):

  around(target, attr, wrapper, plugin=...)
      Полный контроль. wrapper(original, *args, **kwargs) сам решает,
      вызывать ли original и что вернуть. Для async-целей wrapper
      обязан быть `async def` и сам должен `await original(...)`.
      Ошибки внутри wrapper пробрасываются как есть (плагин явно взял
      управление на себя — это его ответственность), но логируются с
      указанием, чей именно патч упал.

  before(target, attr, hook, plugin=...)
      hook(*args, **kwargs) вызывается ДО original, не может отменить
      вызов и не может изменить его аргументы. Безопасный режим:
      исключение в hook логируется и проглатывается, original всё
      равно выполняется.

  after(target, attr, hook, plugin=...)
      hook(result, *args, **kwargs) вызывается ПОСЛЕ original. Если
      вернёт не-None — результат original заменяется на это значение.
      Тоже безопасный режим: исключение в hook логируется, а результат
      original остаётся как есть.

  replace(target, attr, value, plugin=..., create_if_missing=False)
      Полная замена атрибута — используется, когда around не подходит
      (не-callable атрибут) или нужно снести оригинал целиком.

ВАЖНО: патчить надёжно можно классы и объекты (Database, конкретный
экземпляр db/bot/config) — обращение идёт по имени атрибута в момент
вызова, поэтому патч виден всем, кто пишет `db.upsert_user(...)` или
`instance.method(...)`, независимо от того, когда этот код был
импортирован.

ВАЖНО про self: если патчите КЛАСС (target=Database), original/wrapper
получает self первым позиционным аргументом — как обычная функция
класса: `def wrapper(original, self, x): ...`. Если патчите КОНКРЕТНЫЙ
ЭКЗЕМПЛЯР (target=db), self уже связан внутри original (это bound
method), поэтому wrapper/hook получает только явные аргументы вызова,
без self: `def wrapper(original, x): ...`. Это обычная семантика
Python для bound methods, PatchManager её не меняет — но при переносе
патча с экземпляра на класс (или наоборот) сигнатуру wrapper придётся
поправить.

Патчить «голые» функции модуля, которые кто-то уже импортировал как
`from module import func`, ТАК НЕ ПОЛУЧИТСЯ — `from import` копирует
ссылку на функцию в момент импорта, а PatchManager меняет атрибут
модуля, на который эта уже скопированная ссылка больше не смотрит.
Если нужно, чтобы патч видели все, обращайтесь к функции через модуль
(`placeholder.resolve(...)`), а не через прямой импорт имени.
"""
from __future__ import annotations

import inspect
import itertools
from dataclasses import dataclass, field
from typing import Any, Callable

from core.logger import get_logger

logger = get_logger("patches")

_id_counter = itertools.count(1)

_VALID_MODES = ("around", "before", "after", "replace")


class PatchError(Exception):
    """Ошибка установки патча (не найден атрибут, несовместимый тип и т.п.)."""


_MISSING = object()
"""
Сентинел для true_original, когда атрибута не было ВООБЩЕ (случай
replace(..., create_if_missing=True)) — отличает "атрибута не было" от
"атрибут существовал и был равен None". Без этого revert() не мог бы
понять, что атрибут нужно удалить (delattr), а не выставить в None.
"""


@dataclass(frozen=True, slots=True)
class PatchHandle:
    """Токен установленного патча. Нужен только для PatchManager.revert()."""
    id: int
    plugin: str
    target_key: tuple[int, str]


def _safe_log_error(message: str, exc: BaseException) -> None:
    """
    Логирует ошибку из тела патча так, чтобы сама попытка залогировать
    НИКОГДА не могла усугубить ситуацию.

    Эмпирически найдено стресс-тестом (цепочка ~500 around-патчей):
    RecursionError означает, что стек уже исчерпан почти полностью —
    logger.error(..., exc_info=True) сам делает добрый десяток
    вложенных вызовов (isEnabledFor -> _log -> makeRecord ->
    callHandlers -> ... -> formatException -> traceback-модуль ->
    чтение файла через linecache) — КАЖДЫЙ из них тоже мгновенно
    ловит тот же RecursionError, и это цепляется само на себя
    («during handling of the above exception, another exception
    occurred») буквально тысячи раз подряд, прежде чем управление
    вообще куда-то вернётся — на практике это выглядит как процесс,
    зависший на выводе мегабайт трейсбеков. Поэтому для RecursionError
    логирование пропускается полностью — стек всё равно расскажет,
    что произошло, когда исключение дойдёт до места, где стека снова
    достаточно.

    Для всех остальных исключений — обычное логирование, но и оно
    само обёрнуто: если логирование почему-то не удалось (например,
    файловая система недоступна), это не должно уронить сам патч.
    """
    if isinstance(exc, RecursionError):
        return
    try:
        logger.error(message, exc_info=True)
    except Exception:
        pass


@dataclass(slots=True)
class _Layer:
    id: int
    plugin: str
    mode: str
    payload: Any
    is_async: bool
    desc: str

    def build(self, inner: Any) -> Any:
        if self.mode == "replace":
            return self.payload
        if self.mode == "around":
            return self._build_around(inner)
        if self.mode == "before":
            return self._build_before(inner)
        return self._build_after(inner)

    def _build_around(self, inner: Any) -> Any:
        wrapper = self.payload
        plugin, desc = self.plugin, self.desc

        if self.is_async:
            async def layered(*args: Any, **kwargs: Any) -> Any:
                try:
                    return await wrapper(inner, *args, **kwargs)
                except Exception as exc:
                    _safe_log_error(f"Ошибка в around-патче «{plugin}» на {desc}", exc)
                    raise
        else:
            def layered(*args: Any, **kwargs: Any) -> Any:
                try:
                    return wrapper(inner, *args, **kwargs)
                except Exception as exc:
                    _safe_log_error(f"Ошибка в around-патче «{plugin}» на {desc}", exc)
                    raise
        layered.__name__ = getattr(inner, "__name__", desc)
        return layered

    def _build_before(self, inner: Any) -> Any:
        hook = self.payload
        plugin, desc = self.plugin, self.desc

        if self.is_async:
            async def layered(*args: Any, **kwargs: Any) -> Any:
                try:
                    maybe = hook(*args, **kwargs)
                    if inspect.isawaitable(maybe):
                        await maybe
                except Exception as exc:
                    _safe_log_error(
                        f"Ошибка в before-хуке «{plugin}» на {desc} "
                        f"(original всё равно выполнен)",
                        exc,
                    )
                return await inner(*args, **kwargs)
        else:
            def layered(*args: Any, **kwargs: Any) -> Any:
                try:
                    hook(*args, **kwargs)
                except Exception as exc:
                    _safe_log_error(
                        f"Ошибка в before-хуке «{plugin}» на {desc} "
                        f"(original всё равно выполнен)",
                        exc,
                    )
                return inner(*args, **kwargs)
        layered.__name__ = getattr(inner, "__name__", desc)
        return layered

    def _build_after(self, inner: Any) -> Any:
        hook = self.payload
        plugin, desc = self.plugin, self.desc

        if self.is_async:
            async def layered(*args: Any, **kwargs: Any) -> Any:
                result = await inner(*args, **kwargs)
                try:
                    maybe = hook(result, *args, **kwargs)
                    if inspect.isawaitable(maybe):
                        maybe = await maybe
                    if maybe is not None:
                        result = maybe
                except Exception as exc:
                    _safe_log_error(
                        f"Ошибка в after-хуке «{plugin}» на {desc} "
                        f"(результат original не изменён)",
                        exc,
                    )
                return result
        else:
            def layered(*args: Any, **kwargs: Any) -> Any:
                result = inner(*args, **kwargs)
                try:
                    maybe = hook(result, *args, **kwargs)
                    if maybe is not None:
                        result = maybe
                except Exception as exc:
                    _safe_log_error(
                        f"Ошибка в after-хуке «{plugin}» на {desc} "
                        f"(результат original не изменён)",
                        exc,
                    )
                return result
        layered.__name__ = getattr(inner, "__name__", desc)
        return layered


@dataclass(slots=True)
class _ChainState:
    target: Any
    attr: str
    desc: str
    true_original: Any
    layers: list[_Layer] = field(default_factory=list)

    def rebuild(self) -> None:
        current = None if self.true_original is _MISSING else self.true_original
        for layer in self.layers:
            current = layer.build(current)
        setattr(self.target, self.attr, current)

    def restore_true_original(self) -> None:
        """Откатывает target.attr к состоянию ДО первого патча — включая
        случай, когда атрибута изначально не было вовсе (delattr, а не
        setattr(..., None))."""
        if self.true_original is _MISSING:
            try:
                delattr(self.target, self.attr)
            except AttributeError:
                pass
        else:
            setattr(self.target, self.attr, self.true_original)


def _describe(target: Any, attr: str) -> str:
    owner = (
        getattr(target, "__qualname__", None)
        or getattr(target, "__name__", None)
        or type(target).__name__
    )
    return f"{owner}.{attr}"


class PatchManager:
    """Реестр всех активных патчей ядра, общий для всех плагинов процесса."""

    def __init__(self) -> None:
        self._chains: dict[tuple[int, str], _ChainState] = {}

    # ── Установка патчей ──────────────────────────────────────

    def around(self, target: Any, attr: str, wrapper: Callable, *, plugin: str) -> PatchHandle:
        """Полный контроль над вызовом. См. докстринг модуля."""
        return self._install(target, attr, "around", wrapper, plugin, create_if_missing=False)

    def before(self, target: Any, attr: str, hook: Callable, *, plugin: str) -> PatchHandle:
        """Хук перед вызовом. Ошибки в hook не мешают original. См. докстринг модуля."""
        return self._install(target, attr, "before", hook, plugin, create_if_missing=False)

    def after(self, target: Any, attr: str, hook: Callable, *, plugin: str) -> PatchHandle:
        """Хук после вызова, может подменить результат. См. докстринг модуля."""
        return self._install(target, attr, "after", hook, plugin, create_if_missing=False)

    def replace(
        self, target: Any, attr: str, value: Any, *, plugin: str, create_if_missing: bool = False
    ) -> PatchHandle:
        """Полная замена атрибута. create_if_missing=True — если атрибута ещё нет и это ОК."""
        return self._install(target, attr, "replace", value, plugin, create_if_missing)

    def _install(
        self,
        target: Any,
        attr: str,
        mode: str,
        payload: Any,
        plugin: str,
        create_if_missing: bool,
    ) -> PatchHandle:
        attr_exists = hasattr(target, attr)
        if not attr_exists:
            if not (create_if_missing and mode == "replace"):
                raise PatchError(
                    f"Плагин «{plugin}»: нельзя патчить «{_describe(target, attr)}» — "
                    f"атрибут не существует. Если это осознанное добавление нового "
                    f"атрибута/метода — используйте replace(..., create_if_missing=True)."
                )

        key = (id(target), attr)
        existing_chain = self._chains.get(key)
        if existing_chain is not None:
            true_original = existing_chain.true_original
            desc = existing_chain.desc
        else:
            true_original = getattr(target, attr) if attr_exists else _MISSING
            desc = _describe(target, attr)

        is_async = mode != "replace" and inspect.iscoroutinefunction(true_original)
        if mode in ("around", "before", "after"):
            # Валидация — ДО того, как цепочка будет зарегистрирована в
            # self._chains: если она провалится на самой первой попытке
            # патча для этого (target, attr), self._chains не должен
            # обзавестись "призрачной" пустой записью, которую нечем
            # будет вычистить (rebuild()/setattr сюда никогда не дойдёт).
            self._validate_callable_shape(mode, payload, is_async, desc, plugin)

        if existing_chain is not None:
            chain = existing_chain
        else:
            chain = _ChainState(target=target, attr=attr, desc=desc, true_original=true_original)
            self._chains[key] = chain

        layer = _Layer(
            id=next(_id_counter),
            plugin=plugin,
            mode=mode,
            payload=payload,
            is_async=is_async,
            desc=chain.desc,
        )
        if chain.layers:
            logger.info(
                f"Плагин «{plugin}» добавляет патч ({mode}) на «{chain.desc}» "
                f"поверх {len(chain.layers)} уже установленных."
            )
        else:
            logger.info(f"Плагин «{plugin}» патчит «{chain.desc}» ({mode}).")
        chain.layers.append(layer)
        chain.rebuild()
        return PatchHandle(id=layer.id, plugin=plugin, target_key=key)

    @staticmethod
    def _validate_callable_shape(
        mode: str, payload: Callable, target_is_async: bool, desc: str, plugin: str
    ) -> None:
        if mode == "around":
            if not callable(payload):
                raise PatchError(f"Плагин «{plugin}»: around-обёртка для {desc} должна быть вызываемой.")
            if target_is_async and not inspect.iscoroutinefunction(payload):
                raise PatchError(
                    f"Плагин «{plugin}»: {desc} — async-метод, around-обёртка тоже "
                    f"должна быть объявлена как `async def` и вызывать `await original(...)`."
                )
            if not target_is_async and inspect.iscoroutinefunction(payload):
                raise PatchError(
                    f"Плагин «{plugin}»: {desc} — синхронный метод, around-обёртка не "
                    f"может быть `async def` (вызов вернёт незапущенный объект корутины "
                    f"вместо результата — некому его await'ить)."
                )
            return
        # before/after: hook может быть sync ИЛИ async независимо от цели —
        # мы сами решаем, awaitить его результат или нет (см. _Layer._build_*).
        # Запрещена только обратная несовместимая комбинация: цель — sync,
        # а hook — async (мы не можем корректно await из sync-обёртки).
        if not target_is_async and inspect.iscoroutinefunction(payload):
            raise PatchError(
                f"Плагин «{plugin}»: {desc} — синхронный метод, "
                f"{mode}-хук не может быть async (некому его await'ить)."
            )

    # ── Снятие патчей ─────────────────────────────────────────

    def revert(self, handle: PatchHandle) -> bool:
        """Снимает один конкретный патч по хэндлу. Возвращает True, если он был найден."""
        chain = self._chains.get(handle.target_key)
        if chain is None:
            return False
        before_len = len(chain.layers)
        chain.layers = [l for l in chain.layers if l.id != handle.id]
        if len(chain.layers) == before_len:
            return False
        if chain.layers:
            chain.rebuild()
        else:
            chain.restore_true_original()
            del self._chains[handle.target_key]
        logger.info(f"Патч плагина «{handle.plugin}» на «{chain.desc}» снят.")
        return True

    def revert_plugin(self, plugin: str) -> int:
        """
        Снимает ВСЕ патчи данного плагина по всем целям. Вызывается
        автоматически при teardown/reload плагина. Возвращает количество
        снятых патчей.
        """
        removed = 0
        for key, chain in list(self._chains.items()):
            before_len = len(chain.layers)
            chain.layers = [l for l in chain.layers if l.plugin != plugin]
            removed += before_len - len(chain.layers)
            if len(chain.layers) == before_len:
                continue
            if chain.layers:
                chain.rebuild()
            else:
                chain.restore_true_original()
                del self._chains[key]
        if removed:
            logger.info(f"Плагин «{plugin}»: снято {removed} патчей ядра.")
        return removed

    # ── Интроспекция ──────────────────────────────────────────

    def list_active(self) -> list[dict[str, Any]]:
        """Список активных патчей для диагностики: цель, режим, автор, позиция в цепочке."""
        out: list[dict[str, Any]] = []
        for chain in self._chains.values():
            for position, layer in enumerate(chain.layers, start=1):
                out.append({
                    "target": chain.desc,
                    "plugin": layer.plugin,
                    "mode": layer.mode,
                    "position": position,
                    "of": len(chain.layers),
                })
        return out
