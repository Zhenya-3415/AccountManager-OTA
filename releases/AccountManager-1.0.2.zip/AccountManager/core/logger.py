"""
core/logger.py — инициализация логгера.

Консоль: ANSI-цвета по уровню (только если stdout — TTY).
Файл:    plain text, с ротацией по размеру (несколько файлов на сессию
         вместо одного бесконечно растущего).

Формат: [YYYY-MM-DD HH:MM:SS] [LEVEL] name: message

── Почему через очередь, а не напрямую ──────────────────────────────
logging.FileHandler.emit()/StreamHandler.emit() — это СИНХРОННЫЙ вызов
записи (в файл на диск, либо в stdout, который вполне может оказаться
пайпом или сетевым терминалом). Каждый logger.info(...) в коде плагина
исполняется на event loop'е asyncio — синхронная запись в этот момент
блокирует ВЕСЬ процесс (все ожидающие апдейты от всех пользователей),
пока не завершится системный вызов записи.

Здесь logging.handlers.QueueHandler кладёт LogRecord в очередь —
это O(1) и не блокирует — а настоящие файловый/консольный хендлеры
работают в отдельном потоке (QueueListener), не на event loop'е.

── ВАЖНО: QueueHandler.emit() по умолчанию делает prepare() ДО
   постановки в очередь, а prepare() по умолчанию форматирует запись
   целиком — включая traceback.format_exception() для исключений —
   СИНХРОННО на вызывающем потоке (то есть на event loop'е). Это
   эмпирически подтверждено: logger.error(exc_info=True) с трейсбеком
   в 80 фреймов стоило ~7мс на вызывающем потоке при дефолтном
   prepare(). Раз в этом проекте очередь — обычная queue.Queue в
   рамках одного процесса (не multiprocessing), нет необходимости в
   pickle-безопасной подготовке записи, которой служит дефолтный
   prepare() — поэтому здесь он переопределён на дешёвый passthrough
   (см. _BoundedQueueHandler.prepare), а всё форматирование, включая
   traceback, происходит в потоке QueueListener.

── Почему очередь ОГРАНИЧЕНА, а не queue.SimpleQueue() ──────────────
Под нагрузочным тестом (300 000 log-вызовов подряд без единого await)
очередь без предела разрослась до ~230 000 записей (~180МБ) за
считанные секунды — производитель (event loop) обгонял потребителя
(поток QueueListener, конкурирующий с event loop'ом за то же CPU-ядро).
Это worst-case сценарий (реальные апдейты перемежаются с await на
сеть/БД, давая потоку-потребителю шанс поработать), но сама
возможность неограниченного роста памяти при устойчивой (не только
всплеск) перегрузке — реальный риск на большом трафике с
log_level=DEBUG. Поэтому очередь здесь сделана с maxsize и
политикой drop-при-переполнении (см. _BoundedQueueHandler) — то есть
логирование само по себе никогда не станет причиной OOM.

── ERROR/CRITICAL при переполненной очереди ─────────────────────────
ВАЖНО (это была ошибка в предыдущей версии): при переполнении нельзя
давать ERROR/CRITICAL блокирующий put() с таймаутом — это блокирует
event loop на реальное время таймаута, причём именно в момент
перегрузки, когда это наименее допустимо (эмпирически: put(timeout=1.0)
при заполненной очереди блокировал вызывающий поток на ~1000мс).
Вместо этого ERROR/CRITICAL при переполнении ВЫТЕСНЯЮТ самую старую
запись в очереди (queue.get_nowait() + put_nowait(), обе операции
O(1), блокировки нет) — эффект тот же (важные записи получают
приоритет перед DEBUG/INFO-мусором), но без блокировки.

── Ротация файлов ───────────────────────────────────────────────────
RotatingFileHandler поверх прежней схемы "один файл на сессию": имя
файла всё ещё привязано к моменту запуска (удобно искать логи
конкретного запуска бота), но внутри сессии при достижении
max_bytes создаётся новый файл (.1, .2, ...), старые за пределами
backup_count удаляются — единственный файл больше не может расти
неограниченно на долгоживущем процессе.

── Rate limit на повторяющиеся сообщения ────────────────────────────
_RateLimitFilter подавляет ТОЧНО одинаковые (logger, level, текст)
сообщения чаще чем раз в rate_limit_window секунд — защищает от
ситуации, когда один сломанный участок кода (например, retry-цикл)
заваливает лог тысячами одинаковых строк подряд. Первое вхождение
всегда пропускается сразу; при следующем вхождении после паузы к
сообщению подставляется "(подавлено N повторов)". Дедуп — по ТОЧНОМУ
тексту после подстановки, поэтому одинаковые по смыслу, но разные по
данным сообщения (разные user_id и т.п.) друг друга не подавляют —
это осознанное решение, а не недосмотр: в проекте сообщения собираются
f-строками на месте вызова, а не через ленивые %-аргументы, так что
дедуп «по шаблону» здесь невозможен без порчи полезной информации.

ВАЖНО: фильтр повешен на ХЕНДЛЕР (qh.addFilter), а не на
logging.Logger (root.addFilter) — это была ошибка в первой версии
этого фикса, эмпирически проверено и исправлено. Logger.filter()
вызывается ТОЛЬКО у того логгера, на котором непосредственно позвали
.warning()/.error(), а Logger.callHandlers() при подъёме по иерархии
предков проверяет только record.levelno >= hdlr.level для хендлеров
каждого предка — фильтры самих логгеров-предков (в т.ч. root) там не
проверяются вовсе. Поскольку весь проект логирует через именованные
дочерние логгеры (get_logger("antispam") и т.п.), а не через голый
logging.getLogger(), фильтр на root был бы молчаливым no-op для
абсолютно всех сообщений в проекте. Хендлер — единственное надёжное
место повесить фильтр, который увидит каждую запись независимо от
того, какой логгер её создал.
"""
from __future__ import annotations

import atexit
import copy
import logging
import logging.handlers
import queue
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

# ── ANSI-палитра ──────────────────────────────────────────────
_ANSI: dict[str, str] = {
    "DEBUG":    "\033[36m",   # cyan
    "INFO":     "\033[32m",   # green
    "WARNING":  "\033[33m",   # yellow
    "ERROR":    "\033[31m",   # red
    "CRITICAL": "\033[35m",   # magenta
    "RESET":    "\033[0m",
}

_queue_listener: Optional[logging.handlers.QueueListener] = None

# Ёмкость очереди — не «сколько сообщений в секунду», а «сколько
# секунд отставания потребителя мы готовы терпеть, храня разницу в
# памяти, прежде чем начнём отбрасывать».
_MAX_QUEUE_SIZE = 100_000

# Ротация: 10МБ на файл, до 10 файлов на сессию (~100МБ максимум).
_DEFAULT_MAX_BYTES = 10 * 1024 * 1024
_DEFAULT_BACKUP_COUNT = 10

# Одинаковый (logger, level, текст) — не чаще раза в это окно.
_DEFAULT_RATE_LIMIT_WINDOW = 10.0


class _BoundedQueueHandler(logging.handlers.QueueHandler):
    """
    QueueHandler с ограниченной очередью вместо queue.SimpleQueue()
    (у которой предела нет вовсе). При переполнении:
      - DEBUG/INFO/WARNING — отбрасываются без блокировки event loop'а
        (put_nowait + except Full);
      - ERROR/CRITICAL — вытесняют САМУЮ СТАРУЮ запись в очереди
        (get_nowait + put_nowait, обе O(1), без блокировки) вместо
        того, чтобы дожидаться места блокирующим put(timeout=...) —
        см. докстринг модуля про то, почему блокирующий put() здесь
        был ошибкой.
    Потери считаются и время от времени сводятся в одну строку в
    stderr (не в саму переполненную очередь — иначе отчёт о
    переполнении сам усугубляет переполнение). Счётчики защищены
    локом: enqueue() гарантированно вызывается только с event loop'а
    в этом проекте, но лок стоит на случай, если когда-нибудь логи
    начнут писать и из отдельного потока (например, синхронная
    библиотека через asyncio.to_thread) — цена ничтожна, а без него
    в этом случае возможна гонка на _dropped_since_report.
    """

    def __init__(self, q: "queue.Queue[logging.LogRecord]") -> None:
        super().__init__(q)
        self._dropped_since_report = 0
        self._last_report = time.monotonic()
        self._report_lock = threading.Lock()

    def prepare(self, record: logging.LogRecord) -> logging.LogRecord:
        """
        Переопределяет дефолтный QueueHandler.prepare(), который
        форматирует запись целиком (включая traceback.format_exception
        для исключений) СИНХРОННО на вызывающем потоке — то есть здесь
        это был бы event loop. Дефолтная реализация существует ради
        pickle-безопасности при передаче через multiprocessing.Queue;
        здесь используется обычная queue.Queue в рамках одного
        процесса, пиклить ничего не нужно — поэтому вся дорогая работа
        (формат сообщения, форматирование traceback) откладывается на
        поток QueueListener, где она и должна происходить.
        Копия — дешёвая (только ссылки на поля), нужна только чтобы
        никакая будущая правка кода не создала гонку между этим и
        обрабатывающим потоком за один и тот же объект записи.
        """
        return copy.copy(record)

    def enqueue(self, record: logging.LogRecord) -> None:
        if record.levelno >= logging.ERROR:
            try:
                self.queue.put_nowait(record)
                return
            except queue.Full:
                try:
                    self.queue.get_nowait()  # вытесняем самую старую запись
                except queue.Empty:
                    pass
                try:
                    self.queue.put_nowait(record)
                    self._report_drop()
                    return
                except queue.Full:
                    pass  # кто-то успел заполнить снова между get и put — просто дропаем
        else:
            try:
                self.queue.put_nowait(record)
                return
            except queue.Full:
                pass

        self._report_drop()

    def _report_drop(self) -> None:
        elapsed = 0.0
        dropped = 0
        with self._report_lock:
            self._dropped_since_report += 1
            now = time.monotonic()
            if now - self._last_report >= 5.0:
                dropped = self._dropped_since_report
                elapsed = now - self._last_report
                self._dropped_since_report = 0
                self._last_report = now
            else:
                return
        print(
            f"[logger] ПЕРЕГРУЗКА: очередь логов переполнена, за последние "
            f"{elapsed:.0f}с отброшено {dropped} записей.",
            file=sys.stderr,
        )


class _RateLimitFilter(logging.Filter):
    """
    Подавляет повторы ТОЧНО одинакового (logger, level, текст) сообщения
    чаще чем раз в window секунд. См. докстринг модуля.

    _seen хранит по записи на каждый УНИКАЛЬНЫЙ (logger, level, текст) —
    без чистки это неограниченно растущий словарь: сообщения вроде
    f"user {user_id} ..." дают отдельный ключ на каждого пользователя.
    Эмпирически проверено: 1 000 000 различных сообщений -> 1 000 000
    ключей, 278МБ. На боте с заявленным масштабом 800тыс.-2млн
    пользователей это гарантированный рост памяти без потолка вплоть до
    OOM. Поэтому раз в CLEANUP_INTERVAL секунд (не на каждый вызов —
    иначе сам cleanup стал бы тем же самым источником задержки на event
    loop'е, от которого лечит весь этот модуль) устаревшие записи
    (не тронутые дольше window секунд) вычищаются.
    """

    # Не чаще этого чистим _seen — полный проход по словарю на каждый
    # filter() вернул бы ту же проблему блокировки event loop'а, которую
    # весь остальной модуль старается устранить.
    _CLEANUP_MIN_INTERVAL = 30.0

    def __init__(self, window: float = _DEFAULT_RATE_LIMIT_WINDOW) -> None:
        super().__init__()
        self._window = window
        self._lock = threading.Lock()
        # key -> [ts_первого_в_текущем_окне, число_подавленных]
        self._seen: dict[tuple[str, int, str], list[float]] = {}
        self._cleanup_interval = max(window, self._CLEANUP_MIN_INTERVAL)
        self._last_cleanup = time.monotonic()

    def filter(self, record: logging.LogRecord) -> bool:
        text = record.getMessage()
        key = (record.name, record.levelno, text)
        now = time.monotonic()

        with self._lock:
            entry = self._seen.get(key)
            if entry is not None and now - entry[0] < self._window:
                entry[1] += 1
                return False

            suppressed = int(entry[1]) if entry is not None else 0
            self._seen[key] = [now, 0]

            if now - self._last_cleanup >= self._cleanup_interval:
                self._cleanup_locked(now)

        if suppressed:
            # Меняем msg, а не text/args — если сообщение собрано с
            # %-аргументами (а не f-строкой, как обычно в этом проекте),
            # getMessage() ниже по цепочке всё ещё корректно их подставит.
            record.msg = f"(подавлено {suppressed} повторов) {record.msg}"
        return True

    def _cleanup_locked(self, now: float) -> None:
        """Убирает записи, чьё окно истекло без новых повторов. Вызывать под self._lock."""
        stale = [k for k, (ts, _count) in self._seen.items() if now - ts >= self._window]
        for k in stale:
            del self._seen[k]
        self._last_cleanup = now


class _Formatter(logging.Formatter):
    """Единый форматтер: при use_color=True добавляет ANSI-коды."""

    def __init__(self, use_color: bool = False) -> None:
        super().__init__()
        self._use_color = use_color

    def format(self, record: logging.LogRecord) -> str:
        dt = datetime.fromtimestamp(record.created).strftime("%Y-%m-%d %H:%M:%S")
        level = record.levelname
        name = record.name
        msg = record.getMessage()

        if record.exc_info:
            if not record.exc_text:
                record.exc_text = self.formatException(record.exc_info)
        if record.exc_text:
            msg = f"{msg}\n{record.exc_text}"

        line = f"[{dt}] [{level}] {name}: {msg}"

        if self._use_color:
            color = _ANSI.get(level, "")
            reset = _ANSI["RESET"]
            line = f"{color}{line}{reset}"

        return line


def setup_logger(
    log_level: str,
    *,
    max_bytes: int = _DEFAULT_MAX_BYTES,
    backup_count: int = _DEFAULT_BACKUP_COUNT,
    rate_limit_window: float = _DEFAULT_RATE_LIMIT_WINDOW,
) -> None:
    """
    Инициализирует корневой логгер.
    Вызывается один раз из main.py после чтения конфига.

    max_bytes/backup_count — параметры ротации файла лога текущей
    сессии (см. докстринг модуля). rate_limit_window — окно подавления
    повторяющихся сообщений, 0 отключает rate limit полностью.
    """
    global _queue_listener

    level_str = log_level.upper()
    level = getattr(logging, level_str, logging.DEBUG)

    now = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    log_dir = Path("logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"log-{level_str.lower()}-{now}.log"

    # Сначала полностью останавливаем и дожидаемся завершения ПРЕЖНЕГО
    # listener'а (если setup_logger вызывается повторно), и только
    # потом отвязываем старый хендлер от root — так между этими двумя
    # действиями не возникает окна, где root вообще без хендлеров.
    stop_logger()

    root = logging.getLogger()
    root.setLevel(level)
    root.handlers.clear()

    # ── Настоящие (медленные) хендлеры — работают в отдельном потоке,
    # НЕ на event loop'е asyncio ──────────────────────────────────

    fh = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8"
    )
    fh.setLevel(level)
    fh.setFormatter(_Formatter(use_color=False))

    # Цвета — только если stdout реально TTY (не pipe, не redirection)
    is_tty: bool = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level)
    ch.setFormatter(_Formatter(use_color=is_tty))

    # ── QueueHandler — единственное, что видит event loop: put()
    # в очередь, без системных вызовов записи ───────────────────
    log_queue: "queue.Queue[logging.LogRecord]" = queue.Queue(maxsize=_MAX_QUEUE_SIZE)
    qh = _BoundedQueueHandler(log_queue)
    qh.setLevel(level)

    # Rate limit — фильтр вешается на ХЕНДЛЕР, а не на logging.Logger.
    # ВАЖНО: Logger.filter() вызывается ТОЛЬКО у того логгера, на
    # котором непосредственно позвали .warning()/.error() и т.п. —
    # при подъёме по иерархии (Logger.callHandlers) фильтры предков
    # (в т.ч. root) НЕ проверяются вообще, проверяется только
    # record.levelno >= hdlr.level для хендлеров каждого предка.
    # Поэтому root.addFilter(...) здесь был бы no-op для абсолютно
    # всех сообщений в проекте — они все идут через именованные
    # дочерние логгеры (get_logger("antispam") и т.п.), а не через
    # logging.getLogger() без имени. Хендлер — единственное место в
    # этой иерархии, где фильтр гарантированно увидит КАЖДУЮ запись
    # независимо от того, какой логгер её создал (Handler.handle
    # вызывает self.filter(record) сам, отдельно от Logger.filter).
    if rate_limit_window > 0:
        qh.addFilter(_RateLimitFilter(rate_limit_window))

    root.addHandler(qh)

    _queue_listener = logging.handlers.QueueListener(log_queue, fh, ch, respect_handler_level=True)
    _queue_listener.start()

    atexit.register(stop_logger)


def stop_logger() -> None:
    """
    Останавливает фоновый поток QueueListener, дожидаясь, пока он
    дозапишет всё, что уже лежит в очереди (QueueListener.stop()
    блокирующий, но это одноразовый вызов при остановке процесса,
    а не на каждый апдейт — цена оправдана: без этого последние
    сообщения перед падением/остановкой процесса могли бы потеряться).

    Вызывается автоматически на выходе из процесса (atexit) и явно —
    в finally-блоке main.py, чтобы логи гарантированно долетели до
    диска до закрытия остальных ресурсов (БД и т.п.).
    """
    global _queue_listener
    if _queue_listener is not None:
        _queue_listener.stop()
        _queue_listener = None


def get_logger(name: str) -> logging.Logger:
    """Возвращает именованный логгер. Использовать во всех модулях."""
    return logging.getLogger(name)
