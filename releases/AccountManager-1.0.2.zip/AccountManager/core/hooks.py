"""
core/hooks.py — шина событий ядра (HookBus).

Позволяет плагинам подписываться на события жизненного цикла ядра и
других плагинов, не трогая их код напрямую. Это «мягкий» способ
расширения — в отличие от core/patches.py (жёсткая подмена поведения),
здесь плагин только *реагирует* на происходящее и не может сорвать
основной вызов (см. изоляцию ошибок ниже).

Два стиля событий:

  emit(event, *a, **kw)          — «уведомление»: обработчики просто
                                    реагируют, возвращаемые значения
                                    собираются в список, но не влияют
                                    друг на друга и на источник события.

  emit_filter(event, value, *a)  — «конвейер»: значение `value`
                                    последовательно проходит через все
                                    обработчики; каждый может вернуть
                                    новое значение (или None — значит
                                    «оставить как есть»). Пример:
                                    normализация текста, обогащение
                                    словаря перед записью в БД и т.п.

Обработчики могут быть как sync, так и async функциями — вызывающая
сторона не должна об этом думать.

Ошибка в одном обработчике логируется с указанием плагина и события,
но НИКОГДА не прерывает остальные обработчики и не прерывает основной
поток выполнения ядра — событийная подписка по определению не должна
быть способна уронить бота.

Специальное имя события "*" — «прослушать всё»: обработчик получает
(event_name, *args, **kwargs) для КАЖДОГО emit()/emit_filter() в
системе. Удобно для диагностических/аудит-плагинов.
"""
from __future__ import annotations

import inspect
import itertools
from dataclasses import dataclass
from typing import Any, Callable

from core.logger import get_logger

logger = get_logger("hooks")

HandlerT = Callable[..., Any]

_id_counter = itertools.count(1)


@dataclass(frozen=True, slots=True)
class HookHandle:
    """Токен подписки, возвращаемый HookBus.on(). Нужен только для off()."""
    id: int
    event: str
    plugin: str


@dataclass(slots=True)
class _Subscription:
    id: int
    event: str
    handler: HandlerT
    plugin: str
    priority: int


async def _call_maybe_async(fn: HandlerT, *args: Any, **kwargs: Any) -> Any:
    """Вызывает обработчик независимо от того, sync он или async."""
    result = fn(*args, **kwargs)
    if inspect.isawaitable(result):
        return await result
    return result


class HookBus:
    """
    Центральная шина событий. Один экземпляр на процесс, создаётся в
    main.py и передаётся во все PluginContext, а также используется
    самим ядром (middleware, plugin_loader и т.д.) для эмита событий.
    """

    WILDCARD = "*"

    def __init__(self) -> None:
        # event -> список подписок, отсортированный по priority
        # (стабильная сортировка => при равном priority побеждает
        # порядок регистрации).
        self._subs: dict[str, list[_Subscription]] = {}

    # ── Подписка / отписка ───────────────────────────────────

    def on(
        self,
        event: str,
        handler: HandlerT,
        *,
        plugin: str,
        priority: int = 100,
    ) -> HookHandle:
        """
        Подписывает handler на событие event.

        priority: чем МЕНЬШЕ число, тем РАНЬШЕ вызывается обработчик
        относительно других подписчиков этого же события. Обработчики
        с одинаковым priority вызываются в порядке регистрации.
        """
        sub = _Subscription(
            id=next(_id_counter),
            event=event,
            handler=handler,
            plugin=plugin,
            priority=priority,
        )
        bucket = self._subs.setdefault(event, [])
        bucket.append(sub)
        bucket.sort(key=lambda s: s.priority)
        logger.debug(
            f"Плагин «{plugin}» подписался на событие «{event}» "
            f"(priority={priority})."
        )
        return HookHandle(id=sub.id, event=event, plugin=plugin)

    def off(self, handle: HookHandle) -> bool:
        """Снимает одну конкретную подписку. Возвращает True, если она была найдена."""
        bucket = self._subs.get(handle.event)
        if not bucket:
            return False
        for i, sub in enumerate(bucket):
            if sub.id == handle.id:
                bucket.pop(i)
                if not bucket:
                    # Пустой список-значение в словаре не освобождается сам
                    # по себе — при подписках на много уникальных по имени
                    # событий (например, per-user события) это стабильно
                    # растущая утечка на весь остаток жизни процесса.
                    # Эмпирически: 50 000 циклов подписка/отписка на разные
                    # события без этой строчки оставляли 50 000 пустых
                    # записей в self._subs.
                    del self._subs[handle.event]
                return True
        return False

    def remove_all_for(self, plugin: str) -> int:
        """
        Снимает ВСЕ подписки данного плагина (по всем событиям).
        Вызывается автоматически при teardown/reload плагина.
        Возвращает количество снятых подписок.
        """
        removed = 0
        for event, bucket in list(self._subs.items()):
            kept = [s for s in bucket if s.plugin != plugin]
            removed += len(bucket) - len(kept)
            if kept:
                self._subs[event] = kept
            else:
                del self._subs[event]
        if removed:
            logger.debug(f"Плагин «{plugin}»: снято {removed} подписок на события.")
        return removed

    # ── Эмит ──────────────────────────────────────────────────

    async def emit(self, event: str, *args: Any, **kwargs: Any) -> list[Any]:
        """
        Уведомляет всех подписчиков события. Возвращает список
        значений, успешно возвращённых обработчиками (упавшие
        обработчики в список не попадают, но и не прерывают остальных).
        """
        results: list[Any] = []
        for sub in list(self._subs.get(event, ())):
            try:
                results.append(await _call_maybe_async(sub.handler, *args, **kwargs))
            except Exception:
                logger.error(
                    f"Ошибка в обработчике события «{event}» "
                    f"(плагин «{sub.plugin}»)",
                    exc_info=True,
                )
        await self._emit_wildcard(event, args, kwargs)
        return results

    async def emit_filter(self, event: str, value: Any, *args: Any, **kwargs: Any) -> Any:
        """
        Пропускает value последовательно через всех подписчиков.
        Каждый обработчик получает (value, *args, **kwargs) и может
        вернуть новое значение — None означает «не менять».
        Обработчик, упавший с исключением, просто пропускается
        (значение остаётся тем, что было до него).
        """
        for sub in list(self._subs.get(event, ())):
            try:
                new_value = await _call_maybe_async(sub.handler, value, *args, **kwargs)
            except Exception:
                logger.error(
                    f"Ошибка в фильтре события «{event}» "
                    f"(плагин «{sub.plugin}»), значение не изменено",
                    exc_info=True,
                )
                continue
            if new_value is not None:
                value = new_value
        await self._emit_wildcard(event, (value, *args), kwargs)
        return value

    async def _emit_wildcard(self, event: str, args: tuple, kwargs: dict) -> None:
        if event == self.WILDCARD or self.WILDCARD not in self._subs:
            return
        for sub in list(self._subs[self.WILDCARD]):
            try:
                await _call_maybe_async(sub.handler, event, *args, **kwargs)
            except Exception:
                logger.error(
                    f"Ошибка в wildcard-обработчике (плагин «{sub.plugin}») "
                    f"на событии «{event}»",
                    exc_info=True,
                )

    # ── Интроспекция ──────────────────────────────────────────

    def list_hooks(self, event: str | None = None) -> dict[str, list[str]]:
        """Возвращает {событие: [имена плагинов-подписчиков]} — для диагностики."""
        if event is not None:
            return {event: [s.plugin for s in self._subs.get(event, ())]}
        return {ev: [s.plugin for s in subs] for ev, subs in self._subs.items()}
