"""
core/plugin_context.py — PluginContext: всё, что доступно плагину.

Раньше BasePlugin.setup() принимал (dp, bot, db, config) четырьмя
отдельными позиционными аргументами. Это плохо масштабируется — любое
новое общее ядро-возможность (hooks, patches, services...) означало бы
менять сигнатуру setup() у ВСЕХ уже написанных плагинов.

Теперь setup() принимает один объект PluginContext. Старые dp/bot/db/
config остаются доступны как атрибуты (ctx.dp, ctx.bot...), так что
миграция существующего плагина — это просто:

    async def setup(self, ctx: PluginContext) -> None:
        dp, bot, db, config = ctx.dp, ctx.bot, ctx.db, ctx.config
        # ...остальной код плагина не меняется...

Дополнительно ctx даёт доступ к hooks/patches/services/scheduler — но
НЕ напрямую к общим объектам HookBus/PatchManager/ServiceRegistry/
Scheduler (хотя они тоже доступны как ctx.hooks/ctx.patches/
ctx.services/ctx.scheduler для сложных случаев), а через удобные
обёртки ctx.on_hook(...)/ctx.patch_around(...)/ctx.provide_service(...)/
ctx.schedule_interval(...), которые сами подставляют имя плагина —
плагину не нужно нигде руками писать plugin=self.name.

── ctx.db vs ctx.core_db ───────────────────────────────────────────
Раньше ctx.db был ОДНОЙ общей БД на весь бот: ядро и все плагины
писали в один ./database/database.db, различаясь только namespace в
schema_version. Теперь у каждого плагина СВОЯ БД — отдельный файл
plugins/<plugin>/database/database.db, который PluginLoader создаёт и
мигрирует персонально для этого плагина (миграции берутся из
<plugin_dir>/migrations/, если такая папка есть):

  - ctx.db      — БД ЭТОГО плагина. Сюда идут CREATE TABLE в
                  migrations/ плагина и весь его собственный SQL. Другие
                  плагины физически не видят и не могут задеть эти
                  таблицы — это отдельный .db-файл.
  - ctx.core_db — БД ядра (./database/database.db), та самая, что
                  раньше была единственной ctx.db. Нужна, только если
                  плагину действительно требуется читать общие
                  ядровые таблицы (например, users, которую обновляет
                  core/middleware.py). Писать в core_db из плагина
                  без явной необходимости не стоит — миграции ядра
                  плагину не принадлежат и не должны от него зависеть.

Если плагин раньше использовал ctx.db для чего-то, что на самом деле
относится к таблицам ЯДРА (не своим собственным) — при переезде на эту
версию такой код нужно поправить на ctx.core_db.

── ctx.db / ctx.core_db и Postgres ──────────────────────────────────
С появлением config.json → database.backend="postgres" ctx.db/ctx.core_db
типизированы как BaseDatabase (core/db/base.py), а не конкретно
SQLiteDatabase — публичные методы (execute/execute_returning/fetchone/
fetchall/upsert_user) одинаковы на обоих бэкендах, но СХЕМА миграций
плагина — нет: SQLite-специфичный SQL (например, INTEGER PRIMARY KEY
AUTOINCREMENT) не переносится на Postgres автоматически. Если плагин
должен работать на обоих бэкендах, см. CONFIG.md → "Postgres и
миграции плагинов" (папка migrations/postgres/ рядом с обычной
migrations/).

── ctx.scheduler и ctx.schedule_* ───────────────────────────────────
Для фоновых задач (проверка просроченных подписок, ежедневная
рассылка статистики и т.п.) — ctx.schedule_interval/ctx.schedule_cron/
ctx.schedule_once вместо ручного asyncio.create_task в setup(). Задачи
плагина автоматически снимаются при teardown()/reload_plugin() —
плагину не нужно самому их отменять. См. core/scheduler.py и
CONFIG.md → "Планировщик".
"""
from __future__ import annotations

from dataclasses import dataclass
from logging import Logger
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from core.config import Config
from core.db.base import BaseDatabase
from core.hooks import HookBus, HookHandle
from core.patches import PatchHandle, PatchManager
from core.scheduler import JobCallback, JobHandle, Scheduler
from core.services import ServiceRegistry

if TYPE_CHECKING:
    # Только поля датаклаcса (dp/bot ниже) — сам PluginContext их не
    # создаёт и не вызывает, только хранит и прокидывает плагинам.
    # dataclass(slots=True) с `from __future__ import annotations`
    # работает со строковыми аннотациями без реального класса — импорт
    # aiogram (20+ сек на Termux) для этого не нужен.
    from aiogram import Bot, Dispatcher


@dataclass(slots=True)
class PluginContext:
    # ── Базовые объекты ядра (как и раньше) ──────────────────
    dp: Dispatcher
    bot: Bot
    db: BaseDatabase        # БД ЭТОГО плагина (файл или Postgres-схема — зависит от backend)
    core_db: BaseDatabase    # БД ядра — см. докстринг выше
    config: Config

    # ── Общие для всех плагинов шины расширения ──────────────
    hooks: HookBus
    patches: PatchManager
    services: ServiceRegistry
    scheduler: Scheduler

    # ── Персональные для ЭТОГО плагина ───────────────────────
    plugin_name: str
    plugin_dir: Path
    logger: Logger

    # ── Удобные обёртки над hooks ─────────────────────────────

    def on_hook(self, event: str, handler: Callable, *, priority: int = 100) -> HookHandle:
        """Подписка на событие ядра/другого плагина от имени текущего плагина."""
        return self.hooks.on(event, handler, plugin=self.plugin_name, priority=priority)

    async def emit(self, event: str, *args: Any, **kwargs: Any) -> list[Any]:
        """Эмит события всем подписчикам (см. core/hooks.py: HookBus.emit)."""
        return await self.hooks.emit(event, *args, **kwargs)

    async def emit_filter(self, event: str, value: Any, *args: Any, **kwargs: Any) -> Any:
        """Эмит события-фильтра (см. core/hooks.py: HookBus.emit_filter)."""
        return await self.hooks.emit_filter(event, value, *args, **kwargs)

    # ── Удобные обёртки над patches ───────────────────────────

    def patch_around(self, target: Any, attr: str, wrapper: Callable) -> PatchHandle:
        """Полный контроль над вызовом. См. core/patches.py."""
        return self.patches.around(target, attr, wrapper, plugin=self.plugin_name)

    def patch_before(self, target: Any, attr: str, hook: Callable) -> PatchHandle:
        """Хук перед вызовом, безопасный (ошибки не мешают original). См. core/patches.py."""
        return self.patches.before(target, attr, hook, plugin=self.plugin_name)

    def patch_after(self, target: Any, attr: str, hook: Callable) -> PatchHandle:
        """Хук после вызова, может подменить результат. См. core/patches.py."""
        return self.patches.after(target, attr, hook, plugin=self.plugin_name)

    def patch_replace(
        self, target: Any, attr: str, value: Any, *, create_if_missing: bool = False
    ) -> PatchHandle:
        """Полная замена атрибута. См. core/patches.py."""
        return self.patches.replace(
            target, attr, value, plugin=self.plugin_name, create_if_missing=create_if_missing
        )

    # ── Удобные обёртки над services ──────────────────────────

    def provide_service(self, name: str, value: Any) -> None:
        """Публикует сервис для других плагинов от имени текущего плагина."""
        self.services.provide(name, value, plugin=self.plugin_name)

    def get_service(self, name: str) -> Any | None:
        """Сервис другого плагина или None, если не найден/ещё не загружен."""
        return self.services.get(name)

    def require_service(self, name: str) -> Any:
        """Сервис другого плагина или ServiceNotFoundError. Учтите dependencies в manifest.json."""
        return self.services.require(name)

    # ── Удобные обёртки над scheduler ──────────────────────────

    def schedule_interval(
        self,
        job_id: str,
        seconds: float,
        callback: JobCallback,
        *,
        jitter: float = 0.0,
        misfire_policy: str = "run_once",
        max_concurrent: int = 1,
        persist: bool = True,
    ) -> JobHandle:
        """
        Запускать callback каждые `seconds` секунд, от имени текущего
        плагина. job_id должен быть уникален В ПРЕДЕЛАХ плагина (полное
        имя задачи внутри — "<plugin_name>.<job_id>").

        persist=True (по умолчанию) переживает рестарт процесса — время
        следующего запуска считается от последнего сохранённого, а не
        сбрасывается на полный интервал заново. См. core/scheduler.py.
        """
        return self.scheduler.interval(
            job_id, seconds, callback, plugin=self.plugin_name,
            jitter=jitter, misfire_policy=misfire_policy,
            max_concurrent=max_concurrent, persist=persist,
        )

    def schedule_cron(
        self,
        job_id: str,
        expr: str,
        callback: JobCallback,
        *,
        misfire_policy: str = "skip",
        max_concurrent: int = 1,
        persist: bool = True,
    ) -> JobHandle:
        """expr — 5 полей "минута час день_месяца месяц день_недели", напр. "0 3 * * *" (каждый день в 03:00)."""
        return self.scheduler.cron(
            job_id, expr, callback, plugin=self.plugin_name,
            misfire_policy=misfire_policy, max_concurrent=max_concurrent, persist=persist,
        )

    def schedule_once(self, job_id: str, when: float, callback: JobCallback) -> JobHandle:
        """when — задержка в секундах (или datetime) до единственного запуска."""
        return self.scheduler.once(job_id, when, callback, plugin=self.plugin_name)

    def cancel_job(self, handle: JobHandle) -> bool:
        """Обычно не нужно — PluginLoader сам снимает все задачи плагина при teardown()/reload."""
        return self.scheduler.cancel(handle)
