"""
core/dependencies.py — проверка версий pip- и plugin-зависимостей.

Раньше manifest.json → dependencies → pip/plugins были просто списками
ИМЁН ("pip": ["aiogram"]) — PluginLoader.check_pip_deps() проверял
только САМ ФАКТ существования пакета/плагина, а не его версию. Это
значит, что два плагина могли требовать одну и ту же библиотеку в
несовместимых версиях (один — aiogram<3.0, другой — aiogram>=3.15) и
конфликт всплыл бы не при загрузке с понятным сообщением, а позже, как
загадочный AttributeError где-то в середине обработки апдейта.

Теперь строка зависимости может содержать условие версии в формате
PEP 440 — том же, что использует сам pip и requirements.txt:

    "pip": ["aiogram>=3.15,<4.0", "requests"]
    "plugins": ["antispam>=1.0.0"]

Строка без условия версии (как раньше) по-прежнему означает «подходит
любая версия» — старые manifest.json не требуют правки.

Разбор условий (SpecifierSet) и версий (Version) — из пакета packaging,
того же самого, которым пользуется pip для этой же задачи: не
изобретается свой парсер версий, а используется ровно тот же
стандартный код, что уже умеет корректно сравнивать "1.2.3" < "1.10.0",
разбирать pre-release суффиксы и т.п. — вещи, в которых легко ошибиться
при самодельном сравнении строк version.split(".").
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as installed_pip_version
from typing import Optional

from packaging.specifiers import InvalidSpecifier, SpecifierSet
from packaging.version import InvalidVersion, Version

from core.logger import get_logger

logger = get_logger("dependencies")

# Имя пакета/плагина: буквы, цифры, точка/дефис/подчёркивание, не
# начинается с разделителя. Всё после имени — условие версии как есть,
# его целиком разбирает packaging.specifiers.SpecifierSet.
_NAME_RE = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)\s*(.*?)\s*$")
_SPECIFIER_START_CHARS = set("=<>!~")


class DependencySpecError(Exception):
    """Некорректная строка зависимости в manifest.json (не пропускает плагин, а не крашит процесс)."""


@dataclass(frozen=True, slots=True)
class DependencySpec:
    """Разобранная строка зависимости: имя + (возможно пустой) набор условий версии."""
    name: str
    specifier: SpecifierSet = field(default_factory=SpecifierSet)
    # Как строка была написана в manifest.json — используется для
    # сообщений в логах. НЕ используем str(specifier) для этого: у
    # SpecifierSet порядок условий при сериализации не гарантирован
    # (">=3.15,<4.0" может вернуться как "<4.0,>=3.15" — семантически
    # то же самое, но выглядит не так, как написал автор плагина).
    raw: str = ""

    def __post_init__(self) -> None:
        if not self.raw:
            s = str(self.specifier)
            object.__setattr__(self, "raw", f"{self.name}{s}" if s else self.name)

    def satisfied_by(self, version_str: str) -> tuple[bool, str]:
        """
        (ok, note). note непустой, если версию не удалось разобрать —
        в этом случае ok=True (не блокируем загрузку из-за того, что
        МЫ не смогли распарсить нестандартную версию), но диагностика
        всё равно передаётся вызывающему коду для лога.
        """
        if not self.specifier:
            return True, ""
        try:
            parsed = Version(version_str)
        except InvalidVersion:
            return True, f"версия «{version_str}» не в формате PEP 440 — условие не проверено"
        # Не полагаемся на неявное значение prereleases в `Version in
        # SpecifierSet`: его поведение менялось между версиями packaging.
        # Явно разрешаем prerelease внутри диапазона, но не prerelease самой
        # верхней границы: при `<2.0` версия `2.0.0a1` не должна проходить.
        ok = self.specifier.contains(parsed, prereleases=True)
        if ok and parsed.is_prerelease:
            release = parsed.release

            def same_release(other: Version) -> bool:
                return other.release == release or other.release == release[: len(other.release)]

            for clause in self.specifier:
                if clause.operator in ("<", "<=") and same_release(Version(clause.version)):
                    return False, ""
        return ok, ""


def parse_dependency(raw: str) -> DependencySpec:
    """
    "aiogram" -> DependencySpec("aiogram", SpecifierSet())
    "aiogram>=3.15,<4.0" -> DependencySpec("aiogram", SpecifierSet(">=3.15,<4.0"))
    """
    m = _NAME_RE.match(raw)
    if not m or not m.group(1):
        raise DependencySpecError(f"не удалось разобрать зависимость: «{raw}»")
    name, spec_str = m.group(1), m.group(2)
    if spec_str and spec_str[0] not in _SPECIFIER_START_CHARS:
        # Группа имени в _NAME_RE берёт только [A-Za-z0-9._-]. Если сразу
        # после того, что она захватила, идёт что-то ещё, не начинающееся
        # с оператора версии (например, non-ASCII символ, или забытый
        # оператор перед номером версии) — раньше это тихо уходило в
        # SpecifierSet(spec_str) и падало там с невнятным сообщением про
        # "некорректное условие версии", не намекая, что дело может быть
        # в самом имени. Здесь — по возможности честная подсказка сразу.
        raise DependencySpecError(
            f"не удалось разобрать зависимость: «{raw}» — после имени «{name}» "
            f"осталось «{spec_str}», это не похоже на условие версии PEP 440 "
            f"(например, «>=1.0»). Если «{name}» — не полное имя пакета, "
            f"проверьте на недопустимые символы (разрешены буквы, цифры, "
            f"«.», «-», «_»)."
        )
    try:
        specifier = SpecifierSet(spec_str) if spec_str else SpecifierSet()
    except InvalidSpecifier as exc:
        raise DependencySpecError(
            f"некорректное условие версии в «{raw}»: {exc}"
        ) from exc
    return DependencySpec(name=name, specifier=specifier, raw=raw.strip())


def parse_dependency_list(raw_list: list[str]) -> list[DependencySpec]:
    """Разбирает весь список зависимостей; бросает на первой некорректной строке."""
    return [parse_dependency(raw) for raw in raw_list]


@dataclass(frozen=True, slots=True)
class PipCheckResult:
    spec: DependencySpec
    installed: Optional[str]  # None -> пакет не установлен
    ok: bool
    reason: str = ""


def check_pip_dependency(spec: DependencySpec) -> PipCheckResult:
    """Проверяет ОДНУ pip-зависимость против реально установленного окружения."""
    try:
        installed = installed_pip_version(spec.name)
    except PackageNotFoundError:
        return PipCheckResult(spec, None, False, "пакет не установлен")

    ok, note = spec.satisfied_by(installed)
    if ok:
        return PipCheckResult(spec, installed, True, note)
    return PipCheckResult(
        spec, installed, False,
        f"установлена {installed}, требуется {spec.specifier}",
    )


def report_pip_conflicts(plugin_pip_specs: dict[str, list[DependencySpec]]) -> None:
    """
    Логирует сводку по каждому pip-пакету, который требует БОЛЬШЕ ОДНОГО
    плагина — с чьим именно условием версии, и удовлетворяет ли ему
    реально установленная версия. Вызывается ПОСЛЕ поплагинной проверки
    в check_pip_deps() — по отдельности каждый плагин уже либо прошёл,
    либо был пропущен, но эта сводка показывает КАРТИНУ ЦЕЛИКОМ: если
    два плагина хотят разные версии одной библиотеки, это видно одной
    записью в логе, а не двумя не связанными друг с другом «пропущен».
    """
    by_package: dict[str, list[tuple[str, DependencySpec]]] = {}
    for plugin_name, specs in plugin_pip_specs.items():
        for spec in specs:
            by_package.setdefault(spec.name, []).append((plugin_name, spec))

    for package, entries in sorted(by_package.items()):
        if len(entries) < 2:
            continue

        try:
            installed = installed_pip_version(package)
        except PackageNotFoundError:
            installed = None

        satisfied: list[str] = []
        unsatisfied: list[str] = []
        for plugin_name, spec in entries:
            ok = installed is not None and spec.satisfied_by(installed)[0]
            (satisfied if ok else unsatisfied).append(plugin_name)

        requirement_lines = "\n".join(f"        - «{p}» требует {s.raw}" for p, s in entries)
        if unsatisfied:
            logger.warning(
                f"Пакет «{package}» (установлено: {installed or 'не установлен'}) "
                f"требуют несколько плагинов с разными условиями:\n"
                f"{requirement_lines}\n"
                f"        Не удовлетворены: {', '.join(unsatisfied)}."
            )
        else:
            logger.debug(
                f"Пакет «{package}»: несколько плагинов ({', '.join(p for p, _ in entries)}) "
                f"— все условия совместимы с установленной версией {installed}."
            )


def parse_specifier_only(raw: str) -> SpecifierSet:
    """
    Для manifest.json -> core_version, где нет имени пакета — просто
    условие версии: ">=2.0.0,<3.0.0". Пустая строка -> SpecifierSet()
    ("совместимо с любой версией ядра").
    """
    raw = raw.strip()
    if not raw:
        return SpecifierSet()
    try:
        return SpecifierSet(raw)
    except InvalidSpecifier as exc:
        raise DependencySpecError(f"некорректное условие версии ядра «{raw}»: {exc}") from exc


def check_core_version(specifier: SpecifierSet, core_version: str) -> tuple[bool, str]:
    """Проверяет core_version плагина против фактической core.__version__."""
    if not specifier:
        return True, ""
    try:
        ok = Version(core_version) in specifier
    except InvalidVersion:
        return True, f"версия ядра «{core_version}» не в формате PEP 440 — условие не проверено"
    if ok:
        return True, ""
    return False, f"ядро версии {core_version}, требуется {specifier}"


def check_plugin_version(dep_name: str, specifier: SpecifierSet, actual_version: str) -> tuple[bool, str]:
    """Проверяет версию ОДНОГО плагина-зависимости против условия из manifest.json другого плагина."""
    if not specifier:
        return True, ""
    try:
        ok = Version(actual_version) in specifier
    except InvalidVersion:
        return True, f"версия «{actual_version}» не в формате PEP 440 — условие не проверено"
    if ok:
        return True, ""
    return False, f"установлена {actual_version}, требуется {specifier}"
