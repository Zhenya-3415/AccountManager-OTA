"""
core/ota/downloader.py — скачивание OTA-архива и быстрая проверка sha256.

Скачивает:
  framework.zip      → <dest_dir>/framework.zip
  framework.zip.sig  → <dest_dir>/framework.zip.sig

Проверяет sha256 zip-файла СРАЗУ после скачивания (проверка целостности
передачи). Криптографическая верификация подписи — в core/ota/verifier.py.

stdlib only (urllib + hashlib). Никаких module-level констант с захардкоженными
значениями: User-Agent строится из core.__version__ (единственный источник
правды), размер буфера приходит из config.json → ota → download_chunk_kb.
"""
from __future__ import annotations

import hashlib
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from core.ota.checker import ReleaseInfo

_DEFAULT_CHUNK_KB = 64   # используется только если config недоступен


def _user_agent() -> str:
    """
    User-Agent вида «AccountManager-OTA/1.0.0».
    Версия — из core.__version__ (читается из manifest_core.json при старте).
    Если core не импортируется (изолированная среда тестов без манифеста) —
    фоллбэк на «AccountManager-OTA/unknown».
    """
    try:
        import core
        return f"AccountManager-OTA/{core.__version__}"
    except Exception:
        return "AccountManager-OTA/unknown"


def _download_file(url: str, dest: Path, timeout: int = 60,
                   chunk_bytes: int = _DEFAULT_CHUNK_KB * 1024) -> None:
    """Скачивает url → dest по кускам. Бросает urllib.error при ошибке."""
    req = urllib.request.Request(url, headers={"User-Agent": _user_agent()})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(dest, "wb") as fh:
        while True:
            chunk = resp.read(chunk_bytes)
            if not chunk:
                break
            fh.write(chunk)


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    chunk_bytes = _DEFAULT_CHUNK_KB * 1024
    with open(path, "rb") as fh:
        while chunk := fh.read(chunk_bytes):
            h.update(chunk)
    return h.hexdigest()


@dataclass
class DownloadResult:
    ok:       bool
    zip_path: Path = Path()
    sig_path: Path = Path()
    reason:   str  = ""


def download_release(
    release: ReleaseInfo,
    dest_dir: Path,
    timeout: int = 120,
    chunk_kb: int = _DEFAULT_CHUNK_KB,   # переопределяется из config.ota.download_chunk_kb
    progress_cb=None,
) -> DownloadResult:
    """
    Скачивает framework.zip + framework.zip.sig в dest_dir.
    Проверяет sha256 zip после скачивания.

    chunk_kb — размер буфера скачивания в КиБ; берётся из
    config.json → ota → download_chunk_kb (передаётся caller'ом).

    progress_cb(msg) вызывается для текстовых обновлений (необязателен).
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    zip_path = dest_dir / "framework.zip"
    sig_path = dest_dir / "framework.zip.sig"
    chunk_bytes = chunk_kb * 1024

    def _progress(msg: str) -> None:
        if progress_cb:
            progress_cb(msg)

    # ── скачиваем zip ────────────────────────────────────────
    _progress(f"Скачиваю framework.zip ({release.version})...")
    try:
        _download_file(release.zip_url, zip_path, timeout, chunk_bytes)
    except (urllib.error.URLError, OSError) as exc:
        return DownloadResult(ok=False, reason=f"Ошибка скачивания zip: {exc}")

    # ── sha256 zip-файла (проверка передачи, не подписи) ────
    if release.sha256:
        _progress("Проверяю sha256 zip-файла...")
        actual = _sha256_file(zip_path)
        if actual != release.sha256.lower():
            zip_path.unlink(missing_ok=True)
            return DownloadResult(
                ok=False,
                reason=(
                    f"sha256 zip-файла не совпадает.\n"
                    f"  Ожидалось: {release.sha256}\n"
                    f"  Получено:  {actual}"
                ),
            )
        _progress("✓ sha256 zip совпадает.")
    else:
        _progress("⚠ sha256 в releases.json не задан — проверка передачи пропущена.")

    # ── скачиваем .sig ───────────────────────────────────────
    _progress("Скачиваю framework.zip.sig...")
    try:
        _download_file(release.sig_url, sig_path, timeout=30, chunk_bytes=chunk_bytes)
    except (urllib.error.URLError, OSError) as exc:
        zip_path.unlink(missing_ok=True)  # убираем zip — без подписи он бесполезен
        return DownloadResult(ok=False, reason=f"Ошибка скачивания .sig: {exc}")

    _progress("✓ Архив и подпись скачаны.")
    return DownloadResult(ok=True, zip_path=zip_path, sig_path=sig_path)
