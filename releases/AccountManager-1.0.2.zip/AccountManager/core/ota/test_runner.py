"""
core/ota/test_runner.py — запуск слота B и мониторинг без psutil и heartbeat-файлов.

Мониторинг: subprocess.Popen.poll() каждые poll_interval_s секунд (параметр,
  дефолт _DEFAULT_POLL_INTERVAL=5).
  poll() == None  → процесс жив
  poll() == <код> → процесс упал → crash_count++

Логика:
  crash_count >= max_crashes             → ROLLBACK
  elapsed >= test_duration_s без крашей  → PROMOTE (ready_to_promote)

При каждом краше (если crash_count < max_crashes) — перезапускаем
слот B: так отличаем разовый сбой от системной нестабильности.
"""
from __future__ import annotations

import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from core.ota.process_manager import start_slot_b
from core.ota.slot_manager import OTAState, load_state, save_state, set_status, _log

# Дефолты используются только когда config недоступен (изолированные тесты).
_DEFAULT_POLL_INTERVAL = 5
_DEFAULT_STARTUP_GRACE = 10


@dataclass
class TestResult:
    outcome: str           # "promote" | "rollback"
    crash_count: int = 0
    reason: str = ""


def _update_crash_count(count: int) -> None:
    state = load_state()
    state.crash_count = count
    save_state(state)


def run_slot_b_test(
    slot_b_dir: Path,
    max_crashes: int,
    test_duration_s: int,
    poll_interval_s: int = _DEFAULT_POLL_INTERVAL,
    startup_grace_s: int = _DEFAULT_STARTUP_GRACE,
    progress_cb=None,
) -> TestResult:
    """
    Запускает слот B и мониторит его до победы или отката.

    progress_cb(msg: str) — для TUI/CLI обратной связи (необязателен).
    Функция БЛОКИРУЮЩАЯ (запускать в отдельном потоке или процессе для TUI).
    """
    def _p(msg: str) -> None:
        _log(msg)
        if progress_cb:
            progress_cb(msg)

    crash_count     = 0
    start_time      = time.monotonic()
    proc: Optional[subprocess.Popen] = None

    def _launch() -> subprocess.Popen:
        _p(f"[OTA] Запускаю слот B: {slot_b_dir / 'main.py'}")
        p = start_slot_b(slot_b_dir)
        _p(f"[OTA] Слот B запущен, pid={p.pid}")
        return p

    proc = _launch()
    time.sleep(startup_grace_s)   # даём боту время инициализироваться

    while True:
        time.sleep(poll_interval_s)

        exit_code = proc.poll()
        if exit_code is not None:
            # Процесс упал
            crash_count += 1
            _update_crash_count(crash_count)
            _p(f"[OTA] Слот B упал (exit={exit_code}), краш #{crash_count}/{max_crashes}")

            if crash_count >= max_crashes:
                _p(f"[OTA] Превышено max_crashes={max_crashes}, откат.")
                return TestResult(
                    outcome="rollback",
                    crash_count=crash_count,
                    reason=f"Слот B упал {crash_count} раз(а), последний exit-код: {exit_code}",
                )

            # Перезапускаем для следующей попытки
            _p(f"[OTA] Перезапускаю слот B (попытка {crash_count + 1})...")
            proc = _launch()
            # Сбрасываем таймер теста после краша — тест должен пройти
            # непрерывно, а не накопительно
            start_time = time.monotonic()
            time.sleep(startup_grace_s)
            continue

        elapsed = time.monotonic() - start_time
        pct = min(100, int(elapsed * 100 / test_duration_s))
        _p(f"[OTA] Слот B работает... {int(elapsed)}s / {test_duration_s}s ({pct}%)")

        if elapsed >= test_duration_s:
            _p(f"[OTA] Слот B стабилен ({test_duration_s}s без крашей). Готов к промоуту.")
            # Аккуратно останавливаем тестовый процесс
            try:
                proc.terminate()
                proc.wait(timeout=15)
            except (subprocess.TimeoutExpired, OSError):
                try:
                    proc.kill()
                except OSError:
                    pass
            return TestResult(
                outcome="promote",
                crash_count=crash_count,
                reason="",
            )


def run_test_in_thread(
    slot_b_dir: Path,
    max_crashes: int,
    test_duration_s: int,
    poll_interval_s: int = _DEFAULT_POLL_INTERVAL,
    startup_grace_s: int = _DEFAULT_STARTUP_GRACE,
    on_result=None,   # callable(TestResult) — вызывается по завершению
    progress_cb=None,
) -> "threading.Thread":
    """
    Запускает run_slot_b_test() в фоновом Thread.
    on_result(result: TestResult) вызывается из потока после завершения теста.
    Возвращает Thread (не запускает сам — вызывающий делает thread.start()).
    """
    import threading

    def _worker():
        result = run_slot_b_test(slot_b_dir, max_crashes, test_duration_s,
                                   poll_interval_s, startup_grace_s, progress_cb)
        if on_result is not None:
            on_result(result)

    t = threading.Thread(target=_worker, daemon=True, name="ota-test-runner")
    return t
