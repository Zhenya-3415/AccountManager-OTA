"""
core/ota/verifier.py — верификация OTA-пакета.

Три уровня защиты:
  1. sha256 zip-файла — проверка целостности передачи (core/ota/downloader.py)
  2. Ed25519 подпись — проверка аутентичности (этот модуль)
  3. sha256_hash по распакованным файлам — verify_build_integrity() (этот модуль)

Публичный ключ: configs/keys/public.pem (Ed25519, PEM-формат).
Приватный ключ: configs/keys/private.pem — НИКОГДА не входит в репо,
  только у разработчика при подписи релиза (scripts/sign_release.py).

Зависимость: cryptography>=42.0 (из manifest_core.json → requirements).
При отсутствии — OTAVerifyError с подсказкой.
"""
from __future__ import annotations

import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

PUBKEY_PATH = Path("configs") / "keys" / "public.pem"


class OTAVerifyError(Exception):
    """Верификация не прошла."""


@dataclass
class VerifyResult:
    ok:          bool
    reason:      str  = ""
    files_count: int  = 0


# ── Ed25519 ──────────────────────────────────────────────────────

def _load_ed25519_pubkey(pubkey_path: Path):
    """Загружает Ed25519 pubkey из PEM-файла. Требует cryptography."""
    try:
        from cryptography.hazmat.primitives.serialization import load_pem_public_key
    except ImportError as exc:
        raise OTAVerifyError(
            "Библиотека cryptography не установлена. Выполните:\n"
            "  python framework_manager.py deps --install\n"
            "или: pip install cryptography>=42.0"
        ) from exc

    if not pubkey_path.exists():
        raise OTAVerifyError(
            f"Публичный ключ не найден: {pubkey_path}\n"
            f"Сгенерируйте пару ключей: python scripts/generate_keys.py"
        )

    pem = pubkey_path.read_bytes()
    key = load_pem_public_key(pem)
    return key


def verify_ed25519(zip_path: Path, sig_path: Path, pubkey_path: Path = PUBKEY_PATH) -> None:
    """
    Проверяет Ed25519-подпись zip-файла.
    Бросает OTAVerifyError если подпись не прошла.
    """
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature
    except ImportError as exc:
        raise OTAVerifyError("Библиотека cryptography недоступна.") from exc

    key = _load_ed25519_pubkey(pubkey_path)

    if not isinstance(key, Ed25519PublicKey):
        raise OTAVerifyError(
            f"{pubkey_path} содержит не Ed25519 ключ (тип: {type(key).__name__}). "
            "Пересоздайте пару: python scripts/generate_keys.py"
        )

    zip_bytes = zip_path.read_bytes()
    sig_bytes = sig_path.read_bytes()

    try:
        key.verify(sig_bytes, zip_bytes)
    except InvalidSignature as exc:
        raise OTAVerifyError(
            "Ed25519-подпись НЕДЕЙСТВИТЕЛЬНА. Архив мог быть подменён или повреждён."
        ) from exc


# ── Распаковка + verify_build_integrity ──────────────────────────

def extract_zip(zip_path: Path, dest_dir: Path) -> int:
    """
    Распаковывает framework.zip в dest_dir.
    Возвращает кол-во извлечённых файлов.
    Защита от zip-slip: отклоняем пути с ".." или абсолютные.
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.infolist():
            # Защита от zip-slip
            if ".." in member.filename or member.filename.startswith("/"):
                raise OTAVerifyError(f"Опасный путь в архиве: {member.filename!r}")
            zf.extract(member, dest_dir)
            count += 1
    return count


def verify_unpacked(
    unpacked_dir: Path,
    pubkey_path: Path = PUBKEY_PATH,
    skip_signature: bool = False,
    zip_path: Optional[Path] = None,
    sig_path: Optional[Path] = None,
) -> VerifyResult:
    """
    Полная верификация распакованного OTA-пакета:
      1. (опционально) Ed25519 если переданы zip_path + sig_path
      2. verify_build_integrity() из core/manifest.py по распакованным файлам

    skip_signature=True — пропустить шаг 1 (для тестов или если ключ ещё не создан).
    """
    # Ed25519
    if not skip_signature:
        if zip_path is None or sig_path is None:
            raise OTAVerifyError("zip_path и sig_path обязательны для проверки подписи.")
        try:
            verify_ed25519(zip_path, sig_path, pubkey_path)
        except OTAVerifyError:
            raise
        except Exception as exc:
            raise OTAVerifyError(f"Неожиданная ошибка при проверке подписи: {exc}") from exc

    # verify_build_integrity по распакованным файлам
    try:
        from core.manifest import load_manifest, verify_build_integrity, ManifestError
    except ImportError as exc:
        raise OTAVerifyError(f"Не удалось импортировать core.manifest: {exc}") from exc

    manifest_path = unpacked_dir / "manifest_core.json"
    try:
        manifest = load_manifest(manifest_path)
    except ManifestError as exc:
        raise OTAVerifyError(f"manifest_core.json в архиве: {exc}") from exc

    integrity = verify_build_integrity(manifest, project_root=unpacked_dir)
    if not integrity.ok:
        raise OTAVerifyError(
            f"verify_build_integrity для распакованного архива провалилась: {integrity.reason}"
        )

    return VerifyResult(ok=True, files_count=integrity.files_hashed)


def full_verify_and_extract(
    zip_path: Path,
    sig_path: Path,
    unpack_dir: Path,
    pubkey_path: Path = PUBKEY_PATH,
    skip_signature: bool = False,
    progress_cb=None,
) -> VerifyResult:
    """
    Единая точка входа:
      1. verify_ed25519(zip, sig)
      2. extract_zip → unpack_dir
      3. verify_unpacked(unpack_dir)

    progress_cb(msg) — необязательный callback для TUI/CLI.
    """
    def _p(msg: str) -> None:
        if progress_cb:
            progress_cb(msg)

    if not skip_signature:
        _p("Проверяю Ed25519-подпись архива...")
        verify_ed25519(zip_path, sig_path, pubkey_path)
        _p("✓ Подпись действительна.")

    _p("Распаковываю framework.zip...")
    files_n = extract_zip(zip_path, unpack_dir)
    _p(f"✓ Распаковано {files_n} файлов.")

    _p("Проверяю целостность сборки (sha256_hash)...")
    result = verify_unpacked(
        unpack_dir,
        pubkey_path=pubkey_path,
        skip_signature=True,   # уже проверили выше
    )
    _p(f"✓ Целостность подтверждена ({result.files_count} файлов).")
    return result
