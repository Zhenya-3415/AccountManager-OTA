"""
core/ota/notifier.py — уведомления об OTA-событиях.

Два канала (оба опциональны, независимы):
  1. CLI — вопрос в терминале с таймаутом
  2. Telegram — через BOT_TOKEN_TEST (не основной!), чтобы не конфликтовать
     с запущенным слотом A. Только urllib, без aiogram.

Telegram-сообщение с inline-клавиатурой:
  [✅ Применить сейчас]  [⏳ При перезапуске]
Поллинг getUpdates (plain urllib) до timeout_s или ответа.
ADMIN_CHAT_ID — из configs/.env.

Если BOT_TOKEN_TEST / ADMIN_CHAT_ID не заданы → Telegram пропускается,
только CLI.
"""
from __future__ import annotations

import json
import select
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Optional

_TG_API = "https://api.telegram.org/bot{token}/{method}"


def _user_agent() -> str:
    try:
        import core
        return f"AccountManager-OTA/{core.__version__}"
    except Exception:
        return "AccountManager-OTA/unknown"


# ── Telegram helpers ─────────────────────────────────────────────

def _tg(token: str, method: str, payload: dict) -> Optional[dict]:
    """Отправляет запрос к Telegram Bot API. Возвращает result или None."""
    url  = _TG_API.format(token=token, method=method)
    data = json.dumps(payload).encode("utf-8")
    req  = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json", "User-Agent": _user_agent()},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result.get("result") if result.get("ok") else None
    except (urllib.error.URLError, json.JSONDecodeError, OSError):
        return None


def _send_message(
    token: str, chat_id: str, text: str,
    reply_markup: Optional[dict] = None,
) -> Optional[int]:
    """Отправляет сообщение. Возвращает message_id или None."""
    payload: dict = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
    if reply_markup:
        payload["reply_markup"] = reply_markup
    result = _tg(token, "sendMessage", payload)
    if isinstance(result, dict):
        return result.get("message_id")
    return None


def _get_updates(token: str, offset: int, timeout: int = 5) -> list[dict]:
    """Long-poll getUpdates. Возвращает список апдейтов."""
    result = _tg(token, "getUpdates", {
        "offset": offset,
        "timeout": min(timeout, 5),
        "allowed_updates": ["callback_query"],
    })
    return result if isinstance(result, list) else []


def _answer_callback(token: str, callback_query_id: str, text: str = "") -> None:
    _tg(token, "answerCallbackQuery", {
        "callback_query_id": callback_query_id,
        "text": text,
        "show_alert": False,
    })


# ── CLI с таймаутом ──────────────────────────────────────────────

def _cli_ask_with_timeout(prompt: str, timeout_s: int) -> Optional[bool]:
    """
    Выводит prompt и ждёт ввода с таймаутом.
    Возвращает True ("да"), False ("нет/таймаут").
    На Windows select() для stdin не работает — используем threading.
    """
    print(f"\n{prompt}", end=" ", flush=True)

    if sys.platform == "win32":
        return _cli_ask_windows(timeout_s)

    # POSIX: select() на stdin
    ready, _, _ = select.select([sys.stdin], [], [], timeout_s)
    if not ready:
        print(f"\n  (таймаут {timeout_s}s, выбрано: нет)")
        return False
    answer = sys.stdin.readline().strip().lower()
    return answer in ("y", "yes", "д", "да")


def _cli_ask_windows(timeout_s: int) -> Optional[bool]:
    """Windows-вариант: читаем ввод в отдельном потоке с ожиданием."""
    import threading
    result: list[Optional[bool]] = [None]

    def _reader():
        try:
            answer = input().strip().lower()
            result[0] = answer in ("y", "yes", "д", "да")
        except (EOFError, OSError):
            result[0] = False

    t = threading.Thread(target=_reader, daemon=True)
    t.start()
    t.join(timeout=timeout_s)

    if result[0] is None:
        print(f"\n  (таймаут {timeout_s}s, выбрано: нет)")
        return False
    return result[0]


# ── Публичные функции ────────────────────────────────────────────

def ask_interrupt_promote(
    version: str,
    description: str,
    bot_token_test: str,
    admin_chat_id: str,
    timeout_s: int = 60,
) -> bool:
    """
    Спрашивает администратора: "применить обновление сейчас или при перезапуске?"
    Оба канала (CLI + Telegram) запускаются параллельно; первый ответ побеждает.

    Возвращает True → "применить сейчас", False → "при перезапуске".
    """
    prompt = (
        f"Версия {version} протестирована и готова.\n"
        f"  {description}\n"
        f"Остановить бота и применить обновление СЕЙЧАС? "
        f"[y/N] (таймаут {timeout_s}s): "
    )

    answer: list[Optional[bool]] = [None]
    import threading
    done = threading.Event()

    def _cli_worker():
        res = _cli_ask_with_timeout(prompt, timeout_s)
        if not done.is_set():
            answer[0] = res
            done.set()

    def _tg_worker():
        if not (bot_token_test and admin_chat_id):
            return
        _ask_telegram(
            bot_token_test, admin_chat_id, version, description,
            timeout_s, answer, done,
        )

    threads = [
        threading.Thread(target=_cli_worker, daemon=True),
        threading.Thread(target=_tg_worker,  daemon=True),
    ]
    for t in threads:
        t.start()
    done.wait(timeout=timeout_s + 2)

    result = answer[0]
    if result is None:
        print(f"  (нет ответа за {timeout_s}s, выбрано: при перезапуске)")
        return False
    return result


def _ask_telegram(
    token: str,
    chat_id: str,
    version: str,
    description: str,
    timeout_s: int,
    answer: list,
    done: "threading.Event",
) -> None:
    """Отправляет inline-кнопки в Telegram и поллит ответ."""
    text = (
        f"🔄 <b>AccountManager — OTA обновление</b>\n\n"
        f"Версия <b>{version}</b> протестирована и стабильна.\n"
        f"{description}\n\n"
        f"Применить <b>сейчас</b> (бот будет перезапущен) "
        f"или при следующем перезапуске?"
    )
    markup = {
        "inline_keyboard": [[
            {"text": "✅ Применить сейчас",        "callback_data": "ota:now"},
            {"text": "⏳ При следующем перезапуске", "callback_data": "ota:later"},
        ]]
    }
    _send_message(token, chat_id, text, markup)

    deadline = time.monotonic() + timeout_s
    offset   = 0
    while time.monotonic() < deadline and not done.is_set():
        updates = _get_updates(token, offset, timeout=5)
        for upd in updates:
            offset = upd.get("update_id", offset) + 1
            cb     = upd.get("callback_query", {})
            data   = cb.get("data", "")
            if data in ("ota:now", "ota:later"):
                choice = data == "ota:now"
                _answer_callback(token, cb.get("id", ""),
                                 "✅ Принято!" if choice else "⏳ Применим при перезапуске.")
                if not done.is_set():
                    answer[0] = choice
                    done.set()
                return


def notify_rollback(
    version: str,
    reason: str,
    bot_token_test: str,
    admin_chat_id: str,
) -> None:
    """Уведомление об откате в лог + Telegram."""
    msg = f"[OTA] ОТКАТ версии {version}: {reason}"
    print(msg)

    if bot_token_test and admin_chat_id:
        tg_text = (
            f"⚠️ <b>AccountManager — OTA ОТКАТ</b>\n\n"
            f"Версия <b>{version}</b> откатана.\n"
            f"Причина: {reason}\n\n"
            f"Текущий слот A продолжает работать."
        )
        _send_message(bot_token_test, admin_chat_id, tg_text)


def notify_promote_done(
    version: str,
    bot_token_test: str,
    admin_chat_id: str,
) -> None:
    """Уведомление об успешном промоуте."""
    msg = f"[OTA] Промоут выполнен: версия {version} теперь активна."
    print(msg)

    if bot_token_test and admin_chat_id:
        tg_text = (
            f"✅ <b>AccountManager — OTA обновление применено</b>\n\n"
            f"Версия <b>{version}</b> теперь активна в слоте A.\n"
            f"Бот перезапущен."
        )
        _send_message(bot_token_test, admin_chat_id, tg_text)
