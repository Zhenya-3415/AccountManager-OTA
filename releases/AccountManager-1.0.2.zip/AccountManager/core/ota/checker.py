"""
core/ota/checker.py — проверка наличия обновлений в OTA-репозитории.

Структура OTA-репозитория (GitHub, отдельные ветки по каналу):
  <channel>/
    releases.json        ← индекс релизов
    releases/<ver>/
      manifest_core.json
      framework.zip
      framework.zip.sig

raw-URL для GitHub:
  https://raw.githubusercontent.com/<owner>/<repo>/<channel>/releases.json

Никаких внешних зависимостей — только stdlib (urllib).
"""
from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Optional

try:
    from packaging.version import Version
except ImportError:
    # Если packaging не установлен (minimalist env) — примитивный fallback
    class Version:  # type: ignore[no-redef]
        def __init__(self, v: str) -> None:
            self._t = tuple(int(x) for x in v.strip().lstrip("v").split(".")[:3])
        def __lt__(self, other: "Version") -> bool:
            return self._t < other._t
        def __le__(self, other: "Version") -> bool:
            return self._t <= other._t
        def __gt__(self, other: "Version") -> bool:
            return self._t > other._t
        def __eq__(self, other: object) -> bool:
            return isinstance(other, Version) and self._t == other._t


# ─────────────────────────────────────────────────────────────────

@dataclass
class ReleaseInfo:
    version:      str
    date:         str
    description:  str
    zip_url:      str
    sig_url:      str
    manifest_url: str
    sha256:       str        # sha256 самого zip-файла (быстрая проверка передачи)
    min_python:   str = "3.10"
    channel:      str = "stable"

class OTACheckError(Exception):
    """Ошибка при проверке обновлений (сеть, формат, etc.)."""

def _github_raw_url(repo_url: str, branch: str, path: str) -> str:
    """
    Конвертирует https://github.com/owner/repo → raw URL нужного файла.
    Поддерживает и уже-raw URL (raw.githubusercontent.com) — возвращает как есть.
    """
    repo = repo_url.rstrip("/")
    if "raw.githubusercontent.com" in repo:
        return f"{repo}/{branch}/{path}"
    # https://github.com/owner/repo → https://raw.githubusercontent.com/owner/repo
    repo = repo.replace("https://github.com/", "https://raw.githubusercontent.com/", 1)
    repo = repo.replace("http://github.com/",  "https://raw.githubusercontent.com/", 1)
    return f"{repo}/{branch}/{path}"

def _user_agent() -> str:
    try:
        import core
        return f"AccountManager-OTA/{core.__version__}"
    except Exception:
        return "AccountManager-OTA/unknown"

def fetch_releases_json(ota_repo: str, channel: str, timeout: int = 10) -> dict:
    """
    Скачивает releases.json для нужного канала из OTA-репозитория.
    Бросает OTACheckError при любой ошибке.
    """
    branch = channel.lower()   # "stable" / "beta" / "nightly"
    url = _github_raw_url(ota_repo, branch, "releases.json")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": _user_agent()})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise OTACheckError(f"HTTP {exc.code} при загрузке {url}") from exc
    except urllib.error.URLError as exc:
        raise OTACheckError(f"Сеть недоступна: {exc.reason}") from exc
    except json.JSONDecodeError as exc:
        raise OTACheckError(f"Невалидный JSON в releases.json: {exc}") from exc
    if not isinstance(data, dict):
        raise OTACheckError("releases.json должен быть JSON-объектом.")
    return data

def parse_releases(data: dict, ota_repo: str, channel: str) -> list[ReleaseInfo]:
    """Парсит список релизов из releases.json."""
    raw_list = data.get("releases", [])
    if not isinstance(raw_list, list):
        raise OTACheckError("releases.json → releases должен быть массивом.")
    result: list[ReleaseInfo] = []
    branch = channel.lower()
    for entry in raw_list:
        if not isinstance(entry, dict):
            continue
        ver = str(entry.get("version", "")).strip()
        if not ver:
            continue
        # URL-ы могут быть абсолютными или указаны как относительный путь
        def _url(key: str, default_path: str) -> str:
            v = str(entry.get(key, "")).strip()
            if v.startswith("http"):
                return v
            return _github_raw_url(ota_repo, branch, default_path)

        result.append(ReleaseInfo(
            version=ver,
            date=str(entry.get("date", "")),
            description=str(entry.get("description", "")),
            zip_url=_url("zip_url", f"releases/{ver}/framework.zip"),
            sig_url=_url("sig_url", f"releases/{ver}/framework.zip.sig"),
            manifest_url=_url("manifest_url", f"releases/{ver}/manifest_core.json"),
            sha256=str(entry.get("sha256", "")).strip().lower(),
            min_python=str(entry.get("min_python", "3.10")),
            channel=branch,
        ))
    return result

def get_latest_release(releases: list[ReleaseInfo]) -> Optional[ReleaseInfo]:
    """Наибольшая версия из списка."""
    if not releases:
        return None
    try:
        return max(releases, key=lambda r: Version(r.version))
    except Exception:
        return releases[-1]

def check_python_compat(release: ReleaseInfo) -> bool:
    """True если текущий Python >= release.min_python."""
    try:
        min_ver = tuple(int(x) for x in release.min_python.split(".")[:2])
        return sys.version_info[:2] >= min_ver
    except (ValueError, TypeError):
        return True

def check_for_update(
    current_version: str,
    ota_repo: str,
    channel: str,
    timeout: int = 10,
) -> tuple[bool, Optional[ReleaseInfo], str]:
    """
    Полная проверка наличия обновления.

    Returns:
        (has_update, release_info, message)
        has_update  — True если доступна более новая версия
        release_info— ReleaseInfo или None
        message     — человекочитаемый статус
    """
    if not ota_repo.strip():
        return False, None, "ota_repository не задан в manifest_core.json."

    try:
        data     = fetch_releases_json(ota_repo, channel, timeout)
        releases = parse_releases(data, ota_repo, channel)
    except OTACheckError as exc:
        return False, None, f"Ошибка проверки: {exc}"

    if not releases:
        return False, None, f"Канал {channel}: нет ни одного релиза."

    latest = get_latest_release(releases)
    if latest is None:
        return False, None, "Не удалось определить последнюю версию."

    try:
        is_newer = Version(latest.version) > Version(current_version)
    except Exception:
        is_newer = latest.version != current_version

    if not is_newer:
        return False, latest, f"Вы используете актуальную версию {current_version}."

    if not check_python_compat(latest):
        msg = (
            f"Версия {latest.version} требует Python >= {latest.min_python}, "
            f"текущий {sys.version.split()[0]}. Обновление недоступно."
        )
        return False, latest, msg

    return True, latest, (
        f"Доступна новая версия {latest.version} (текущая: {current_version}).\n"
        f"  Канал: {channel}   Дата: {latest.date}\n"
        f"  {latest.description}"
    )
