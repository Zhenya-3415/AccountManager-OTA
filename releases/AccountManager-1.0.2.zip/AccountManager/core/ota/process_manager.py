"""
core/ota/process_manager.py — кросс-платформенный перезапуск фреймворка.

Поддерживаемые среды (в порядке auto-детекта):
  Termux   — plain (nohup-аналог через start_new_session=True)
  systemctl— systemctl restart <unit_name>
  supervisor— supervisorctl restart <name>
  plain    — subprocess.Popen с detach

Windows: subprocess с DETACHED_PROCESS + CREATE_NEW_PROCESS_GROUP.
POSIX:   start_new_session=True (аналог nohup).

Модуль намеренно не зависит от psutil или других тяжёлых библиотек.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Optional


# ── Детекция среды ───────────────────────────────────────────────

def is_termux() -> bool:
    """True если запущены в Termux (Android)."""
    prefix = os.environ.get("PREFIX", "")
    return "com.termux" in prefix or os.path.isdir("/data/data/com.termux")


def _cmd_exists(name: str) -> bool:
    """True если команда доступна в PATH."""
    import shutil
    return shutil.which(name) is not None


def _systemd_running() -> bool:
    """True если systemd запущен как PID 1 (Linux, не контейнер)."""
    try:
        with open("/proc/1/comm") as f:
            return f.read().strip() == "systemd"
    except OSError:
        return False


def detect_manager(override: str = "auto") -> str:
    """
    Определяет менеджер процессов.
    override: "auto" | "systemctl" | "supervisor" | "plain"
    """
    if override != "auto":
        return override

    if is_termux() or sys.platform == "win32":
        return "plain"

    if _cmd_exists("systemctl") and _systemd_running():
        return "systemctl"

    if _cmd_exists("supervisorctl"):
        return "supervisor"

    return "plain"


# ── Остановка / запуск ────────────────────────────────────────────

def _run(cmd: list[str], check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, check=check, capture_output=True, text=True)


def stop_slot_a(
    manager: str = "auto",
    unit_name: str = "accountmanager",
    supervisor_name: str = "accountmanager",
) -> str:
    """
    Останавливает текущий (A) процесс.
    Возвращает человекочитаемый результат.
    """
    mgr = detect_manager(manager)

    if mgr == "systemctl":
        res = _run(["systemctl", "stop", unit_name], check=False)
        if res.returncode == 0:
            return f"systemctl stop {unit_name}: OK"
        return f"systemctl stop {unit_name}: код {res.returncode}, {res.stderr.strip()}"

    if mgr == "supervisor":
        res = _run(["supervisorctl", "stop", supervisor_name], check=False)
        return f"supervisorctl stop {supervisor_name}: код {res.returncode}"

    # plain — ищем control.json и убиваем по PID
    return _kill_by_control_json()


def start_slot_a(
    slot_a_dir: Optional[Path] = None,
    manager: str = "auto",
    unit_name: str = "accountmanager",
    supervisor_name: str = "accountmanager",
) -> str:
    """
    Запускает слот A после промоута.
    slot_a_dir нужен только для plain-режима.
    """
    mgr = detect_manager(manager)

    if mgr == "systemctl":
        res = _run(["systemctl", "start", unit_name], check=False)
        if res.returncode == 0:
            return f"systemctl start {unit_name}: OK"
        return f"systemctl start {unit_name}: код {res.returncode}, {res.stderr.strip()}"

    if mgr == "supervisor":
        res = _run(["supervisorctl", "start", supervisor_name], check=False)
        return f"supervisorctl start {supervisor_name}: код {res.returncode}"

    # plain — запускаем main.py из slots/a/ (или текущей директории)
    root = slot_a_dir or Path("slots") / "a"
    return _start_plain(root)


def restart_slot_a(
    slot_a_dir: Optional[Path] = None,
    manager: str = "auto",
    unit_name: str = "accountmanager",
    supervisor_name: str = "accountmanager",
) -> str:
    """Перезапуск слота A (используется после interrupt-промоута)."""
    mgr = detect_manager(manager)

    if mgr == "systemctl":
        res = _run(["systemctl", "restart", unit_name], check=False)
        if res.returncode == 0:
            return f"systemctl restart {unit_name}: OK"
        return f"systemctl restart {unit_name}: код {res.returncode}, {res.stderr.strip()}"

    if mgr == "supervisor":
        res = _run(["supervisorctl", "restart", supervisor_name], check=False)
        return f"supervisorctl restart {supervisor_name}: код {res.returncode}"

    root = slot_a_dir or Path("slots") / "a"
    _kill_by_control_json()
    return _start_plain(root)


# ── Запуск слота B ────────────────────────────────────────────────

def start_slot_b(
    slot_b_dir: Path,
    extra_env: Optional[dict] = None,
) -> "subprocess.Popen[bytes]":
    """
    Запускает main.py в слоте B как изолированный дочерний процесс.
    CWD = slot_b_dir → все относительные пути в коде слота B
    (configs/.env, database/, run/control.json, ...) резолвятся
    в директорию слота автоматически.

    Возвращает Popen-объект — вызывающий код (.poll()) мониторит его.
    """
    env = {**os.environ, **(extra_env or {})}
    main_py = slot_b_dir / "main.py"

    kwargs: dict = dict(
        args=[sys.executable, str(main_py)],
        cwd=str(slot_b_dir),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    if sys.platform == "win32":
        # Отсоединяем от консоли родителя, но остаёмся в группе процессов
        # менеджера чтобы poll() работал
        kwargs["creationflags"] = (
            subprocess.CREATE_NEW_PROCESS_GROUP
        )
    else:
        # start_new_session=True — слот B в отдельной сессии,
        # не получит SIGINT от Ctrl+C в терминале менеджера
        kwargs["start_new_session"] = True

    return subprocess.Popen(**kwargs)


# ── Вспомогательное ──────────────────────────────────────────────

def _kill_by_control_json(control_json: Path = Path("run/control.json")) -> str:
    """Читает run/control.json и отправляет SIGTERM (POSIX) или TerminateProcess (Windows)."""
    if not control_json.exists():
        return "run/control.json не найден — процесс уже остановлен или не запускался через main.py."
    try:
        import json
        data = json.loads(control_json.read_text(encoding="utf-8"))
        pid  = int(data.get("pid", 0))
        if not pid:
            return "run/control.json: pid не найден."
        if sys.platform == "win32":
            _run(["taskkill", "/PID", str(pid), "/F"], check=False)
        else:
            os.kill(pid, __import__("signal").SIGTERM)
        return f"Отправлен SIGTERM → pid {pid}."
    except (OSError, ValueError, KeyError) as exc:
        return f"Не удалось остановить процесс: {exc}"


def _start_plain(root: Path) -> str:
    """Запускает main.py в фоне без systemd/supervisor."""
    main_py = root / "main.py"
    if not main_py.exists():
        return f"{main_py} не найден."

    kwargs: dict = dict(
        args=[sys.executable, str(main_py)],
        cwd=str(root),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if sys.platform == "win32":
        kwargs["creationflags"] = (
            subprocess.DETACHED_PROCESS
            | subprocess.CREATE_NEW_PROCESS_GROUP
        )
    else:
        kwargs["start_new_session"] = True

    proc = subprocess.Popen(**kwargs)
    return f"Запущен plain: pid {proc.pid}, CWD={root}"
