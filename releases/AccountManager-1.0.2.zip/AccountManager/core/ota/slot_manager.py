"""
core/ota/slot_manager.py — управление A/B слотами и состоянием OTA.

Структура на диске (PROJECT_ROOT):
  slots/
    a/           — активный слот (всегда = текущая боевая версия)
    b/           — тестовый слот (заполняется при OTA)
    ota_state.json

Записи в ota_state.json атомарные (write→rename) — защита от
обрезанных файлов при сбое питания/kill.  На POSIX os.replace()
атомарен; на Windows — best-effort (NTFS транзакции недоступны без
WinAPI, но rename на одном томе де-факто атомарен с Vista+).

Состояния (status):
  idle               — ничего не происходит
  downloading        — идёт скачивание framework.zip
  verifying          — Ed25519 + sha256 + verify_build_integrity
  testing            — слот B запущен, мониторим краши
  ready_to_promote   — тест прошёл, ждём решения
  pending_promote    — "применить при следующем shutdown"
  promoting          — активный промоут (interrupt mode)
  promoting_on_shutdown — применяем в shutdown-хуке main.py
  rolled_back        — откат выполнен (до след. попытки)
  failed             — верификация/скачивание провалились
"""
from __future__ import annotations

import json
import os
import shutil
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

SLOTS_DIR      = Path("slots")
SLOT_A_DIR     = SLOTS_DIR / "a"
SLOT_B_DIR     = SLOTS_DIR / "b"
OTA_STATE_PATH = SLOTS_DIR / "ota_state.json"

# Файлы/папки, копируемые в слот — должны покрывать всё что входит в sha256_hash.
# _SLOT_DIRS="plugins" включает plugins/base.py целиком (не нужен отдельной строкой).
# manifest.py::HASHED_SINGLE_FILES перечисляет plugins/base.py явно только потому, что
# hashing обходит дерево иначе — здесь копируется вся папка, результат тот же.
_SLOT_DIRS  = ("core", "plugins")
_SLOT_FILES = ("main.py", "framework_manager.py", "manifest_core.json")

VALID_STATUSES = frozenset({
    "idle", "downloading", "verifying", "testing",
    "ready_to_promote", "pending_promote",
    "promoting", "promoting_on_shutdown",
    "rolled_back", "failed",
})


@dataclass
class OTAState:
    active_slot:     str            = "a"
    pending_slot:    Optional[str]  = None
    pending_version: Optional[str]  = None
    test_started_at: Optional[str]  = None   # ISO-8601 UTC
    crash_count:     int            = 0
    # max_crashes и test_duration_s намеренно отсутствуют: они всегда
    # читаются из config.json → ota.*, а не из state, чтобы изменение
    # конфига применялось немедленно без пересоздания state.
    status:          str            = "idle"
    last_error:      Optional[str]  = None
    promoted_at:     Optional[str]  = None
    rolled_back_at:  Optional[str]  = None


# ── I/O ──────────────────────────────────────────────────────────

def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_state() -> OTAState:
    if not OTA_STATE_PATH.exists():
        return OTAState()
    try:
        raw = json.loads(OTA_STATE_PATH.read_text(encoding="utf-8"))
        s = OTAState()
        for k, v in raw.items():
            if hasattr(s, k):
                setattr(s, k, v)
        return s
    except (json.JSONDecodeError, OSError):
        return OTAState()


def save_state(state: OTAState) -> None:
    SLOTS_DIR.mkdir(parents=True, exist_ok=True)
    tmp = OTA_STATE_PATH.with_suffix(".tmp")
    tmp.write_text(
        json.dumps(asdict(state), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    os.replace(tmp, OTA_STATE_PATH)


def set_status(status: str, **extra) -> OTAState:
    """Загружает, обновляет status + extra поля, сохраняет, возвращает."""
    if status not in VALID_STATUSES:
        raise ValueError(f"Неизвестный OTA-статус: {status!r}. Допустимые: {sorted(VALID_STATUSES)}")
    state = load_state()
    state.status = status
    for k, v in extra.items():
        if hasattr(state, k):
            setattr(state, k, v)
    save_state(state)
    return state


# ── Слот-операции ────────────────────────────────────────────────

def _copy_to_slot(src_root: Path, dst_slot: Path) -> None:
    """
    Копирует «сборку» (core/, plugins/, main.py, framework_manager.py,
    manifest_core.json) из src_root в dst_slot.
    configs/ НЕ копируется — у каждого слота свои токены/конфиги.
    """
    dst_slot.mkdir(parents=True, exist_ok=True)

    for d in _SLOT_DIRS:
        src = src_root / d
        dst = dst_slot / d
        if src.is_dir():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))

    for f in _SLOT_FILES:
        src = src_root / f
        if src.is_file():
            shutil.copy2(src, dst_slot / f)


def init_slots(project_root: Optional[Path] = None) -> None:
    """
    Первичная инициализация: копирует текущие файлы в slots/a/.
    Вызывается один раз при «python framework_manager.py ota --init-slots».
    slots/a/configs/ создаётся пустой — администратор должен скопировать
    туда configs/.env (или symlink).
    """
    root = project_root or Path(".")
    SLOT_A_DIR.mkdir(parents=True, exist_ok=True)
    (SLOT_A_DIR / "configs").mkdir(exist_ok=True)
    (SLOT_A_DIR / "database").mkdir(exist_ok=True)
    (SLOT_A_DIR / "logs").mkdir(exist_ok=True)
    (SLOT_A_DIR / "run").mkdir(exist_ok=True)

    _copy_to_slot(root, SLOT_A_DIR)

    if not OTA_STATE_PATH.exists():
        save_state(OTAState())


def prepare_slot_b(
    unpacked_dir: Path,
    version: str,
    bot_token_test: str,
    main_config_json: Optional[dict] = None,
    production_root: Optional[Path] = None,
) -> None:
    """
    Готовит слот B из распакованного OTA-архива:

      1. Копирует ядро (core/, main.py, framework_manager.py, manifest_core.json,
         plugins/base.py) из распакованного OTA-архива.
      2. Копирует ПОЛЬЗОВАТЕЛЬСКИЕ плагины (все подпапки plugins/*/) из
         production_root (обычно PROJECT_ROOT). Это ключевой момент: тест
         должен воспроизводить реальную конфигурацию после промоута, т.е.
         «новое ядро + текущие плагины пользователя», а не «голое ядро».
         plugins/base.py в этом шаге НЕ перезаписывается — он уже взят из
         OTA-архива (новая версия контракта плагина).
      3. Создаёт slots/b/configs/.env с BOT_TOKEN=<test_token>.
      4. Копирует config.json, если передан.

    production_root по умолчанию — Path(".") (CWD при запуске framework_manager.py,
    то есть корень проекта, где лежат боевые plugins/).
    """
    root = production_root or Path(".")

    SLOT_B_DIR.mkdir(parents=True, exist_ok=True)
    for d in ("configs", "database", "logs", "run"):
        (SLOT_B_DIR / d).mkdir(exist_ok=True)

    # Шаг 1: новое ядро из OTA-архива (включает plugins/base.py новой версии)
    _copy_to_slot(unpacked_dir, SLOT_B_DIR)

    # Шаг 2: пользовательские плагины из production_root/plugins/
    # Копируем только директории (каждый плагин — отдельная папка).
    # plugins/base.py уже на месте из шага 1, его не трогаем.
    prod_plugins = root / "plugins"
    slot_b_plugins = SLOT_B_DIR / "plugins"
    slot_b_plugins.mkdir(exist_ok=True)
    if prod_plugins.is_dir():
        for item in prod_plugins.iterdir():
            if item.is_dir():
                dst = slot_b_plugins / item.name
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(
                    item, dst,
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
                )

    # Шаг 3: .env для слота B — только тестовый токен
    (SLOT_B_DIR / "configs" / ".env").write_text(
        f"BOT_TOKEN={bot_token_test}\n", encoding="utf-8"
    )

    # Шаг 4: config.json, если передан явно
    if main_config_json:
        (SLOT_B_DIR / "configs" / "config.json").write_text(
            json.dumps(main_config_json, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    set_status("testing",
               pending_slot="b",
               pending_version=version,
               test_started_at=_now_utc(),
               crash_count=0)


def promote_b_to_a(project_root: Optional[Path] = None) -> str:
    """
    Промоут: перезаписывает слот A файлами из слота B.
    Вызывается либо немедленно (interrupt mode), либо из apply_pending_if_any().
    """
    root = project_root or Path(".")

    if not SLOT_B_DIR.exists():
        raise FileNotFoundError(f"Слот B не найден: {SLOT_B_DIR.resolve()}")

    # Обновляем slots/a/
    _copy_to_slot(SLOT_B_DIR, SLOT_A_DIR)

    # Обновляем сам PROJECT_ROOT (боевые файлы)
    _copy_to_slot(SLOT_B_DIR, root)

    version = load_state().pending_version or "?"
    set_status("idle",
               active_slot="a",
               pending_slot=None,
               pending_version=None,
               test_started_at=None,
               crash_count=0,
               promoted_at=_now_utc(),
               last_error=None)

    return version


def rollback(reason: str = "") -> None:
    """Откат: слот B останавливается вышестоящим кодом, здесь — только state."""
    set_status("rolled_back",
               pending_slot=None,
               pending_version=None,
               test_started_at=None,
               rolled_back_at=_now_utc(),
               last_error=reason or None)


# ── Shutdown-хук (вызывается из main.py) ─────────────────────────

def apply_pending_if_any(project_root: Optional[Path] = None) -> bool:
    """
    Вызывается в самом конце graceful shutdown main.py.
    Если status == "pending_promote" — промоутит B→A.
    Возвращает True если промоут был выполнен, False если нечего делать.
    Не бросает — любая ошибка логируется, но не роняет shutdown.
    """
    state = load_state()
    if state.status != "pending_promote":
        return False

    set_status("promoting_on_shutdown")
    try:
        version = promote_b_to_a(project_root)
        _log(f"[OTA] Отложенный промоут выполнен: версия {version} теперь активна в слоте A.")
        return True
    except Exception as exc:  # noqa: BLE001
        err = f"Ошибка при отложенном промоуте: {exc}"
        _log(f"[OTA] ОШИБКА: {err}")
        set_status("failed", last_error=err)
        return False


def _log(msg: str) -> None:
    """Минимальный лог в stdout + logs/ota/ без зависимости от core/logger.py."""
    import datetime as _dt
    ts = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    try:
        log_dir = Path("logs") / "ota"
        log_dir.mkdir(parents=True, exist_ok=True)
        # Один файл в сутки, не один на сессию — OTA-события редкие
        fname = _dt.date.today().strftime("ota-%Y-%m-%d.log")
        with open(log_dir / fname, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass
