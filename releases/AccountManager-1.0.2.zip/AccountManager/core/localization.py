"""
core/localization.py — строки интерфейса Менеджера Фреймворка.

messages/lang/{rus,eng}.ini — активный язык берётся из
configs/settings.json -> language ("rus"/"eng", см. core/settings.py).

Объём: этот модуль покрывает НОВЫЙ слой меню-фреймворка, который
добавляется этой задачей (главное меню, "Информация и состояние",
OTA-заготовка, тесты, экран плагинов, настройки, помощь). Уже
существующий вывод команд status/install/uninstall/lock/unlock/
verify/update (унаследованный от прежнего "Менеджера плагинов",
core/framework_manager.py) остаётся как есть, на русском — перевод ~700
строк устоявшегося и покрытого тестами CLI-вывода на два языка не
входил в объём этой задачи и рискует внести регрессии в код, который
сейчас полностью зелёный (787/787). См. MANIFEST.md.
"""
from __future__ import annotations

import configparser
from pathlib import Path

MESSAGES_DIR = Path("messages")  # не configs/ — это UI-строки, не конфиги
LANG_DIR = MESSAGES_DIR / "lang"
HELP_FILE = MESSAGES_DIR / "help.txt"

FALLBACK_LANG = "rus"

_cache: dict[str, configparser.ConfigParser] = {}


def _lang_path(lang: str) -> Path:
    return LANG_DIR / f"{lang}.ini"


def _load(lang: str) -> configparser.ConfigParser:
    if lang in _cache:
        return _cache[lang]
    parser = configparser.ConfigParser(interpolation=None)
    path = _lang_path(lang)
    if path.exists():
        # utf-8-sig на случай файла, сохранённого с BOM (частый случай
        # для .ini на Windows) — configparser иначе включит \ufeff в
        # имя первой секции, и она перестанет находиться по имени.
        parser.read(path, encoding="utf-8-sig")
    _cache[lang] = parser
    return parser


def clear_cache() -> None:
    """Сбрасывает закэшированные .ini — для тестов и для settings-экрана сразу после смены языка."""
    _cache.clear()


def t(section: str, key: str, lang: str = FALLBACK_LANG, **fmt: object) -> str:
    """
    Строка `key` из секции `section` для языка `lang`.

    Порядок разрешения: запрошенный язык -> FALLBACK_LANG -> сам ключ
    "section.key" (заметно как недостающий перевод в интерфейсе, но
    никогда не бросает исключение и не роняет экран).

    **fmt подставляется через str.format(**fmt), если в строке есть
    {плейсхолдеры}; строка без них просто возвращается как есть.
    """
    value = _lookup(lang, section, key)
    if value is None and lang != FALLBACK_LANG:
        value = _lookup(FALLBACK_LANG, section, key)
    if value is None:
        value = f"{section}.{key}"
    if fmt:
        try:
            return value.format(**fmt)
        except (KeyError, IndexError):
            return value
    return value


def _lookup(lang: str, section: str, key: str) -> str | None:
    parser = _load(lang)
    if not parser.has_section(section):
        return None
    return parser.get(section, key, fallback=None)


def read_help_text() -> str:
    """Содержимое messages/help.txt — пункт «Помощь по использованию/техподдержка»."""
    if not HELP_FILE.exists():
        return "Файл справки messages/help.txt не найден."
    return HELP_FILE.read_text(encoding="utf-8")
