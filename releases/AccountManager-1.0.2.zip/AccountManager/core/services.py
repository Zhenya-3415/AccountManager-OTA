"""
core/services.py — реестр сервисов (ServiceRegistry).

Механизм, которым один плагин предоставляет свой Python-API другим
плагинам, не создавая прямых импортов друг на друга (антиspam не
должен импортировать конкретный класс из другого плагина, чтобы им
воспользоваться — это ломало бы независимую загрузку/выключение).

Плагин публикует что угодно — функцию, объект, датакласс — под
строковым именем:

    ctx.provide_service("antispam.is_blacklisted", is_blacklisted_fn)

Другой плагин (объявивший зависимость от antispam в manifest.json,
чтобы гарантировать порядок загрузки) получает её:

    is_blacklisted = ctx.require_service("antispam.is_blacklisted")

require_service бросает понятную ошибку, если сервис не найден —
в отличие от AttributeError/KeyError на неизвестном месте, сразу
видно, какого сервиса не хватает и какие вообще зарегистрированы.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from core.logger import get_logger

logger = get_logger("services")


class ServiceNotFoundError(LookupError):
    """Сервис с таким именем не зарегистрирован ни одним плагином."""


@dataclass(slots=True)
class _ServiceEntry:
    value: Any
    plugin: str


class ServiceRegistry:
    """Реестр сервисов, общий для всех плагинов процесса."""

    def __init__(self) -> None:
        self._services: dict[str, _ServiceEntry] = {}

    def provide(self, name: str, value: Any, *, plugin: str) -> None:
        """
        Публикует сервис под именем name. Если имя уже занято другим
        плагином — старое значение перезаписывается (последний
        зарегистрировавший побеждает), но факт перезаписи логируется,
        чтобы конфликт имён не остался незамеченным.
        """
        existing = self._services.get(name)
        if existing is not None and existing.plugin != plugin:
            logger.warning(
                f"Сервис «{name}» от плагина «{existing.plugin}» "
                f"переопределён плагином «{plugin}»."
            )
        self._services[name] = _ServiceEntry(value=value, plugin=plugin)
        logger.debug(f"Плагин «{plugin}» опубликовал сервис «{name}».")

    def get(self, name: str) -> Any | None:
        """Возвращает сервис или None, если не найден."""
        entry = self._services.get(name)
        return entry.value if entry is not None else None

    def require(self, name: str) -> Any:
        """Возвращает сервис или бросает ServiceNotFoundError с подсказкой."""
        entry = self._services.get(name)
        if entry is None:
            available = ", ".join(sorted(self._services)) or "нет ни одного"
            raise ServiceNotFoundError(
                f"Сервис «{name}» не найден. Зарегистрированы: {available}."
            )
        return entry.value

    def has(self, name: str) -> bool:
        return name in self._services

    def remove_all_for(self, plugin: str) -> int:
        """Убирает все сервисы данного плагина. Вызывается при teardown/reload."""
        to_remove = [n for n, e in self._services.items() if e.plugin == plugin]
        for n in to_remove:
            del self._services[n]
        if to_remove:
            logger.debug(f"Плагин «{plugin}»: снято {len(to_remove)} сервисов.")
        return len(to_remove)

    def list_services(self) -> dict[str, str]:
        """{имя_сервиса: имя_плагина_владельца} — для диагностики."""
        return {name: entry.plugin for name, entry in self._services.items()}
