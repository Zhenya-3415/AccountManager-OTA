"""
core/database.py — обратно-совместимый шим.

До появления Postgres-бэкенда весь код БД жил прямо в этом модуле как
единственный класс `Database` поверх aiosqlite. Теперь есть два
бэкенда (core/db/sqlite_backend.py, core/db/postgres_backend.py) за
общим контрактом core/db/base.py:BaseDatabase, выбираемые фабрикой
core/db/factory.py:create_database() по config.json → database.backend.

Старый код (`from core.database import Database`, `Database(path)`)
продолжает работать без изменений — `Database` здесь алиас на
SQLiteDatabase, поведение идентично тому, что было раньше, когда
Postgres-бэкенда не существовало. Новый код (main.py, plugin_loader.py)
использует create_database()/BaseDatabase напрямую из core.db —
см. PLUGIN_API.md.
"""
from __future__ import annotations

from core.db.base import BaseDatabase
from core.db.factory import create_database
from core.db.migrations import resolve_migration_dir, split_sql_statements
from core.db.sqlite_backend import DB_PATH, SQLiteDatabase

# Алиас ради обратной совместимости — раньше это был единственный класс.
Database = SQLiteDatabase

__all__ = [
    "BaseDatabase",
    "Database",
    "SQLiteDatabase",
    "DB_PATH",
    "create_database",
    "resolve_migration_dir",
    "split_sql_statements",
]
