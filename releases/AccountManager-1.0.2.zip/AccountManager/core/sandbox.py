"""
core/sandbox.py — мягкая изоляция плагинов.

Две защиты, которые работают без переписывания plugin API:

1. БЛОКИРОВКА ОПАСНЫХ ОПЕРАЦИЙ
   ─────────────────────────────
   a) sys.addaudithook — блокирует системные вызовы через Python audit events:
      subprocess.Popen, os.system, os.execve, os.popen.
      Плагин не может запустить внешний процесс.
      НЕОБРАТИМО: хук живёт до конца процесса (Python ограничение).
      Устанавливается ОДИН РАЗ в main.py перед загрузкой плагинов.

   b) importlib meta finder — блокирует импорт ctypes, pty, pexpect.
      Устанавливается первым в sys.meta_path.

2. ТАЙМАУТ ХЕНДЛЕРА
   ──────────────────
   PluginHandlerTimeoutMiddleware регистрируется на dp.update.outer_middleware
   ПОСЛЕ UserUpsertMiddleware. asyncio.wait_for отменяет завязший хендлер
   через handler_timeout_s секунд — бот продолжает работать.

Что НЕ делает эта sandbox:
  - Не изолирует память между плагинами (общий процесс).
  - Не блокирует доступ к файловой системе.
  - Не ограничивает сеть (socket доступен — aiogram тоже его использует).
  - Не блокирует threading/asyncio.
Это осознанно: полная изоляция требует переписывания всего plugin API.

Настройки: config.json → sandbox.*  (core/config.py::SandboxConfig).
"""
from __future__ import annotations

import asyncio
import builtins
import sys
from typing import Optional

# ── Модули, полностью запрещённые для плагинов ───────────────────
# Только то, для чего нет ни одного легитимного use-case в Telegram-боте
# и что даёт прямой доступ к нативному коду/shell.
# socket намеренно НЕ блокируется — aiogram его использует.
_ALWAYS_BLOCKED_MODULES: frozenset[str] = frozenset({
    "ctypes",       # прямой вызов нативных C-библиотек
    "ctypes.util",
    "_ctypes",      # внутренний модуль ctypes
    "pty",          # псевдотерминал — нет смысла в боте
    "pexpect",      # автоматизация терминала
    "winreg",       # реестр Windows
    "msilib",       # Windows installer
})

# ── Audit events для блокировки (sys.addaudithook) ───────────────
# Имена verified на Python 3.12 (core/sandbox.py запуском audit-capture).
_BLOCKED_AUDIT_EVENTS: frozenset[str] = frozenset({
    "subprocess.Popen",   # subprocess.run / check_call / Popen / ...
    "os.system",          # os.system("rm -rf /")
    "os.popen",           # os.popen("cmd")
    "os.execve",          # замена текущего процесса (exec-семейство)
    "os.execvp",
    "os.execl",
    "os.execle",
    "os.execlp",
    "os.execlpe",
    "os.execvpe",
    "os.spawnl",
    "os.spawnle",
    "os.spawnlp",
    "os.spawnlpe",
    "os.spawnv",
    "os.spawnve",
    "os.spawnvp",
    "os.spawnvpe",
})

# ── Глобальные флаги: устанавливались ли хуки ─────────────────────
_audit_hook_installed: bool = False
_import_finder_installed: bool = False
_original_import = builtins.__import__


# ═════════════════════════════════════════════════════════════════
# 1. Блокировка системных вызовов
# ═════════════════════════════════════════════════════════════════

def install_audit_hooks(extra_blocked: Optional[frozenset[str]] = None) -> None:
    """
    Устанавливает sys.addaudithook, блокирующий shell/exec-операции.

    ВАЖНО: вызывать только из main.py, один раз, до load_plugins().
    Хук необратим — он не может быть снят (ограничение Python).
    После установки subprocess.Popen/os.system и т.п. поднимут
    PermissionError в любой части процесса, включая core.
    Поэтому core должен выполнять все subprocess-операции в
    framework_manager.py (отдельный процесс), а не в main.py.
    """
    global _audit_hook_installed
    if _audit_hook_installed:
        return

    blocked = _BLOCKED_AUDIT_EVENTS | (extra_blocked or frozenset())

    def _hook(event: str, _args: tuple) -> None:
        if event in blocked:
            raise PermissionError(
                f"Операция '{event}' заблокирована политикой безопасности "
                f"фреймворка. Плагины не могут выполнять системные команды."
            )

    sys.addaudithook(_hook)
    _audit_hook_installed = True


def install_import_restrictions(
    extra_blocked: Optional[frozenset[str]] = None,
) -> None:
    """
    Блокирует импорт опасных модулей через importlib meta finder.
    Finder вставляется ПЕРВЫМ в sys.meta_path — проверяется до
    стандартных фильтров.
    """
    global _import_finder_installed
    if _import_finder_installed:
        return

    blocked = _ALWAYS_BLOCKED_MODULES | (extra_blocked or frozenset())

    def _restricted_import(name, globals=None, locals=None, fromlist=(), level=0):
        # meta_path-finder не вызывается для модулей, уже находящихся в
        # sys.modules. Проверяем имя и здесь, иначе предварительно
        # импортированный ctypes/pty становился обходом sandbox.
        if level == 0 and (name in blocked or name.split(".")[0] in blocked):
            raise ImportError(
                f"Модуль '{name}' заблокирован политикой безопасности "
                "AccountManager Framework."
            )
        return _original_import(name, globals, locals, fromlist, level)

    builtins.__import__ = _restricted_import

    # Удаляем только запрещённые модули, уже загруженные до установки
    # sandbox: следующий импорт попадёт под finder/import-hook. Это
    # выполняется после инициализации core в main.py, поэтому core не
    # полагается на эти модули после границы загрузки плагинов.
    for module_name in tuple(sys.modules):
        if module_name in blocked or module_name.split(".")[0] in blocked:
            sys.modules.pop(module_name, None)

    class _BlockedImportFinder:
        def find_module(self, fullname: str, path=None):  # type: ignore[override]
            # Проверяем и полное имя ("ctypes.util") и базовый пакет ("ctypes")
            if fullname in blocked or fullname.split(".")[0] in blocked:
                return self

        def load_module(self, fullname: str):  # type: ignore[override]
            raise ImportError(
                f"Модуль '{fullname}' заблокирован политикой безопасности "
                f"AccountManager Framework. Обратитесь к администратору, "
                f"если этот модуль необходим для легитимной работы плагина."
            )

    sys.meta_path.insert(0, _BlockedImportFinder())
    _import_finder_installed = True


# ═════════════════════════════════════════════════════════════════
# 2. Таймаут хендлера
# ═════════════════════════════════════════════════════════════════

def make_timeout_middleware(timeout_s: float):
    """
    Фабрика: возвращает outer_middleware-класс с нужным таймаутом.

    Регистрировать ПОСЛЕ UserUpsertMiddleware в main.py:
        dp.update.outer_middleware(UserUpsertMiddleware(db, hooks))
        dp.update.outer_middleware(make_timeout_middleware(30.0)())

    Если хендлер завис — asyncio.wait_for отменяет его корутину через
    timeout_s секунд. Бот продолжает принимать апдейты. Ошибка
    логируется, апдейт считается обработанным (return None).

    Логика wait_for вынесена в _apply_timeout и работает независимо
    от наличия aiogram (тесты без aiogram тоже проверяют таймаут).
    Нет asyncio.shield: завязший хендлер ОТМЕНЯЕТСЯ.
    """
    from core.logger import get_logger
    _log = get_logger("sandbox")

    async def _apply_timeout(handler, event, data):
        try:
            return await asyncio.wait_for(
                handler(event, data),
                timeout=timeout_s,
            )
        except asyncio.TimeoutError:
            event_name = type(event).__name__
            _log.error(
                f"Хендлер завис и был отменён "
                f"(таймаут {timeout_s}s, тип апдейта: {event_name}). "
                f"Проверьте плагин на бесконечные циклы или блокирующие вызовы."
            )
            return None

    try:
        from aiogram import BaseMiddleware

        class _TimeoutMiddleware(BaseMiddleware):  # type: ignore[misc]
            async def __call__(self, handler, event, data):
                return await _apply_timeout(handler, event, data)

        return _TimeoutMiddleware

    except ImportError:
        # Тесты без установленного aiogram — используем plain класс.
        # Таймаут работает так же через общий _apply_timeout.
        class _TimeoutMiddlewareFallback:  # type: ignore[no-redef]
            async def __call__(self, handler, event, data):
                return await _apply_timeout(handler, event, data)

        return _TimeoutMiddlewareFallback


# ═════════════════════════════════════════════════════════════════
# Удобная точка входа для main.py
# ═════════════════════════════════════════════════════════════════

def apply_sandbox(config) -> None:
    """
    Устанавливает все защиты на основе config.sandbox.
    Вызывается из main.py после load_config() и до load_plugins().

    config — объект core.config.Config.
    """
    sb = config.sandbox
    if not sb.enabled:
        return

    extra = frozenset(sb.extra_blocked_modules) if sb.extra_blocked_modules else None

    if sb.block_system_calls:
        install_audit_hooks(extra_blocked=extra)
        install_import_restrictions(extra_blocked=extra)
