"""
core/bootstrap.py — предстартовые проверки.

Запускается до логгера и бота. Пишет только в
  logs/bootstrap/bootstrap-YYYY-MM-DD-HH-MM-SS.log
и в stdout.

При любой ошибке — sys.exit(1).

── manifest_core.json и sha256_hash ─────────────────────────────────
С этой версии сюда же добавлена проверка манифеста сборки
(core/manifest.py): manifest_core.json обязан существовать, быть
валидным JSON-объектом И иметь sha256_hash, совпадающий с реально
вычисленным хэшем текущих core/main.py/framework_manager.py/plugins/base.py
(см. core/manifest.py::verify_build_integrity). Без этого — sys.exit(1),
ровно как и для остальных проверок в этом модуле: "без валидного
манифеста и хэша использование сборки недоступно" — осознанное решение
по ТЗ, а не недосмотр. Единственный штатный обход — configs/settings.json
-> disable_signature_and_hash_check (core/settings.py), доступный из
экрана "Для разработчиков" в framework_manager.py; при включённом обходе
несовпадение хэша попадает в лог как WARNING, а не как фатальная ошибка.
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from pathlib import Path

from core.config import CONFIG_PATH, ENV_PATH
from core.manifest import MANIFEST_PATH, ManifestError, load_manifest, verify_build_integrity
from core.settings import load_settings

# Папки, которые bootstrap создаёт сам если их нет
_AUTO_DIRS: list[Path] = [
    Path("database"),
    Path("database/migrations"),
    Path("logs"),
    Path("logs/bootstrap"),
    Path("plugins"),
    Path("configs"),
]

# Файлы, которые должны существовать (НЕ создаём)
_REQUIRED_FILES: list[Path] = [
    ENV_PATH,
    Path("plugins/base.py"),
    MANIFEST_PATH,
]

# config.json — НЕ в _REQUIRED_FILES: core/config.py и без него
# спокойно работает на дефолтах (log_level="DEBUG", disabled_plugins=[]).
# Если файл всё же есть — он должен быть валидным JSON (проверяется ниже).

# Директории, на которые нужны права R+W
_RW_DIRS: list[Path] = [
    Path("database"),
    Path("logs"),
    Path("plugins"),
]

# Файлы, на которые нужно право чтения
_R_FILES: list[Path] = [
    ENV_PATH,
    CONFIG_PATH,
    MANIFEST_PATH,
]


def run_bootstrap() -> None:
    """
    Выполняет все предстартовые проверки.
    Не возвращает ничего при успехе.
    Завершает процесс с кодом 1 при любой ошибке.
    """
    now = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")

    # Лог-директорию создаём безусловно — она нужна для записи. Если
    # именно ЭТО не получается, логировать уже физически некуда:
    # печатаем прямо в stderr и выходим с тем же кодом 1, что и любая
    # другая фатальная ошибка bootstrap, вместо необработанного OSError
    # наружу (раньше только цикл по остальным _AUTO_DIRS ниже был
    # обёрнут в try/except — эта самая первая директория, от которой
    # зависит вообще всё остальное логирование, не была).
    bootstrap_dir = Path("logs/bootstrap")
    try:
        bootstrap_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        print(
            f"[BOOTSTRAP ERROR] Не удалось создать директорию {bootstrap_dir}/: {exc}",
            file=sys.stderr, flush=True,
        )
        sys.exit(1)
    log_file = bootstrap_dir / f"bootstrap-{now}.log"

    errors: list[str] = []

    def _write(tag: str, msg: str) -> None:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{ts}] [{tag}] {msg}"
        print(line, flush=True)
        with open(log_file, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")

    def info(msg: str) -> None:
        _write("BOOTSTRAP INFO ", msg)

    def warn(msg: str) -> None:
        _write("BOOTSTRAP WARN ", msg)

    def error(msg: str) -> None:
        errors.append(msg)
        _write("BOOTSTRAP ERROR", msg)

    # ── 1. Создать недостающие директории ────────────────────
    for d in _AUTO_DIRS:
        if not d.exists():
            try:
                d.mkdir(parents=True, exist_ok=True)
                info(f"Создана директория: {d}/")
            except OSError as exc:
                error(f"Не удалось создать директорию {d}/: {exc}")

    # ── 2. Проверить наличие обязательных файлов ─────────────
    for fp in _REQUIRED_FILES:
        if not fp.exists():
            if fp == ENV_PATH:
                error(
                    f"Файл {ENV_PATH} не найден. "
                    f"Создайте его на основе configs/.env.example"
                )
            elif fp == MANIFEST_PATH:
                error(
                    f"Файл {MANIFEST_PATH} не найден — это основной манифест "
                    f"сборки (имя, версия, requirements, sha256_hash). См. MANIFEST.md."
                )
            else:
                error(f"Файл {fp} не найден.")

    if errors:
        sys.exit(1)

    # ── 3. Валидация содержимого файлов ──────────────────────

    # .env должен содержать непустой BOT_TOKEN
    env_text = ENV_PATH.read_text(encoding="utf-8")
    token_value = ""
    for line in env_text.splitlines():
        line = line.strip()
        if line.startswith("BOT_TOKEN="):
            token_value = line.split("=", 1)[1].strip()
            break
    if not token_value:
        error(
            f"Файл {ENV_PATH} не содержит BOT_TOKEN или он пустой. "
            f"Добавьте: BOT_TOKEN=<ваш_токен>"
        )

    # config.json, если присутствует, должен быть валидным JSON
    # (файл необязателен — см. комментарий у _REQUIRED_FILES)
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH, encoding="utf-8") as fh:
                json.load(fh)
        except json.JSONDecodeError as exc:
            error(f"{CONFIG_PATH} содержит невалидный JSON: {exc}")

    # manifest_core.json — обязан быть валидным JSON-объектом И иметь
    # sha256_hash, совпадающий с реально вычисленным (см. докстринг
    # модуля). Обход — только явный settings.disable_signature_and_hash_check,
    # и даже тогда расхождение попадает в лог, просто не как фатальная ошибка.
    try:
        manifest = load_manifest(MANIFEST_PATH)
    except ManifestError as exc:
        error(str(exc))
        manifest = None

    if manifest is not None:
        settings = load_settings()
        integrity = verify_build_integrity(manifest)
        if not integrity.ok:
            if settings.disable_signature_and_hash_check:
                warn(
                    f"Проверка целостности сборки ОТКЛЮЧЕНА (configs/settings.json -> "
                    f"disable_signature_and_hash_check=true). {integrity.reason}"
                )
            else:
                error(integrity.reason)

    if errors:
        sys.exit(1)

    # ── 4. Проверить права доступа ───────────────────────────
    for d in _RW_DIRS:
        if d.exists():
            if not os.access(d, os.R_OK):
                error(f"Нет прав на чтение директории {d}/")
            if not os.access(d, os.W_OK):
                error(f"Нет прав на запись в директорию {d}/")

    for fp in _R_FILES:
        if fp.exists() and not os.access(fp, os.R_OK):
            error(f"Нет прав на чтение файла {fp}")

    if errors:
        sys.exit(1)

    info("Bootstrap завершён успешно.")