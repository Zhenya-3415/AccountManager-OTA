"""
core/manifest.py — чтение manifest_core.json и проверка целостности сборки.

manifest_core.json — единый источник правды о сборке ядра: имя,
описание, версия, канал сборки, авторы, requirements (заменяет удалённые
requirements.txt / requirements-test.txt), ссылки на 3 репозитория
(основной/OTA/плагинов) и sha256_hash. Полный референс полей — MANIFEST.md.

── Импорт этого модуля НИКОГДА не бросает и не завершает процесс ───
В отличие от core/bootstrap.py (который обязан упасть громко, если
что-то не так — это его единственная работа), простой факт импорта
core.manifest (а транзитивно — импорта core/__init__.py, который читает
отсюда __version__) не должен ронять процесс только из-за того, что
manifest_core.json ещё не создан или испорчен. Это критично для tests/:
весь пакет core импортируется один раз на процесс `unittest discover`,
и происходит это ДО того, как отдельные тесты успевают подготовить
себе рабочую директорию — падение здесь уронило бы вообще все тесты
проекта, а не только те, что реально проверяют манифест.

Поэтому "манифеста нет / он битый" — это ДВЕ разные ситуации:
  - load_manifest() бросает ManifestError — для кода, которому
    правда нужны реальные данные (экран информации о фреймворке,
    команды install/update, hash generate/verify).
  - core/__init__.py ловит эту ошибку сам и подставляет безопасный
    плейсхолдер вместо version (см. его докстринг) — __version__
    обязан остаться валидной PEP 440 строкой при любых обстоятельствах,
    потому что core/dependencies.py целиком строится на packaging.version.Version(...).

Жёсткая проверка "без валидной сборки ничего не работает" (по просьбе
из ТЗ) — не здесь, а в core/bootstrap.py:run_bootstrap(), который и
раньше был тем местом, где любая проблема = sys.exit(1) ДО того, как
поднимется бот. Те же load_manifest()/verify_build_integrity() из этого
модуля там просто вызываются явно — см. bootstrap.py.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

MANIFEST_PATH = Path("manifest_core.json")

# Плейсхолдер для display() — единообразный текст вместо пустых/отсутствующих
# полей на экранах "Посмотреть информацию и состояние" и т.п.
UNKNOWN = "неизвестно"

# Каналы сборки, которые понимает менеджер (manifest_core.json -> build_channel
# И configs/settings.json -> build_channel — второе см. в core/settings.py).
BUILD_CHANNELS = ("Stable", "Beta", "Nightly")

# ── Что входит в "сборку" для sha256_hash ───────────────────────────
# Осознанно НЕ входят: tests/ (не разворачивается на боевом хосте
# через OTA), *.md (документация, не код), database/logs/settings/plugins
# (рантайм- и пользовательские данные, а не код ядра — иначе хэш никогда
# бы не был стабилен), сам manifest_core.json (самоссылочно — файл не
# может валидно содержать хэш самого себя).
HASHED_SINGLE_FILES: tuple[Path, ...] = (
    Path("main.py"),
    Path("framework_manager.py"),
    Path("plugins/base.py"),
)
HASHED_DIRS: tuple[Path, ...] = (
    Path("core"),
)


class ManifestError(Exception):
    """manifest_core.json отсутствует, не читается или не является валидным JSON-объектом."""


def load_manifest(path: Path = MANIFEST_PATH) -> dict[str, Any]:
    """
    Читает и разбирает manifest_core.json. Ничего не подставляет и не
    валидирует поля по отдельности — это дело display()/вызывающего
    кода. Бросает ManifestError с понятным сообщением, если файла нет,
    JSON битый, либо корень JSON — не объект (например, список).
    """
    if not path.exists():
        raise ManifestError(
            f"«{path}» не найден. Это основной манифест сборки — без него "
            f"фреймворк не может определить свою версию и требования. "
            f"См. MANIFEST.md."
        )
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ManifestError(f"«{path}» содержит невалидный JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ManifestError(
            f"«{path}» должен быть JSON-объектом ({{...}}), получено: {type(data).__name__}."
        )
    return data


def display(manifest: dict[str, Any], key: str, default: str = UNKNOWN) -> str:
    """
    Человекочитаемое значение поля манифеста для экранов "Информация
    и состояние" и т.п. Пустая строка/пустой список/отсутствие ключа —
    всё одинаково подставляет `default` ("неизвестно"), а не пустую
    строку — молчаливая пустота на экране статуса выглядит как баг
    отображения, а не как "разработчик пока не заполнил это поле".
    Список (напр. authors) склеивается через запятую.
    """
    value = manifest.get(key)
    if value is None:
        return default
    if isinstance(value, (list, tuple)):
        items = [str(v).strip() for v in value if str(v).strip()]
        return ", ".join(items) if items else default
    text = str(value).strip()
    return text if text else default


def requirements_list(manifest: dict[str, Any]) -> list[str]:
    """manifest["requirements"] как список строк PEP 440 — пустой список, если поля нет."""
    raw = manifest.get("requirements", [])
    if not isinstance(raw, list):
        return []
    return [str(r).strip() for r in raw if str(r).strip()]


def pip_install_command(manifest: dict[str, Any]) -> list[str]:
    """
    Готовая команда для subprocess: python -m pip install --break-system-packages <req...>.
    --break-system-packages нужен на управляемых Python-окружениях
    (Debian/Termux и т.п.) — см. то же самое в CONFIG.md про asyncpg.
    """
    import sys
    return [sys.executable, "-m", "pip", "install", "--break-system-packages", *requirements_list(manifest)]


# ═══════════════════════════════════════════════════════════════
# sha256_hash — целостность сборки
# ═══════════════════════════════════════════════════════════════

def iter_build_files(project_root: Optional[Path] = None) -> list[Path]:
    """
    Отсортированный (детерминированный) список файлов, входящих в
    "сборку" для sha256_hash — см. HASHED_SINGLE_FILES/HASHED_DIRS
    выше за тем, что именно и почему. Отсутствующие пути молча
    пропускаются (не считается ошибкой здесь — verify_build_integrity()
    всё равно даст расхождение хэша, если чего-то не хватает; здесь не
    место решать, фатально это или нет).
    """
    root = project_root or Path(".")
    files: list[Path] = []
    for rel in HASHED_SINGLE_FILES:
        p = root / rel
        if p.is_file():
            files.append(p)
    for rel in HASHED_DIRS:
        d = root / rel
        if not d.is_dir():
            continue
        for p in d.rglob("*.py"):
            if "__pycache__" in p.parts:
                continue
            files.append(p)
    return sorted(files, key=lambda p: p.relative_to(root).as_posix())


def compute_source_hash(project_root: Optional[Path] = None) -> str:
    """
    sha256 по (относительный_путь + содержимое) каждого файла из
    iter_build_files(), в детерминированном порядке. Путь участвует в
    хэше наравне с содержимым — переименование файла с тем же
    содержимым (или их перестановка) тоже должно менять хэш, а не
    оставаться незамеченным. \\0 — разделитель полей/записей, чтобы
    склейка "a"+"bc" не совпадала с "ab"+"c" на границе файлов.
    """
    root = project_root or Path(".")
    h = hashlib.sha256()
    for p in iter_build_files(root):
        rel = p.relative_to(root).as_posix()
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(p.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


@dataclass
class BuildIntegrityResult:
    ok: bool
    declared: str = ""
    computed: str = ""
    reason: str = ""
    files_hashed: int = 0


def verify_build_integrity(
    manifest: dict[str, Any], project_root: Optional[Path] = None
) -> BuildIntegrityResult:
    """
    Сверяет manifest["sha256_hash"] с реально вычисленным хэшем
    текущих файлов сборки (см. iter_build_files). Пустой/отсутствующий
    sha256_hash считается ошибкой намеренно (ТЗ: "без валидного хеша
    обновление и использование сборки будет недоступно вообще никак") —
    это НЕ то же самое, что "хэш не проверяется, если его нет".
    """
    root = project_root or Path(".")
    declared = str(manifest.get("sha256_hash", "") or "").strip().lower()
    files = iter_build_files(root)
    computed = compute_source_hash(root)

    if not declared:
        return BuildIntegrityResult(
            ok=False, declared="", computed=computed, files_hashed=len(files),
            reason=(
                "manifest_core.json → sha256_hash не задан (пусто). Выполните "
                "«python framework_manager.py hash --generate», чтобы сгенерировать "
                "и записать хэш текущей сборки."
            ),
        )
    if declared != computed.lower():
        return BuildIntegrityResult(
            ok=False, declared=declared, computed=computed, files_hashed=len(files),
            reason=(
                f"хэш сборки не совпадает: в манифесте {declared}, фактически "
                f"{computed}. Либо код менялся без пересчёта хэша (выполните "
                f"«python framework_manager.py hash --generate»), либо файлы были "
                f"повреждены/подменены."
            ),
        )
    return BuildIntegrityResult(ok=True, declared=declared, computed=computed, files_hashed=len(files))
