# AccountManager Framework

Модульный кроссплатформеный Telegram фреймворк на [aiogram 3.x](https://docs.aiogram.dev/) с системой плагинов, расширения систем через hooks / patches / services. Поддержка SQLite и Postgres, OTA A/B-обновления с автоматическим откатом и встроенным удобным менеджером фреймворка (CLI + TUI).

- **Версия ядра:** `1.0.0` Beta (`core.__version__`)
- **Автор:** [@Zhenya3415](https://github.com/Zhenya3415)
- **Репозиторий:** https://github.com/Zhenya3415/AccountManager (пока пусто)
- **Минимальная версия Python:** 3.10

---

## Содержание

- [Возможности](#возможности)
- [Требования](#требования)
- [Быстрый старт](#быстрый-старт)
- [Структура проекта](#структура-проекта)
- [Конфигурация](#конфигурация)
  - [configs/.env](#configsenv)
  - [configs/config.json](#configsconfigjson)
  - [configs/settings.json](#configssettingsjson)
- [manifest_core.json](#manifest_corejson)
- [Режимы работы: polling / webhook](#режимы-работы-polling--webhook)
- [База данных: SQLite / Postgres](#база-данных-sqlite--postgres)
- [Менеджер фреймворка](#менеджер-фреймворка)
- [OTA A/B-обновления](#ota-ab-обновления)
- [Sandbox и безопасность плагинов](#sandbox-и-безопасность-плагинов)
- [Целостность сборки](#целостность-сборки)
- [Локализация](#локализация)
- [Логирование](#логирование)
- [Тесты](#тесты)
- [API разработчика плагинов](#api-разработчика-плагинов)
  - [1. Структура плагина](#1-структура-плагина)
  - [2. manifest.json](#2-manifestjson)
  - [3. BasePlugin](#3-baseplugin)
  - [4. PluginContext](#4-plugincontext)
  - [5. BaseDatabase](#5-basedatabase)
  - [6. Scheduler](#6-scheduler)
  - [7. HookBus](#7-hookbus)
  - [8. PatchManager](#8-patchmanager)
  - [9. ServiceRegistry](#9-serviceregistry)
  - [10. Зависимости и порядок загрузки](#10-зависимости-и-порядок-загрузки)
  - [11. Утилиты](#11-утилиты)
  - [12. Минимальный рабочий плагин](#12-минимальный-рабочий-плагин)

---

## Возможности

- **Плагины с полной изоляцией.** У каждого плагина своя БД (отдельный SQLite-файл или отдельная схема Postgres), свой пул соединений, свои миграции, своя область видимости — плагины физически не могут задеть чужие таблицы.
- **Шины расширения для плагинов:** `hooks` (события/фильтры), `patches` (before/after/around/replace над произвольными методами), `services` (реестр общих сервисов), `scheduler` (interval/cron/once-задачи, переживающие рестарт процесса).
- **SQLite и Postgres «из коробки»** — один и тот же интерфейс `BaseDatabase` для плагина независимо от бэкенда; переключение — одна строка в `config.json`.
- **Polling и webhook** — переключаются правкой `mode` в `config.json`, без изменений в коде плагинов.
- **OTA A/B-обновления** — скачивание, проверка Ed25519-подписи и sha256-хеша, тестовый запуск в отдельном слоте (`slots/b`) с тестовым токеном бота, автоматический откат при крашах, промоут по расписанию или по подтверждению.
- **Sandbox** — блокировка опасных системных вызовов (`subprocess`, `os.system`), таймаут хендлера плагина, верификация Ed25519-подписей плагинов.
- **Проверка целостности сборки** — `manifest_core.json → sha256_hash` считается по всем core-файлам; бот отказывается стартовать при несовпадении.
- **Менеджер фреймворка** — CLI и curses-TUI для установки/обновления/удаления плагинов, управления OTA, пересчёта хеша, диагностики зависимостей и прогона тестов.
- **944 unit-теста** на ядро, проходят и через `pytest`, и через голый `unittest`.
- **Локализация интерфейса менеджера** — русский и английский, легко расширяется.
- **Асинхронное логирование без блокировки event loop'а** — очередь + фоновый поток, ротация файлов, rate-limit на повторяющиеся сообщения.

---

## Требования

- Python **3.10+**
- Зависимости из `manifest_core.json → requirements`:
  - `aiogram>=3.15,<4.0`
  - `aiosqlite>=0.19`
  - `python-dotenv>=1.0`
  - `packaging>=23.0`
  - `cryptography>=42.0` (OTA-подписи и верификация плагинов)
  - `pytest>=7.4`
- Опционально, только для `database.backend = "postgres"`: `asyncpg`

---

## Быстрый старт

```bash
# 1. Клонировать репозиторий
git clone https://github.com/Zhenya3415/AccountManager.git
cd AccountManager

# 2. Настроить токен бота
cp configs/.env.example configs/.env
# впишите BOT_TOKEN=<токен от @BotFather> в configs/.env

# 3. (опционально) настроить конфигурацию
cp configs/config.json.example configs/config.json

# 4. Установить зависимости
python framework_manager.py deps --install

# 5. Запустить бота
python main.py
```

Проверить готовность и статус плагинов:

```bash
python framework_manager.py status
python framework_manager.py info
```

---

## Структура проекта

```
AccountManager/
├── main.py                    # точка входа
├── framework_manager.py       # CLI/TUI менеджера
├── manifest_core.json         # единственный источник правды о сборке
├── core/
│   ├── bootstrap.py           # проверка целостности файлов перед стартом
│   ├── config.py              # чтение .env + config.json → Config
│   ├── settings.py            # settings.json → ManagerSettings
│   ├── manifest.py            # manifest_core.json, sha256_hash
│   ├── logger.py              # асинхронный логгер
│   ├── database.py            # БД ядра
│   ├── db/                    # бэкенды: sqlite, postgres, factory, migrations
│   ├── hooks.py               # HookBus
│   ├── patches.py             # PatchManager
│   ├── services.py            # ServiceRegistry
│   ├── scheduler.py           # Scheduler
│   ├── plugin_loader.py       # сканирование, зависимости, hot reload
│   ├── plugin_context.py      # PluginContext → setup(ctx)
│   ├── plugin_installer.py    # установка/обновление/удаление
│   ├── plugin_verifier.py     # Ed25519-верификация плагинов
│   ├── sandbox.py             # мягкая изоляция плагинов
│   ├── middleware.py          # UserUpsertMiddleware
│   ├── control_server.py      # TCP-сервер для restart без перезапуска
│   ├── lockfile.py            # защита от повторного старта
│   ├── localization.py        # t(section, key, lang)
│   ├── tui.py                 # curses-интерфейс менеджера
│   ├── update_staging.py      # отложенные обновления плагинов
│   └── ota/                   # checker, downloader, verifier, slot_manager,
│                               # test_runner, notifier, process_manager
├── plugins/
│   └── base.py                # BasePlugin
├── configs/
│   ├── .env / .env.example
│   ├── config.json / config.json.example
│   ├── settings.json
│   └── keys/                  # Ed25519-ключи (private.pem — gitignored)
├── messages/
│   ├── help.txt
│   └── lang/                  # rus.ini, eng.ini
├── scripts/
│   ├── generate_keys.py       # генерация Ed25519-ключей
│   ├── sign_plugin.py         # подпись плагина
│   ├── sign_release.py        # подпись OTA-релиза
│   └── build_release.py       # сборка полного OTA-релиза
├── slots/                     # A/B слоты OTA
├── tests/                     # 944 unit-теста
│   └── README.md
└── utils/                     # formatter.py, placeholder.py
```

---

## Конфигурация

Три источника настроек:

| Файл | Отвечает за | Обязателен |
|---|---|---|
| `configs/.env` | Секреты: `BOT_TOKEN`, `BOT_TOKEN_TEST`, `ADMIN_CHAT_ID` | `BOT_TOKEN` — да |
| `configs/config.json` | Настройки **бота**: режим, БД, OTA, sandbox, log_level | нет |
| `configs/settings.json` | Настройки **менеджера** (не бота): язык, канал обновлений, логгер | нет |

> `config.json → log_level` — уровень логов **бота**. `settings.json → logger_level` — уровень логов **менеджера фреймворка**. Это два независимых значения.

### configs/.env

```dotenv
BOT_TOKEN=<токен от @BotFather>    # обязательно
BOT_TOKEN_TEST=                     # для OTA-тестирования в слоте B и Telegram-уведомлений
ADMIN_CHAT_ID=                      # chat_id для Telegram-уведомлений OTA
```

`DATABASE_URL` и подобное намеренно НЕ вынесено в `.env` — все настройки БД в `config.json`, `.env` — только секреты.

### configs/config.json

Все ключи необязательны. Одна опечатка в поле откатывает только это поле к дефолту.

```json
{
  "log_level": "DEBUG",
  "mode": "polling",
  "disabled_plugins": [],
  "webhook": { ... },
  "database": { ... },
  "ota": { ... },
  "process": { ... },
  "sandbox": { ... }
}
```

### configs/settings.json

```json
{
  "language": "rus",
  "allow_nightly_beta": false,
  "build_channel": "Stable",
  "confirm_actions": true,
  "logger_level": "Info",
  "dev_mode": false,
  "disable_signature_and_hash_check": false
}
```

Редактируется через TUI → «Глобальные настройки» → «Настройки и безопасность».

---

## manifest_core.json

Единственный источник правды о сборке. **Никогда не удаляйте** — `core/bootstrap.py` отказывается запускать бота без него.

```json
{
  "name":              "AccountManager Framework",
  "version":           "1.0.0",
  "build_channel":     "Stable",
  "authors":           ["Zhenya3415"],
  "min_python":        "3.10",
  "requirements":      ["aiogram>=3.15,<4.0", "aiosqlite>=0.19", "..."],
  "repository_url":    "https://github.com/Zhenya3415/AccountManager",
  "ota_repository":    "https://github.com/Zhenya-3415/AccountManager-OTA",
  "plugin_repository": "https://github.com/Zhenya-3415/AccountManager-Plugin-Repository",
  "sha256_hash":       ""
}
```

| Поле | Описание |
|---|---|
| `version` | SemVer: `MAJOR.MINOR.PATCH` — читается как `core.__version__` |
| `build_channel` | `Stable` / `Beta` / `Nightly` |
| `requirements` | Заменяет `requirements.txt` — PEP 440 спецификаторы |
| `sha256_hash` | SHA-256 текущей сборки — **обязателен для запуска бота** |

После любой правки `core/**/*.py`, `main.py`, `framework_manager.py` или `plugins/base.py`:

```bash
python framework_manager.py hash --generate
```

---

## Режимы работы: polling / webhook

```json
{ "mode": "polling" }
```

```json
{
  "mode": "webhook",
  "webhook": {
    "url": "https://bot.example.com",
    "path": "",
    "host": "0.0.0.0",
    "port": 8080,
    "secret_token": "",
    "drop_pending_updates": false
  }
}
```

| Поле | По умолчанию | Смысл |
|---|---|---|
| `webhook.url` | — (обязателен при `mode="webhook"`) | Публичный HTTPS-URL — обычно домен за reverse-proxy с валидным сертификатом |
| `webhook.path` | `/webhook/<BOT_TOKEN>` | Путь куда Telegram шлёт POST. Токен в пути — простая защита |
| `webhook.host` / `webhook.port` | `0.0.0.0` / `8080` | На чём слушает встроенный aiohttp-сервер, НЕ то же что `webhook.url` |
| `webhook.secret_token` | `""` | Telegram присылает в `X-Telegram-Bot-Api-Secret-Token`, aiogram проверяет сам |
| `webhook.drop_pending_updates` | `false` | Сбросить накопившиеся апдейты при выставлении вебхука |

При переходе с webhook на polling снимите вебхук вручную один раз:

```bash
curl https://api.telegram.org/bot<TOKEN>/deleteWebhook
```

---

## База данных: SQLite / Postgres

```json
{
  "database": {
    "backend": "sqlite",
    "sqlite_core_reader_pool_size": 4,
    "postgres": {
      "dsn": "postgresql://user:password@localhost:5432/accountmanager",
      "pool_min_size": 1,
      "pool_max_size": 5
    }
  }
}
```

| Поле | По умолчанию | Смысл |
|---|---|---|
| `database.backend` | `"sqlite"` | `"sqlite"` или `"postgres"`. Один бэкенд на весь процесс |
| `database.sqlite_core_reader_pool_size` | `4` | Пул read-only соединений БД ядра (SQLite) |
| `database.postgres.dsn` | — | `postgresql://user:pass@host:port/db` |
| `database.postgres.pool_min_size` / `pool_max_size` | `1` / `5` | Пул `asyncpg` на каждый неймспейс |

Для `backend="postgres"` требуется:

```bash
pip install asyncpg --break-system-packages
```

**Изоляция плагинов:**
- SQLite: каждый плагин → `plugins/<name>/database/database.db`
- Postgres: каждый плагин → отдельная схема в общей БД (`search_path` изолирует)

**Миграции для обоих бэкендов:** между бэкендами нет автоматического перевода SQL. Положите Postgres-версии в отдельную подпапку:

```
plugins/<name>/migrations/            # SQLite
plugins/<name>/migrations/postgres/   # Postgres (если отличается)
```

Планировщик (`ctx.schedule_*`) хранит персистентное состояние в той же БД что настраивается выше.

---

## Менеджер фреймворка

Отдельный CLI/TUI-инструмент, не входит в процесс бота:

```bash
python framework_manager.py --tui              # curses TUI (с текстовым fallback)
python framework_manager.py status             # статус плагинов
python framework_manager.py info               # информация о сборке
python framework_manager.py hash --generate    # пересчитать sha256_hash
python framework_manager.py hash --verify      # проверить sha256_hash
python framework_manager.py test               # прогнать tests/
python framework_manager.py deps --install     # установить requirements
python framework_manager.py deps --list        # показать requirements
python framework_manager.py install --yes <src>
python framework_manager.py uninstall --yes <name>
python framework_manager.py update --yes [<name>]
python framework_manager.py lock --yes
python framework_manager.py unlock --yes
python framework_manager.py verify
python framework_manager.py ota check          # проверить обновления
python framework_manager.py ota download       # скачать обновление
python framework_manager.py ota apply          # тест в слоте B → промоут
python framework_manager.py ota status         # состояние OTA
python framework_manager.py ota rollback       # принудительный откат
python framework_manager.py ota promote        # принудительный промоут
python framework_manager.py ota init-slots     # инициализация slots/
python framework_manager.py --help
```

---

## OTA A/B-обновления

Новая версия скачивается и тестируется в слоте B, пока боевой слот A продолжает работать.

### Структура слотов

```
slots/
  a/   ← активный (боевая версия)  configs/.env → BOT_TOKEN
  b/   ← тестовый (новая версия)   configs/.env → BOT_TOKEN_TEST
  ota_state.json
```

### Машина состояний

```
idle → downloading → verifying → testing → ready_to_promote
                                     ↓ (краши ≥ max_crashes)
                                 rolled_back

ready_to_promote → promoting       (подтверждено)
                 → pending_promote (нет/таймаут)
                        ↓ (следующий shutdown main.py)
                   promoting_on_shutdown → idle
```

### Workflow

```bash
python framework_manager.py ota init-slots   # первый раз
cp configs/.env slots/a/configs/.env         # скопировать токен

python framework_manager.py ota check        # проверить наличие
python framework_manager.py ota download     # скачать + верифицировать
python framework_manager.py ota apply        # тест B → спросить → промоут
```

### Настройки (config.json → ota)

| Поле | По умолчанию | Описание |
|---|---|---|
| `max_crashes` | `3` | Крашей слота B до отката |
| `test_duration_s` | `300` | Секунд стабильной работы слота B для промоута |
| `interrupt_allowed` | `true` | Спрашивать «применить сейчас?» в CLI + Telegram |
| `interrupt_timeout_s` | `60` | Таймаут вопроса → автовыбор «нет» |
| `poll_interval_s` | `5` | Интервал проверки живости слота B |
| `startup_grace_s` | `10` | Ожидание после старта слота B до начала мониторинга |
| `auto_check_on_startup` | `false` | Проверять обновления при каждом старте |
| `notify_on_rollback` | `"log"` | `"log"` или `"telegram"` |
| `download_chunk_kb` | `64` | Буфер скачивания framework.zip в КиБ |

### Создание релиза (разработчик)

```bash
# Сгенерировать ключи (один раз)
python scripts/generate_keys.py
# configs/keys/public.pem  ← коммитить в репо
# configs/keys/private.pem ← GITIGNORED

# Собрать и подписать релиз
python scripts/build_release.py --channel stable --description "Fix: ..."
```

Структура OTA-репозитория (ветки = каналы):

```
stable/releases.json
stable/releases/1.0.1/framework.zip
stable/releases/1.0.1/framework.zip.sig
```

### Настройки (config.json → process)

```json
"process": {
  "manager": "auto",
  "unit_name": "accountmanager",
  "supervisor_name": "accountmanager"
}
```

`"auto"` — детект среды: Termux→plain, systemd→systemctl, иначе plain.

---

## Sandbox и безопасность плагинов

### Мягкая изоляция (sandbox)

Две защиты без переписывания plugin API:

**1. Блокировка системных вызовов** (`block_system_calls: true`):
- `sys.addaudithook` блокирует `subprocess.Popen`, `os.system`, `os.popen`, семейство `os.execv*`/`os.spawn*`
- `importlib` meta finder блокирует импорт `ctypes`, `pty`, `pexpect`

**2. Таймаут хендлера** (`handler_timeout_s: 30.0`):
- `asyncio.wait_for` отменяет завязший хендлер, бот продолжает работать

```json
"sandbox": {
  "enabled": true,
  "handler_timeout_s": 30.0,
  "block_system_calls": true,
  "extra_blocked_modules": [],
  "verify_plugin_signatures": false,
  "allow_unsigned_plugins": false
}
```

Переключение через TUI → «Глобальные настройки» → «Безопасность и Sandbox».

### Верификация подписей плагинов

Каждый плагин может быть подписан тем же Ed25519 ключом, что и OTA-релизы.

```json
"sandbox": {
  "verify_plugin_signatures": true,
  "allow_unsigned_plugins": false
}
```

**Подписать плагин** (разработчик):

```bash
python scripts/sign_plugin.py plugins/antispam/   # один плагин
python scripts/sign_plugin.py plugins/ --all       # все плагины
```

Создаёт `manifest.json.sig` и записывает `sha256_hash` в `manifest.json`.

**Как работает верификация:**
1. sha256 всех `.py` + `manifest.json` (без поля `sha256_hash`) пересчитывается заново
2. Сравнивается с `manifest.json → sha256_hash` → не совпадает = файлы подменены
3. `manifest.json.sig` проверяется как Ed25519-подпись хеша → не совпадает = хеш подменён

| `allow_unsigned_plugins` | Поведение |
|---|---|
| `false` (дефолт) | Плагин без подписи — блокируется |
| `true` | Плагин без `.sig` — WARNING, грузится; с неверной подписью — блокируется |

---

## Целостность сборки

`manifest_core.json → sha256_hash` покрывает `core/**/*.py`, `main.py`, `framework_manager.py`, `plugins/base.py`. Без валидного хеша бот не стартует.

```bash
python framework_manager.py hash --generate   # пересчитать и записать
python framework_manager.py hash --verify     # только проверить
```

Отключить проверку для разработки (не для продакшена):

```json
// configs/settings.json
"disable_signature_and_hash_check": true
```

---

## Локализация

Интерфейс менеджера — русский (`messages/lang/rus.ini`) и английский (`messages/lang/eng.ini`).

Активный язык: `configs/settings.json → language` (`"rus"` / `"eng"`).
Изменить: TUI → «Глобальные настройки» → «Настройки и безопасность».

```python
from core.localization import t
print(t("main_menu", "title"))               # рус
print(t("main_menu", "title", lang="eng"))   # eng
```

---

## Логирование

Асинхронный логгер: `logger.info(...)` кладёт запись в очередь (O(1), без блокировки event loop), запись в файл и консоль — в отдельном потоке.

- Уровень логов **бота**: `configs/config.json → log_level` (`DEBUG`/`INFO`/`WARNING`/`ERROR`/`CRITICAL`, по умолчанию `DEBUG`)
- Уровень логов **менеджера**: `configs/settings.json → logger_level` (`Disabled`/`Debug`/`Info`/`Warning`/`Error`/`Critical`)

---

## Тесты

944 unit-теста на весь `core/`. Работают через `pytest` и голый `unittest`. Без установленных `aiogram`/`aiosqlite` автоматически подставляются лёгкие фейки из `tests/_support/fakes/`.

```bash
python framework_manager.py deps --install
python framework_manager.py test
# или напрямую:
pytest tests/ -v
python -m unittest discover -s tests -v
```

Полный прогон ~4 секунды. Подробности — [tests/README.md](tests/README.md).

---

## API разработчика плагинов

Ядро: `core.__version__ = "1.0.0"`. Референс по фактическому коду `core/plugin_loader.py`, `core/plugin_context.py`, `plugins/base.py`, `core/hooks.py`, `core/patches.py`, `core/services.py`, `core/database.py`.

### 1. Структура плагина

```
plugins/<plugin_dir>/
├── manifest.json          # обязателен
├── plugin.py              # обязателен — класс(ы) BasePlugin
├── __init__.py            # обязателен (пустой)
└── migrations/
    ├── 0001_initial.sql
    └── postgres/          # Postgres-версии миграций (опционально)
```

Идентичность плагина — `manifest.json → "name"`, **не** имя папки. Если две папки объявят одинаковый `name` — обе пропускаются с ошибкой.

### 2. manifest.json

```json
{
  "name": "antispam",
  "version": "1.0.0",
  "author": "@Zhenya3415",
  "description": "необязательное описание",
  "repository_url": "",
  "enabled": true,
  "load_order": "after_bot",
  "core_version": ">=1.0.0,<2.0.0",
  "dependencies": {
    "plugins": ["some_other_plugin>=1.0.0"],
    "pip": ["aiogram>=3.15,<4.0"]
  },
  "sha256_hash": ""
}
```

| Поле | Обязательно | Умолч. | Смысл |
|---|---|---|---|
| `name` | нет | имя папки | Идентичность плагина |
| `version` | нет | `"0.0.0"` | Для зависимостей других плагинов |
| `enabled` | нет | `true` | `false` — плагин отключён автором |
| `load_order` | нет | `"after_bot"` | `"before_bot"` \| `"after_bot"` \| `"after:<name>"` |
| `core_version` | нет | не проверяется | PEP 440-условие на `core.__version__` |
| `dependencies.plugins` | нет | `[]` | `"имя"` или `"имя>=X.Y.Z"` |
| `dependencies.pip` | нет | `[]` | pip-пакеты с версионными условиями |
| `sha256_hash` | нет | `""` | Заполняется `scripts/sign_plugin.py` |

Пользователь может дополнительно отключить плагин через `config.json → disabled_plugins: ["имя"]`.

### 3. BasePlugin

```python
from abc import ABC, abstractmethod
from core.plugin_context import PluginContext

class BasePlugin(ABC):

    @property
    @abstractmethod
    def name(self) -> str: ...          # должно совпадать с manifest.json → name

    @property
    @abstractmethod
    def version(self) -> str: ...       # должно совпадать с manifest.json → version

    @abstractmethod
    async def setup(self, ctx: PluginContext) -> None: ...   # точка входа, обязателен

    async def teardown(self) -> None: ...   # опционален
    # Освобождайте только СВОИ ресурсы — hooks/patches/services/scheduler
    # PluginLoader снимает автоматически.
```

Если в `plugin.py` несколько подклассов `BasePlugin`, укажите явно:

```python
PLUGIN = MyActualPluginClass
```

### 4. PluginContext

```python
@dataclass(slots=True)
class PluginContext:
    dp:          Dispatcher
    bot:         Bot
    db:          BaseDatabase    # СВОЯ БД плагина
    core_db:     BaseDatabase    # БД ядра (таблица users и т.п.)
    config:      Config
    hooks:       HookBus
    patches:     PatchManager
    services:    ServiceRegistry
    scheduler:   Scheduler
    plugin_name: str
    plugin_dir:  Path
    logger:      Logger
```

Обёртки (подставляют `plugin=self.plugin_name` автоматически):

```python
# Hooks
ctx.on_hook(event, handler, *, priority=100) -> HookHandle
await ctx.emit(event, *args, **kwargs) -> list[Any]
await ctx.emit_filter(event, value, *args, **kwargs) -> Any

# Patches
ctx.patch_around(target, attr, wrapper) -> PatchHandle
ctx.patch_before(target, attr, hook) -> PatchHandle
ctx.patch_after(target, attr, hook) -> PatchHandle
ctx.patch_replace(target, attr, value, *, create_if_missing=False) -> PatchHandle

# Services
ctx.provide_service(name, value) -> None
ctx.get_service(name) -> Any | None
ctx.require_service(name) -> Any       # бросает ServiceNotFoundError если нет

# Scheduler
ctx.schedule_interval(job_id, seconds, callback, *, jitter=0.0,
                       misfire_policy="run_once", max_concurrent=1, persist=True)
ctx.schedule_cron(job_id, expr, callback, *, misfire_policy="skip",
                   max_concurrent=1, persist=True)
ctx.schedule_once(job_id, when, callback)   # when: секунды или datetime
ctx.cancel_job(handle) -> bool
```

`ctx.db` — физически изолирована от других плагинов. `ctx.core_db` — общая таблица `users`. Пишите в `core_db` только когда реально нужно.

### 5. BaseDatabase

```python
await db.execute(sql, params=()) -> Any
await db.execute_returning(sql, params=()) -> Optional[Any]
await db.fetchone(sql, params=()) -> Optional[Any]
await db.fetchall(sql, params=()) -> list[Any]
```

Один и тот же интерфейс на SQLite и Postgres. Плейсхолдеры `?` / `:name` работают на обоих (в Postgres переводятся в `$1..$n` автоматически).

**Миграции:** `migrations/NNNN_описание.sql`, применяются по возрастанию номера, каждая один раз. `$$...$$` dollar-quoting и `BEGIN...END` в триггерах разбираются корректно. Дублирующиеся номера — фатальная ошибка.

### 6. Scheduler

```python
# Каждые 6 часов, переживает рестарт (persist=True по умолчанию)
ctx.schedule_interval("check_expired", 6 * 3600, self._check_expired)

# Cron: каждый день в 09:00
ctx.schedule_cron("daily_report", "0 9 * * *", self._send_report)

# Один раз через 30 секунд
ctx.schedule_once("welcome_followup", 30, self._followup)
```

| Параметр | Описание |
|---|---|
| `misfire_policy` | `"run_once"` (дефолт interval) или `"skip"` (дефолт cron) — что делать при пропущенных запусках |
| `max_concurrent` | `1` по умолчанию — пропускает тик если предыдущий ещё выполняется |
| `persist` | Хранить время последнего запуска в `core_db` (переживает рестарт) |

Исключение в задаче логируется и **никогда** не роняет бота. Задачи снимаются автоматически при `teardown()/reload_plugin()`.

### 7. HookBus

```python
handle = hooks.on(event, handler, *, plugin, priority=100) -> HookHandle
hooks.off(handle) -> bool
hooks.remove_all_for(plugin) -> int

results = await hooks.emit(event, *args, **kwargs) -> list[Any]
value   = await hooks.emit_filter(event, value, *args, **kwargs) -> Any
```

- `emit` — уведомление: все обработчики независимо
- `emit_filter` — конвейер: `value` проходит последовательно, каждый может вернуть новое значение (`None` = «не менять»)
- `priority`: меньше число — раньше вызов
- `handler` может быть sync или async
- `"*"` (`HookBus.WILDCARD`) — подписка на все события: `handler(event_name, *args, **kwargs)`

**Встроенные события ядра:**

| Событие | Когда | Аргументы |
|---|---|---|
| `core.user.upserted` | после апдейта записи пользователя | `user: aiogram.types.User` |
| `core.plugins.ready` | после загрузки всех плагинов | `loaded: list[str], skipped: list[str]` |
| `core.plugin.before_load` | перед `setup()` | `name: str, record: PluginRecord` |
| `core.plugin.after_load` | после `setup()` | `name, record, instance: BasePlugin` |
| `core.plugin.load_failed` | `setup()` бросил исключение | `name: str, error: Exception` |
| `core.plugin.before_teardown` | перед `teardown()` | `name: str` |
| `core.plugin.after_teardown` | после `teardown()` | `name: str` |

### 8. PatchManager

```python
ctx.patch_around(target, attr, wrapper)
# wrapper(original, *args, **kwargs) — полный контроль.
# Для async-цели wrapper обязан быть async def и сам await original(...).

ctx.patch_before(target, attr, hook)
# hook(*args, **kwargs) до original. Не может отменить вызов.
# Исключение в hook проглатывается — original выполняется всегда.

ctx.patch_after(target, attr, hook)
# hook(result, *args, **kwargs) после original.
# Не-None → заменяет результат.

ctx.patch_replace(target, attr, value, create_if_missing=False)
# Полная замена атрибута.
```

Патчи на один `(target, attr)` складываются в цепочку. Патчите **класс** (`target=SQLiteDatabase`) — wrapper получает `self`. Патчите **экземпляр** (`target=db`) — `self` уже связан.

**Ограничение:** `from module import func` копирует ссылку — изменение через PatchManager не затронет код, который уже импортировал функцию напрямую.

Снимаются автоматически при teardown/reload.

### 9. ServiceRegistry

```python
ctx.provide_service("antispam.is_blacklisted", is_blacklisted_fn)

# в другом плагине (объявите зависимость в manifest.json → dependencies.plugins):
is_blacklisted = ctx.require_service("antispam.is_blacklisted")
# бросает ServiceNotFoundError с перечнем зарегистрированных сервисов

value_or_none = ctx.get_service("antispam.is_blacklisted")
```

Снимаются автоматически при teardown/reload владеющего плагина.

### 10. Зависимости и порядок загрузки

Пайплайн: `scan()` → `check_core_compat()` → `check_pip_deps()` → `resolve_order()` → `load_plugins()`.

- `load_order: "before_bot"` — до основного набора, `"after_bot"` — после, `"after:<name>"` — сразу после конкретного
- Топосортировка по `dependencies.plugins` (алгоритм Кана, детерминированный). Цикл — все участники пропускаются
- Недоступная зависимость → плагин пропускается каскадно
- `core_version` проверяется первым
- Конфликты версий pip-пакетов логируются сводкой

### 11. Утилиты

```python
from utils.placeholder import resolve
resolve("Привет, {name}!", message.from_user)
# {user_name} full_name, {username} "@ник" или "", {name} first_name, {user_id}

from utils.formatter import (
    escape_mdv2,      # экранирование для parse_mode=MarkdownV2
    format_datetime,  # datetime → "ДД.ММ.ГГГГ ЧЧ:ММ"
    truncate,         # обрезка до лимита Telegram (4096) с «…»
    format_list,      # список строк с маркером "•"
    format_header,    # заголовок, обрамлённый "═"
    format_separator, # горизонтальный разделитель
)
```

### 12. Минимальный рабочий плагин

`plugins/example/manifest.json`:

```json
{
  "name": "example",
  "version": "1.0.0",
  "author": "@Zhenya3415",
  "enabled": true,
  "load_order": "after_bot",
  "core_version": ">=1.0.0,<2.0.0",
  "dependencies": {"plugins": [], "pip": []}
}
```

`plugins/example/migrations/0001_initial.sql`:

```sql
CREATE TABLE IF NOT EXISTS example_counters (
    user_id    INTEGER PRIMARY KEY,
    count      INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
);
```

`plugins/example/plugin.py`:

```python
from __future__ import annotations
from datetime import datetime, timezone
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from core.plugin_context import PluginContext
from plugins.base import BasePlugin

PLUGIN_VERSION = "1.0.0"


async def _bump_counter(db, user_id: int) -> int:
    now_iso = datetime.now(timezone.utc).isoformat()
    row = await db.execute_returning(
        """
        INSERT INTO example_counters (user_id, count, updated_at)
        VALUES (:user_id, 1, :now)
        ON CONFLICT(user_id) DO UPDATE SET
            count = example_counters.count + 1,
            updated_at = excluded.updated_at
        RETURNING count
        """,
        {"user_id": user_id, "now": now_iso},
    )
    return row["count"]


class ExamplePlugin(BasePlugin):

    @property
    def name(self) -> str:
        return "example"

    @property
    def version(self) -> str:
        return PLUGIN_VERSION

    async def setup(self, ctx: PluginContext) -> None:
        router = Router(name=self.name)
        self._dp = ctx.dp
        self._router = router

        @router.message(Command("count"))
        async def cmd_count(message: Message) -> None:
            count = await _bump_counter(ctx.db, message.from_user.id)
            await message.answer(f"Счётчик: {count}")

        ctx.on_hook("core.user.upserted", self._on_user_upserted)
        ctx.dp.include_router(router)
        ctx.logger.info("example настроен.")

    async def _on_user_upserted(self, user) -> None:
        pass

    async def teardown(self) -> None:
        if getattr(self, "_dp", None) and getattr(self, "_router", None):
            if self._router in self._dp.sub_routers:
                self._dp.sub_routers.remove(self._router)
            self._router._parent_router = None
            self._router = None
            self._dp = None
```

Подписка `ctx.on_hook` снимается автоматически при teardown/reload — в `teardown()` явно снимать не нужно.
